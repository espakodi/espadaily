# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
"""Listas curadas de películas vía API de TMDB."""
import json
import os
import sys
import time
import urllib.parse

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings

_TMDB_BASE  = "https://api.themoviedb.org/3"
_IMG_W342   = "https://image.tmdb.org/t/p/w342"
_IMG_ORIG   = "https://image.tmdb.org/t/p/original"
_TTL        = 6 * 3600
_PAGE_SIZE  = 20  # TMDB devuelve 20 por página

_LISTS = [
    ("Top valoradas de todos los tiempos", "movie/top_rated",        "movie"),
    ("Populares ahora",                    "movie/popular",           "movie"),
    ("Tendencias hoy",                     "trending/movie/day",      "movie"),
    ("Tendencias esta semana",             "trending/movie/week",     "movie"),
    ("En cines ahora",                     "movie/now_playing",       "movie"),
    ("Próximos estrenos",                  "movie/upcoming",          "movie"),
    ("Mejores series TV",                  "tv/top_rated",            "show"),
    ("Series populares",                   "tv/popular",              "show"),
    ("Tendencias series esta semana",      "trending/tv/week",        "show"),
    ("Series en emisión",                  "tv/on_the_air",           "show"),
    ("Series que emiten hoy",              "tv/airing_today",         "show"),
]


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)

def _handle():
    return int(sys.argv[1])


def _api_key():
    return getattr(core_settings, '_ESPADAILY_TMDB_API_KEY', '') or ''


def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'espadaily_tmdb_lists_cache.json')


def _load_cache():
    try:
        p = _cache_path()
        if not os.path.exists(p):
            return {}
        with open(p, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_cache(data):
    try:
        p = _cache_path()
        os.makedirs(os.path.dirname(p), exist_ok=True)
        tmp = p + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, p)
    except OSError as e:
        xbmc.log("[EspaDaily-TL] cache save: {0}".format(e), xbmc.LOGWARNING)


def _tmdb_get(path, params=None):
    key = _api_key()
    if not key:
        return None
    full = dict(params or {}, api_key=key, language='es-ES')
    try:
        r = requests.get("{0}/{1}".format(_TMDB_BASE, path), params=full, timeout=10)
        xbmc.log("[EspaDaily-TL] {0} -> {1}".format(path, r.status_code), xbmc.LOGINFO)
        if r.status_code != 200:
            return None
        return r.json()
    except (requests.RequestException, ValueError) as e:
        xbmc.log("[EspaDaily-TL] error {0}: {1}".format(path, e), xbmc.LOGERROR)
        return None


def _fetch_page(endpoint, media_type, page=1):
    cache = _load_cache()
    cache_key = "{0}|{1}".format(endpoint, page)
    entry = cache.get(cache_key, {})
    if entry and (time.time() - entry.get('ts', 0)) < _TTL:
        return entry['items']

    data = _tmdb_get(endpoint, {'page': page})
    if not data:
        return []

    results = data.get('results') or []
    items = []
    for r in results:
        if media_type == 'show':
            title = r.get('name') or r.get('original_name', '')
            year  = (r.get('first_air_date') or '')[:4]
        else:
            title = r.get('title') or r.get('original_title', '')
            year  = (r.get('release_date') or '')[:4]
        if not title:
            continue
        poster_path = r.get('poster_path') or ''
        items.append({
            'tmdb_id':    str(r.get('id', '')),
            'title':      title,
            'year':       year,
            'plot':       r.get('overview', ''),
            'rating':     r.get('vote_average', 0),
            'poster':     "{0}{1}".format(_IMG_W342, poster_path) if poster_path else '',
            'fanart':     "{0}{1}".format(_IMG_ORIG, r.get('backdrop_path', '')) if r.get('backdrop_path') else '',
            'media_type': media_type,
        })

    total_pages = data.get('total_pages', 1)
    cache[cache_key] = {'ts': time.time(), 'items': items, 'total_pages': total_pages}
    _save_cache(cache)
    return items


def _get_total_pages(endpoint, page):
    cache = _load_cache()
    cache_key = "{0}|{1}".format(endpoint, page)
    entry = cache.get(cache_key, {})
    return entry.get('total_pages', 1)


def show_menu():
    h = _handle()
    if not _api_key():
        li = xbmcgui.ListItem(label="[COLOR red]Configura la API key de TMDB en los ajustes del addon[/COLOR]")
        li.setArt({'icon': 'DefaultIconError.png'})
        xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    for label, endpoint, media_type in _LISTS:
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultVideoPlaylists.png'})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='tmdb_lists_show', endpoint=endpoint, media_type=media_type, page=1),
            listitem=li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)


def show_list(endpoint, media_type, page=1):
    import metadata_enricher as me

    h = _handle()
    page = int(page)
    items = _fetch_page(endpoint, media_type, page)
    if not items:
        xbmcgui.Dialog().notification("EspaDaily", "No se pudo cargar la lista de TMDB", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(h)
        return

    af = core_settings.addon_fanart()

    for item in items:
        year_int = int(item['year']) if item.get('year', '').isdigit() else 0
        rating   = item.get('rating', 0)
        label    = "{0} ({1})".format(item['title'], year_int) if year_int else item['title']
        li = xbmcgui.ListItem(label=label)

        meta = me.enrich(
            tmdb_id=item['tmdb_id'],
            title=item['title'],
            year=year_int or None,
            media_type=media_type,
            use_cache_only=True,
        )
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or item['poster']
        else:
            art = {'icon': 'DefaultVideo.png'}
            if item['poster']:
                art.update({'thumb': item['poster'], 'poster': item['poster']})
            if item['fanart']:
                art['fanart'] = item['fanart']
            li.setArt(art)
            info = {
                'title':     item['title'],
                'plot':      item['plot'],
                'mediatype': 'tvshow' if media_type == 'show' else 'movie',
            }
            if year_int:
                info['year'] = year_int
            if rating:
                info['rating'] = rating
            li.setInfo('video', info)
            poster = item['poster']

        cm = [
            ("Buscar en otras fuentes", "Container.Update({0})".format(
                _u(action='search_alt_prompt', q=item['title'], ot=poster, mode=media_type))),
        ]
        li.addContextMenuItems(cm)
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=item['title'], ot=poster, mode=media_type)
        xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=False)

    total_pages = _get_total_pages(endpoint, page)
    if page < total_pages:
        li = xbmcgui.ListItem(label="[COLOR limegreen]Página siguiente ({0}/{1})[/COLOR]".format(page + 1, total_pages))
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='tmdb_lists_show', endpoint=endpoint, media_type=media_type, page=page + 1),
            listitem=li,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(h)
