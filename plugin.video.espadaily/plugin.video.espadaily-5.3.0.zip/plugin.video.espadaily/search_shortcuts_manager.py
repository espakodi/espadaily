# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
# Gestión de atajos y fuentes alternativas de búsqueda en Kodi.

import os
import json
import sys
import re
import xml.etree.ElementTree as ET
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import core_settings

_ADDON = xbmcaddon.Addon()
_PROFILE = xbmcvfs.translatePath(_ADDON.getAddonInfo('profile'))
_MEDIA = os.path.join(xbmcvfs.translatePath(_ADDON.getAddonInfo('path')), 'resources', 'media')
_SHORTCUTS_FILE = os.path.join(_PROFILE, 'search_shortcuts.json')

_BBCODE_RE = re.compile(r'\[/?(?:B|I|S|CR|LIGHT|COLOR[^\]]*)\]', re.IGNORECASE)

_KNOWN_TEMPLATES = {
    'plugin.video.youtube':    'Container.Update(plugin://plugin.video.espadaily/?action=yt_html_search&q={query})',
    'plugin.video.balandro':   'RunPlugin(plugin://plugin.video.balandro/?action=buscar&q={query})',
    'plugin.video.espadaily':  'RunPlugin(plugin://plugin.video.espadaily/?action=search_alt_prompt&q={query})',
    'plugin.video.espatv':     'RunPlugin(plugin://plugin.video.espatv/?action=search&q={query})',
}


def _handle():
    return int(sys.argv[1])


def _u(**kwargs):
    return sys.argv[0] + '?' + urllib.parse.urlencode(kwargs)


def _icon(name):
    p = os.path.join(_MEDIA, name)
    return p if os.path.exists(p) else ''


def _sanitize_name(text):
    if not text:
        return ''
    return _BBCODE_RE.sub('', str(text)).strip()


def load_shortcuts():
    if not os.path.exists(_SHORTCUTS_FILE):
        return []
    try:
        with open(_SHORTCUTS_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if not isinstance(data, list):
            return []
        result = []
        for item in data:
            if not isinstance(item, dict):
                continue
            t = item.get('type', 'command')
            if t == 'builtin' and not item.get('handler'):
                continue
            if t != 'builtin' and not isinstance(item.get('command'), str):
                continue
            result.append(item)
        return result
    except Exception:
        return []


def save_shortcuts(shortcuts):
    os.makedirs(_PROFILE, exist_ok=True)
    tmp = _SHORTCUTS_FILE + '.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(shortcuts, f, ensure_ascii=False, indent=2)
        os.replace(tmp, _SHORTCUTS_FILE)
    except Exception as e:
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except Exception:
                pass
        xbmcgui.Dialog().notification("Atajos", f"Error al guardar: {e}", xbmcgui.NOTIFICATION_ERROR, 3000)
        raise


def _default_shortcuts():
    # Atajos de búsqueda predeterminados del sistema
    shortcuts = [{'name': '[COLOR white]Buscar en webs de torrent[/COLOR]', 'icon': _icon('srch_torrent.png'), 'type': 'builtin', 'handler': 'elementum', 'addon_id': ''}]

    if xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
        shortcuts.append({'name': '[COLOR red]Buscar en YouTube[/COLOR]', 'icon': 'DefaultTVShows.png', 'type': 'builtin', 'handler': 'youtube', 'addon_id': 'plugin.video.youtube'})

    if xbmcaddon.Addon().getSetting('gujal_search_enabled') == 'true':
        if xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)"):
            shortcuts.append({'name': '[COLOR deepskyblue]Buscar en addon Dailymotion (Gujal)[/COLOR]', 'icon': 'DefaultTVShows.png', 'type': 'builtin', 'handler': 'dm_gujal', 'addon_id': 'plugin.video.dailymotion_com'})

    palantir_id = core_settings.get_palantir_addon_id()
    if palantir_id:
        shortcuts.append({'name': '[COLOR orange]Buscar en Palantir[/COLOR]', 'icon': 'DefaultAddonService.png', 'type': 'builtin', 'handler': 'palantir', 'addon_id': palantir_id})

    shortcuts.append({'name': '[COLOR deepskyblue]Buscar en Odysee[/COLOR]', 'icon': 'DefaultTVShows.png', 'type': 'builtin', 'handler': 'odysee', 'addon_id': ''})

    if xbmc.getCondVisibility("System.HasAddon(plugin.video.balandro)"):
        shortcuts.append({'name': '[COLOR chartreuse]Buscar en Balandro[/COLOR]', 'icon': 'DefaultAddonService.png', 'type': 'builtin', 'handler': 'balandro', 'addon_id': 'plugin.video.balandro'})

    if core_settings.is_jacktook_installed():
        shortcuts.append({'name': '[COLOR gold]Buscar en Jacktook[/COLOR]', 'icon': 'DefaultAddonService.png', 'type': 'builtin', 'handler': 'jacktook', 'addon_id': 'plugin.video.jacktook'})

    alfa_id = core_settings.get_alfa_addon_id()
    if alfa_id:
        shortcuts.append({'name': '[COLOR cyan]Buscar en Alfa[/COLOR]', 'icon': 'DefaultAddonService.png', 'type': 'builtin', 'handler': 'alfa', 'addon_id': alfa_id})

    return shortcuts


def load_active_shortcuts():
    # atajos del addon, filtrados si el addon requerido no está instalado
    active = []
    for s in _default_shortcuts():
        addon_id = s.get('addon_id', '')
        if not addon_id or xbmc.getCondVisibility(f"System.HasAddon({addon_id})"):
            active.append(s)

    # Atajos de usuario personalizados del archivo de configuración
    for s in load_shortcuts():
        if s.get('type') == 'builtin':
            continue  # Ignorar si el tipo ya está integrado por defecto
        addon_id = s.get('addon_id', '')
        if s.get('type') == 'addon':
            if addon_id and xbmc.getCondVisibility(f"System.HasAddon({addon_id})"):
                active.append(s)
        else:
            active.append(s)

    return active


def main_menu():
    h = _handle()
    shortcuts = load_shortcuts()

    li = xbmcgui.ListItem(label="[COLOR white]+ AÑADIR ATAJO DE ADDON INSTALADO[/COLOR]")
    li.setArt({'icon': _icon('shortcut_addon.png')})
    li.setInfo('video', {'plot': 'Selecciona un addon instalado para añadirlo como fuente de búsqueda.'})
    xbmcplugin.addDirectoryItem(h, _u(action='ssm_add_addon'), li, False)

    li = xbmcgui.ListItem(label="[COLOR white]+ AÑADIR COMANDO[/COLOR]")
    li.setArt({'icon': _icon('comando.png')})
    li.setInfo('video', {'plot': 'Introduce un comando Kodi con {query} como marcador de búsqueda.'})
    xbmcplugin.addDirectoryItem(h, _u(action='ssm_add_command'), li, False)

    li = xbmcgui.ListItem(label="[COLOR white]+ AÑADIR DESDE FAVORITOS DE KODI[/COLOR]")
    li.setArt({'icon': _icon('favoritos.png') or 'DefaultFavourites.png'})
    li.setInfo('video', {'plot': 'Usa un favorito de Kodi como base para un atajo de búsqueda.'})
    xbmcplugin.addDirectoryItem(h, _u(action='ssm_add_fav'), li, False)

    if shortcuts:
        li = xbmcgui.ListItem(label="↕ REORDENAR VENTANA '¿DÓNDE BUSCAR?'")
        li.setArt({'icon': _icon('adv_busqueda.png') or 'DefaultAddonService.png'})
        li.setInfo('video', {'plot': 'Cambia el orden en que aparecen las fuentes en el diálogo de búsqueda.'})
        xbmcplugin.addDirectoryItem(h, _u(action='ssm_reorder'), li, True)

    for i, s in enumerate(shortcuts):
        name = s.get('name', f'Atajo {i + 1}')
        t = s.get('type', 'command')
        addon_id = s.get('addon_id', '')

        installed = True
        if t in ('addon', 'builtin') and addon_id:
            installed = bool(xbmc.getCondVisibility(f"System.HasAddon({addon_id})"))

        if t == 'builtin':
            type_txt = '[COLOR orange]integrado[/COLOR]'
        elif t == 'addon':
            type_txt = '[COLOR deepskyblue]addon[/COLOR]'
        else:
            type_txt = '[COLOR lime]comando[/COLOR]'

        display_label = name if installed else f"[COLOR gray]{name} (no instalado)[/COLOR]"
        cmd_preview = s.get('command', s.get('handler', ''))[:80]
        plot = f"[B]Tipo:[/B] {type_txt}\n{cmd_preview}"

        icon = s.get('icon') or ''
        if t == 'addon' and addon_id:
            try:
                live_icon = xbmcaddon.Addon(addon_id).getAddonInfo('icon')
                if live_icon:
                    icon = live_icon
            except Exception:
                pass
        li = xbmcgui.ListItem(label=display_label)
        li.setArt({'icon': icon or 'DefaultAddonVideo.png'})
        li.setInfo('video', {'plot': plot})
        li.addContextMenuItems([
            ("Renombrar",  f"RunPlugin({_u(action='ssm_rename', idx=i)})"),
            ("Eliminar",   f"RunPlugin({_u(action='ssm_delete', idx=i)})"),
            ("↑ Subir",    f"RunPlugin({_u(action='ssm_move_up', idx=i)})"),
            ("↓ Bajar",    f"RunPlugin({_u(action='ssm_move_down', idx=i)})"),
        ])
        xbmcplugin.addDirectoryItem(h, _u(action='ssm_actions', idx=i), li, False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def shortcut_actions(idx):
    shortcuts = load_shortcuts()
    if not (0 <= idx < len(shortcuts)):
        return
    name = shortcuts[idx].get('name', f'Atajo {idx + 1}')
    sel = xbmcgui.Dialog().select(f"'{name}'", ['Renombrar', '[COLOR red]Eliminar[/COLOR]'])
    if sel == 0:
        rename_shortcut(idx)
    elif sel == 1:
        delete_shortcut(idx)


def _get_installed_addons():
    seen = set()
    result = []
    try:
        req = json.dumps({
            'jsonrpc': '2.0',
            'method': 'Addons.GetAddons',
            'params': {'type': 'xbmc.python.pluginsource', 'enabled': True, 'properties': ['name', 'thumbnail']},
            'id': 1,
        })
        data = json.loads(xbmc.executeJSONRPC(req) or '{}')
        for a in (data.get('result') or {}).get('addons') or []:
            if not isinstance(a, dict):
                continue
            aid = a.get('addonid', '')
            if aid and aid not in seen:
                seen.add(aid)
                result.append(a)
    except Exception:
        pass
    result.sort(key=lambda x: (x.get('name') or '').lower())
    return result


def add_from_installed_addon():
    addons = _get_installed_addons()
    if not addons:
        xbmcgui.Dialog().notification("Atajos", "No se encontraron addons instalados.", xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    names = [a.get('name', a['addonid']) for a in addons]
    sel = xbmcgui.Dialog().select("Selecciona un addon", names)
    if sel < 0:
        return

    chosen = addons[sel]
    addon_id = chosen['addonid']
    addon_name = _sanitize_name(chosen.get('name') or addon_id)
    try:
        addon_icon = xbmcaddon.Addon(addon_id).getAddonInfo('icon') or ''
    except Exception:
        addon_icon = ''
    if not addon_icon:
        addon_icon = chosen.get('thumbnail') or 'DefaultAddonProgram.png'

    mode = xbmcgui.Dialog().select(
        f"Añadir: {addon_name}",
        ['Buscar con {query} (atajo de búsqueda)', 'Abrir addon directamente (sin búsqueda)'],
    )
    if mode < 0:
        return

    if mode == 1:
        cmd = f'RunAddon({addon_id})'
    else:
        default_cmd = _KNOWN_TEMPLATES.get(addon_id, f'RunPlugin(plugin://{addon_id}/?search={{query}})')
        kb = xbmc.Keyboard(default_cmd, 'Comando ({query} = término de búsqueda)')
        kb.doModal()
        if not kb.isConfirmed():
            return
        cmd = kb.getText().strip()
        if not cmd:
            return

    kb2 = xbmc.Keyboard(addon_name, 'Nombre para mostrar')
    kb2.doModal()
    if not kb2.isConfirmed():
        return
    name = _sanitize_name(kb2.getText()) or addon_name

    shortcuts = load_shortcuts()
    shortcuts.append({'name': name, 'icon': addon_icon, 'type': 'addon', 'command': cmd, 'addon_id': addon_id})
    save_shortcuts(shortcuts)
    xbmcgui.Dialog().notification("Atajo añadido", name, xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")


def add_command():
    kb = xbmc.Keyboard('', 'Nombre para mostrar')
    kb.doModal()
    if not kb.isConfirmed():
        return
    name = _sanitize_name(kb.getText())
    if not name:
        return

    kb2 = xbmc.Keyboard('RunPlugin(plugin://...?q={query})', 'Comando Kodi ({query} = término)')
    kb2.doModal()
    if not kb2.isConfirmed():
        return
    cmd = kb2.getText().strip()
    if not cmd:
        return

    shortcuts = load_shortcuts()
    shortcuts.append({'name': name, 'icon': _icon('comando.png'), 'type': 'command', 'command': cmd})
    save_shortcuts(shortcuts)
    xbmcgui.Dialog().notification("Comando añadido", name, xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")


def add_from_kodi_favorites():
    favs_path = xbmcvfs.translatePath('special://profile/favourites.xml')
    if not os.path.exists(favs_path):
        xbmcgui.Dialog().notification("Favoritos", "No hay favoritos guardados en Kodi.", xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    try:
        root = ET.parse(favs_path).getroot()
    except ET.ParseError:
        xbmcgui.Dialog().notification("Favoritos", "Los favoritos de Kodi están dañados.", xbmcgui.NOTIFICATION_ERROR, 3000)
        return
    except Exception:
        xbmcgui.Dialog().notification("Favoritos", "Error leyendo favoritos.", xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    favs = []
    for el in root.findall('favourite'):
        cmd = (el.text or '').strip()
        if not cmd:
            continue
        favs.append({
            'name':    _sanitize_name(el.get('name', '')) or cmd[:40],
            'thumb':   el.get('thumb', ''),
            'command': cmd,
        })

    if not favs:
        xbmcgui.Dialog().notification("Favoritos", "No hay favoritos de Kodi.", xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    sel = xbmcgui.Dialog().select("Selecciona un favorito", [f['name'] for f in favs])
    if sel < 0:
        return

    chosen = favs[sel]

    kb = xbmc.Keyboard(chosen['command'], 'Comando ({query} = término de búsqueda)')
    kb.doModal()
    if not kb.isConfirmed():
        return
    cmd = kb.getText().strip()
    if not cmd:
        return

    kb2 = xbmc.Keyboard(chosen['name'], 'Nombre para mostrar')
    kb2.doModal()
    if not kb2.isConfirmed():
        return
    name = _sanitize_name(kb2.getText()) or chosen['name']

    shortcuts = load_shortcuts()
    shortcuts.append({
        'name':    name,
        'icon':    chosen.get('thumb') or _icon('favoritos.png') or 'DefaultFavourites.png',
        'type':    'command',
        'command': cmd,
    })
    save_shortcuts(shortcuts)
    xbmcgui.Dialog().notification("Atajo añadido", name, xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")


def reorder_menu():
    h = _handle()
    shortcuts = load_shortcuts()

    if not shortcuts:
        li = xbmcgui.ListItem(label="[COLOR gray]No hay atajos configurados.[/COLOR]")
        li.setArt({'icon': ''})
        xbmcplugin.addDirectoryItem(h, '', li, False)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    for i, s in enumerate(shortcuts):
        li = xbmcgui.ListItem(label=f"[{i + 1}] {s.get('name', '???')}")
        li.setArt({'icon': s.get('icon') or 'DefaultIconInfo.png'})
        cm = []
        if i > 0:
            cm.append(("Subir", f"RunPlugin({_u(action='ssm_move_up', idx=i)})"))
        if i < len(shortcuts) - 1:
            cm.append(("↓ Bajar", f"RunPlugin({_u(action='ssm_move_down', idx=i)})"))
        if cm:
            li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(h, _u(action='ssm_reorder'), li, False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def delete_shortcut(idx):
    shortcuts = load_shortcuts()
    if not (0 <= idx < len(shortcuts)):
        return
    name = shortcuts[idx].get('name', '???')
    if xbmcgui.Dialog().yesno("Eliminar atajo", f"¿Eliminar '{name}'?"):
        shortcuts.pop(idx)
        save_shortcuts(shortcuts)
        xbmcgui.Dialog().notification("Atajo eliminado", name, xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")


def rename_shortcut(idx):
    shortcuts = load_shortcuts()
    if not (0 <= idx < len(shortcuts)):
        return
    kb = xbmc.Keyboard(shortcuts[idx].get('name', ''), 'Nuevo nombre')
    kb.doModal()
    if kb.isConfirmed():
        new_name = _sanitize_name(kb.getText())
        if new_name:
            shortcuts[idx]['name'] = new_name
            save_shortcuts(shortcuts)
            xbmc.executebuiltin("Container.Refresh")


def move_shortcut(idx, direction):
    shortcuts = load_shortcuts()
    if direction == 'up' and 0 < idx < len(shortcuts):
        shortcuts[idx], shortcuts[idx - 1] = shortcuts[idx - 1], shortcuts[idx]
        save_shortcuts(shortcuts)
        xbmc.executebuiltin("Container.Refresh")
    elif direction == 'down' and 0 <= idx < len(shortcuts) - 1:
        shortcuts[idx], shortcuts[idx + 1] = shortcuts[idx + 1], shortcuts[idx]
        save_shortcuts(shortcuts)
        xbmc.executebuiltin("Container.Refresh")
