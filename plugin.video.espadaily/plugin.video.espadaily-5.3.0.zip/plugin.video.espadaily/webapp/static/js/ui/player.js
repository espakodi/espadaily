import { Icons } from '../icons.js';
import { API } from '../api.js';
import { toast } from './toast.js';

let _hls = null;
let _dash = null;
let _progressTimer = null;
let _hideTimer = null;
let _currentItem = null;
let _isLive = false;
let _isOpen = false;
let _keyHandler = null;
let _clickOutsideHandler = null;
let _retryCount = 0;
const MAX_HLS_RETRIES = 3;

const view = document.getElementById('player-view');
const videoEl = document.getElementById('video-el');

export function isPlayerOpen() { return _isOpen; }

export async function openPlayer(item, streamData) {
  _currentItem = item;
  _isLive = item.play?.kind === 'live' || streamData.kind === 'live';
  _isOpen = true;

  view.classList.remove('hidden');
  document.body.style.overflow = 'hidden';

  // Limpiar elementos track de la instancia previa
  Array.from(videoEl.querySelectorAll('track')).forEach(t => t.remove());

  buildControls(streamData);
  // Registrar antes de cargar: la entrada queda en el historial (sube en la lista,
  // sin pisar progreso previo) antes de que maybeOfferResume consulte para reanudar.
  if (!_isLive) _registerPlay(item);
  await loadStream(streamData);
  startProgressSaving();

  _keyHandler = onKeyDown;
  document.addEventListener('keydown', _keyHandler);
}

function cleanupVideoHandlers() {
  // Desasociar manejadores de eventos explícitamente para evitar fugas de memoria y closures obsoletos
  videoEl.onplay = null;
  videoEl.onpause = null;
  videoEl.onwaiting = null;
  videoEl.onplaying = null;
  videoEl.ontimeupdate = null;
  videoEl.onprogress = null;
  videoEl.ondblclick = null;
  videoEl.onvolumechange = null;
  view.onmousemove = null;
  view.ontouchstart = null;
}

export function closePlayer() {
  if (!_isOpen) return;
  _isOpen = false;
  // Guardado final antes de soltar el <video>. La vista "Seguir viendo" recarga
  // sola al abrirla, asi que no hace falta avisar a nadie.
  stopProgressSaving();
  clearTimeout(_hideTimer);

  if (_keyHandler) {
    document.removeEventListener('keydown', _keyHandler);
    _keyHandler = null;
  }
  if (_clickOutsideHandler) {
    document.removeEventListener('click', _clickOutsideHandler);
    _clickOutsideHandler = null;
  }

  cleanupVideoHandlers();

  if (_hls) { _hls.destroy(); _hls = null; }
  if (_dash) { try { _dash.destroy(); } catch {} _dash = null; }
  try { videoEl.pause(); } catch {}
  videoEl.removeAttribute('src');
  try { videoEl.load(); } catch {}

  Array.from(videoEl.querySelectorAll('track')).forEach(t => t.remove());

  view.classList.add('hidden');
  view.classList.remove('cinema-mode');
  document.body.style.overflow = '';
  _currentItem = null;
  _retryCount = 0;

  if (document.fullscreenElement) {
    document.exitFullscreen?.().catch(() => {});
  }
}

async function loadStream(streamData) {
  showSpinner(true);

  const src = streamData.playlist;

  // Aprovisionamiento de subtítulos externos
  for (const sub of (streamData.subtitles || [])) {
    const track = document.createElement('track');
    track.kind = 'subtitles';
    track.label = sub.lang || 'es';
    track.srclang = sub.lang || 'es';
    track.src = sub.url;
    videoEl.appendChild(track);
  }

  // Reproduccion directa (MP4 de Dailymotion): el <video> nativo lo sirve
  // mejor que hls.js. El backend marca streamData.direct para estos casos.
  if (streamData.direct) {
    if (_hls) { _hls.destroy(); _hls = null; }
    videoEl.src = src;
    videoEl.addEventListener('loadeddata', () => { showSpinner(false); maybeOfferResume(); }, { once: true });
    videoEl.play().catch(() => {});
    return;
  }

  // DASH (.mpd, p. ej. RTVE en directo): requiere dash.js.
  if (streamData.type === 'dash') {
    if (typeof dashjs === 'undefined') {
      toast('Reproductor DASH no disponible (sin conexion para cargarlo)', 'error', 5000);
      closePlayer();
      return;
    }
    if (_dash) { try { _dash.destroy(); } catch {} _dash = null; }
    _dash = dashjs.MediaPlayer().create();
    _dash.initialize(videoEl, src, true);
    _dash.on('canPlay', () => showSpinner(false));
    _dash.on('error', () => { toast('Error de reproduccion DASH', 'error', 5000); closePlayer(); });
    return;
  }

  if (typeof Hls !== 'undefined' && Hls.isSupported()) {
    if (_hls) _hls.destroy();
    _hls = new Hls({
      enableWorker: true,
      lowLatencyMode: _isLive,
      backBufferLength: _isLive ? 4 : 30,
      maxBufferLength: _isLive ? 6 : 60,
    });
    _hls.loadSource(src);
    _hls.attachMedia(videoEl);
    _retryCount = 0;
    _hls.on(Hls.Events.MANIFEST_PARSED, () => {
      showSpinner(false);
      _retryCount = 0;
      videoEl.play().catch(() => {});
      updateQualityMenu();
      maybeOfferResume();
    });
    _hls.on(Hls.Events.FRAG_LOADED, () => { _retryCount = 0; });
    _hls.on(Hls.Events.LEVEL_SWITCHED, updateQualityMenu);
    _hls.on(Hls.Events.ERROR, (_, data) => {
      if (!data.fatal) return;
      if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
        _retryCount++;
        if (_retryCount > MAX_HLS_RETRIES) {
          toast('No se pudo conectar al stream tras varios intentos', 'error', 5000);
          closePlayer();
          return;
        }
        toast(`Error de red, reintentando (${_retryCount}/${MAX_HLS_RETRIES})…`, 'error', 3000);
        _hls.startLoad();
      } else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
        _retryCount++;
        if (_retryCount > MAX_HLS_RETRIES) {
          toast('Error de media irrecuperable', 'error', 5000);
          closePlayer();
          return;
        }
        toast('Error de media, recuperando…', 'error', 3000);
        _hls.recoverMediaError();
      } else {
        toast('Error fatal del stream', 'error', 5000);
        closePlayer();
      }
    });
  } else if (videoEl.canPlayType('application/vnd.apple.mpegurl')) {
    videoEl.src = src;
    videoEl.addEventListener('loadeddata', () => { showSpinner(false); maybeOfferResume(); }, { once: true });
    videoEl.play().catch(() => {});
  } else {
    videoEl.src = src;
    videoEl.play().catch(() => {});
    showSpinner(false);
  }
}

function buildControls(streamData) {
  const title = streamData.title || _currentItem?.title || '';
  const controls = view.querySelector('.player-controls');

  controls.innerHTML = `
    <div class="ctrl-top">
      <button class="ctrl-back" id="ctrl-back" title="Volver">${Icons.back}</button>
      <span class="ctrl-title">${escHtml(title)}</span>
    </div>
    <div class="player-spinner" id="player-spinner">
      <div class="spinner"></div>
    </div>
    <div class="ctrl-bottom">
      <div class="ctrl-progress" id="ctrl-progress">
        <div class="ctrl-progress-buf" id="ctrl-buf" style="width:0%"></div>
        <div class="ctrl-progress-fill" id="ctrl-fill" style="width:0%"></div>
      </div>
      <div class="ctrl-row">
        <div class="ctrl-left">
          <button class="ctrl-btn play-pause" id="ctrl-play">${Icons.play}</button>
          <button class="ctrl-btn" id="ctrl-skipfwd" title="+10s">${Icons.skipFwd}</button>
          ${!_isLive ? `<span class="ctrl-time" id="ctrl-time">0:00 / 0:00</span>` : ''}
          ${_isLive ? `<button class="live-edge-btn" id="ctrl-live-edge"><span class="card-live-dot"></span>EN DIRECTO</button>` : ''}
        </div>
        <div class="ctrl-right">
          <button class="ctrl-btn" id="ctrl-mute">${Icons.volume}</button>
          <input type="range" class="ctrl-vol-slider" id="ctrl-vol" min="0" max="1" step="0.05" value="1">
          <button class="ctrl-btn" id="ctrl-subs" title="Subtítulos">${Icons.subtitles}</button>
          <div class="ctrl-dropdown" id="ctrl-quality-dd">
            <button class="ctrl-btn" title="Calidad">${Icons.quality}</button>
            <div class="ctrl-dropdown-menu" id="ctrl-quality-menu"></div>
          </div>
          <button class="ctrl-btn" id="ctrl-pip" title="Picture in Picture">${Icons.pip}</button>
          <button class="ctrl-btn" id="ctrl-fs" title="Pantalla completa">${Icons.fullscreen}</button>
        </div>
      </div>
    </div>
  `;

  bindControls();
  autoHideControls();
}

function bindControls() {
  document.getElementById('ctrl-back').onclick = closePlayer;
  document.getElementById('ctrl-play').onclick = togglePlay;
  document.getElementById('ctrl-skipfwd').onclick = () => { videoEl.currentTime += 10; };
  document.getElementById('ctrl-mute').onclick = toggleMute;
  document.getElementById('ctrl-vol').oninput = (e) => { videoEl.volume = parseFloat(e.target.value); videoEl.muted = false; };
  document.getElementById('ctrl-subs').onclick = toggleSubs;
  document.getElementById('ctrl-pip').onclick = () => {
    if (document.pictureInPictureElement) document.exitPictureInPicture?.().catch(() => {});
    else videoEl.requestPictureInPicture?.().catch(() => toast('Picture-in-Picture no disponible', 'info'));
  };
  document.getElementById('ctrl-fs').onclick = toggleFullscreen;

  const qualityDd = document.getElementById('ctrl-quality-dd');
  qualityDd.querySelector('button').onclick = (e) => {
    e.stopPropagation();
    qualityDd.classList.toggle('open');
  };

  // Prevenir duplicación de manejadores mediante desvinculación previa
  if (_clickOutsideHandler) {
    document.removeEventListener('click', _clickOutsideHandler);
  }
  _clickOutsideHandler = (e) => {
    if (!qualityDd.contains(e.target)) qualityDd.classList.remove('open');
  };
  document.addEventListener('click', _clickOutsideHandler);

  document.getElementById('ctrl-live-edge')?.addEventListener('click', () => {
    if (_hls && _hls.liveSyncPosition) videoEl.currentTime = _hls.liveSyncPosition;
    else if (videoEl.duration) videoEl.currentTime = videoEl.duration;
  });

  const progress = document.getElementById('ctrl-progress');
  progress.onclick = (e) => {
    if (_isLive) return;
    const rect = progress.getBoundingClientRect();
    const pct = (e.clientX - rect.left) / rect.width;
    videoEl.currentTime = pct * videoEl.duration;
  };

  videoEl.onplay = () => { document.getElementById('ctrl-play').innerHTML = Icons.pause; };
  videoEl.onpause = () => { document.getElementById('ctrl-play').innerHTML = Icons.play; };
  videoEl.onwaiting = () => showSpinner(true);
  videoEl.onplaying = () => showSpinner(false);
  videoEl.ontimeupdate = updateProgress;
  videoEl.onprogress = updateBuffer;
  videoEl.ondblclick = () => view.classList.toggle('cinema-mode');
  videoEl.onvolumechange = () => {
    document.getElementById('ctrl-vol').value = videoEl.muted ? 0 : videoEl.volume;
    document.getElementById('ctrl-mute').innerHTML = (videoEl.muted || videoEl.volume === 0) ? Icons.volumeMute : Icons.volume;
  };
}

function onKeyDown(e) {
  if (e.target.tagName === 'INPUT') return;
  switch (e.key) {
    case ' ': case 'k': e.preventDefault(); togglePlay(); break;
    case 'ArrowLeft': e.preventDefault(); if (!_isLive) { videoEl.currentTime -= 10; showSeekIndicator(-10); } break;
    case 'ArrowRight': e.preventDefault(); if (!_isLive) { videoEl.currentTime += 10; showSeekIndicator(+10); } break;
    case 'ArrowUp': e.preventDefault(); videoEl.volume = Math.min(1, videoEl.volume + 0.1); break;
    case 'ArrowDown': e.preventDefault(); videoEl.volume = Math.max(0, videoEl.volume - 0.1); break;
    case 'f': case 'F': toggleFullscreen(); break;
    case 'm': case 'M': toggleMute(); break;
    case 'c': case 'C': toggleSubs(); break;
    case 'p': case 'P': document.getElementById('ctrl-pip')?.click(); break;
    case 'Escape': if (!document.fullscreenElement) closePlayer(); break;
    default:
      if (!_isLive && e.key >= '0' && e.key <= '9' && videoEl.duration) {
        videoEl.currentTime = (parseInt(e.key) / 10) * videoEl.duration;
      }
  }
  resetHideTimer();
}

function togglePlay() { videoEl.paused ? videoEl.play() : videoEl.pause(); }
function toggleMute() { videoEl.muted = !videoEl.muted; }
function toggleSubs() {
  let hasShowing = false;
  for (const track of videoEl.textTracks) if (track.mode === 'showing') hasShowing = true;
  for (const track of videoEl.textTracks) track.mode = hasShowing ? 'disabled' : 'showing';
}
function toggleFullscreen() {
  const btn = document.getElementById('ctrl-fs');
  if (!document.fullscreenElement) {
    view.requestFullscreen?.().then(() => { if (btn) btn.innerHTML = Icons.exitFullscreen; }).catch(() => {});
  } else {
    document.exitFullscreen?.().then(() => { if (btn) btn.innerHTML = Icons.fullscreen; }).catch(() => {});
  }
}

function updateProgress() {
  const fill = document.getElementById('ctrl-fill');
  const timeEl = document.getElementById('ctrl-time');
  if (!fill || !videoEl.duration) return;
  fill.style.width = `${(videoEl.currentTime / videoEl.duration) * 100}%`;
  if (timeEl && !_isLive) {
    timeEl.textContent = `${fmtTime(videoEl.currentTime)} / ${fmtTime(videoEl.duration)}`;
  }
}

function updateBuffer() {
  const buf = document.getElementById('ctrl-buf');
  if (!buf || !videoEl.duration || !videoEl.buffered.length) return;
  const end = videoEl.buffered.end(videoEl.buffered.length - 1);
  buf.style.width = `${(end / videoEl.duration) * 100}%`;
}

function updateQualityMenu() {
  const menu = document.getElementById('ctrl-quality-menu');
  if (!menu || !_hls) return;
  menu.innerHTML = '';
  const levels = _hls.levels || [];

  const auto = document.createElement('div');
  auto.className = `ctrl-dropdown-item${_hls.currentLevel === -1 || _hls.autoLevelEnabled ? ' active' : ''}`;
  auto.textContent = 'Auto';
  auto.onclick = () => { _hls.currentLevel = -1; closeQualityMenu(); };
  menu.appendChild(auto);

  // Ordenar flujos HLS de mayor a menor resolución
  const sortedLevels = levels.map((l, i) => ({ ...l, idx: i })).sort((a, b) => (b.height || 0) - (a.height || 0));
  for (const lvl of sortedLevels) {
    const d = document.createElement('div');
    d.className = `ctrl-dropdown-item${_hls.currentLevel === lvl.idx && !_hls.autoLevelEnabled ? ' active' : ''}`;
    d.textContent = lvl.height ? `${lvl.height}p` : `${Math.round(lvl.bitrate / 1000)}k`;
    d.onclick = () => { _hls.currentLevel = lvl.idx; closeQualityMenu(); };
    menu.appendChild(d);
  }
}

function closeQualityMenu() {
  document.getElementById('ctrl-quality-dd')?.classList.remove('open');
}

function showSpinner(show) {
  const sp = document.getElementById('player-spinner');
  if (sp) sp.classList.toggle('hidden', !show);
}

function autoHideControls() {
  view.onmousemove = resetHideTimer;
  view.ontouchstart = resetHideTimer;
  resetHideTimer();
}

function resetHideTimer() {
  view.querySelector('.player-controls')?.classList.remove('hidden-controls');
  clearTimeout(_hideTimer);
  _hideTimer = setTimeout(() => {
    if (!videoEl.paused) view.querySelector('.player-controls')?.classList.add('hidden-controls');
  }, 3000);
}

// Clave estable de historial por contenido: el id de DM directo, o 'q:'+query
// para los items de catalogo (dm_search). Independiente del DM que se resuelva,
// asi reproducir el mismo episodio actualiza siempre la misma entrada.
function _historyKey(play) {
  if (!play) return null;
  if (play.vid) return play.vid;
  if (play.q) return 'q:' + play.q;
  return null;
}

// Cadena de guardados serializada: cada save espera al anterior antes de salir.
// Asi un tick del timer (15s) y el guardado final al cerrar no pueden adelantarse
// y machacar la posicion con un valor mas viejo (las posiciones ya van capturadas
// en pos/dur en el momento de la llamada, no se leen tarde).
let _saveChain = Promise.resolve();

function _saveProgress(item, pos, dur) {
  const play = item?.play;
  const key = _historyKey(play);
  if (!key) return Promise.resolve();
  // Capturar todo ahora: el .then corre mas tarde y el item podria cambiar.
  const title = item.title, thumb = item.thumb || '', source = item.source || '';
  _saveChain = _saveChain
    .then(() => API.saveProgress(key, pos, dur, title, thumb, play, source))
    .catch(() => {});
  return _saveChain;
}

function _registerPlay(item) {
  _saveProgress(item, 0, 0);
}

function startProgressSaving() {
  if (_isLive) return;
  _progressTimer = setInterval(() => {
    if (!_currentItem || videoEl.paused || !videoEl.duration) return;
    if (videoEl.currentTime > 5) {
      _saveProgress(_currentItem, Math.floor(videoEl.currentTime), Math.floor(videoEl.duration));
    }
  }, 15000);
}

function stopProgressSaving() {
  clearInterval(_progressTimer);
  _progressTimer = null;
  // Guardar la posicion final al salir (el timer de 15s puede perder el ultimo tramo).
  if (!_isLive && _currentItem && videoEl.duration && videoEl.currentTime > 5) {
    return _saveProgress(_currentItem, Math.floor(videoEl.currentTime), Math.floor(videoEl.duration));
  }
  return Promise.resolve();
}

async function maybeOfferResume() {
  if (_isLive) return;
  const key = _historyKey(_currentItem?.play);
  if (!key) return;

  try {
    const data = await API.getHistory();
    const entry = (data.items || []).find(it => _historyKey(it.play) === key);
    if (!entry) return;
    if (entry.progress > 30 && entry.duration > 0) {
      const pct = entry.progress / entry.duration;
      if (pct > 0.03 && pct < 0.95) showResumeModal(entry.progress, entry.duration);
    }
  } catch {}
}

function showResumeModal(pos, dur) {
  const existing = view.querySelector('.resume-modal');
  if (existing) existing.remove();

  const modal = document.createElement('div');
  modal.className = 'resume-modal';
  modal.innerHTML = `
    <h3>Continuar viendo</h3>
    <p>Estabas en ${fmtTime(pos)} de ${fmtTime(dur)}</p>
    <div class="resume-btns">
      <button class="btn btn-primary" id="resume-yes">Continuar</button>
      <button class="btn btn-ghost" id="resume-no">Desde el principio</button>
    </div>
  `;
  view.appendChild(modal);
  videoEl.pause();

  document.getElementById('resume-yes').onclick = () => { videoEl.currentTime = pos; videoEl.play(); modal.remove(); };
  document.getElementById('resume-no').onclick = () => { videoEl.play(); modal.remove(); };
}

function showSeekIndicator(seconds) {
  let ind = view.querySelector('.seek-indicator');
  if (!ind) {
    ind = document.createElement('div');
    ind.className = 'seek-indicator';
    view.appendChild(ind);
  }
  ind.textContent = seconds > 0 ? `+${seconds}s` : `${seconds}s`;
  ind.classList.add('visible');
  clearTimeout(ind._t);
  ind._t = setTimeout(() => ind.classList.remove('visible'), 700);
}

function fmtTime(s) {
  if (!s || isNaN(s) || !isFinite(s)) return '0:00';
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = Math.floor(s % 60);
  if (h) return `${h}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;
  return `${m}:${String(sec).padStart(2,'0')}`;
}

function escHtml(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
