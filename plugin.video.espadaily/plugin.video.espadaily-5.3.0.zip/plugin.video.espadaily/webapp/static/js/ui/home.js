import { Icons } from '../icons.js';
import { makeRow } from './row.js';
import { makeSkeleton } from './grid.js';
import { toast } from './toast.js';
import { API } from '../api.js';

let _heroItems = [];
let _heroIdx = 0;
let _heroTimer = null;
let _heroAdvance = null;  // fn de avance del hero, para reanudar la rotación al restaurar
let _curSource = 'all';
// Token de render: si llega un _load nuevo (p.ej. al cambiar de pestaña de fuente)
// mientras otro sigue en su await, el viejo se descarta y no pisa el DOM del nuevo.
let _renderToken = 0;
let _scrollY = 0;          // scroll del Home, para restaurarlo al volver atrás
let _homeNode = null;      // DOM del Home ya renderizado; al volver atrás se re-inserta
let _homeTs = 0;           // tal cual (miniaturas y scroll intactos, sin recargas)
const _HOME_TTL = 120000;  // ms; pasado esto se re-renderiza con datos frescos

const _SRC_LABEL = { rtve: 'RTVE', mediaset: 'MEDIASET', atres: 'ATRESPLAYER' };

// Lo llama app.js antes de salir del Home: guarda la posición de scroll y para el
// rotador del hero (evita un setInterval corriendo sobre nodos ya desconectados).
export function saveHomeScroll() { _scrollY = window.scrollY || window.pageYOffset || 0; }
export function pauseHomeHero() { if (_heroTimer) { clearInterval(_heroTimer); _heroTimer = null; } }
function resumeHero() {
  if (!_heroTimer && _heroAdvance && _heroItems.length > 1) {
    _heroTimer = setInterval(_heroAdvance, 9000);
  }
}

export async function renderHome(container, cbs, { restore = false } = {}) {
  // Volver atrás: si el DOM del Home sigue fresco, se re-inserta tal cual. Las <img>
  // ya cargadas no se recrean (no parpadean) y se conserva el scroll horizontal de las
  // filas; solo se reanuda el rotador del hero y se restaura el scroll vertical.
  if (restore && _homeNode && (Date.now() - _homeTs < _HOME_TTL)) {
    _renderToken++;  // descarta cualquier _load del Home aún en vuelo
    const t = _renderToken;
    container.appendChild(_homeNode);
    resumeHero();
    const y = _scrollY;
    requestAnimationFrame(() => requestAnimationFrame(() => {
      if (t === _renderToken) window.scrollTo(0, y);
    }));
    return;
  }
  // Sin restore (nav "Inicio"): de cero en "Todo" y arriba. Con restore pero sin nodo
  // fresco (>TTL): se re-renderiza con datos cacheados (sin re-fetch) manteniendo fuente/scroll.
  if (!restore) { _curSource = 'all'; _scrollY = 0; }
  await _load(container, cbs, { restore });
}

async function _load(container, { onPlay, onNavigate, favSet }, { restore = false } = {}) {
  const token = ++_renderToken;
  if (_heroTimer) { clearInterval(_heroTimer); _heroTimer = null; }
  container.innerHTML = '';
  // Todo el Home vive dentro de este wrapper, que se guarda en _homeNode para poder
  // re-insertarlo entero al volver atrás sin recrear las miniaturas.
  const view = document.createElement('div');
  view.className = 'home-view';
  container.appendChild(view);

  // Hero skeleton
  const heroEl = document.createElement('section');
  heroEl.className = 'hero';
  heroEl.innerHTML = `<div class="hero-bg skeleton-box" style="position:absolute;inset:0"></div>`;
  view.appendChild(heroEl);

  // Pestañas de filtro por fuente. Se rellenan con las fuentes que devuelve el
  // backend (data.sources): Atresplayer solo aparece si atresdaily esta instalado.
  const tabs = document.createElement('div');
  tabs.className = 'source-tabs';
  const buildTabs = (sources) => {
    tabs.innerHTML = '';
    for (const { id, label } of sources) {
      const b = document.createElement('button');
      b.className = 'source-tab' + (id === _curSource ? ' active' : '');
      b.textContent = label;
      b.addEventListener('click', () => {
        if (_curSource !== id) { _curSource = id; _load(container, { onPlay, onNavigate, favSet }); }
      });
      tabs.appendChild(b);
    }
  };
  // Placeholder mientras carga (RTVE/Mediaset siempre estan; Atres se anade tras el fetch).
  buildTabs([{ id: 'all', label: 'Todo' }, { id: 'rtve', label: 'RTVE' }, { id: 'mediaset', label: 'Mediaset' }]);
  view.appendChild(tabs);

  // Filas skeleton
  const rowsEl = document.createElement('section');
  rowsEl.className = 'rows-container';
  for (let i = 0; i < 3; i++) {
    const sec = document.createElement('div');
    sec.className = 'row-section';
    sec.innerHTML = `
      <div class="row-header">
        <span class="skeleton-box" style="height:16px;width:180px;border-radius:4px;display:inline-block"></span>
      </div>
      <div class="row-scroll" style="overflow:hidden"></div>`;
    const scroll = sec.querySelector('.row-scroll');
    makeSkeleton(6).forEach(c => scroll.appendChild(c));
    rowsEl.appendChild(sec);
  }
  view.appendChild(rowsEl);

  let data;
  try {
    // Cache en memoria (120s) por fuente: al volver atrás no se re-pide ni se
    // re-escanean las APIs de las cadenas. Los directos viajan en este payload, así
    // que su frescura es como mucho el TTL (la vista "Directos" va aparte, a 60s).
    data = await API.home(_curSource);
  } catch (e) {
    if (token !== _renderToken) return;  // render obsoleto: otro _load tomó el relevo
    const isNet = /failed to fetch|networkerror|load failed|http 5/i.test(e.message || '');
    heroEl.remove();
    if (isNet) {
      rowsEl.innerHTML = `
        <div class="empty-state" style="padding:80px 20px;line-height:1.7">
          <div style="font-size:1.3rem;color:var(--text);margin-bottom:12px;font-weight:600">
            El servidor de EspaDaily no está disponible
          </div>
          <div>Vuelve a Kodi y abre <b>EspaDaily WebApp</b> en el apartado Experimental.<br>
          Después recarga esta página.</div>
          <button class="btn btn-primary" style="margin-top:24px" onclick="location.reload()">Reintentar</button>
        </div>`;
    } else {
      toast(`Error cargando inicio: ${e.message}`, 'error');
      rowsEl.innerHTML = `<div class="empty-state">No se pudo cargar el contenido.</div>`;
    }
    return;
  }

  if (token !== _renderToken) return;  // render obsoleto: otro _load tomó el relevo

  // Reconstruir tabs con las fuentes reales (oculta Atresplayer si no esta disponible)
  if (Array.isArray(data.sources) && data.sources.length) buildTabs(data.sources);

  // Hero: destacados del catálogo (rota cada 9s)
  _heroItems = (data.featured || []).filter(it => it.thumb).slice(0, 5);
  if (!_heroItems.length) {
    for (const row of (data.rows || [])) {
      for (const it of (row.items || [])) {
        if (it.thumb && it.type === 'video') { _heroItems.push(it); break; }
      }
      if (_heroItems.length >= 5) break;
    }
    _heroItems = _heroItems.slice(0, 5);
  }
  if (_heroItems.length) buildHero(heroEl, onPlay);
  else heroEl.remove();

  // Filas
  rowsEl.innerHTML = '';
  if (!data.rows?.length) {
    rowsEl.innerHTML = `<div class="empty-state">No hay contenido para mostrar.</div>`;
    return;
  }
  for (const row of data.rows) {
    if (!row.items?.length) continue;
    rowsEl.appendChild(makeRow(row, onPlay, onNavigate, favSet));
  }

  // Render correcto: guardar el nodo para restaurarlo al volver atrás sin recrearlo.
  _homeNode = view;
  _homeTs = Date.now();

  // Restaurar scroll al volver atrás: dos rAF para esperar al layout/paint real, y
  // re-chequear el token por si entremedias se disparó otro render (p.ej. una pestaña).
  // Se restaura aunque sea 0: goBack no hace scrollTo(0,0), así que sin esto el Home
  // heredaría el scroll de la vista anterior (p.ej. un detalle scrolleado).
  if (restore) {
    const y = _scrollY, t = token;
    requestAnimationFrame(() => requestAnimationFrame(() => {
      if (t === _renderToken) window.scrollTo(0, y);
    }));
  }
}

function buildHero(heroEl, onPlay) {
  heroEl.innerHTML = `
    <div class="hero-bg" id="hero-bg"></div>
    <div class="hero-gradient"></div>
    <div class="hero-content" id="hero-content"></div>
    <div class="hero-dots" id="hero-dots"></div>`;

  const bg = heroEl.querySelector('#hero-bg');
  const content = heroEl.querySelector('#hero-content');
  const dotsEl = heroEl.querySelector('#hero-dots');

  const dots = _heroItems.map((_, i) => {
    const d = document.createElement('button');
    d.className = `hero-dot${i === 0 ? ' active' : ''}`;
    d.setAttribute('aria-label', `Destacado ${i + 1}`);
    d.addEventListener('click', () => { showHero(i); resetTimer(); });
    dotsEl.appendChild(d);
    return d;
  });

  function showHero(idx) {
    _heroIdx = idx;
    dots.forEach((d, i) => d.classList.toggle('active', i === idx));
    const item = _heroItems[idx];

    bg.style.opacity = '0';
    setTimeout(() => {
      bg.style.backgroundImage = `url('${item.thumb}')`;
      bg.style.opacity = '1';
    }, 200);

    const label = item.is_live ? 'EN DIRECTO' : (_SRC_LABEL[item.source] || 'DESTACADO');
    content.innerHTML = `
      <div class="hero-label">${label}</div>
      <h2 class="hero-title">${escHtml(item.title)}</h2>
      ${item.plot ? `<p class="hero-plot">${escHtml(item.plot)}</p>` : ''}
      <div class="hero-actions">
        <button class="btn btn-primary hero-play">${Icons.play} Reproducir</button>
      </div>`;
    content.querySelector('.hero-play').addEventListener('click', () => onPlay(item));
  }

  showHero(0);

  // A nivel módulo para que resumeHero() pueda reanudar la rotación tras restaurar el
  // nodo del Home (el closure sigue apuntando a este hero, que es el mismo DOM).
  _heroAdvance = () => showHero((_heroIdx + 1) % _heroItems.length);

  function resetTimer() {
    if (_heroTimer) clearInterval(_heroTimer);
    if (_heroItems.length > 1) {
      _heroTimer = setInterval(_heroAdvance, 9000);
    }
  }
  resetTimer();
}

function escHtml(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
