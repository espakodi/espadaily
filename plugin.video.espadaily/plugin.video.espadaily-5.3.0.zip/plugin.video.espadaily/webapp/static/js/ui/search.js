import { API } from '../api.js';
import { makeCard } from './grid.js';
import { toast } from './toast.js';

let _isOpen = false;
let _debounce = null;
let _onKeyRef = null;
let _onPlay, _onNavigate, _favSet;

export function openSearch(onPlay, onNavigate, favSet, initialQuery = '') {
  if (_isOpen) return;
  _isOpen = true;
  _onPlay = onPlay;
  _onNavigate = onNavigate;
  _favSet = favSet;

  const overlay = document.getElementById('search-overlay');
  overlay.classList.remove('hidden');

  const input = document.getElementById('search-input');
  const results = document.getElementById('search-results');
  results.innerHTML = '';

  input.value = initialQuery;

  // Listeners scoped a esta sesión
  input.oninput = onInput;
  document.getElementById('search-close').onclick = closeSearch;

  _onKeyRef = (e) => { if (e.key === 'Escape') closeSearch(); };
  document.addEventListener('keydown', _onKeyRef);

  // Focus tras animación de entrada
  setTimeout(() => input.focus(), 50);

  if (initialQuery) onInput({ target: input });
}

export function closeSearch() {
  if (!_isOpen) return;
  _isOpen = false;
  const overlay = document.getElementById('search-overlay');
  overlay.classList.add('hidden');
  document.removeEventListener('keydown', _onKeyRef);
  _onKeyRef = null;
  clearTimeout(_debounce);
}

function onInput(e) {
  clearTimeout(_debounce);
  const q = e.target.value.trim();
  const results = document.getElementById('search-results');

  if (!q) { results.innerHTML = ''; return; }
  if (q.length < 2) return;

  // Skeleton inmediato
  results.innerHTML = '';
  for (let i = 0; i < 8; i++) {
    const sk = document.createElement('div');
    sk.className = 'card card-landscape card-skeleton';
    sk.innerHTML = `<div class="card-img skeleton-box"></div><div class="card-info"><div class="skeleton-box" style="height:12px;width:70%;border-radius:4px;margin-bottom:6px"></div></div>`;
    results.appendChild(sk);
  }

  _debounce = setTimeout(() => doSearch(q, results), 350);
}

async function doSearch(q, container) {
  try {
    const data = await API.search(q);
    container.innerHTML = '';
    if (!data.items?.length) {
      container.innerHTML = `<div class="empty-state" style="grid-column:1/-1">Sin resultados para "${escHtml(q)}"</div>`;
      return;
    }
    for (const item of data.items) {
      container.appendChild(makeCard(item, playAndClose, navAndClose, _favSet, 'landscape'));
    }
  } catch (e) {
    container.innerHTML = '';
    toast(`Error de búsqueda: ${e.message}`, 'error');
  }
}

function playAndClose(item) {
  closeSearch();
  _onPlay(item);
}

function navAndClose(item) {
  closeSearch();
  _onNavigate(item);
}

function escHtml(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
