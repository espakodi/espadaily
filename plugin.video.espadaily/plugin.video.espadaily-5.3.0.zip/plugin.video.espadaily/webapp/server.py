# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
import os
import json
import mimetypes
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import proxy
from .api import handle_api

_STATIC_DIR = os.path.join(os.path.dirname(__file__), 'static')
_STATIC_ROOT = os.path.realpath(_STATIC_DIR)

_MIME_MAP = {
    '.html': 'text/html; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.json': 'application/json',
    '.webmanifest': 'application/manifest+json',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon',
}


class _Handler(BaseHTTPRequestHandler):

    def log_message(self, fmt, *args):
        pass  # Desactivar logs verbosos de peticiones HTTP en consola

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self):
        self._dispatch('GET')

    def do_POST(self):
        self._dispatch('POST')

    def _cors(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')

    def _dispatch(self, method):
        path = self.path

        if path.startswith('/proxy/'):
            self._handle_proxy(path)
            return

        if path.startswith('/thumb/'):
            thumb_id = path[7:].split('?')[0]
            proxy.serve_thumb(self, thumb_id)
            return

        if path.startswith('/api/'):
            try:
                handle_api(self, path, method)
            except Exception as e:
                body = json.dumps({'error': str(e)}).encode()
                self.send_response(500)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            return

        self._serve_static(path)

    def _handle_proxy(self, path):
        # Rutas de proxy HLS admitidas: /proxy/<token>/{master.m3u8 | variant | seg | key | sub}
        parts = path.lstrip('/').split('/', 2)
        if len(parts) < 3:
            self.send_error(400)
            return
        _, token, rest = parts

        # DASH: manifiesto y segmentos (relpath conserva su query para urljoin)
        if rest == 'manifest.mpd' or rest.startswith('manifest.mpd?'):
            proxy.serve_dash_manifest(self, token)
            return
        if rest.startswith('dseg/'):
            proxy.serve_dash_segment(self, token, rest[len('dseg/'):])
            return

        u_param = None
        if '?' in rest:
            rest, qs = rest.split('?', 1)
            import urllib.parse
            u_param = dict(urllib.parse.parse_qsl(qs)).get('u', '')

        if rest == 'master.m3u8':
            proxy.serve_playlist(self, token, 'master')
        elif rest == 'variant':
            proxy.serve_playlist(self, token, 'variant', u_param)
        elif rest in ('seg', 'key', 'sub'):
            proxy.serve_segment(self, token, u_param)
        else:
            self.send_error(404)

    def _serve_static(self, path):
        # Fallback a index.html para soportar el enrutamiento del lado del cliente (SPA)
        clean = path.split('?')[0]
        rel = clean.lstrip('/')
        if not rel:
            rel = 'index.html'

        full = os.path.join(_STATIC_DIR, rel.replace('/', os.sep))
        if not os.path.realpath(full).startswith(_STATIC_ROOT + os.sep):
            self.send_error(403)
            return
        if not os.path.isfile(full):
            full = os.path.join(_STATIC_DIR, 'index.html')

        try:
            with open(full, 'rb') as f:
                data = f.read()
        except OSError:
            self.send_error(404)
            return

        ext = os.path.splitext(full)[1].lower()
        ct = _MIME_MAP.get(ext, mimetypes.guess_type(full)[0] or 'application/octet-stream')

        self.send_response(200)
        self.send_header('Content-Type', ct)
        self.send_header('Content-Length', str(len(data)))
        # Imagenes/manifest: cache larga (cambian poco). Codigo (.js/.css):
        # no-cache (revalida siempre) para que los cambios se vean sin reiniciar
        # Kodi ni vaciar cache a mano. El SW es Network-First, asi que no estorba.
        if ext in ('.png', '.jpg', '.ico', '.svg', '.webmanifest'):
            self.send_header('Cache-Control', 'public, max-age=86400')
        else:
            self.send_header('Cache-Control', 'no-cache')
        self.end_headers()
        self.wfile.write(data)


def make_server(host='127.0.0.1', port=8092):
    for p in range(port, port + 8):
        try:
            srv = ThreadingHTTPServer((host, p), _Handler)
            return srv, p
        except OSError:
            continue
    raise RuntimeError('No hay puertos disponibles en el rango 8089-8096')
