# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
import sys
import json
import os
import time
import urllib.parse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import requests
import core_settings

_TOP_URL     = "https://cinemeta-catalogs.strem.io/top/catalog/movie/top.json"
_POSTER_BASE = "https://images.metahub.space/poster/medium"
_CM_TTL      = 6 * 3600
_CM_MIN      = 3


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)

def _handle():
    return int(sys.argv[1])

def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'espadaily_cinemeta_cache.json')


def _load_cache():
    empty = {"top": {}}
    try:
        path = _cache_path()
        if not os.path.exists(path):
            return empty
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        if not isinstance(data.get("top"), dict):
            return empty
        return data
    except Exception as e:
        xbmc.log(f"[EspaDaily-CM] cache load error: {e}", xbmc.LOGWARNING)
        return empty


def _save_cache(data):
    try:
        path = _cache_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, path)
    except Exception as e:
        xbmc.log(f"[EspaDaily-CM] cache save error: {e}", xbmc.LOGWARNING)


def _cache_fresh(cache):
    c = cache.get("top", {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < _CM_TTL


def _fetch_top():
    """Saca el top de pelis, None si peta."""
    try:
        r = requests.get(_TOP_URL, timeout=12)
        xbmc.log(f"[EspaDaily-CM] top -> {r.status_code}", xbmc.LOGINFO)
        if r.status_code != 200:
            return None
        metas = r.json().get("metas", [])
        films = []
        for m in metas:
            imdb_id = m.get("imdb_id") or m.get("id", "")
            name = m.get("name", "").strip()
            if not name:
                continue
            poster = f"{_POSTER_BASE}/{imdb_id}/img" if imdb_id else m.get("poster", "")
            year = str(m.get("year", ""))
            films.append({
                "id":     imdb_id,
                "title":  name,
                "poster": poster,
                "year":   year,
                "genre":  ", ".join(m.get("genres") or m.get("genre") or []),
                "plot":   m.get("description", ""),
            })
        if len(films) < _CM_MIN:
            xbmc.log(f"[EspaDaily-CM] resultado sospechoso ({len(films)} films), ignorando", xbmc.LOGWARNING)
            return None
        xbmc.log(f"[EspaDaily-CM] {len(films)} películas en top", xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log(f"[EspaDaily-CM] fetch error: {e}", xbmc.LOGERROR)
        return None


def _get_top_films():
    """Top de pelis con cache, sin tocar la UI."""
    cache = _load_cache()

    if _cache_fresh(cache):
        films = cache["top"]["films"]
        xbmc.log(f"[EspaDaily-CM] top desde caché ({len(films)} títulos)", xbmc.LOGINFO)
        return films

    fetched = _fetch_top()
    if fetched is not None:
        films = fetched
        cache["top"] = {"fetched_at": time.time(), "films": films}
    elif cache.get("top", {}).get("films"):
        films = cache["top"]["films"]
        xbmc.log("[EspaDaily-CM] Cinemeta inaccesible, usando caché caducada", xbmc.LOGWARNING)
    else:
        return []

    _save_cache(cache)
    return films


def show_top():
    import metadata_enricher as me

    films = _get_top_films()
    if not films:
        xbmcgui.Dialog().notification("EspaDaily", "No se pudo cargar Cinemeta", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    addon = xbmcaddon.Addon()
    af = core_settings.addon_fanart()

    first_imdb = films[0].get('id') if films else None
    has_meta = bool(me.enrich(imdb_id=first_imdb, use_cache_only=True)) if first_imdb else False

    if not has_meta:
        li = xbmcgui.ListItem(label="[COLOR yellow][B]Descargar metadatos completos (actores, director...)[/B][/COLOR]")
        icon_path = os.path.join(addon.getAddonInfo('path'), 'resources', 'media', 'descargas.png')
        li.setArt({'icon': icon_path})
        li.setInfo('video', {'plot': "Descarga en español: sinopsis, actores y director de ~100 películas.\nSe guarda permanentemente (30 días)."})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="cinemeta_cache_meta"), listitem=li, isFolder=False)
    else:
        li = xbmcgui.ListItem(label="[COLOR red]Borrar metadatos descargados[/COLOR]")
        li.setArt({'icon': 'DefaultIconError.png'})
        li.setInfo('video', {'plot': "Elimina los metadatos guardados para que vuelva a cargar solo con datos básicos."})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="cinemeta_clear_meta"), listitem=li, isFolder=False)

    for f in films:
        year_int = int(f['year']) if f.get('year', '').isdigit() else 0
        label = "{0} ({1})".format(f['title'], year_int) if year_int else f['title']
        li = xbmcgui.ListItem(label=label)

        meta = me.enrich(imdb_id=f.get('id'), title=f['title'], year=year_int, use_cache_only=True)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster']})
            li.setInfo('video', {
                'title':     f['title'],
                'year':      year_int,
                'genre':     f.get('genre', ''),
                'plot':      f.get('plot', ''),
                'mediatype': 'movie',
            })
            poster = f['poster']

        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=f['title'], ot=poster, mode='movie')
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())


def cache_meta():
    """Descarga y guarda metadatos TMDB para todas las películas del top de Cinemeta."""
    import metadata_enricher as me

    films = _get_top_films()
    if not films:
        xbmcgui.Dialog().notification("EspaDaily", "No hay películas para descargar", xbmcgui.NOTIFICATION_ERROR)
        return

    items = [
        {'imdb_id': f.get('id'), 'title': f['title'],
         'year': int(f['year']) if f.get('year', '').isdigit() else None,
         'media_type': 'movie'}
        for f in films
    ]

    pDialog = xbmcgui.DialogProgress()
    pDialog.create("EspaDaily", "Descargando metadatos Cinemeta...")
    try:
        count = me.batch_fetch_with_progress(items, pDialog)
    finally:
        pDialog.close()

    xbmcgui.Dialog().notification(
        "EspaDaily",
        "Metadatos guardados: {0}/{1}".format(count, len(items)),
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")


def clear_meta():
    """Elimina del caché los metadatos de las películas de Cinemeta."""
    import metadata_enricher as me

    films = _get_top_films()
    imdb_ids = [f.get('id') for f in films if f.get('id')]
    me.delete_by_imdb_ids(imdb_ids)
    xbmcgui.Dialog().notification("EspaDaily", "Metadatos de Cinemeta eliminados", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")
