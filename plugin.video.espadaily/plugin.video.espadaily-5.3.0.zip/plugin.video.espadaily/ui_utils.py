# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
# Helpers de interfaz, serializacion y entrada de texto.
import os
import sys
import json
import threading
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import core_settings

ADDON = xbmcaddon.Addon()
ICON_MAIN = os.path.join(ADDON.getAddonInfo('path'), 'icon.jpg')
_MEDIA_DIR = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'media')

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
}

def media_icon(filename):
    p = os.path.join(_MEDIA_DIR, filename)
    return p if os.path.exists(p) else ''

def get_params():
    p = {}
    if len(sys.argv) >= 3 and sys.argv[2]:
        p = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    return p

def add_item(action, title, url='', thumbnail='', extra='', folder=True, isPlayable=False, plot='', fanart='', context=None, **kwargs):
    li = xbmcgui.ListItem(title)
    art = {}
    if thumbnail:
        art['icon'] = thumbnail
        art['thumb'] = thumbnail
    if not fanart:
        fanart = core_settings.addon_fanart()
    if fanart:
        art['fanart'] = fanart
    li.setArt(art)
    info = {'title': title}
    if plot:
        info['plot'] = plot
    li.setInfo('video', info)
    if isPlayable:
        li.setProperty('IsPlayable', 'true')
        folder = False
    if context:
        li.addContextMenuItems(context)
    u = f'{sys.argv[0]}?action={action}&title={urllib.parse.quote(title)}&url={urllib.parse.quote(url)}&extra={urllib.parse.quote(extra)}'
    for key, value in kwargs.items():
        u += f'&{key}={urllib.parse.quote(str(value))}'
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=li, isFolder=folder)

def close_item_list():
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def play_resolved(url):
    li = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)

def get_path(filename):
    p = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    return os.path.join(p, filename)

def load_json(name, default=None):
    try:
        with open(get_path(name), 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        if default is not None:
            return default
        if 'settings' in name or 'config' in name or 'last_adv' in name:
            return {}
        return []

def save_json(name, data):
    path = get_path(name)
    tmp = f'{path}.{os.getpid()}.{threading.get_ident()}.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f)
        os.replace(tmp, path)
    except Exception as e:
        try:
            os.remove(tmp)
        except OSError:
            pass
        xbmc.log(f'[EspaDaily] Error guardando {name}: {e}', xbmc.LOGERROR)

_ask_choice = None

def get_text(title, default=''):
    global _ask_choice
    mode = load_json('settings.json').get('web_input_mode', 'keyboard')
    use_web = mode == 'web'
    if mode == 'ask':
        if _ask_choice is None:
            sel = xbmcgui.Dialog().select('Como quieres escribir?',
                ['Teclado de Kodi', 'Escribir desde el movil/PC'])
            if sel < 0:
                return ''
            _ask_choice = sel
        use_web = _ask_choice == 1
    if use_web:
        try:
            import web_input
            r = web_input.receive_text(title, default)
            if r is not None:
                return r
        except Exception as e:
            xbmc.log(f'[EspaDaily] web_input no disponible, uso teclado: {e}', xbmc.LOGWARNING)
    kb = xbmc.Keyboard(default, title)
    kb.doModal()
    return kb.getText() if kb.isConfirmed() else ''
