# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
#
# Compartido por url_player.py y webapp/api.py.
# Devuelve URL de variante HLS de DM (vod*.cf.dmcdn.net) en vez del master:
# cdndirector.dailymotion.com da 403 con el urllib3 de Kodi 21 (TLS fingerprint
# bloqueado por DM); el urllib3 del Python del sistema sí pasa.
#
# Cascada para descargar el master HLS:
#   1. requests directo: falla con el urllib3 viejo de Kodi.
#   2. requests.Session con warmup (cookies ts_e/dmvk/__qca).
#   3. subprocess al Python del sistema (solo Windows): TLS moderno.
#   4. urllib.request stdlib como último recurso.
import json
import re
import sys
import urllib.parse
import urllib.request


_UA_DM = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36"
)
HEADERS_DM = {
    "User-Agent": _UA_DM,
    "Origin": "https://www.dailymotion.com",
    "Referer": "https://www.dailymotion.com/",
}

# Script inline para subprocess. Usa urllib3 del Python del sistema, que bypasea
# el fingerprint TLS que bloquea Kodi. Imprime el master HLS en stdout.
_FETCH_MASTER_SCRIPT = r'''
import sys, urllib.request
url = sys.argv[1]
hdr = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
       "Origin":"https://www.dailymotion.com","Referer":"https://www.dailymotion.com/"}
try:
    import requests
    r = requests.get(url, headers=hdr, timeout=15)
    if r.status_code != 200:
        sys.exit(10 + (r.status_code // 100))
    sys.stdout.buffer.write(r.content)
except ImportError:
    r = urllib.request.urlopen(urllib.request.Request(url, headers=hdr), timeout=15)
    if r.getcode() != 200:
        sys.exit(20)
    sys.stdout.buffer.write(r.read())
'''


def _log(msg, level='info'):
    try:
        import xbmc
        lvl = {'info': xbmc.LOGINFO, 'warning': xbmc.LOGWARNING,
               'error': xbmc.LOGERROR}.get(level, xbmc.LOGINFO)
        xbmc.log(f"[dm_resolver] {msg}", lvl)
    except Exception:
        pass


def _fetch_master_direct(url, timeout=15):
    try:
        import requests
        r = requests.get(url, headers=HEADERS_DM, timeout=timeout)
        if r.status_code == 200 and r.text:
            return r.text
        _log(f"direct status={r.status_code} bytes={len(r.text)}", 'warning')
    except Exception as exc:
        _log(f"direct exception: {exc}", 'warning')
    return None


def _fetch_master_warmup(url, timeout=15):
    try:
        import requests
        s = requests.Session()
        s.get("https://www.dailymotion.com/", headers=HEADERS_DM, timeout=timeout)
        r = s.get(url, headers=HEADERS_DM, timeout=timeout)
        if r.status_code == 200 and r.text:
            _log(f"warmup OK cookies={sorted(s.cookies.keys())}", 'info')
            return r.text
        _log(f"warmup status={r.status_code} bytes={len(r.text)} cookies={sorted(s.cookies.keys())}", 'warning')
    except Exception as exc:
        _log(f"warmup exception: {exc}", 'warning')
    return None


def _fetch_master_subprocess(url, timeout=20):
    if not sys.platform.startswith('win'):
        return None
    try:
        import subprocess
        p = subprocess.run(
            ['python', '-c', _FETCH_MASTER_SCRIPT, url],
            capture_output=True, timeout=timeout,
            creationflags=0x08000000,  # CREATE_NO_WINDOW
        )
        if p.returncode == 0 and p.stdout:
            text = p.stdout.decode('utf-8', errors='replace')
            if text:
                _log(f"subprocess OK bytes={len(text)}", 'info')
                return text
        stderr = (p.stderr or b'').decode('utf-8', errors='replace')[:200]
        _log(f"subprocess rc={p.returncode} stderr={stderr}", 'warning')
    except FileNotFoundError:
        _log("subprocess: python no encontrado en PATH", 'warning')
    except Exception as exc:
        _log(f"subprocess exception: {exc}", 'warning')
    return None


def _fetch_master_urllib(url, timeout=15):
    try:
        req = urllib.request.Request(url, headers=HEADERS_DM)
        resp = urllib.request.urlopen(req, timeout=timeout)
        if resp.getcode() == 200:
            return resp.read().decode('utf-8', errors='replace')
    except Exception as exc:
        _log(f"urllib exception: {exc}", 'warning')
    return None


def _fetch_master(url):
    """Un master válido debe contener #EXT-X-STREAM-INF, no solo cabeceras HTTP."""
    for strategy in (_fetch_master_direct, _fetch_master_warmup,
                     _fetch_master_subprocess, _fetch_master_urllib):
        text = strategy(url)
        if text and '#EXT-X-STREAM-INF' in text:
            return text
    return None


def fetch_hls_variants(master_url, headers=None):
    """`headers` se ignora, se usan HEADERS_DM. Parámetro mantenido por compat."""
    from urllib.parse import urljoin

    text = _fetch_master(master_url)
    if not text:
        return []

    variants = []
    current_bw = 0
    current_res = ''
    expecting = False
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        if line.startswith('#EXT-X-STREAM-INF'):
            bw_m = re.search(r'BANDWIDTH=(\d+)', line)
            res_m = re.search(r'RESOLUTION=(\d+x\d+)', line)
            current_bw = int(bw_m.group(1)) if bw_m else 0
            current_res = res_m.group(1) if res_m else ''
            expecting = True
        elif expecting and not line.startswith('#'):
            url = line if line.startswith('http') else urljoin(master_url, line)
            url = url.split('#')[0]  # quitar fragmentos #cell=cf4
            variants.append({'url': url, 'bandwidth': current_bw, 'resolution': current_res})
            expecting = False
    variants.sort(key=lambda x: x['bandwidth'], reverse=True)
    return variants


def resolve(vid, max_height=1080):
    """Resuelve un vid de DM a una variante HLS directa (vod*.cf.dmcdn.net).
    Devuelve {'url', 'mime', 'subs', 'headers'} o None si falla."""
    if not vid or not isinstance(vid, str) or not vid.strip():
        return None

    meta_url = f"https://www.dailymotion.com/player/metadata/video/{urllib.parse.quote(vid.strip())}"
    try:
        import requests
        r = requests.get(meta_url, headers=HEADERS_DM, timeout=15)
        if r.status_code != 200 or not r.text:
            _log(f"metadata status={r.status_code} vid={vid}", 'warning')
            return None
        data = r.json()
    except ImportError:
        try:
            req = urllib.request.Request(meta_url, headers=HEADERS_DM)
            data = json.loads(urllib.request.urlopen(req, timeout=15).read().decode('utf-8'))
        except Exception as exc:
            _log(f"metadata urllib error vid={vid}: {exc}", 'warning')
            return None
    except Exception as exc:
        _log(f"metadata error vid={vid}: {exc}", 'warning')
        return None

    if not isinstance(data, dict) or data.get('error'):
        return None

    qualities = data.get('qualities', {}) or {}
    subs = []
    for sub_list in (data.get('subtitles') or {}).values():
        if isinstance(sub_list, list):
            for s in sub_list:
                if isinstance(s, dict) and s.get('url'):
                    subs.append(s['url'])

    # MP4 directo (raro en la API actual, defensivo).
    best_mp4, best_res = None, 0
    for res_key, fmts in qualities.items():
        if res_key == 'auto':
            continue
        try:
            res_val = int(res_key)
        except (ValueError, TypeError):
            continue
        if res_val > max_height:
            continue
        for fmt in fmts:
            if isinstance(fmt, dict) and fmt.get('type') == 'video/mp4' and res_val > best_res:
                best_mp4 = fmt.get('url')
                best_res = res_val
    if best_mp4:
        _log(f"MP4 directo {best_res}p vid={vid}", 'info')
        return {'url': best_mp4, 'mime': 'video/mp4', 'subs': subs, 'headers': HEADERS_DM}

    hls_master = None
    for item in qualities.get('auto', []) or []:
        if isinstance(item, dict) and item.get('type') == 'application/x-mpegURL':
            hls_master = item.get('url')
            if hls_master:
                break
    if not hls_master:
        _log(f"sin HLS en metadata vid={vid}", 'warning')
        return None

    variants = fetch_hls_variants(hls_master)
    if not variants:
        _log(f"sin variantes para vid={vid} (todas las estrategias fallaron)", 'error')
        return None

    filtered = []
    for v in variants:
        res = v.get('resolution', '')
        try:
            height = int(res.split('x')[1]) if 'x' in res else 0
        except (ValueError, IndexError):
            height = 0
        if height == 0 or height <= max_height:
            filtered.append(v)
    chosen = filtered[0] if filtered else variants[-1]
    _log(f"variante {chosen.get('resolution','?')} bw={chosen['bandwidth']} vid={vid}", 'info')
    return {'url': chosen['url'], 'mime': 'application/x-mpegURL', 'subs': subs, 'headers': HEADERS_DM}
