# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
# Normalizador para el Modo Cine y la WebApp. Capa de adaptacion pura:
# toda peticion de red pasa por connector. Aqui no hay URLs de APIs ni HTTP propio.
import html
import re
import urllib.parse

import connector

_TAG_RE = re.compile(r'<[^>]+>')


def _clean(t):
    """Quita etiquetas HTML y desescapa entidades de las sinopsis."""
    if not t:
        return ""
    return _TAG_RE.sub('', html.unescape(t)).strip()

# (nombre visible, id interno, fuente). El id lleva prefijo de plataforma para
# que fetch_cat_rows sepa a que funcion del connector despachar.
CATS = [
    ("Series",             "rtve:864",          "rtve"),
    ("Cine",               "rtve:866",          "rtve"),
    ("Documentales",       "rtve:863",          "rtve"),
    ("Programas",          "rtve:102610",       "rtve"),
    ("Infantil",           "rtve:865",          "rtve"),
    ("Series Mediaset",    "ms:series-online",  "mediaset"),
    ("Pelis Mediaset",     "ms:peliculas",      "mediaset"),
    ("Programas Mediaset", "ms:programas-tv",   "mediaset"),
]

# Categorias de Atresplayer al final (debajo de Mediaset). Se toman del connector
# para no duplicar los ids ofuscados; cada id lleva prefijo "atres:".
try:
    CATS += [(f"{c['title']} Atresplayer", f"atres:{c['id']}", "atres")
             for c in (connector.get_platform_cats("atresplayer") or [])]
except Exception:
    pass

SOURCE_LABEL = {"rtve": "RTVE", "mediaset": "Mediaset", "atres": "Atresplayer"}


def fetch_cat_rows(cat_id, page=0):
    """Lista de programas de una categoria, normalizados. page base-0."""
    if cat_id.startswith("rtve:"):
        raw = connector.fetch_rtve_list(cat_id[5:], page=page + 1)
        return [_norm_rtve_item(i) for i in (raw or [])]
    if cat_id.startswith("ms:"):
        raw = connector.fetch_mediaset_list(cat_id[3:], page + 1)
        return [_norm_ms_item(i) for i in (raw or [])]
    if cat_id.startswith("atres:"):
        # Atresplayer pagina en base-0 (a diferencia de RTVE/Mediaset).
        raw = connector.fetch_atres_list(cat_id[len("atres:"):], page=page)
        return [_norm_atres_item(i) for i in (raw or [])]
    return []


def search_catalogs(q):
    """Programas de los catalogos de las cadenas que coinciden con q. Devuelve items
    tipo 'programa' (con href espa://) que navegan a sus episodios. La busqueda por
    texto vive en el connector. RTVE/Mediaset se anadiran cuando el connector exponga
    su busqueda directa."""
    out = []
    try:
        out += [_norm_atres_item(i) for i in (connector.search_atres(q) or [])
                if (i.get("link") or {}).get("href")]
    except Exception:
        pass
    try:
        out += [_norm_rtve_item(i) for i in (connector.search_rtve(q) or [])]
    except Exception:
        pass
    try:
        out += [_norm_ms_search_item(i) for i in (connector.search_mediaset(q) or [])]
    except Exception:
        pass
    return out


def _norm_ms_search_item(i):
    # SeriesItem del buscador de Mediaset: estructura distinta a la del catalogo MAB.
    cl = i.get("cardLink") or {}
    val = cl.get("value", "")
    path = urllib.parse.urlparse(val).path if val.startswith("http") else val
    rid = cl.get("referenceId", "")
    thumb = (f"https://img-prod-api2.mediasetplay.mediaset.it/api/images/mse/v5/esp/"
             f"{rid}/image_vertical/500/700?r=") if rid else ""
    return {
        "title": i.get("cardTitle", "Sin titulo"),
        "source": "mediaset",
        "thumb": thumb,
        "href": "espa://ms/prog/" + urllib.parse.quote(path, safe=""),
        "plot": "",
    }


def fetch_episodes(href):
    """Episodios de un programa a partir de su href interno espa://."""
    if href.startswith("espa://rtve/prog/"):
        pid = href.rsplit("/", 1)[-1]
        return [_norm_rtve_ep(e) for e in (connector.fetch_rtve_episodes(pid) or [])]
    if href.startswith("espa://ms/prog/"):
        url = urllib.parse.unquote(href[len("espa://ms/prog/"):])
        return [_norm_ms_ep(e) for e in (connector.fetch_mediaset_episodes(url, "") or [])]
    if href.startswith("espa://atres/prog/"):
        url = urllib.parse.unquote(href[len("espa://atres/prog/"):])
        return [_norm_atres_ep(e) for e in (connector.fetch_atres_program_episodes(url) or [])]
    return []


def _norm_rtve_item(i):
    thumb = connector.fix_img(i.get("imagen", ""))
    return {
        "title": i.get("title", "Sin titulo"),
        "source": "rtve",
        "thumb": thumb,
        "href": f"espa://rtve/prog/{i.get('id', '')}",
        "plot": _clean(i.get("longDescription") or i.get("description") or "")[:600],
    }


def _norm_ms_item(i):
    imgs = i.get("images", {}) or {}
    thumb = connector.fix_img(imgs.get("main") or imgs.get("poster") or "")
    return {
        "title": i.get("title", "Sin titulo"),
        "source": "mediaset",
        "thumb": thumb,
        "href": "espa://ms/prog/" + urllib.parse.quote(i.get("url", ""), safe=""),
        "plot": _clean(i.get("description") or "")[:600],
    }


def _norm_atres_item(i):
    img = i.get("image", {}) or {}
    thumb = connector.fix_img(img.get("pathHorizontal") or img.get("pathVertical") or "")
    href = (i.get("link", {}) or {}).get("href", "")
    return {
        "title": i.get("title", "Sin titulo"),
        "source": "atres",
        "thumb": thumb,
        "href": "espa://atres/prog/" + urllib.parse.quote(href, safe=""),
        "plot": _clean(i.get("description") or "")[:600],
    }


def _norm_atres_ep(e):
    img = e.get("image", {}) or {}
    thumb = connector.fix_img(img.get("pathHorizontal") or img.get("pathVertical") or "")
    name = e.get("name", "")
    title = e.get("title", "Episodio")
    eid = e.get("id", "")
    if not eid:
        m = re.search(r'/episode/([a-fA-F0-9]{20,30})', (e.get("link", {}) or {}).get("href", ""))
        eid = m.group(1) if m else ""
    return {
        "title": f"{name} - {title}" if name else title,
        "source": "atres",
        "thumb": thumb,
        # contentId resoluble: atres:<eid> -> connector.resolve_atres_episode(eid)
        "vid": f"atres:{eid}" if eid else "",
        "plot": _clean(e.get("description") or "")[:600],
    }


def _norm_rtve_ep(e):
    thumb = connector.fix_img(e.get("imagen", ""))
    return {
        "title": e.get("title", "Episodio"),
        "source": "rtve",
        "thumb": thumb,
        # contentId resoluble: rtve:<video_id> -> rtve.es/v/<id>/
        "vid": f"rtve:{e.get('id', '')}",
        "plot": _clean(e.get("longDescription") or e.get("description") or "")[:600],
    }


def _norm_ms_ep(e):
    # fetch_mediaset_episodes devuelve {title, image, url(path)}
    thumb = e.get("image", "") or ""
    if thumb.startswith("//"):
        thumb = "https:" + thumb
    ep_path = e.get("url", "")
    return {
        "title": e.get("title", "Episodio"),
        "source": "mediaset",
        "thumb": thumb,
        # contentId resoluble: ms:<quoted path> -> mitele.es<path>
        "vid": "ms:" + urllib.parse.quote(ep_path, safe=""),
        "plot": "",
    }


def eid_for(vid):
    """Convierte un contentId normalizado en la URL original que espera ep_dialog."""
    if vid.startswith("rtve:"):
        return f"https://www.rtve.es/v/{vid[5:]}/"
    if vid.startswith("ms:"):
        path = urllib.parse.unquote(vid[3:])
        return path if path.startswith("http") else ("https://www.mitele.es" + path)
    return ""
