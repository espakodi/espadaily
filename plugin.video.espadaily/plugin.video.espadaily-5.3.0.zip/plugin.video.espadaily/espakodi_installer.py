# -*- coding: utf-8 -*-
# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
# Módulo de instalación de el ecosistema EspaKodi.

import json
import os
import re
import sys
import urllib.parse
import zipfile

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

EK_REPO_POLL_TIMEOUT_S  = 20
EK_ADDON_POLL_TIMEOUT_S = 60
EK_POLL_INTERVAL_MS     = 500
EK_MAX_REPO_ZIP_BYTES   = 50 * 1024 * 1024
EK_MAX_ADDON_ZIP_BYTES  = 200 * 1024 * 1024

EK_OWN_ADDON_ID = "plugin.video.espadaily"

# Definición de metadatos de addons de EspaKodi (addon_id, repo_id, zip_url, source_url, name, plot, fallback_icon)

EK_ADDONS = [
    (
        "plugin.video.espatv",
        "repository.espatv",
        "https://raw.githubusercontent.com/espakodi/espatv/main/repository.espatv-1.0.0.zip",
        "https://espakodi.github.io/espatv/",
        "EspaTV",
        "TDT, RTVE a la carta, búsqueda en YouTube y Dailymotion, catálogo de vídeos, radio, podcasts, reproducción de enlaces, noticias, meteorología, agenda deportiva y mucho más.",
        "directo.png",
    ),
    (
        "plugin.video.espadaily",
        "repository.espadaily",
        "https://fullstackcurso.github.io/espadaily/repository.espadaily-1.0.2.zip",
        "https://fullstackcurso.github.io/espadaily/",
        "EspaDaily",
        "EspaDaily permite explorar catálogos de televisión española y buscar vídeos públicos en internet que coincidan.",
        "busqueda.png",
    ),
    (
        "plugin.video.atresdaily",
        "repository.atresdaily",
        "https://espatv.github.io/atresdaily/repository.atresdaily-1.0.1.zip",
        "https://espatv.github.io/atresdaily/",
        "AtresDaily",
        "Disfruta del contenido de A3Player con la potencia de AtresDaily. Búsquedas inteligentes y programación en directo.",
        "play_generic.png",
    ),
    (
        "plugin.program.loiolog",
        "repository.loiolog",
        "https://raw.githubusercontent.com/loioloio/loiolog/main/repository.loiolog-1.0.0.zip",
        "https://loioloio.github.io/loiolog/",
        "loiolog",
        "Visualiza y busca en el log de Kodi con un visor de colores por severidad. Filtra por addon, texto o expresiones regulares. Exporta a TXT o JSON, comparte el log subiendo a internet o ábrelo en el móvil desde tu red local. Consulta estadísticas del log, compara errores entre sesiones y gestiona los logs anteriores.",
        "adv_log.png",
    ),
    (
        "plugin.program.flowfavmanager",
        "repository.flowfavmanager",
        "https://loioloio.github.io/flowfav/repository.flowfavmanager-1.0.0.zip",
        "https://loioloio.github.io/flowfav/",
        "Flow FavManager",
        "Flow FavManager mejora la experiencia de gestión de favoritos en Kodi.\nPermite organizarlos, personalizar su apariencia y las acciones que realizan. Incluye herramientas de copia de seguridad, un editor intuitivo, perfiles y ordenación por secciones, entre otras funciones.",
        "favoritos.png",
    ),
    (
        "plugin.video.streamninja",
        "repository.streamninja",
        "https://raw.githubusercontent.com/fullstackcurso/estreamninja/main/repository.streamninja-1.0.0.zip",
        "https://fullstackcurso.github.io/estreamninja/",
        "StreamNinja",
        "StreamNinja permite enviar URLs a Kodi desde un móvil o PC mediante una web local efímera, o bien recibirlas directamente desde otros addons. Soporta Dailymotion, YouTube, AceStream, Torrents y casi cualquier enlace de vídeo.",
        "srch_externa.png",
    ),
    (
        "plugin.video.topzilla",
        "repository.topzilla",
        "https://raw.githubusercontent.com/espatv/topzilla/main/repository.topzilla-1.0.0.zip",
        "https://espatv.github.io/topzilla/",
        "TopZilla",
        "TopZilla muestra rankings, información y vídeos relacionados de películas y series. Además permite buscarlas, filtrarlas y guardar en tu biblioteca o consultar sus fichas con solo dos clics, estés donde estés en tu Kodi.",
        "busqueda.png",
    ),
    (
        "plugin.program.loiolink",
        "repository.loiolink",
        "https://loiolo.io/repository.loiolink-1.0.0.zip",
        "https://loiolo.io/",
        "loiolink",
        "• Mando a distancia: Controla lo que estás viendo, navega por los menús o gestiona tus addons desde la web.\n• Toda tu colección: Navega por tus películas, series y música desde el navegador y reprodúcelas en la TV.\n• Streaming al móvil: Envía el vídeo desde el televisor a tu móvil, tablet o PC.\n• Favoritos: Elimina, reordena o edita accesos directos desde el navegador.\n• Escribe sin el mando: Escribe búsquedas o enlaces largos en el navegador y aparecerán al instante en Kodi.\n• Envío de vídeos, torrents, listas M3U o enlaces AceStream para reproducirlos al vuelo o grabarlos.\n• Escáner web y Telegram: Rastrea páginas o canales para recopilar y reproducir torrents, vídeos y enlaces.\n• Instalación de addons y archivos: Envía ZIPs de addons o APKs desde el navegador para instalarlos al instante.\n• Grabación HLS, explorador de archivos, apagado remoto y copia de seguridad.",
        "info.png",
    ),
]


def _ek_addon_is_installed(addon_id):
    try:
        xbmcaddon.Addon(addon_id)
        return True
    except Exception:
        return False


def _ek_addon_dir_present(addon_id):
    addon_dir = xbmcvfs.translatePath("special://home/addons/{0}/".format(addon_id))
    return os.path.isdir(addon_dir) and os.path.isfile(os.path.join(addon_dir, "addon.xml"))


def _ek_jsonrpc(method, params=None):
    req = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        req["params"] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    except Exception:
        return {}


def _ek_addon_is_known(addon_id):
    resp = _ek_jsonrpc("Addons.GetAddonDetails", {"addonid": addon_id, "properties": ["enabled"]})
    return "result" in resp and "addon" in resp.get("result", {})


def _ek_enable_addon_jsonrpc(addon_id):
    resp = _ek_jsonrpc("Addons.SetAddonEnabled", {"addonid": addon_id, "enabled": True})
    return resp.get("result") == "OK"


def _ek_try_recover_addon(addon_id):
    if _ek_addon_is_known(addon_id):
        if _ek_enable_addon_jsonrpc(addon_id):
            xbmc.sleep(800)
            if _ek_addon_is_installed(addon_id):
                return True
    if not _ek_addon_dir_present(addon_id):
        return False
    xbmc.executebuiltin("UpdateLocalAddons()")
    xbmc.sleep(1500)
    if _ek_addon_is_known(addon_id) and _ek_enable_addon_jsonrpc(addon_id):
        xbmc.sleep(800)
        if _ek_addon_is_installed(addon_id):
            return True
    xbmc.executebuiltin("EnableAddon({0})".format(addon_id))
    xbmc.sleep(1500)
    return _ek_addon_is_installed(addon_id)


def _ek_addon_status_label(addon_id):
    try:
        xbmcaddon.Addon(addon_id)
        return "[COLOR lime]Instalado[/COLOR]"
    except Exception:
        pass
    if _ek_addon_is_known(addon_id):
        return "[COLOR orange]Deshabilitado[/COLOR]"
    return "[COLOR gray]No instalado[/COLOR]"


def _ek_addon_icon(addon_id, fallback=None):
    try:
        ad = xbmcaddon.Addon(addon_id)
        path = ad.getAddonInfo("path")
        for name in ("icon.png", "icon.jpg"):
            p = os.path.join(path, name)
            if os.path.exists(p):
                return p
    except Exception:
        pass
    media_dir = os.path.join(xbmcaddon.Addon().getAddonInfo("path"), "resources", "media")
    return fallback or os.path.join(media_dir, "play_generic.png")


def _addon_fanart():
    try:
        import core_settings
        return core_settings.addon_fanart()
    except Exception:
        return xbmcaddon.Addon().getAddonInfo("fanart")


def _ek_get_repo_datadir(repo_id):
    repo_xml = xbmcvfs.translatePath("special://home/addons/{0}/addon.xml".format(repo_id))
    if not os.path.isfile(repo_xml):
        return None
    try:
        with open(repo_xml, "r", encoding="utf-8") as f:
            content = f.read()
        m = re.search(r"<datadir[^>]*>\s*([^<\s]+)\s*</datadir>", content)
        if m:
            url = m.group(1).strip()
            if not url.endswith("/"):
                url += "/"
            return url
    except Exception as e:
        xbmc.log("[EspaDaily] No se pudo leer datadir del repo {0}: {1}".format(repo_id, e), xbmc.LOGWARNING)
    return None


def _ek_find_addon_version_in_index(addons_xml_text, addon_id):
    try:
        m = re.search(
            r'<addon[^>]*\bid="' + re.escape(addon_id) + r'"[^>]*\bversion="([^"]+)"',
            addons_xml_text
        )
        if m:
            return m.group(1)
        m = re.search(
            r'<addon[^>]*\bversion="([^"]+)"[^>]*\bid="' + re.escape(addon_id) + r'"',
            addons_xml_text
        )
        if m:
            return m.group(1)
    except Exception:
        pass
    return None


def _ek_install_addon_zip_directly(addon_id, repo_id, friendly_name):
    try:
        datadir = _ek_get_repo_datadir(repo_id)
        if not datadir:
            xbmc.log("[EspaDaily] Fallback ({0}): no se pudo obtener datadir de {1}".format(friendly_name, repo_id), xbmc.LOGWARNING)
            return False
        try:
            r = requests.get(datadir + "addons.xml", timeout=20)
            if r.status_code != 200:
                return False
            addons_xml = r.text
        except Exception:
            return False
        version = _ek_find_addon_version_in_index(addons_xml, addon_id)
        if not version:
            return False
        addon_zip_url = "{0}{1}/{1}-{2}.zip".format(datadir, addon_id, version)
        try:
            r = requests.get(addon_zip_url, timeout=60)
            if r.status_code != 200:
                return False
            if len(r.content) < 4 or r.content[:2] != b"PK":
                return False
            if len(r.content) > EK_MAX_ADDON_ZIP_BYTES:
                return False
        except Exception:
            return False
        addons_dir = xbmcvfs.translatePath("special://home/addons/")
        addons_dir_real = os.path.realpath(addons_dir)
        zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"), "{0}-{1}.zip".format(addon_id, version))
        with open(zip_path, "wb") as f:
            f.write(r.content)
        with zipfile.ZipFile(zip_path, "r") as zf:
            for entry in zf.namelist():
                resolved = os.path.realpath(os.path.join(addons_dir, entry))
                if not resolved.startswith(addons_dir_real):
                    raise Exception("ZIP contiene ruta sospechosa: {0}".format(entry))
            zf.extractall(addons_dir)
        try:
            os.remove(zip_path)
        except Exception:
            pass
        xbmc.executebuiltin("UpdateLocalAddons()")
        xbmc.sleep(1500)
        xbmc.executebuiltin("EnableAddon({0})".format(addon_id))
        xbmc.sleep(1500)
        for _ in range(20):
            if _ek_addon_is_installed(addon_id):
                return True
            xbmc.executebuiltin("EnableAddon({0})".format(addon_id))
            xbmc.sleep(EK_POLL_INTERVAL_MS)
        return _ek_try_recover_addon(addon_id) or _ek_addon_is_installed(addon_id)
    except Exception as e:
        xbmc.log("[EspaDaily] Fallback excepción: {0}".format(e), xbmc.LOGERROR)
        return False


def _ek_install_repo_and_addon(addon_id, repo_id, repo_zip_url, friendly_name):
    if _ek_addon_is_installed(addon_id):
        xbmcgui.Dialog().notification("EspaDaily", "{0} ya está instalado".format(friendly_name), xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin("Container.Refresh")
        return True
    if _ek_try_recover_addon(addon_id):
        xbmcgui.Dialog().notification("EspaDaily", "{0} reactivado correctamente".format(friendly_name), xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin("Container.Refresh")
        return True

    # Si el repositorio ya está instalado, omitimos la extracción para evitar problemas de concurrencia en la sesión activa.
    repo_already_present = _ek_addon_is_installed(repo_id)
    dp = xbmcgui.DialogProgress()
    dp.create(
        "EspaDaily",
        "Descargando repositorio de {0}...".format(friendly_name) if not repo_already_present
        else "Instalando {0}...".format(friendly_name)
    )
    zip_path = None
    bg = None
    try:
        if not repo_already_present:
            dp.update(5, "Descargando repositorio...")
            r = requests.get(repo_zip_url, timeout=30)
            if r.status_code != 200:
                raise Exception("Error HTTP {0}".format(r.status_code))
            if len(r.content) < 4 or r.content[:2] != b"PK":
                raise Exception("El archivo descargado no es un ZIP válido")
            if len(r.content) > EK_MAX_REPO_ZIP_BYTES:
                raise Exception("Tamaño sospechoso: {0}KB".format(len(r.content) // 1024))
            zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"), "{0}.zip".format(repo_id))
            with open(zip_path, "wb") as f:
                f.write(r.content)
            dp.update(20, "Extrayendo repositorio...")
            addons_dir = xbmcvfs.translatePath("special://home/addons/")
            addons_dir_real = os.path.realpath(addons_dir)
            with zipfile.ZipFile(zip_path, "r") as zf:
                for entry in zf.namelist():
                    resolved = os.path.realpath(os.path.join(addons_dir, entry))
                    if not resolved.startswith(addons_dir_real):
                        raise Exception("ZIP contiene ruta sospechosa: {0}".format(entry))
                zf.extractall(addons_dir)
            dp.update(35, "Registrando repositorio en Kodi...")
            xbmc.executebuiltin("UpdateLocalAddons()")
            repo_iters = (EK_REPO_POLL_TIMEOUT_S * 1000) // EK_POLL_INTERVAL_MS
            repo_ready = False
            for i in range(repo_iters):
                if dp.iscanceled():
                    raise Exception("Cancelado por el usuario")
                try:
                    xbmcaddon.Addon(repo_id)
                    repo_ready = True
                    break
                except Exception:
                    # Forzar la habilitación del addon si quedó inactivo tras la extracción del archivo.
                    if i in (4, 12, 24):
                        xbmc.executebuiltin("EnableAddon({0})".format(repo_id))
                    xbmc.sleep(EK_POLL_INTERVAL_MS)
            if not repo_ready:
                raise Exception("Kodi no registró el repositorio tras {0}s".format(EK_REPO_POLL_TIMEOUT_S))
            dp.update(55, "Activando repositorio...")
            xbmc.executebuiltin("EnableAddon({0})".format(repo_id))
            xbmc.sleep(1500)
        dp.update(65, "Actualizando índice del repositorio...")
        xbmc.executebuiltin("UpdateAddonRepos()")
        xbmc.sleep(3000)
        # Cerrar el indicador de progreso previo a la invocación nativa de instalación para evitar colisiones de interfaz.
        dp.close()
        xbmcgui.Dialog().notification("EspaDaily", "Confirma la instalación de {0}".format(friendly_name), xbmcgui.NOTIFICATION_INFO, 4000)
        xbmc.executebuiltin("InstallAddon({0})".format(addon_id))
        bg = xbmcgui.DialogProgressBG()
        bg.create("EspaDaily", "Esperando instalación de {0}...".format(friendly_name))
        addon_iters = (EK_ADDON_POLL_TIMEOUT_S * 1000) // EK_POLL_INTERVAL_MS
        addon_ready = False
        for i in range(addon_iters):
            if _ek_addon_is_installed(addon_id):
                addon_ready = True
                break
            xbmc.sleep(EK_POLL_INTERVAL_MS)
            pct = min(int((i + 1) * 100 / addon_iters), 99)
            bg.update(pct, "EspaDaily", "Esperando instalación de {0}...".format(friendly_name))
        bg.close()
        bg = None
        if not addon_ready and _ek_try_recover_addon(addon_id):
            addon_ready = True
        if addon_ready:
            xbmcgui.Dialog().notification("EspaDaily", "{0} instalado correctamente".format(friendly_name), xbmcgui.NOTIFICATION_INFO, 4000)
            xbmc.executebuiltin("Container.Refresh")
            return True
        bg = xbmcgui.DialogProgressBG()
        bg.create("EspaDaily", "Instalación automática de {0} (fallback)...".format(friendly_name))
        bg.update(50)
        ok = _ek_install_addon_zip_directly(addon_id, repo_id, friendly_name)
        bg.close()
        bg = None
        if ok:
            xbmcgui.Dialog().notification("EspaDaily", "{0} instalado correctamente".format(friendly_name), xbmcgui.NOTIFICATION_INFO, 4000)
            xbmc.executebuiltin("Container.Refresh")
            return True
        xbmcgui.Dialog().ok(
            "EspaDaily",
            "El repositorio de {0} se instaló, pero la instalación del addon no se completó.\n\n"
            "Para terminarla manualmente:\nAddons - Instalar desde repositorio - {0} - Instalar".format(friendly_name)
        )
        return False
    except Exception as e:
        try:
            dp.close()
        except Exception:
            pass
        if bg:
            try:
                bg.close()
            except Exception:
                pass
        xbmc.log("[EspaDaily] Error instalando {0}: {1}".format(friendly_name, e), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            "Error de instalación",
            "No se pudo instalar {0} automáticamente.\n\nError: {1}\n\n"
            "Puede que necesites activar Orígenes desconocidos en Ajustes.".format(friendly_name, e)
        )
        return False
    finally:
        if zip_path and os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except Exception:
                pass


def _launch_espatv():
    addon_id = "plugin.video.espatv"
    source   = "https://espakodi.github.io/espatv/"
    try:
        xbmcaddon.Addon(addon_id)
        xbmcgui.Dialog().notification("EspaDaily", "Abriendo EspaTV...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("RunAddon({0})".format(addon_id))
        return
    except Exception:
        pass
    idx = xbmcgui.Dialog().select("EspaTV - instalación",
        ["Instalador automático (puede fallar)", "Ver instrucciones de instalación manual"])
    if idx == 0:
        if xbmcgui.Dialog().yesno("EspaDaily", "EspaTV no está instalado.\n\n¿Descargar e instalar automáticamente?"):
            _ek_install_repo_and_addon(addon_id, "repository.espatv",
                "https://raw.githubusercontent.com/espakodi/espatv/main/repository.espatv-1.0.0.zip", "EspaTV")
    elif idx == 1:
        xbmcgui.Dialog().textviewer("Instrucciones EspaTV",
            "[B]Cómo instalar EspaTV[/B]\n\n"
            "1. Ajustes - Sistema - Addons - activa Orígenes desconocidos\n\n"
            "2. Ajustes - Explorador de archivos - Añadir fuente:\n   {0}\n\n"
            "3. Addons - Instalar desde un archivo zip - EspaTV\n   repository.espatv-x.x.x.zip\n\n"
            "4. Instalar desde repositorio - EspaTV - Addons de vídeo - EspaTV".format(source))


def _launch_espadaily():
    addon_id = "plugin.video.espadaily"
    source   = "https://fullstackcurso.github.io/espadaily/"
    try:
        xbmcaddon.Addon(addon_id)
        xbmc.executebuiltin("Container.Update(plugin://{0}/,replace)".format(addon_id))
        return
    except Exception:
        pass
    idx = xbmcgui.Dialog().select("EspaDaily - instalación",
        ["Instalador automático (puede fallar)", "Ver instrucciones de instalación manual"])
    if idx == 0:
        if xbmcgui.Dialog().yesno("EspaDaily", "EspaDaily no está instalado.\n\n¿Descargar e instalar automáticamente?"):
            _ek_install_repo_and_addon(addon_id, "repository.espadaily",
                "https://fullstackcurso.github.io/espadaily/repository.espadaily-1.0.2.zip", "EspaDaily")
    elif idx == 1:
        xbmcgui.Dialog().textviewer("Instrucciones EspaDaily",
            "[B]Cómo instalar EspaDaily[/B]\n\n"
            "1. Ajustes - Sistema - Addons - activa Orígenes desconocidos\n\n"
            "2. Ajustes - Explorador de archivos - Añadir fuente:\n   {0}\n\n"
            "3. Addons - Instalar desde un archivo zip - EspaDaily\n   repository.espadaily-x.x.x.zip\n\n"
            "4. Instalar desde repositorio - EspaDaily - Addons de vídeo - EspaDaily".format(source))


def _launch_atresdaily():
    addon_id = "plugin.video.atresdaily"
    source   = "https://espatv.github.io/atresdaily/"
    try:
        xbmcaddon.Addon(addon_id)
        xbmc.executebuiltin("Container.Update(plugin://{0}/,replace)".format(addon_id))
        return
    except Exception:
        pass
    idx = xbmcgui.Dialog().select("AtresDaily - instalación",
        ["Instalador automático (puede fallar)", "Ver instrucciones de instalación manual"])
    if idx == 0:
        if xbmcgui.Dialog().yesno("AtresDaily", "AtresDaily no está instalado.\n\n¿Descargar e instalar automáticamente?"):
            _ek_install_repo_and_addon(addon_id, "repository.atresdaily",
                "https://espatv.github.io/atresdaily/repository.atresdaily-1.0.1.zip", "AtresDaily")
    elif idx == 1:
        xbmcgui.Dialog().textviewer("Instrucciones AtresDaily",
            "[B]Cómo instalar AtresDaily[/B]\n\n"
            "1. Ajustes - Sistema - Addons - activa Orígenes desconocidos\n\n"
            "2. Ajustes - Explorador de archivos - Añadir fuente:\n   {0}\n\n"
            "3. Addons - Instalar desde un archivo zip - AtresDaily\n   repository.atresdaily-x.x.x.zip\n\n"
            "4. Instalar desde repositorio - AtresDaily - Addons de vídeo - AtresDaily".format(source))


def _launch_EspaDaily():
    addon_id = EK_OWN_ADDON_ID
    source   = "https://fullstackcurso.github.io/espadaily/"
    try:
        xbmcaddon.Addon(addon_id)
        xbmc.executebuiltin("Container.Update(plugin://{0}/,replace)".format(addon_id))
        return
    except Exception:
        pass
    idx = xbmcgui.Dialog().select("EspaDaily - instalación",
        ["Instalador automático (puede fallar)", "Ver instrucciones de instalación manual"])
    if idx == 0:
        if xbmcgui.Dialog().yesno("EspaDaily", "EspaDaily no está instalado.\n\n¿Descargar e instalar automáticamente?"):
            _ek_install_repo_and_addon(addon_id, "repository.espadaily",
                "https://fullstackcurso.github.io/espadaily/repository.espadaily-1.0.2.zip", "EspaDaily")
    elif idx == 1:
        xbmcgui.Dialog().textviewer("Instrucciones EspaDaily",
            "[B]Cómo instalar EspaDaily[/B]\n\n"
            "1. Ajustes - Sistema - Addons - activa Orígenes desconocidos\n\n"
            "2. Ajustes - Explorador de archivos - Añadir fuente:\n   {0}\n\n"
            "3. Addons - Instalar desde un archivo zip - EspaDaily\n   repository.espadaily-x.x.x.zip\n\n"
            "4. Instalar desde repositorio - EspaDaily - Addons de vídeo - EspaDaily".format(source))


def _launch_loiolog():
    addon_id = "plugin.program.loiolog"
    source   = "https://loioloio.github.io/loiolog/"
    try:
        xbmcaddon.Addon(addon_id)
        xbmcgui.Dialog().notification("EspaDaily", "Abriendo loiolog...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("RunAddon({0})".format(addon_id))
        return
    except Exception:
        pass
    idx = xbmcgui.Dialog().select("loiolog - instalación",
        ["Instalador automático (puede fallar)", "Ver instrucciones de instalación manual"])
    if idx == 0:
        if xbmcgui.Dialog().yesno("EspaDaily", "loiolog no está instalado.\n\n¿Descargar e instalar automáticamente?"):
            _ek_install_repo_and_addon(addon_id, "repository.loiolog",
                "https://raw.githubusercontent.com/loioloio/loiolog/main/repository.loiolog-1.0.0.zip", "loiolog")
    elif idx == 1:
        xbmcgui.Dialog().textviewer("Instrucciones loiolog",
            "[B]Cómo instalar loiolog[/B]\n\n"
            "1. Ajustes - Sistema - Addons - activa Orígenes desconocidos\n\n"
            "2. Ajustes - Explorador de archivos - Añadir fuente:\n   {0}\n\n"
            "3. Addons - Instalar desde un archivo zip - loiolog\n   repository.loiolog-x.x.x.zip\n\n"
            "4. Instalar desde repositorio - loiolog - Addons de programa - loiolog".format(source))


def _launch_flowfav():
    addon_id = "plugin.program.flowfavmanager"
    source   = "https://loioloio.github.io/flowfav/"
    try:
        xbmcaddon.Addon(addon_id)
        xbmcgui.Dialog().notification("EspaDaily", "Abriendo Flow FavManager...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("RunAddon({0})".format(addon_id))
        return
    except Exception:
        pass
    idx = xbmcgui.Dialog().select("Flow FavManager - instalación",
        ["Instalador automático (puede fallar)", "Ver instrucciones de instalación manual"])
    if idx == 0:
        if xbmcgui.Dialog().yesno("EspaDaily", "Flow FavManager no está instalado.\n\n¿Descargar e instalar automáticamente?"):
            _ek_install_repo_and_addon(addon_id, "repository.flowfavmanager",
                "https://loioloio.github.io/flowfav/repository.flowfavmanager-1.0.0.zip", "Flow FavManager")
    elif idx == 1:
        xbmcgui.Dialog().textviewer("Instrucciones Flow FavManager",
            "[B]Flow FavManager[/B] - gestor avanzado de favoritos para Kodi.\n\n"
            "1. Ajustes - Sistema - Addons - activa Orígenes desconocidos\n\n"
            "2. Ajustes - Explorador de archivos - Añadir fuente:\n   {0}\n\n"
            "3. Addons - cajita - Instalar desde archivo zip - flowfav\n   repository.flowfavmanager-1.0.0.zip\n\n"
            "4. Instalar desde repositorio - Flow FavManager Repository\n   Program add-ons - Flow FavManager".format(source))


def _launch_streamninja():
    addon_id = "plugin.video.streamninja"
    source   = "https://fullstackcurso.github.io/estreamninja/"
    try:
        xbmcaddon.Addon(addon_id)
        xbmcgui.Dialog().notification("EspaDaily", "Abriendo StreamNinja...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("RunAddon({0})".format(addon_id))
        return
    except Exception:
        pass
    idx = xbmcgui.Dialog().select("StreamNinja - instalación",
        ["Instalador automático (puede fallar)", "Ver instrucciones de instalación manual"])
    if idx == 0:
        if xbmcgui.Dialog().yesno("EspaDaily", "StreamNinja no está instalado.\n\n¿Descargar e instalar automáticamente?"):
            _ek_install_repo_and_addon(addon_id, "repository.streamninja",
                "https://raw.githubusercontent.com/fullstackcurso/estreamninja/main/repository.streamninja-1.0.0.zip", "StreamNinja")
    elif idx == 1:
        xbmcgui.Dialog().textviewer("Instrucciones StreamNinja",
            "[B]Cómo instalar StreamNinja[/B]\n\n"
            "1. Ajustes - Sistema - Addons - activa Orígenes desconocidos\n\n"
            "2. Ajustes - Explorador de archivos - Añadir fuente:\n   {0}\n\n"
            "3. Addons - Instalar desde un archivo zip - StreamNinja\n   repository.streamninja-x.x.x.zip\n\n"
            "4. Instalar desde repositorio - StreamNinja - Addons de vídeo - StreamNinja".format(source))


def _launch_topzilla():
    addon_id = "plugin.video.topzilla"
    source   = "https://espatv.github.io/topzilla/"
    try:
        xbmcaddon.Addon(addon_id)
        xbmcgui.Dialog().notification("EspaDaily", "Abriendo TopZilla...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("RunAddon({0})".format(addon_id))
        return
    except Exception:
        pass
    idx = xbmcgui.Dialog().select("TopZilla - instalación",
        ["Instalador automático (puede fallar)", "Ver instrucciones de instalación manual"])
    if idx == 0:
        if xbmcgui.Dialog().yesno("EspaDaily", "TopZilla no está instalado.\n\n¿Descargar e instalar automáticamente?"):
            _ek_install_repo_and_addon(addon_id, "repository.topzilla",
                "https://raw.githubusercontent.com/espatv/topzilla/main/repository.topzilla-1.0.0.zip", "TopZilla")
    elif idx == 1:
        xbmcgui.Dialog().textviewer("Instrucciones TopZilla",
            "[B]Cómo instalar TopZilla[/B]\n\n"
            "1. Ajustes - Sistema - Addons - activa Orígenes desconocidos\n\n"
            "2. Ajustes - Explorador de archivos - Añadir fuente:\n   {0}\n\n"
            "3. Addons - Instalar desde un archivo zip - TopZilla\n   repository.topzilla-x.x.x.zip\n\n"
            "4. Instalar desde repositorio - TopZilla - Addons de vídeo - TopZilla".format(source))


def _launch_loiolink():
    addon_id = "plugin.program.loiolink"
    source   = "https://loiolo.io/"
    try:
        xbmcaddon.Addon(addon_id)
        xbmcgui.Dialog().notification("EspaDaily", "Abriendo loiolink...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("RunAddon({0})".format(addon_id))
        return
    except Exception:
        pass
    idx = xbmcgui.Dialog().select("loiolink - instalación",
        ["Instalador automático (puede fallar)", "Ver instrucciones de instalación manual"])
    if idx == 0:
        if xbmcgui.Dialog().yesno("EspaDaily", "loiolink no está instalado.\n\n¿Descargar e instalar automáticamente?"):
            _ek_install_repo_and_addon(addon_id, "repository.loiolink",
                "https://loiolo.io/repository.loiolink-1.0.0.zip", "loiolink")
    elif idx == 1:
        xbmcgui.Dialog().textviewer("Instrucciones loiolink",
            "[B]Cómo instalar loiolink[/B]\n\n"
            "1. Ajustes - Sistema - Addons - activa Orígenes desconocidos\n\n"
            "2. Ajustes - Explorador de archivos - Añadir fuente:\n   {0}\n\n"
            "3. Addons - Instalar desde un archivo zip - loiolink\n   repository.loiolink-x.x.x.zip\n\n"
            "4. Instalar desde repositorio - loiolink - Addons de programa - loiolink".format(source))


_LAUNCH_HANDLERS = {
    "plugin.video.espatv":           _launch_espatv,
    "plugin.video.espadaily":        _launch_espadaily,
    "plugin.video.atresdaily":       _launch_atresdaily,
    "plugin.program.loiolog":        _launch_loiolog,
    "plugin.program.flowfavmanager": _launch_flowfav,
    "plugin.video.streamninja":      _launch_streamninja,
    "plugin.video.topzilla":         _launch_topzilla,
    "plugin.program.loiolink":       _launch_loiolink,
}


def launch_by_id(addon_id):
    fn = _LAUNCH_HANDLERS.get(addon_id)
    if fn:
        fn()


def open_repo_unificado():
    url = 'https://loiolo.io'
    abrir = xbmcgui.Dialog().yesno(
        'Repositorio Unificado',
        f'Añade esta URL como fuente en Kodi para instalar los addons de EspaKodi:\n\n[B]{url}[/B]\n\n¿Abrir en el navegador?',
        nolabel='Cerrar',
        yeslabel='Abrir navegador',
    )
    if not abrir:
        return
    if xbmc.getCondVisibility('System.Platform.Android'):
        xbmc.executebuiltin(f'StartAndroidActivity("","android.intent.action.VIEW","","{url}")')
        xbmcgui.Dialog().notification('EspaDaily', 'Abriendo repositorio...', xbmcgui.NOTIFICATION_INFO, 2000)
    else:
        import webbrowser
        try:
            ok = webbrowser.open(url)
        except webbrowser.Error:
            ok = False
        if not ok:
            xbmcgui.Dialog().ok('EspaDaily', f'No se pudo abrir el navegador.\n\nAccede manualmente a:\n{url}')


_PLOT_REPO_UNIFICADO = (
    'Fuente para instalar todos los addons del ecosistema EspaKodi. '
    'Añade loiolo.io como fuente en Kodi para tener acceso al repositorio con '
    'EspaTV, EspaDaily, AtresDaily, StreamNinja, loiolog, Flow FavManager, '
    'TopZilla y loiolink en un solo lugar.'
)


def render_menu(handle):
    media_dir = os.path.join(xbmcaddon.Addon().getAddonInfo("path"), "resources", "media")
    af = _addon_fanart()

    repo_icon = os.path.join(media_dir, "info_repo.png")
    li_repo = xbmcgui.ListItem(label='Repositorio Unificado')
    li_repo.setArt({'icon': repo_icon, 'fanart': af})
    li_repo.setInfo('video', {'plot': _PLOT_REPO_UNIFICADO})
    url_repo = sys.argv[0] + '?' + urllib.parse.urlencode({'action': 'ek_open_repo'})
    xbmcplugin.addDirectoryItem(handle=handle, url=url_repo, listitem=li_repo, isFolder=False)

    for addon_id, _repo_id, _zip, _src, name, plot, fallback_icon in EK_ADDONS:
        status = _ek_addon_status_label(addon_id)
        fallback_path = os.path.join(media_dir, fallback_icon) if fallback_icon else os.path.join(media_dir, "play_generic.png")
        icon = _ek_addon_icon(addon_id, fallback=fallback_path)
        if addon_id == EK_OWN_ADDON_ID:
            own_icon = os.path.join(xbmcaddon.Addon().getAddonInfo("path"), "icon.png")
            if not os.path.exists(own_icon):
                own_icon = os.path.join(xbmcaddon.Addon().getAddonInfo("path"), "icon.jpg")
            if os.path.exists(own_icon):
                icon = own_icon
        li = xbmcgui.ListItem(label="{0} - {1}".format(name, status))
        li.setArt({"icon": icon, "fanart": af})
        li.setInfo("video", {"plot": plot})
        url = sys.argv[0] + "?" + urllib.parse.urlencode({"action": "ek_launch", "addon_id": addon_id})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(handle)


# Estado de actualización del repositorio oficial del addon

_EK_OWN_REPO_PREFIX = "repository.espadaily"


def _find_own_repo():
    addons_dir = xbmcvfs.translatePath("special://home/addons/")
    try:
        _, dirs = xbmcvfs.listdir(addons_dir)
    except Exception:
        dirs = []
    for d in dirs:
        if d.startswith(_EK_OWN_REPO_PREFIX):
            addon_xml = os.path.join(addons_dir, d, "addon.xml")
            if xbmcvfs.exists(addon_xml):
                return d
    return None


def repo_status_label():
    if _find_own_repo():
        return "Actualizaciones: [COLOR lime]● INSTALADO[/COLOR]"
    return "Actualizaciones: [COLOR orange]○ NO DETECTADO[/COLOR]"


def check_repo_status():
    repo_id = _find_own_repo()
    if repo_id:
        xbmcgui.Dialog().ok(
            "EspaDaily - Actualizaciones",
            "El repositorio oficial está instalado.\n\n"
            "Las actualizaciones de EspaDaily llegarán automáticamente a través de él.\n\n"
            "Si quieres forzar una comprobación: Addons - Mis addons - {0} - Actualizar".format(repo_id)
        )
    else:
        xbmcgui.Dialog().ok(
            "EspaDaily - Actualizaciones",
            "El repositorio oficial [B]no está detectado[/B].\n\n"
            "Sin él, EspaDaily no recibirá actualizaciones automáticas.\n\n"
            "Instálalo manualmente desde el repositorio oficial de EspaDaily."
        )
