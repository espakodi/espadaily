# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
import os
import json
import re as _re
import threading
import time
import xbmc
import xbmcaddon
import xbmcvfs
import xbmcgui



_PROFILE_PATH = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
if not os.path.exists(_PROFILE_PATH): os.makedirs(_PROFILE_PATH)

_CONTEXT_FILE = os.path.join(_PROFILE_PATH, "full_context.json")
_DEBUG_FILE = os.path.join(_PROFILE_PATH, 'debug_state.json')
_FROZEN_FILE = os.path.join(_PROFILE_PATH, 'frozen_state.json')
_RECENT_FILE = os.path.join(_PROFILE_PATH, 'recent_state.json')
_FAV_FILE = os.path.join(_PROFILE_PATH, 'favorites.json')
_DL_FILE = os.path.join(_PROFILE_PATH, 'downloads_history.json')
_DURATION_FILE = os.path.join(_PROFILE_PATH, 'min_duration.json')
_ADVANCED_SEARCH_FILE = os.path.join(_PROFILE_PATH, 'advanced_search_state.json')
_SNAPSHOT_CTX_FILE = os.path.join(_PROFILE_PATH, 'snapshot_context.json')
_PALANTIR_INTEGRATION_FILE = os.path.join(_PROFILE_PATH, 'palantir_integration_state.json')
_BALANDRO_INTEGRATION_FILE = os.path.join(_PROFILE_PATH, 'balandro_integration_state.json')
_ALFA_INTEGRATION_FILE = os.path.join(_PROFILE_PATH, 'alfa_integration_state.json')
_JACKTOOK_INTEGRATION_FILE = os.path.join(_PROFILE_PATH, 'jacktook_integration_state.json')
_ATRESDAILY_INTEGRATION_FILE = os.path.join(_PROFILE_PATH, 'atresdaily_integration_state.json')
_ESPATV_INTEGRATION_FILE = os.path.join(_PROFILE_PATH, 'espatv_integration_state.json')
_TOPZILLA_INTEGRATION_FILE = os.path.join(_PROFILE_PATH, 'topzilla_integration_state.json')
_TMDBHELPER_INTEGRATION_FILE = os.path.join(_PROFILE_PATH, 'tmdbhelper_integration_state.json')
_IPTV_ANTI_ERRORS_FILE = os.path.join(_PROFILE_PATH, 'iptv_anti_errors_state.json')
_TDT_ENGINE_FILE = os.path.join(_PROFILE_PATH, 'tdt_engine_state.json')
_ACC_FILE        = os.path.join(_PROFILE_PATH, 'acc_settings.json')
_INTEGRATION_FIRST_USE_FILE = os.path.join(_PROFILE_PATH, 'integration_first_use.json')


def atomic_write_json(path, data, ensure_ascii=True, indent=None):
    """Escribe JSON de forma atómica (tmp único + os.replace). Nunca lanza; devuelve bool.
    Un corte a mitad o dos escrituras solapadas no pueden dejar el archivo corrupto."""
    tmp = f'{path}.{os.getpid()}.{threading.get_ident()}.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=ensure_ascii, indent=indent)
        os.replace(tmp, path)
        return True
    except Exception as e:
        xbmc.log(f'[EspaDaily] No se pudo guardar {os.path.basename(path)}: {e}', xbmc.LOGWARNING)
        try:
            os.remove(tmp)
        except OSError:
            pass
        return False


def get_acc_settings():
    if not os.path.exists(_ACC_FILE): return {}
    try:
        with open(_ACC_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except Exception: return {}

def _save_acc_settings(data):
    with open(_ACC_FILE, 'w', encoding='utf-8') as f: json.dump(data, f)

def get_acc_color_mode():
    return get_acc_settings().get('color_mode', 'none')

def set_acc_color_mode(mode):
    d = get_acc_settings(); d['color_mode'] = mode; _save_acc_settings(d)

def get_acc_force_bold():
    return get_acc_settings().get('force_bold', True)

def set_acc_force_bold(state):
    d = get_acc_settings(); d['force_bold'] = state; _save_acc_settings(d)

def get_acc_strip_symbols():
    return get_acc_settings().get('strip_symbols', False)

def set_acc_strip_symbols(state):
    d = get_acc_settings(); d['strip_symbols'] = state; _save_acc_settings(d)

def get_menu_icon_tint_mode():
    """Devuelve el modo de color del menú principal.
    'icon'  → color en el icono tintado, texto plano
    'text'  → color en el label [COLOR ...], icono sin tintar (clásico, por defecto)
    """
    return get_acc_settings().get('menu_icon_tint_mode', 'text')

def set_menu_icon_tint_mode(mode):
    d = get_acc_settings(); d['menu_icon_tint_mode'] = mode; _save_acc_settings(d)


_ACC_COLOR_MODE    = get_acc_color_mode()
_ACC_FORCE_BOLD    = get_acc_force_bold()
_ACC_STRIP_SYMBOLS = get_acc_strip_symbols()

_ACC_DRG_MAP = {
    'red': 'orange', 'green': 'cyan', 'lime': 'cyan', 'limegreen': 'cyan',
    'darkred': 'darkorange', 'darkgreen': 'darkcyan',
}
_ACC_DBY_MAP = {
    'yellow': 'magenta', 'gold': 'magenta', 'khaki': 'magenta',
    'blue': 'red', 'cyan': 'red', 'aqua': 'red', 'skyblue': 'red',
    'dodgerblue': 'red', 'deepskyblue': 'red', 'lightblue': 'red',
}
_ACC_HCD_KEEP_RED = frozenset({'red', 'darkred', 'crimson'})
_ACC_COLOR_RE     = _re.compile(r'\[COLOR\s+([a-zA-Z]+)\]')
_ACC_BOLD_RE      = _re.compile(r'\[/?B\]')
_ACC_SYMBOL_TABLE = str.maketrans('★●○▲▼◑◐', '**-^v~~')

def _acc_remap(match):
    c = match.group(1).lower()
    if _ACC_COLOR_MODE == 'white':
        return '[COLOR white]'
    elif _ACC_COLOR_MODE == 'daltonic_rg':
        return '[COLOR ' + _ACC_DRG_MAP.get(c, 'white') + ']'
    elif _ACC_COLOR_MODE == 'daltonic_by':
        return '[COLOR ' + _ACC_DBY_MAP.get(c, 'white') + ']'
    elif _ACC_COLOR_MODE == 'hc_dark':
        return '[COLOR ' + (c if c in _ACC_HCD_KEEP_RED else 'yellow') + ']'
    elif _ACC_COLOR_MODE == 'hc_light':
        return '[COLOR ' + (c if c in _ACC_HCD_KEEP_RED else 'black') + ']'
    return match.group(0)

def _acc_transform(s):
    if not isinstance(s, str) or not s:
        return s
    if _ACC_STRIP_SYMBOLS:
        s = s.translate(_ACC_SYMBOL_TABLE)
    if _ACC_FORCE_BOLD:
        if '[B]' not in s:
            s = '[B]' + s + '[/B]'
    else:
        s = _ACC_BOLD_RE.sub('', s)
    if _ACC_COLOR_MODE not in ('', 'none'):
        s = _ACC_COLOR_RE.sub(_acc_remap, s)
    return s

_OrigListItem = xbmcgui.ListItem

def _ListItemFactory(label="", label2="", path="", offscreen=False):
    label = _acc_transform(label)
    if label2:
        label2 = _acc_transform(label2)
    return _OrigListItem(label=label, label2=label2, path=path, offscreen=offscreen)

xbmcgui.ListItem = _ListItemFactory


def is_iptv_anti_errors_active():
    if not os.path.exists(_IPTV_ANTI_ERRORS_FILE): return False
    try:
        with open(_IPTV_ANTI_ERRORS_FILE, 'r', encoding='utf-8') as o:
            return json.load(o).get('active', False)
    except Exception:
        return False

def set_iptv_anti_errors(state):
    with open(_IPTV_ANTI_ERRORS_FILE, 'w', encoding='utf-8') as o:
        json.dump({'active': state}, o)


def is_tdt_inputstream_active():
    if not os.path.exists(_TDT_ENGINE_FILE): return False
    try:
        with open(_TDT_ENGINE_FILE, 'r', encoding='utf-8') as o:
            return json.load(o).get('active', False)
    except Exception:
        return False

def set_tdt_inputstream(state):
    with open(_TDT_ENGINE_FILE, 'w', encoding='utf-8') as o:
        json.dump({'active': state}, o)


def get_context_level():
    if not os.path.exists(_CONTEXT_FILE): return 1 # Default
    try:
        with open(_CONTEXT_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
            val = data.get("level", 1)

            if isinstance(val, bool): return 1 if val else 0
            return int(val)
    except Exception: return 1

def cycle_context_level():
    """Cicla el nivel 0 -> 1 -> 2 -> 3 -> 0 y lo guarda. Devuelve el nuevo nivel."""
    current = get_context_level()
    new_level = (current + 1) % 4
    try:
        with open(_CONTEXT_FILE, 'w', encoding='utf-8') as f: json.dump({"level": new_level}, f)
        return new_level
    except Exception:
        return current


def get_snapshot_context_level():
    if not os.path.exists(_SNAPSHOT_CTX_FILE): return -1
    try:
        with open(_SNAPSHOT_CTX_FILE, 'r', encoding='utf-8') as f:
            return int(json.load(f).get("level", -1))
    except Exception: return -1

def cycle_snapshot_context():
    """Cicla -1 -> 0 -> 1 -> 2 -> -1"""
    curr = get_snapshot_context_level()
    new_val = curr + 1
    if new_val > 2: new_val = -1
    
    with open(_SNAPSHOT_CTX_FILE, 'w', encoding='utf-8') as f: json.dump({"level": new_val}, f)
    return new_val

def build_query(title, context_data, force_level=None):
    """Aplica contexto a un titulo segun el nivel configurado."""
    depth = get_context_level() if force_level is None else force_level
    
    if depth == 0: return title.strip()
    if not context_data: return title.strip()

    clean_title = title.strip()
    

    if "||" in context_data:
        parts = context_data.split("||")

        if depth > len(parts): depth = len(parts) 
        used = parts[-depth:]
        ctx_str = " ".join(used)
    else:

        ctx_str = context_data


    if ctx_str.lower() not in clean_title.lower():

        return f"{ctx_str} {clean_title}".strip()
    
    return clean_title



def is_debug_active():
    if not os.path.exists(_DEBUG_FILE): return False
    try:
        with open(_DEBUG_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False

def set_debug_active(state):
    with open(_DEBUG_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)



def is_frozen_active():
    if not os.path.exists(_FROZEN_FILE): return False
    try:
        with open(_FROZEN_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False


_PRIORITY_FILE = os.path.join(_PROFILE_PATH, 'priority_state.json')


def is_prioritize_match_active():
    if os.path.exists(_PRIORITY_FILE):
        try:
            with open(_PRIORITY_FILE, 'r', encoding='utf-8') as o:
                data = json.load(o)
            val = data.get('active', False) if isinstance(data, dict) else False
            xbmcaddon.Addon().setSetting('prioritize_match_active', 'true' if val else 'false')
            os.remove(_PRIORITY_FILE)
        except (OSError, ValueError, RuntimeError) as e:
            xbmc.log(f"[EspaDaily] Error al migrar priority_state.json: {e}", xbmc.LOGWARNING)
    try:
        return xbmcaddon.Addon().getSetting('prioritize_match_active') == 'true'
    except Exception:
        return False


def set_prioritize_match(state):
    try:
        xbmcaddon.Addon().setSetting('prioritize_match_active', 'true' if state else 'false')
    except Exception as e:
        xbmc.log(f"[EspaDaily] Error al guardar prioritize_match_active: {e}", xbmc.LOGWARNING)


def is_recent_active():
    if os.path.exists(_RECENT_FILE):
        try:
            with open(_RECENT_FILE, 'r', encoding='utf-8') as o:
                data = json.load(o)
            val = data.get('active', False) if isinstance(data, dict) else False
            xbmcaddon.Addon().setSetting('recent_active', 'true' if val else 'false')
            os.remove(_RECENT_FILE)
        except (OSError, ValueError, RuntimeError) as e:
            xbmc.log(f"[EspaDaily] Error al migrar recent_state.json: {e}", xbmc.LOGWARNING)
    try:
        return xbmcaddon.Addon().getSetting('recent_active') == 'true'
    except Exception:
        return False


def set_recent_active(state):
    try:
        xbmcaddon.Addon().setSetting('recent_active', 'true' if state else 'false')
    except Exception as e:
        xbmc.log(f"[EspaDaily] Error al guardar recent_active: {e}", xbmc.LOGWARNING)



def get_favorites():
    if not os.path.exists(_FAV_FILE): return []
    try:
        with open(_FAV_FILE, 'r', encoding='utf-8') as f: data = json.load(f)
    except Exception: return []
    # Solo entradas válidas. Una importada sin 'url' tumbaba todas las operaciones con KeyError.
    return [f for f in data if isinstance(f, dict) and f.get('url')] if isinstance(data, list) else []

def add_favorite(title, url, icon, platform, action, params=None):
    favs = get_favorites()

    if any(f.get('title') == title and f.get('platform') == platform for f in favs): return False

    favs.append({
        "title": title, "url": url, "icon": icon,
        "platform": platform, "action": action, "params": params or {}
    })
    return atomic_write_json(_FAV_FILE, favs, ensure_ascii=False)

def remove_favorite(url):
    favs = get_favorites()
    new_favs = [f for f in favs if f['url'] != url]
    atomic_write_json(_FAV_FILE, new_favs, ensure_ascii=False)
    return len(favs) != len(new_favs)

def rename_favorite(url, new_title):
    favs = get_favorites()
    changed = False
    for f in favs:
        if f['url'] == url:
            f['title'] = new_title
            changed = True
            break
    if changed:
        atomic_write_json(_FAV_FILE, favs, ensure_ascii=False)
    return changed

def move_favorite(url, direction):
    favs = get_favorites()
    index = -1
    for i, f in enumerate(favs):
        if f['url'] == url:
            index = i
            break
            
    if index == -1: return False
    
    if direction == "up" and index > 0:
        favs[index], favs[index-1] = favs[index-1], favs[index]
        atomic_write_json(_FAV_FILE, favs, ensure_ascii=False)
        return True
    elif direction == "down" and index < len(favs) - 1:
        favs[index], favs[index+1] = favs[index+1], favs[index]
        atomic_write_json(_FAV_FILE, favs, ensure_ascii=False)
        return True
        
    return False



def get_downloads():
    if not os.path.exists(_DL_FILE): return []
    try:
        with open(_DL_FILE, 'r', encoding='utf-8') as f: data = json.load(f)
    except Exception: return []
    return [d for d in data if isinstance(d, dict) and d.get('path')] if isinstance(data, list) else []

def log_download(title, path, vid):
    dls = get_downloads()

    entry = {"title": title, "path": path, "vid": vid}
    entry["date"] = time.strftime("%d/%m/%Y %H:%M")
    dls.insert(0, entry)
    atomic_write_json(_DL_FILE, dls[:50])

def remove_download(path):
    dls = get_downloads()
    new_dls = [d for d in dls if d['path'] != path]
    atomic_write_json(_DL_FILE, new_dls)


def get_min_duration():
    """Minutos de «Ocultar clips cortos», del ajuste nativo dm_min_duracion. Lo que había en
    min_duration.json, donde se guardaba antes, pasa al ajuste la primera vez."""
    if os.path.exists(_DURATION_FILE):
        try:
            with open(_DURATION_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
            minutos = int(data.get('minutes', 0)) if isinstance(data, dict) else 0
            xbmcaddon.Addon().setSetting('dm_min_duracion', str(max(0, min(minutos, 30))))
            os.remove(_DURATION_FILE)
        except (OSError, ValueError, TypeError, RuntimeError) as e:
            xbmc.log(f"[EspaDaily] Error al migrar min_duration.json: {e}", xbmc.LOGWARNING)
    try:
        return int(float(xbmcaddon.Addon().getSetting('dm_min_duracion') or 0))
    except ValueError:
        return 0


def set_min_duration(minutes):
    xbmcaddon.Addon().setSetting('dm_min_duracion', str(int(minutes)))


def is_advanced_search_active():
    if not os.path.exists(_ADVANCED_SEARCH_FILE): return True
    try:
        with open(_ADVANCED_SEARCH_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', True)
    except Exception: return True

def set_advanced_search_active(state):
    with open(_ADVANCED_SEARCH_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)


_ESTUARY_FIX_FILE = os.path.join(_PROFILE_PATH, 'estuary_fix_state.json')

def is_estuary_fix_accepted():
    """True si el usuario aceptó el ajuste de compatibilidad del skin Estuary Palantir."""
    if not os.path.exists(_ESTUARY_FIX_FILE): return False
    try:
        with open(_ESTUARY_FIX_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('accepted', False)
    except (OSError, ValueError): return False

def set_estuary_fix_accepted(state):
    with open(_ESTUARY_FIX_FILE, 'w', encoding='utf-8') as o: json.dump({'accepted': state}, o)


def is_palantir_integration_enabled():
    """Devuelve True si la integracion con Palantir 3 esta habilitada (por defecto: False)."""
    if not os.path.exists(_PALANTIR_INTEGRATION_FILE): return False
    try:
        with open(_PALANTIR_INTEGRATION_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False

def set_palantir_integration_enabled(state):
    """Guarda el estado del toggle de integracion con Palantir."""
    with open(_PALANTIR_INTEGRATION_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)

def is_palantir_installed():
    """Comprueba si plugin.video.palantir3 esta instalado en el sistema."""
    try:
        return xbmc.getCondVisibility("System.HasAddon(plugin.video.palantir3)")
    except Exception:
        return False

def is_balandro_integration_enabled():
    """Devuelve True si la integracion con Balandro esta habilitada (por defecto: False)."""
    if not os.path.exists(_BALANDRO_INTEGRATION_FILE): return False
    try:
        with open(_BALANDRO_INTEGRATION_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False

def set_balandro_integration_enabled(state):
    """Guarda el estado del toggle de integracion con Balandro."""
    with open(_BALANDRO_INTEGRATION_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)

def is_balandro_installed():
    """Comprueba si plugin.video.balandro esta instalado en el sistema."""
    try:
        return xbmc.getCondVisibility("System.HasAddon(plugin.video.balandro)")
    except Exception:
        return False

def is_atresdaily_integration_enabled():
    if not os.path.exists(_ATRESDAILY_INTEGRATION_FILE): return True
    try:
        with open(_ATRESDAILY_INTEGRATION_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', True)
    except Exception: return True

def set_atresdaily_integration_enabled(state):
    with open(_ATRESDAILY_INTEGRATION_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)

def is_espatv_integration_enabled():
    if not os.path.exists(_ESPATV_INTEGRATION_FILE): return True
    try:
        with open(_ESPATV_INTEGRATION_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', True)
    except Exception: return True

def set_espatv_integration_enabled(state):
    with open(_ESPATV_INTEGRATION_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)

def is_topzilla_integration_enabled():
    if not os.path.exists(_TOPZILLA_INTEGRATION_FILE): return True
    try:
        with open(_TOPZILLA_INTEGRATION_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', True)
    except Exception: return True

def set_topzilla_integration_enabled(state):
    with open(_TOPZILLA_INTEGRATION_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)

def is_tmdbhelper_integration_enabled():
    if not os.path.exists(_TMDBHELPER_INTEGRATION_FILE): return True
    try:
        with open(_TMDBHELPER_INTEGRATION_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', True)
    except Exception: return True

def set_tmdbhelper_integration_enabled(state):
    with open(_TMDBHELPER_INTEGRATION_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)

def is_alfa_integration_enabled():
    if not os.path.exists(_ALFA_INTEGRATION_FILE): return True
    try:
        with open(_ALFA_INTEGRATION_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', True)
    except Exception: return True

def set_alfa_integration_enabled(state):
    with open(_ALFA_INTEGRATION_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)

def is_alfa_installed():
    try:
        return bool(xbmc.getCondVisibility("System.HasAddon(plugin.video.alfa)"))
    except Exception:
        return False

def is_jacktook_integration_enabled():
    if not os.path.exists(_JACKTOOK_INTEGRATION_FILE): return True
    try:
        with open(_JACKTOOK_INTEGRATION_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', True)
    except Exception: return True

def set_jacktook_integration_enabled(state):
    with open(_JACKTOOK_INTEGRATION_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)

def get_palantir_addon_id():
    """Busca cualquier variante de Palantir instalada (plugin.video.palantir*)."""
    common_ids = ['plugin.video.palantir', 'plugin.video.palantir2', 'plugin.video.palantir3', 'plugin.video.palantir4']
    for pid in common_ids:
        if xbmc.getCondVisibility(f"System.HasAddon({pid})"):
            return pid
    try:
        addons_dir = xbmcvfs.translatePath('special://home/addons/')
        if os.path.exists(addons_dir):
            for d in os.listdir(addons_dir):
                if d.startswith('plugin.video.palantir') and 'visor' not in d:
                    if xbmc.getCondVisibility(f"System.HasAddon({d})"):
                        return d
    except Exception:
        pass
    return None

def is_jacktook_installed():
    try:
        return bool(xbmc.getCondVisibility("System.HasAddon(plugin.video.jacktook)"))
    except Exception:
        return False

def get_alfa_addon_id():
    try:
        if xbmc.getCondVisibility("System.HasAddon(plugin.video.alfa)"):
            return 'plugin.video.alfa'
    except Exception:
        pass
    return None


_EXTERNAL_INTEGRATIONS_FILE = os.path.join(_PROFILE_PATH, 'external_integrations_state.json')

def are_external_integrations_disabled():
    if not os.path.exists(_EXTERNAL_INTEGRATIONS_FILE): return False
    try:
        with open(_EXTERNAL_INTEGRATIONS_FILE, 'r', encoding='utf-8') as o:
            return json.load(o).get('disabled', False)
    except Exception:
        return False

def set_external_integrations_disabled(state):
    with open(_EXTERNAL_INTEGRATIONS_FILE, 'w', encoding='utf-8') as o:
        json.dump({'disabled': state}, o)



_ACESTREAM_SERVER_FILE = os.path.join(_PROFILE_PATH, 'acestream_server_mode.json')

def get_acestream_server_mode():
    if not os.path.exists(_ACESTREAM_SERVER_FILE): return "publico"
    try:
        with open(_ACESTREAM_SERVER_FILE, 'r', encoding='utf-8') as o:
            return json.load(o).get('mode', 'publico')
    except Exception:
        return "publico"

def set_acestream_server_mode(mode):
    with open(_ACESTREAM_SERVER_FILE, 'w', encoding='utf-8') as o:
        json.dump({'mode': mode}, o)

def cycle_acestream_server_mode():
    current = get_acestream_server_mode()
    order = ["publico", "auto", "local"]
    idx = order.index(current) if current in order else 0
    new_mode = order[(idx + 1) % len(order)]
    set_acestream_server_mode(new_mode)
    return new_mode


_ACESTREAM_ENABLED_FILE = os.path.join(_PROFILE_PATH, 'acestream_enabled.json')

def is_acestream_enabled():
    if not os.path.exists(_ACESTREAM_ENABLED_FILE): return False
    try:
        with open(_ACESTREAM_ENABLED_FILE, 'r', encoding='utf-8') as o:
            return json.load(o).get('active', False) is True
    except Exception:
        return False

def set_acestream_enabled(state):
    with open(_ACESTREAM_ENABLED_FILE, 'w', encoding='utf-8') as o:
        json.dump({'active': bool(state)}, o)


_LEGAL_DISCLAIMER_FILE = os.path.join(_PROFILE_PATH, 'legal_state.json')

def is_legal_disclaimer_accepted():
    if not os.path.exists(_LEGAL_DISCLAIMER_FILE): return False
    try:
        with open(_LEGAL_DISCLAIMER_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('accepted', False)
    except Exception: return False


def set_legal_disclaimer_accepted(state):
    with open(_LEGAL_DISCLAIMER_FILE, 'w', encoding='utf-8') as o: json.dump({'accepted': state}, o)


_TRAKT_SETTINGS_FILE = os.path.join(_PROFILE_PATH, 'trakt_settings.json')
_TRAKT_CLIENT_ID = "bS4meB1pF9rQhl_dGFF2z0llxa-0sIRiMEgh3gUSQUA"
_ESPADAILY_TMDB_API_KEY = "273ffd2f428df3e0ef479eeb8d632541"

_DEFAULT_TRAKT_LIST_IDS = [
    "805405", "1282987", "2748259", "797798", "832943",
    "4737076", "4834057", "9429302", "851495", "1558961",
    "6544049", "3785062", "20579314", "11512456", "2142753",
    "2143363", "1211468", "11416887", "801239", "6652041",
    "20770365", "1326415", "1076107", "20492899", "20770267",
    "20772087", "21583416"
]

def get_trakt_settings():
    if not os.path.exists(_TRAKT_SETTINGS_FILE): return {"api_key": "", "lists": []}
    try:
        with open(_TRAKT_SETTINGS_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except Exception: return {"api_key": "", "lists": []}

def save_trakt_settings(data):
    # Atómico; y sigue lanzando si falla, como antes, porque quien llama avisa del error.
    if not atomic_write_json(_TRAKT_SETTINGS_FILE, data):
        raise OSError("No se pudo guardar la configuración de Trakt")

def get_trakt_api_key():
    return get_trakt_settings().get("api_key", "") or _TRAKT_CLIENT_ID

def set_trakt_api_key(key):
    data = get_trakt_settings()
    data["api_key"] = key
    save_trakt_settings(data)

def get_trakt_lists():
    return get_trakt_settings().get("lists", [])

def add_trakt_list(list_id, name, user, item_count=0):
    data = get_trakt_settings()
    lists = data.get("lists", [])

    for l in lists:
        if l['id'] == list_id:

            l['name'] = name
            l['user'] = user
            l['item_count'] = item_count
            save_trakt_settings(data)
            return
    
    lists.append({"id": list_id, "name": name, "user": user, "item_count": item_count})
    data["lists"] = lists
    save_trakt_settings(data)

def seed_default_trakt_lists(api_key=''):
    data = get_trakt_settings()
    lists = data.get("lists", [])
    removed_defaults = set(data.get("removed_defaults", []))
    existing_ids = {l['id'] for l in lists}
    new_ids = [lid for lid in _DEFAULT_TRAKT_LIST_IDS if lid not in existing_ids and lid not in removed_defaults]
    if not new_ids:
        return
    names = {lid: f"Lista Trakt #{lid}" for lid in new_ids}
    if api_key:
        try:
            import requests
            from concurrent.futures import ThreadPoolExecutor
            headers = {'trakt-api-key': api_key, 'trakt-api-version': '2', 'Content-Type': 'application/json'}
            def fetch_name(lid):
                try:
                    r = requests.get(f'https://api.trakt.tv/lists/{lid}', headers=headers, timeout=5)
                    if r.status_code == 200:
                        return lid, r.json().get('name', names[lid])
                except Exception:
                    pass
                return lid, names[lid]
            with ThreadPoolExecutor(max_workers=8) as ex:
                for lid, name in ex.map(fetch_name, new_ids):
                    names[lid] = name
        except Exception:
            pass
    for lid in new_ids:
        lists.append({"id": lid, "name": names[lid], "user": "official", "item_count": 0})
    data["lists"] = lists
    save_trakt_settings(data)

def remove_trakt_list(list_id):
    data = get_trakt_settings()
    lists = data.get("lists", [])
    if list_id in _DEFAULT_TRAKT_LIST_IDS:
        removed = data.get("removed_defaults", [])
        if list_id not in removed:
            removed.append(list_id)
        data["removed_defaults"] = removed
    data["lists"] = [l for l in lists if l['id'] != list_id]
    save_trakt_settings(data)


def is_integration_first_use_shown(addon_name):
    try:
        with open(_INTEGRATION_FIRST_USE_FILE, 'r', encoding='utf-8') as f:
            return bool(json.load(f).get(addon_name, False))
    except Exception:
        return False


def mark_integration_first_use_shown(addon_name):
    try:
        try:
            with open(_INTEGRATION_FIRST_USE_FILE, 'r', encoding='utf-8') as f:
                d = json.load(f)
        except Exception:
            d = {}
        d[addon_name] = True
        tmp = _INTEGRATION_FIRST_USE_FILE + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(d, f)
        os.replace(tmp, _INTEGRATION_FIRST_USE_FILE)
    except Exception:
        pass


def welcome_last_version():
    import json as _j
    f = os.path.join(_PROFILE_PATH, 'welcome_state.json')
    try:
        with open(f, 'r', encoding='utf-8') as _fh:
            d = _j.load(_fh)
            return d.get('last_version', '')
    except Exception:
        return ''

def set_welcome_shown(version):
    import json as _j
    f = os.path.join(_PROFILE_PATH, 'welcome_state.json')
    try:
        os.makedirs(_PROFILE_PATH, exist_ok=True)
        tmp = f + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as _fh:
            _j.dump({'last_version': version}, _fh)
        os.replace(tmp, f)
    except Exception:
        pass


# --- Fanart de fondo ---

def get_fanart_mode():
    try:
        return xbmcaddon.Addon().getSetting('fanart_mode') or 'addon'
    except Exception:
        return 'addon'


def set_fanart_mode(mode):
    try:
        xbmcaddon.Addon().setSetting('fanart_mode', mode)
    except Exception:
        pass


def get_custom_fanart_path():
    try:
        return xbmcaddon.Addon().getSetting('fanart_custom_path') or ''
    except Exception:
        return ''


def set_custom_fanart_path(path):
    try:
        xbmcaddon.Addon().setSetting('fanart_custom_path', path)
    except Exception:
        pass


def is_fanart_disabled():
    try:
        return xbmcaddon.Addon().getSetting('disable_fanart') == 'true'
    except Exception:
        return False


def set_fanart_disabled(disabled):
    try:
        xbmcaddon.Addon().setSetting('disable_fanart', 'true' if disabled else 'false')
    except Exception:
        pass


def migrate_fanart_legacy():
    # El menú anterior guardaba el estado "desactivado" en fanart_mode.
    # Ahora el on/off vive en disable_fanart y fanart_mode solo elige fuente.
    if get_fanart_mode() == 'disabled':
        set_fanart_disabled(True)
        set_fanart_mode('addon')


def addon_fanart():
    try:
        if is_fanart_disabled():
            return ''
        mode = get_fanart_mode()
        if mode == 'disabled':  # compat: estado heredado antes de migrate_fanart_legacy()
            return ''
        if mode == 'custom':
            path = get_custom_fanart_path()
            if path and xbmcvfs.exists(path):
                return path
        a = xbmcaddon.Addon()
        return a.getAddonInfo('fanart') or os.path.join(a.getAddonInfo('path'), 'fanart.jpg')
    except Exception:
        return ''
