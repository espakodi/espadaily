# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
# Helpers de interfaz, serializacion y entrada de texto.
import os
import sys
import json
import threading
import urllib.parse
from concurrent.futures import ThreadPoolExecutor

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import core_settings

ADDON = xbmcaddon.Addon()
ICON_MAIN = os.path.join(ADDON.getAddonInfo('path'), 'icon.jpg')
_MEDIA_DIR = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'media')

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
}

_DM_OCULTAR = ('dm_filtrar_retirados', 'dm_ocultar_privados', 'dm_ocultar_directos_apagados')


def ajuste_dm(clave):
    """Interruptor de las listas de Dailymotion. Son ajustes nativos, así que la
    pestaña Dailymotion de los ajustes del addon y el submenú de Ajustes
    avanzados cambian lo mismo. Todos valen True por defecto."""
    return xbmcaddon.Addon().getSetting(clave) != 'false'


def dm_firma_filtro():
    """Estado de los interruptores de las listas DM, para la clave de las cachés
    de búsquedas. Sin ella, un cambio de ajuste no se notaría hasta que caducan."""
    return "".join("1" if ajuste_dm(c) else "0" for c in _DM_OCULTAR + ('dm_rellenar_listas',))


def dm_limite_lista(n):
    """Cuántos resultados pedir a la API para poder enseñar n después del filtro.

    En algunas búsquedas 16 de cada 20 resultados están retirados. Con "Rellenar
    las listas" se piden hasta cinco veces más (la API da 100 como mucho) y
    filtrar_dm_borrados recorta a n, así que la lista sale llena sin consultas de más.
    """
    if any(ajuste_dm(c) for c in _DM_OCULTAR) and ajuste_dm('dm_rellenar_listas'):
        return max(n, min(100, n * 5))
    return n


# access_error de un vídeo que ya no existe. Es el que traen los retirados en las
# búsquedas; los vivos nunca lo llevan.
_DM_RETIRADO = "DM005"
# Tope de privados que se comprueban por lista. Un canal que restringe sus vídeos
# los tiene todos así, y sin tope su playlist tardaría decenas de segundos.
_DM_MAX_PRIVADOS = 20


def dm_api_videos(url, params, timeout=10):
    """GET a la API de vídeos de DM pidiendo también access_error, para que
    filtrar_dm_borrados sepa qué no se puede ver sin hacer otra consulta (unos
    0,3 s menos por lista). Si la API rechazara el campo, se repite sin él."""
    cabeceras = {"User-Agent": HEADERS["User-Agent"]}
    con_error = dict(params, fields=f"{params.get('fields', 'id')},access_error")
    r = requests.get(url, params=con_error, headers=cabeceras, timeout=timeout)
    if r.status_code == 400:
        r = requests.get(url, params=params, headers=cabeceras, timeout=timeout)
    return r


def _dm_codigo(v):
    ae = v.get("access_error")
    return ae.get("code") if isinstance(ae, dict) else None


def _dm_privado(vid):
    """True si el vídeo no se puede ver ni pidiéndolo como la web de DM.

    La API marca con DM016 tanto los que su autor solo deja ver en dailymotion.com,
    que el addon sí reproduce, como los privados, y solo la metadata pedida así los
    distingue. Ante un fallo de red se deja el vídeo a la vista.
    """
    try:
        r = requests.get(f"https://www.dailymotion.com/player/metadata/video/{vid}",
                         params={"app": "com.dailymotion.neon"},
                         headers={"User-Agent": HEADERS["User-Agent"],
                                  "Referer": "https://www.dailymotion.com/"}, timeout=4)
        return bool(r.json().get("error"))
    except (requests.RequestException, ValueError) as e:
        xbmc.log(f"[EspaDaily] filtro DM, comprobando {vid}: {e}", xbmc.LOGINFO)
        return False


def _dm_privados(vids):
    """Los de `vids` (todos DM016) que son privados, comprobados a la vez."""
    if not vids:
        return set()
    with ThreadPoolExecutor(max_workers=min(8, len(vids))) as ex:
        return {vid for vid, es in zip(vids, ex.map(_dm_privado, vids)) if es}


def _dm_codigos_por_lote(ids):
    """{id: código de access_error} de los vídeos que siguen existiendo, o None si
    la API falla. Es el camino de las listas pedidas sin dm_api_videos."""
    codigos = {}
    for inicio in range(0, len(ids), 100):
        lote = ",".join(ids[inicio:inicio + 100])
        try:
            for campos in ("id,access_error", "id"):
                r = requests.get("https://api.dailymotion.com/videos",
                                 params={"ids": lote, "fields": campos, "limit": 100},
                                 headers={"User-Agent": HEADERS["User-Agent"]}, timeout=8)
                if r.status_code != 400:
                    break
            if r.status_code != 200:
                return None
            for v in r.json().get("list", []):
                codigos[str(v.get("id"))] = _dm_codigo(v)
        except Exception as e:
            # Un filtro no puede romper la lista: cualquier fallo, sin filtrar.
            xbmc.log(f"[EspaDaily] filtro DM: {e}", xbmc.LOGWARNING)
            return None
    return codigos


def filtrar_dm_borrados(videos, id_key="id", cuantos=None):
    """Quita de una lista de resultados de Dailymotion lo que no se puede ver.

    Según los ajustes: retirados, privados y directos que no están emitiendo. Con
    `cuantos` devuelve como mucho esos, para las listas pedidas de más con
    dm_limite_lista.

    El índice de búsqueda de DM sigue devolviendo vídeos borrados. Su campo
    access_error dice qué error daría cada uno: DM005 retirado, DM003 directo sin
    emisión y DM016 posible privado. Si la lista se pidió con dm_api_videos ya lo
    trae y no hace falta consultar nada; si no, se piden los ids por lote, que
    omite los retirados. Los DM016 se comprueban a la vez, hasta _DM_MAX_PRIVADOS.

    Ante cualquier fallo devuelve la lista intacta: mostrar algún vídeo muerto es
    mucho menos grave que vaciar los resultados del usuario.
    """
    intacta = videos if cuantos is None else videos[:cuantos]
    retirados = ajuste_dm('dm_filtrar_retirados')
    privados = ajuste_dm('dm_ocultar_privados')
    apagados = ajuste_dm('dm_ocultar_directos_apagados')
    if not (retirados or privados or apagados) or not videos:
        return intacta

    if all(isinstance(v, dict) and "access_error" in v for v in videos):
        codigos = {str(v.get(id_key)): _dm_codigo(v) for v in videos}
    else:
        ids = [str(v.get(id_key)) for v in videos if v.get(id_key)]
        # Por lote, una respuesta vacía no distingue "todos retirados" de un fallo
        # de la API; ante la duda, sin filtrar.
        codigos = _dm_codigos_por_lote(ids) if len(ids) >= 2 else None
        if not codigos:
            return intacta

    dudosos = [str(v.get(id_key)) for v in videos
               if codigos.get(str(v.get(id_key))) == "DM016"] if privados else []
    son_privados = _dm_privados(dudosos[:_DM_MAX_PRIVADOS])

    visibles = []
    n_retirados = n_privados = n_apagados = 0
    for v in videos:
        if cuantos is not None and len(visibles) >= cuantos:
            break
        vid = str(v.get(id_key))
        codigo = codigos.get(vid, _DM_RETIRADO)  # por lote, el que falta es retirado
        if codigo == _DM_RETIRADO:
            if retirados:
                n_retirados += 1
                continue
        elif codigo == "DM003" and apagados:
            n_apagados += 1
            continue
        elif vid in son_privados:
            n_privados += 1
            continue
        visibles.append(v)

    if n_retirados or n_privados or n_apagados:
        xbmc.log(f"[EspaDaily] filtro DM: ocultos {n_retirados} retirados, {n_privados} "
                 f"privados y {n_apagados} directos sin emisión", xbmc.LOGINFO)
    return visibles

def media_icon(filename):
    p = os.path.join(_MEDIA_DIR, filename)
    return p if os.path.exists(p) else ''

def get_params():
    p = {}
    if len(sys.argv) >= 3 and sys.argv[2]:
        p = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    return p

def add_item(action, title, url='', thumbnail='', extra='', folder=True, isPlayable=False, plot='', fanart='', context=None, **kwargs):
    li = xbmcgui.ListItem(title)
    art = {}
    if thumbnail:
        art['icon'] = thumbnail
        art['thumb'] = thumbnail
    if not fanart:
        fanart = core_settings.addon_fanart()
    if fanart:
        art['fanart'] = fanart
    li.setArt(art)
    info = {'title': title}
    if plot:
        info['plot'] = plot
    li.setInfo('video', info)
    if isPlayable:
        li.setProperty('IsPlayable', 'true')
        folder = False
    if context:
        li.addContextMenuItems(context)
    u = f'{sys.argv[0]}?action={action}&title={urllib.parse.quote(title)}&url={urllib.parse.quote(url)}&extra={urllib.parse.quote(extra)}'
    for key, value in kwargs.items():
        u += f'&{key}={urllib.parse.quote(str(value))}'
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=li, isFolder=folder)

def close_item_list():
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def play_resolved(url):
    li = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)

def get_path(filename):
    p = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    return os.path.join(p, filename)

def load_json(name, default=None):
    try:
        with open(get_path(name), 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        if default is not None:
            return default
        if 'settings' in name or 'config' in name or 'last_adv' in name:
            return {}
        return []

def save_json(name, data):
    path = get_path(name)
    tmp = f'{path}.{os.getpid()}.{threading.get_ident()}.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f)
        os.replace(tmp, path)
    except Exception as e:
        try:
            os.remove(tmp)
        except OSError:
            pass
        xbmc.log(f'[EspaDaily] Error guardando {name}: {e}', xbmc.LOGERROR)

_ask_choice = None

def get_text(title, default=''):
    global _ask_choice
    mode = load_json('settings.json').get('web_input_mode', 'keyboard')
    use_web = mode == 'web'
    if mode == 'ask':
        if _ask_choice is None:
            sel = xbmcgui.Dialog().select('Como quieres escribir?',
                ['Teclado de Kodi', 'Escribir desde el movil/PC'])
            if sel < 0:
                return ''
            _ask_choice = sel
        use_web = _ask_choice == 1
    if use_web:
        try:
            import web_input
            r = web_input.receive_text(title, default)
            if r is not None:
                return r
        except Exception as e:
            xbmc.log(f'[EspaDaily] web_input no disponible, uso teclado: {e}', xbmc.LOGWARNING)
    kb = xbmc.Keyboard(default, title)
    kb.doModal()
    return kb.getText() if kb.isConfirmed() else ''


def _activar(addon_id):
    """Enciende un addon instalado. True si queda encendido.

    Con JSON-RPC y no con el builtin EnableAddon, que pregunta sí/no cada vez. SetAddonEnabled
    contesta OK tanto si lo enciende como si no, así que se pide una vez y se mira el estado."""
    xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Addons.SetAddonEnabled",
                                    "params": {"addonid": addon_id, "enabled": True}}))
    monitor = xbmc.Monitor()
    for _ in range(30):
        if xbmc.getCondVisibility(f"System.AddonIsEnabled({addon_id})"):
            return True
        if monitor.waitForAbort(0.1):
            break
    return bool(xbmc.getCondVisibility(f"System.AddonIsEnabled({addon_id})"))


def addon_listo(addon_id, nombre, aviso_si_falta=None):
    """True si el addon está instalado y activado. Si está desactivado, ofrece activarlo; si no
    está instalado, enseña aviso_si_falta (si lo hay) y devuelve False.

    Desde Kodi 19 System.HasAddon es cierto también con el addon desactivado, y uno desactivado
    no abre ni reproduce nada. InstallAddon tampoco hace nada con él."""
    if xbmc.getCondVisibility(f"System.AddonIsEnabled({addon_id})"):
        return True
    if not xbmc.getCondVisibility(f"System.HasAddon({addon_id})"):
        if aviso_si_falta:
            xbmcgui.Dialog().ok("EspaDaily", aviso_si_falta)
        return False
    if not xbmcgui.Dialog().yesno("EspaDaily", f"{nombre} está instalado pero desactivado.\n\n¿Activarlo ahora?",
                                  nolabel="Cerrar", yeslabel="Activar"):
        return False
    if _activar(addon_id):
        xbmcgui.Dialog().notification("EspaDaily", f"{nombre} activado", xbmcgui.NOTIFICATION_INFO, 3000)
        return True
    xbmcgui.Dialog().ok("EspaDaily", f"Kodi no ha podido activar {nombre}. Actívalo en Addons > Mis addons.")
    return False
