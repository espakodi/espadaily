# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
import os
import re

import xbmc
import xbmcgui
import xbmcvfs

import core_settings

_SKIN_ID = 'skin.estuary.palantir'
_MARKER = '<!-- ESPADAILY_PATCH_VIDEOS -->'
_LEGACY_MARKER = '<!-- ATRESDAILY_PATCH_VIDEOS -->'

# Texto que se inyecta tras cada expresión de vista. Se usa la MISMA constante para parchear
# (via re.sub con callable, sin procesar escapes) y para revertir, garantizando que la
# reversión borra exactamente lo insertado.
_INJECTED = '\n\t\t\t[Container.Content(videos) | Container.Content()] |'

_VISTAS = ['Vista50', 'Vista54', 'Vista55', 'Vista500', 'Vista504', 'Vista505', 'Vista506', 'Vista507']

_CONSENT_TEXT = (
    "Tienes activo el skin Estuary Palantir. Para que los resultados de Palantir se vean "
    "(sin este ajuste pueden aparecer como una pantalla negra), EspaDaily necesita modificar "
    "un archivo del skin (Includes.xml).\n\n"
    "El cambio es reversible y puedes deshacerlo cuando quieras desde Opciones.\n\n"
    "¿Aplicar el ajuste ahora?"
)


def _includes_xml_path():
    """Ruta del Includes.xml del skin Estuary Palantir, o None si el skin activo no es ese
    o el archivo no existe."""
    if xbmc.getSkinDir() != _SKIN_ID:
        return None
    path = os.path.join(xbmcvfs.translatePath('special://skin/'), 'xml', 'Includes.xml')
    return path if os.path.exists(path) else None


def patch_state():
    """'na' (no aplica: otro skin o sin archivo), 'patched' o 'unpatched'."""
    path = _includes_xml_path()
    if not path:
        return 'na'
    try:
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
    except OSError:
        return 'na'
    if _MARKER in content or _LEGACY_MARKER in content:
        return 'patched'
    return 'unpatched'


def _atomic_write(path, content):
    """Escribe de forma atómica: temp en el mismo directorio + os.replace."""
    tmp = path + '.espadaily.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            f.write(content)
        os.replace(tmp, path)
    except OSError:
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass
        raise


def patch_palantir_skin():
    """Inyecta compatibilidad de vistas en el Includes.xml del skin Estuary Palantir.
    Devuelve True si aplica el parche; False si no procede o falla.

    NO pide consentimiento: para flujos con consentimiento usar ensure_palantir_skin_patched().
    """
    path = _includes_xml_path()
    if not path:
        return False
    try:
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        if _MARKER in content or _LEGACY_MARKER in content:
            return False

        modified = False
        for vista in _VISTAS:
            pattern = r'(<expression name="' + vista + r'">\s*\[\s*\$EXP\[IsPalantirVistas\]\s*\+)'
            # Callable como replacement: re no procesa escapes, se inserta _INJECTED tal cual.
            new_content = re.sub(pattern, lambda m: m.group(1) + _INJECTED, content)
            if new_content != content:
                content = new_content
                modified = True
        if not modified:
            return False

        content = content.replace('<includes>', '<includes>\n\t' + _MARKER, 1)
        _atomic_write(path, content)
        xbmcgui.Dialog().notification(
            'EspaDaily', 'Ajuste de compatibilidad con Estuary Palantir aplicado',
            xbmcgui.NOTIFICATION_INFO, 5000)
        xbmc.executebuiltin('ReloadSkin()')
        return True
    except OSError as e:
        xbmc.log('estuary_palantir_compatibility patch: ' + str(e), xbmc.LOGERROR)
        return False


def unpatch_palantir_skin():
    """Revierte el parche dejando el Includes.xml como estaba. Devuelve True si lo modificó."""
    path = _includes_xml_path()
    if not path:
        return False
    try:
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        original = content
        content = content.replace(_INJECTED, '')
        content = content.replace('\n\t' + _MARKER, '')
        content = content.replace('\n\t' + _LEGACY_MARKER, '')
        if content == original:
            return False
        _atomic_write(path, content)
        xbmc.executebuiltin('ReloadSkin()')
        return True
    except OSError as e:
        xbmc.log('estuary_palantir_compatibility unpatch: ' + str(e), xbmc.LOGERROR)
        return False


def ensure_palantir_skin_patched():
    """Garantiza el parche SOLO con consentimiento, en el punto de uso. Devuelve:
      'ok'       no aplica (otro skin) o ya estaba parcheado: continuar normalmente.
      'applied'  se acaba de aplicar; el skin se está recargando (ReloadSkin): conviene
                 reintentar la acción una vez recargado, para no encadenar recarga + navegación.
      'declined' el usuario rechazó el ajuste.

    Si el consentimiento ya estaba dado (p. ej. una actualización del skin borró el parche),
    reaplica sin volver a preguntar.
    """
    if patch_state() != 'unpatched':
        return 'ok'
    if not core_settings.is_estuary_fix_accepted():
        if not xbmcgui.Dialog().yesno('EspaDaily', _CONSENT_TEXT):
            return 'declined'
        core_settings.set_estuary_fix_accepted(True)
    return 'applied' if patch_palantir_skin() else 'ok'
