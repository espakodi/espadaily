# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
# Reproductor nativo adaptado del de StreamNinja (mismo autor, GPL-2.0).
"""
Reproductor AceStream nativo de EspaDaily.

Cadena de reproducción: StreamNinja (solo en contexto imperativo) -> EKHorus -> motor AceStream local (127.0.0.1:6878).

Dos contextos de uso, con mecanismos distintos por exigencia de Kodi:
  - Imperativo (introducir hash/URL): play_from_url() / play(). Habla con el motor,
    prebufferea con diálogo de progreso y cierra la sesión P2P al terminar. Puede
    bloquear: se llama desde RunPlugin, nunca desde una resolución de item.
  - Resolución de item (búsqueda, escaneo, historial): el llamador hace
    setResolvedUrl() con horus_target()/direct_stream_url(). No
    bloquea: el plugin retorna y muere tras resolver.

API del motor (wiki.acestream.media/Engine_HTTP_API):
  GET /ace/getstream?id=<40hex>&format=json -> {playback_url, stat_url, command_url}
  GET stat_url   -> {status: "prebuf"|"dl", peers, speed_down (KB/s), total_progress}
  GET command_url?method=stop -> cierra la sesión P2P.
"""
import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcgui

HORUS_ID = "script.module.horus"
STREAMNINJA_ID = "plugin.video.streamninja"

_ENGINE = "127.0.0.1:6878"
_PREBUFFER_TIMEOUT = 45  # segundos que esperamos a que el motor llegue a estado "dl"

_ID_RE = re.compile(r"([0-9a-fA-F]{40})")


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[EspaDaily/acestream] {msg}", level)


def content_id(text):
    """Extrae el content id (40 hex en minúscula) de 'acestream://<hash>', '<hash>'
    o una URL con cola de parámetros. None si no hay un hash de 40 hex."""
    if not isinstance(text, str):
        return None
    m = _ID_RE.search(text)
    return m.group(1).lower() if m else None


def _is_android():
    return xbmc.getCondVisibility("System.Platform.Android")


def _play_android(cid):
    """En Android la vía nativa es lanzar la app AceStream por Intent: ella arranca su
    propio motor (el HTTP API en 6878 no es fiable en segundo plano en Android)."""
    xbmc.executebuiltin(
        'StartAndroidActivity("","org.acestream.action.start_content","",'
        f'"acestream:?content_id={cid}")')


def horus_target(cid):
    return f"plugin://{HORUS_ID}/?" + urllib.parse.urlencode({"action": "play", "id": cid})


def streamninja_target(cid):
    return f"plugin://{STREAMNINJA_ID}/?" + urllib.parse.urlencode({"action": "acestream", "id": cid})


def direct_stream_url(cid):
    """URL de stream directo del motor. La sesión va atada a esta conexión HTTP: al
    parar la reproducción, Kodi cierra el socket y el motor libera la sesión."""
    return f"http://{_ENGINE}/ace/getstream?id={cid}"


def _api_get(url, timeout):
    """GET que devuelve el dict JSON del motor, o None ante cualquier fallo."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "EspaDaily"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8", errors="replace"))
    except (urllib.error.URLError, OSError, ValueError):
        return None


def engine_ready(timeout=2):
    """True si el motor responde a get_version. Readiness real (no solo socket
    abierto): distingue 'motor escuchando y listo' de 'puerto abierto pero arrancando'."""
    res = _api_get(f"http://{_ENGINE}/webui/api/service?method=get_version&format=json", timeout)
    if not isinstance(res, dict):
        return False
    inner = res.get("result") if isinstance(res.get("result"), dict) else res
    return bool(inner.get("version"))


def _open_session(cid):
    """Abre la sesión de stream. Devuelve (playback_url, stat_url, command_url) o None."""
    res = _api_get(f"http://{_ENGINE}/ace/getstream?id={cid}&format=json", timeout=15)
    if not isinstance(res, dict):
        return None
    if res.get("error"):
        _log(f"el motor devolvió error: {res['error']}", xbmc.LOGWARNING)
        return None
    data = res.get("response") if isinstance(res.get("response"), dict) else res
    playback = data.get("playback_url")
    if not playback:
        return None
    return playback, data.get("stat_url"), data.get("command_url")


def _stop_session(command_url):
    if command_url:
        _api_get(command_url + "?method=stop", timeout=5)


def _prebuffer(stat_url, command_url):
    """Diálogo de precarga hasta status='dl'. True si listo para reproducir; False si
    el usuario canceló o se agotó el tiempo (en ese caso cierra la sesión)."""
    monitor = xbmc.Monitor()
    dp = xbmcgui.DialogProgress()
    dp.create("EspaDaily", "Conectando con la red AceStream...")
    # Tiempo de pared real: consultar stats añade latencia variable, así que el timeout
    # debe medirse en segundos reales, no contando vueltas del bucle.
    start = time.monotonic()
    try:
        while True:
            elapsed = int(time.monotonic() - start)
            if elapsed >= _PREBUFFER_TIMEOUT:
                break
            if dp.iscanceled() or monitor.abortRequested():
                _stop_session(command_url)
                return False
            stats = _api_get(stat_url, timeout=3) or {}
            data = stats.get("response", stats) if isinstance(stats, dict) else {}
            if data.get("status") == "dl":
                return True
            peers = data.get("peers", 0)
            speed = data.get("speed_down", 0)  # ya en KB/s
            # total_progress es el progreso real en VOD; en directo es siempre 0, así
            # que ahí movemos la barra con el tiempo transcurrido (solo feedback visual).
            try:
                pct = int(data.get("total_progress") or 0)
            except (TypeError, ValueError):
                pct = 0
            if pct <= 0:
                pct = min(95, int(elapsed * 100 / _PREBUFFER_TIMEOUT))
            dp.update(pct, f"Conectando: {peers} fuentes, {speed} KB/s\n"
                           f"Tiempo: {elapsed}s / {_PREBUFFER_TIMEOUT}s")
            if monitor.waitForAbort(1):
                _stop_session(command_url)
                return False
    finally:
        dp.close()
    # Sin llegar a 'dl' en el tiempo dado: ofrecer reproducir igualmente.
    if xbmcgui.Dialog().yesno("EspaDaily",
                              "El buffer va lento (pocas fuentes).\n\n¿Reproducir igualmente?"):
        return True
    _stop_session(command_url)
    return False


def play(cid, name="AceStream"):
    """Reproduce un content id vía el motor local con prebuffer y cierre de sesión.

    Devuelve True si el motor gestionó la petición (reprodujo o el usuario canceló el
    prebuffer) y False si el motor no está disponible o no devolvió sesión, para que el
    llamador siga su cadena de fallback. SOLO en contexto imperativo (bloquea hasta que
    la reproducción termina, para cerrar la sesión de forma determinista)."""
    if _is_android():
        _play_android(cid)
        return True
    if not engine_ready():
        return False
    session = _open_session(cid)
    if not session:
        return False
    playback_url, stat_url, command_url = session
    if stat_url and not _prebuffer(stat_url, command_url):
        return True  # cancelado por el usuario: no caer al fallback

    li = xbmcgui.ListItem(label=name, path=playback_url)
    li.setContentLookup(False)  # MPEG-TS progresivo: evita el probe HEAD que cuelga
    li.setProperty("IsPlayable", "true")

    player = xbmc.Player()
    player.play(playback_url, li)

    monitor = xbmc.Monitor()
    # Esperar a que arranque (hasta 10 s) antes de vigilar el fin.
    for _ in range(100):
        if player.isPlaying() or monitor.waitForAbort(0.1):
            break
    # Mantener vivo el proceso mientras haya reproducción, para cerrar la sesión al
    # terminar. Si el usuario abre otro vídeo, el motor ya libera esta sesión al cerrarse
    # su conexión HTTP; el stop posterior es idempotente (no comparamos getPlayingFile:
    # Kodi puede normalizar la URL y provocaría un cierre prematuro).
    while not monitor.abortRequested():
        if monitor.waitForAbort(1) or not player.isPlaying():
            break
    _stop_session(command_url)
    return True


def play_from_url(raw, name="AceStream"):
    """Reproduce desde contexto imperativo (introducir hash/URL): StreamNinja ->
    EKHorus -> motor nativo -> error. Valida el hash antes de nada."""
    cid = content_id(raw)
    if not cid:
        xbmcgui.Dialog().ok("AceStream", "Enlace no válido.\nSe esperaba un hash de 40 caracteres hexadecimales.")
        return
    if xbmc.getCondVisibility(f"System.AddonIsEnabled({STREAMNINJA_ID})"):
        xbmcgui.Dialog().notification("EspaDaily", "Abriendo en StreamNinja...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin(f'RunPlugin("{streamninja_target(cid)}")')
        return
    if xbmc.getCondVisibility(f"System.AddonIsEnabled({HORUS_ID})"):
        xbmcgui.Dialog().notification("EspaDaily", "Abriendo en EKHorus...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin(f'PlayMedia("{horus_target(cid)}")')
        return
    if play(cid, name):
        return
    xbmcgui.Dialog().ok(
        "EspaDaily",
        "No se detectó el motor AceStream en este equipo (127.0.0.1:6878).\n\n"
        "Arranca el motor AceStream, o instala EKHorus (script.module.horus) o StreamNinja.\n\n"
        "Los dos necesitan además el motor AceStream instalado en el sistema.",
    )
