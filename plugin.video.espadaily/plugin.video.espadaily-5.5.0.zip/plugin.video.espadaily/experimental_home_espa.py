# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
# Modo Cine: interfaz tipo streaming sobre el catalogo de Mediaset y RTVE.
# La reproduccion delega en el flujo existente del addon (ep_dialog): EspaDaily
# busca el contenido, no resuelve streams directos. Aqui solo se navega y se
# lanza esa busqueda.
import sys
import threading
import urllib.parse

import xbmc
import xbmcgui
import xbmcaddon

import ce_espa as ce
import ui_utils

try:
    import core_settings
except ImportError:
    core_settings = None

_LOG = "[EspaDaily/ModoCine]"

_ID_HERO = 200
_ID_ROWS_BASE = 310
_N_ROWS = 9
_ID_LOADING = 500
_ID_GRID = 600
_ID_EPISODES = 710
_ID_SEARCH_BTN = 900
_ID_CLOSE_BTN = 901
_ID_FILTER_BTN = 902

_FOCUS_POLL_MS = 250
_PAGE_SIZE = 50
_RECENT_FILE = "cine_recent.json"
_RECENT_MAX = 20

_FILTERS = ["all", "rtve", "mediaset"]
_FILTER_LABEL = {"all": "Todo", "rtve": "RTVE", "mediaset": "Mediaset"}

_CLOSE_ACTIONS = {xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK}


def _build_query(ep_title, show_title):
    if core_settings:
        try:
            return core_settings.build_query(ep_title, show_title)
        except Exception:
            pass
    return f"{show_title} {ep_title}".strip()


def _load_recent():
    data = ui_utils.load_json(_RECENT_FILE, default=[])
    return data if isinstance(data, list) else []


def _push_recent(entry):
    data = _load_recent()
    data = [e for e in data if e.get("vid") != entry.get("vid")]
    data.insert(0, entry)
    ui_utils.save_json(_RECENT_FILE, data[:_RECENT_MAX])


def _show_li(item):
    th = item.get("thumb") or ""
    li = xbmcgui.ListItem(label=item.get("title", ""))
    li.setArt({"thumb": th, "icon": th, "poster": th, "fanart": th, "landscape": th})
    li.setProperty("ad_action", "show")
    li.setProperty("ad_title", item.get("title", ""))
    li.setProperty("ad_image", th)
    li.setProperty("ad_href", item.get("href", ""))
    li.setProperty("ad_source", item.get("source", ""))
    li.setProperty("ad_cat", ce.SOURCE_LABEL.get(item.get("source", ""), ""))
    li.setProperty("ad_plot", item.get("plot", ""))
    return li


def _ep_li(ep, show_title):
    th = ep.get("thumb") or ""
    li = xbmcgui.ListItem(label=ep.get("title", ""))
    li.setArt({"thumb": th, "icon": th, "poster": th, "fanart": th, "landscape": th})
    li.setProperty("ad_action", "episode")
    li.setProperty("ad_title", ep.get("title", ""))
    li.setProperty("ad_image", th)
    li.setProperty("ad_plot", ep.get("plot", ""))
    li.setProperty("ad_source", ep.get("source", ""))
    li.setProperty("ad_vid", ep.get("vid", ""))
    li.setProperty("ad_show", show_title)
    return li


def _recent_li(entry):
    th = entry.get("thumb") or ""
    li = xbmcgui.ListItem(label=entry.get("title", ""))
    li.setArt({"thumb": th, "icon": th, "poster": th, "fanart": th, "landscape": th})
    li.setProperty("ad_action", "episode")
    li.setProperty("ad_title", entry.get("title", ""))
    li.setProperty("ad_image", th)
    li.setProperty("ad_source", entry.get("source", ""))
    li.setProperty("ad_cat", ce.SOURCE_LABEL.get(entry.get("source", ""), ""))
    li.setProperty("ad_vid", entry.get("vid", ""))
    li.setProperty("ad_show", entry.get("show", ""))
    li.setProperty("ad_recent", "1")
    return li


def _nav_li(action, label, cat="", source="", page=""):
    icon = ui_utils.media_icon("sub_explorar.png") or "DefaultFolder.png"
    li = xbmcgui.ListItem(label=label)
    li.setArt({"thumb": icon, "icon": icon, "poster": icon, "landscape": icon})
    li.setProperty("ad_action", action)
    li.setProperty("ad_title", label)
    li.setProperty("ad_image", icon)
    li.setProperty("ad_cat", cat)
    li.setProperty("ad_source", source)
    li.setProperty("ad_page", str(page))
    return li


class ModoCine(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.selected_action = None
        self.play_params = None
        self._cat_rows = {}
        self._recent = []
        self._loaded = False
        self._closing = False
        self._populate_lock = threading.Lock()
        self._filter = "all"
        self._view_stack = ["home"]
        self._detail_title = ""
        self._grid_cat = ""
        self._grid_cid = ""
        self._grid_source = ""
        self._grid_page = 0
        self._grid_rows = []
        self._grid_busy = False

    # --- Ciclo de vida ---

    def onInit(self):
        self.setProperty("view", "home")
        self.setProperty("filter_label", _FILTER_LABEL[self._filter])
        self._set_focus_props("Cargando...", "")
        threading.Thread(target=self._load_all, daemon=True).start()
        threading.Thread(target=self._focus_poll_loop, daemon=True).start()

    def _load_all(self):
        try:
            self._recent = _load_recent()
            results = {}
            lock = threading.Lock()

            def worker(name, cid):
                try:
                    rows = ce.fetch_cat_rows(cid, page=0)
                except Exception as e:
                    xbmc.log(f"{_LOG} fetch {name} fallo: {e}", xbmc.LOGWARNING)
                    rows = []
                with lock:
                    results[name] = rows or []

            threads = [threading.Thread(target=worker, args=(n, c), daemon=True)
                       for n, c, _s in ce.CATS]
            for t in threads:
                t.start()
            for t in threads:
                t.join(timeout=20)

            self._cat_rows = results
            if self._closing:
                return
            self._populate_home()
        except Exception as e:
            xbmc.log(f"{_LOG} _load_all error: {e}", xbmc.LOGERROR)
            self._set_loading("[COLOR red]Error al cargar el catalogo. Pulsa Atras.[/COLOR]")

    # --- Vista HOME ---

    def _visible_rows(self):
        """Filas a mostrar segun el filtro activo, en orden, contiguas."""
        rows = []
        if self._recent:
            rows.append(("Continuar viendo", [_recent_li(e) for e in self._recent], "recent"))
        for name, cid, source in ce.CATS:
            if self._filter != "all" and self._filter != source:
                continue
            items = [_show_li(i) for i in self._cat_rows.get(name, [])]
            if not items:
                continue
            items.append(_nav_li("view_all", "Ver todo  >", cat=name, source=source))
            rows.append((name, items, source))
        return rows

    def _populate_home(self):
        # Serializa carga inicial (hilo) y cambios de filtro (hilo UI): ambos
        # resetean y repueblan los mismos controles.
        with self._populate_lock:
            if self._closing:
                return
            self._populate_home_impl()

    def _populate_home_impl(self):
        rows = self._visible_rows()

        # Hero: primer programa de cada categoria visible (no la fila recientes).
        hero_items = []
        seen = set()
        for label, items, source in rows:
            if source == "recent":
                continue
            for li in items:
                if li.getProperty("ad_action") != "show":
                    continue
                key = li.getProperty("ad_href")
                if key in seen:
                    continue
                seen.add(key)
                hero_items.append(_clone_show_li(li))
                break
            if len(hero_items) >= 8:
                break
        try:
            hero = self.getControl(_ID_HERO)
            hero.reset()
            if hero_items:
                hero.addItems(hero_items)
        except Exception as e:
            xbmc.log(f"{_LOG} hero: {e}", xbmc.LOGWARNING)

        for idx in range(_N_ROWS):
            try:
                ctrl = self.getControl(_ID_ROWS_BASE + idx)
                ctrl.reset()
            except Exception:
                ctrl = None
            if idx < len(rows):
                label, items, _src = rows[idx]
                self.setProperty(f"row_label_{idx}", label)
                if ctrl is not None:
                    ctrl.addItems(items)
            else:
                self.setProperty(f"row_label_{idx}", "")

        try:
            self.getControl(_ID_LOADING).setVisible(False)
        except Exception:
            pass

        if hero_items:
            try:
                self.setFocusId(_ID_HERO)
            except Exception:
                pass
        elif rows:
            try:
                self.setFocusId(_ID_ROWS_BASE)
            except Exception:
                pass
        else:
            self._set_loading("[COLOR orange]No hay contenido. Revisa tu conexion.[/COLOR]")

        self._loaded = True
        self._refresh_focus_props()

    def _cycle_filter(self):
        i = (_FILTERS.index(self._filter) + 1) % len(_FILTERS)
        self._filter = _FILTERS[i]
        self.setProperty("filter_label", _FILTER_LABEL[self._filter])
        self._populate_home()

    # --- Vista GRID (Ver todo) ---

    def _open_grid(self, cat_name):
        match = next((c for c in ce.CATS if c[0] == cat_name), None)
        if not match:
            return
        self._grid_cat, self._grid_cid, self._grid_source = match
        self._grid_page = 0
        self._grid_rows = []
        self.setProperty("grid_title", f"{cat_name}  -  Cargando...")
        self._navigate_to("grid")
        threading.Thread(target=self._grid_fetch_first, daemon=True).start()

    def _grid_fetch_first(self):
        rows = ce.fetch_cat_rows(self._grid_cid, page=0)
        self._grid_rows = rows or []
        self.setProperty("grid_title", f"{self._grid_cat}  -  Todo")
        self._render_grid(last_count=len(rows or []), focus_pos=0)

    def _render_grid(self, last_count, focus_pos=0):
        try:
            ctrl = self.getControl(_ID_GRID)
        except Exception:
            return
        ctrl.reset()
        items = [_show_li(r) for r in self._grid_rows]
        if last_count >= _PAGE_SIZE:
            items.append(_nav_li("load_more", "Siguiente  >", cat=self._grid_cat,
                                 source=self._grid_source, page=self._grid_page + 1))
        if not items:
            self.setProperty("grid_title", f"{self._grid_cat}  -  Sin contenido")
            return
        ctrl.addItems(items)
        try:
            ctrl.selectItem(min(focus_pos, len(items) - 1))
            self.setFocusId(_ID_GRID)
        except Exception:
            pass

    def _grid_load_more(self):
        if self._grid_busy:
            return
        self._grid_busy = True

        def work():
            try:
                nxt = self._grid_page + 1
                new = ce.fetch_cat_rows(self._grid_cid, page=nxt)
                if not new:
                    xbmcgui.Dialog().notification("EspaDaily", "No hay mas contenido",
                                                  xbmcgui.NOTIFICATION_INFO, 1500)
                    self._render_grid(last_count=0, focus_pos=len(self._grid_rows) - 1)
                    return
                focus_at = len(self._grid_rows)
                self._grid_rows.extend(new)
                self._grid_page = nxt
                self._render_grid(last_count=len(new), focus_pos=focus_at)
            finally:
                self._grid_busy = False

        threading.Thread(target=work, daemon=True).start()

    # --- Vista DETALLE ---

    def _open_detail(self, href, title, source):
        self._detail_title = title
        self._detail_source = source
        self.setProperty("detail_title", title)
        self._navigate_to("detail")
        threading.Thread(target=self._load_detail, args=(href, title), daemon=True).start()

    def _load_detail(self, href, title):
        eps = ce.fetch_episodes(href)
        norm = [_ep_li(e, title) for e in eps if e.get("vid")]
        try:
            ctrl = self.getControl(_ID_EPISODES)
            ctrl.reset()
            if norm:
                ctrl.addItems(norm)
                self.setFocusId(_ID_EPISODES)
        except Exception as e:
            xbmc.log(f"{_LOG} episodios: {e}", xbmc.LOGWARNING)
        if not norm:
            xbmcgui.Dialog().notification("EspaDaily", "Sin episodios. Prueba el buscador.",
                                          xbmcgui.NOTIFICATION_INFO, 2500)
            self._go_back()

    # --- Reproduccion (delegada en ep_dialog) ---

    def _play(self, li):
        vid = li.getProperty("ad_vid")
        if not vid:
            return
        ep_title = li.getProperty("ad_title")
        show = li.getProperty("ad_show") or self._detail_title
        source = li.getProperty("ad_source")
        thumb = li.getProperty("ad_image")
        eid = ce.eid_for(vid)
        src_prefix = "RTVE" if source == "rtve" else ("Mediaset" if source == "mediaset" else "")
        q = f"{src_prefix} {_build_query(ep_title, show)}".strip()

        _push_recent({"vid": vid, "title": ep_title, "show": show,
                      "source": source, "thumb": thumb})

        self.play_params = {
            "q": q, "ot": thumb, "t": urllib.parse.quote(ep_title),
            "eid": eid, "sn": urllib.parse.quote(show),
        }
        self.selected_action = "play"
        self._closing = True
        self.close()

    def _do_search(self):
        self.selected_action = "search"
        self._closing = True
        self.close()

    # --- Navegacion entre vistas ---

    def _navigate_to(self, view):
        self._view_stack.append(view)
        self.setProperty("view", view)
        self._refresh_focus_props()

    def _go_back(self):
        if len(self._view_stack) > 1:
            self._view_stack.pop()
            target = self._view_stack[-1]
            self.setProperty("view", target)
            fid = {"home": _ID_HERO, "grid": _ID_GRID, "detail": _ID_EPISODES}.get(target, _ID_HERO)
            try:
                self.setFocusId(fid)
            except Exception:
                pass
            self._refresh_focus_props()
        else:
            self._closing = True
            self.close()

    # --- Eventos ---

    def onAction(self, action):
        if action.getId() in _CLOSE_ACTIONS:
            self._go_back()

    def onClick(self, controlId):
        if not self._loaded:
            return
        if controlId == _ID_CLOSE_BTN:
            self._closing = True
            self.close()
            return
        if controlId == _ID_SEARCH_BTN:
            self._do_search()
            return
        if controlId == _ID_FILTER_BTN:
            self._cycle_filter()
            return
        try:
            ctrl = self.getControl(controlId)
            pos = ctrl.getSelectedPosition()
            if pos < 0:
                return
            li = ctrl.getListItem(pos)
        except Exception:
            return
        action = li.getProperty("ad_action")
        if action == "view_all":
            self._open_grid(li.getProperty("ad_cat"))
        elif action == "load_more":
            self._grid_load_more()
        elif action == "episode":
            self._play(li)
        elif action == "show":
            href = li.getProperty("ad_href")
            if href:
                self._open_detail(href, li.getProperty("ad_title"), li.getProperty("ad_source"))

    # --- Fondo dinamico segun foco ---

    def _focus_poll_loop(self):
        monitor = xbmc.Monitor()
        last = None
        while not self._closing and not monitor.abortRequested():
            try:
                cur = self._focus_key()
                if cur != last:
                    self._refresh_focus_props()
                    last = cur
            except Exception:
                pass
            if monitor.waitForAbort(_FOCUS_POLL_MS / 1000.0):
                break

    def _focus_key(self):
        try:
            ctrl = self.getFocus()
            return (ctrl.getId(), ctrl.getSelectedPosition())
        except Exception:
            return None

    def _refresh_focus_props(self):
        try:
            ctrl = self.getFocus()
            pos = ctrl.getSelectedPosition()
            if pos < 0:
                return
            li = ctrl.getListItem(pos)
            if li is None:
                return
            self._set_focus_props(
                li.getProperty("ad_title") or li.getLabel() or "",
                li.getProperty("ad_image") or "",
            )
        except Exception:
            pass

    def _set_focus_props(self, title, fanart):
        self.setProperty("focused_title", title)
        self.setProperty("focused_fanart", fanart)

    def _set_loading(self, msg):
        try:
            c = self.getControl(_ID_LOADING)
            c.setLabel(msg)
            c.setVisible(True)
        except Exception:
            pass


def _clone_show_li(li):
    # Las ListItem ya anadidas a un control no se pueden reutilizar en otro;
    # clonamos las propiedades para el hero.
    new = xbmcgui.ListItem(label=li.getLabel())
    th = li.getProperty("ad_image")
    new.setArt({"thumb": th, "icon": th, "poster": th, "fanart": th, "landscape": th})
    for k in ("ad_action", "ad_title", "ad_image", "ad_href", "ad_source", "ad_cat", "ad_plot"):
        new.setProperty(k, li.getProperty(k))
    return new


def show():
    addon_path = xbmcaddon.Addon().getAddonInfo("path")
    win = ModoCine("experimental_home_espa.xml", addon_path, "Default", "1080i")
    try:
        win.doModal()
        action = win.selected_action
        play_params = win.play_params
    finally:
        # Si la ventana se cerró por otra vía, _focus_poll_loop seguiría vivo y Kodi no
        # daría por terminada la invocación.
        win._closing = True
        del win

    if action == "search":
        xbmc.executebuiltin("Container.Update({0}?action=busqueda_total)".format(sys.argv[0]))
    elif action == "play" and play_params:
        qs = {"action": "ep_dialog"}
        qs.update(play_params)
        url = sys.argv[0] + "?" + urllib.parse.urlencode(qs)
        xbmc.executebuiltin(f"RunPlugin({url})")
