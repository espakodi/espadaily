# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
#
# Compartido por url_player.py y webapp/api.py.
# Devuelve URL de variante HLS de DM (vod*.cf.dmcdn.net) en vez del master:
# cdndirector.dailymotion.com, el host del master, filtra por huella TLS y exige
# las cookies que deja la petición de metadata. Los clientes de reproducción de
# Kodi no pasan ese filtro; las variantes no lo tienen.
#
# Cascada para descargar el master HLS:
#   1. urllib con el tarro de cookies de la metadata: pasa en Windows y Android.
#   2. requests directo: pasa en Android, no en el Python de Kodi de Windows.
#   3. requests.Session con warmup.
#   4. subprocess al Python del sistema, si hay python en el PATH.
import http.cookiejar
import json
import re
import sys
import urllib.parse
import urllib.request


_UA_DM = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36"
)
HEADERS_DM = {
    "User-Agent": _UA_DM,
    "Origin": "https://www.dailymotion.com",
    "Referer": "https://www.dailymotion.com/",
}

# Script para subprocess. Usa el urllib3 del Python del sistema, que esquiva el
# fingerprint TLS que bloquea a Kodi. Imprime el master HLS en stdout.
_FETCH_MASTER_SCRIPT = r'''
import sys, urllib.request
url = sys.argv[1]
hdr = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
       "Origin":"https://www.dailymotion.com","Referer":"https://www.dailymotion.com/"}
try:
    import requests
    r = requests.get(url, headers=hdr, timeout=15)
    if r.status_code != 200:
        sys.exit(10 + (r.status_code // 100))
    sys.stdout.buffer.write(r.content)
except ImportError:
    r = urllib.request.urlopen(urllib.request.Request(url, headers=hdr), timeout=15)
    if r.getcode() != 200:
        sys.exit(20)
    sys.stdout.buffer.write(r.read())
'''


def _log(msg, level='info'):
    try:
        import xbmc
        lvl = {'info': xbmc.LOGINFO, 'warning': xbmc.LOGWARNING,
               'error': xbmc.LOGERROR}.get(level, xbmc.LOGINFO)
        xbmc.log(f"[dm_resolver] {msg}", lvl)
    except Exception:
        pass


def _fetch_master_direct(url, timeout=15):
    try:
        import requests
        r = requests.get(url, headers=HEADERS_DM, timeout=timeout)
        if r.status_code == 200 and r.text:
            return r.text
        _log(f"direct status={r.status_code} bytes={len(r.text)}", 'warning')
    except Exception as exc:
        _log(f"direct exception: {exc}", 'warning')
    return None


def _fetch_master_warmup(url, timeout=15):
    try:
        import requests
        s = requests.Session()
        s.get("https://www.dailymotion.com/", headers=HEADERS_DM, timeout=timeout)
        r = s.get(url, headers=HEADERS_DM, timeout=timeout)
        if r.status_code == 200 and r.text:
            _log(f"warmup OK cookies={sorted(s.cookies.keys())}", 'info')
            return r.text
        _log(f"warmup status={r.status_code} bytes={len(r.text)} cookies={sorted(s.cookies.keys())}", 'warning')
    except Exception as exc:
        _log(f"warmup exception: {exc}", 'warning')
    return None


def _fetch_master_subprocess(url, timeout=20):
    # Vale en cualquier plataforma con python en el PATH: es la unica via cuyo
    # TLS no lo negocia el interprete de Kodi. En Android no hay, y ahi salta
    # FileNotFoundError, que ya se captura.
    try:
        import subprocess
        extra = {'creationflags': 0x08000000} if sys.platform.startswith('win') else {}
        p = subprocess.run(
            ['python', '-c', _FETCH_MASTER_SCRIPT, url],
            capture_output=True, timeout=timeout,
            **extra,
        )
        if p.returncode == 0 and p.stdout:
            text = p.stdout.decode('utf-8', errors='replace')
            if text:
                _log(f"subprocess OK bytes={len(text)}", 'info')
                return text
        stderr = (p.stderr or b'').decode('utf-8', errors='replace')[:200]
        _log(f"subprocess rc={p.returncode} stderr={stderr}", 'warning')
    except FileNotFoundError:
        _log("subprocess: python no encontrado en PATH", 'warning')
    except Exception as exc:
        _log(f"subprocess exception: {exc}", 'warning')
    return None


def _abridor():
    """Opener de urllib con tarro de cookies, para metadata y master a la vez:
    cdndirector solo entrega el master si trae las cookies de la metadata."""
    return urllib.request.build_opener(
        urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))


def _get(abridor, url, timeout=15):
    with abridor.open(urllib.request.Request(url, headers=HEADERS_DM), timeout=timeout) as r:
        return r.read().decode('utf-8', errors='replace')


def _fetch_master_cookies(url, abridor):
    try:
        return _get(abridor, url)
    except Exception as exc:
        _log(f"cookies exception: {exc}", 'warning')
    return None


def _fetch_master(url, abridor=None):
    """Un master válido debe contener #EXT-X-STREAM-INF, no solo cabeceras HTTP.

    Con `abridor` (el que pidió la metadata) se prueba primero urllib con sus
    cookies. urllib sin cookies no está entre las estrategias: cdndirector lo
    rechaza siempre y solo añadiría espera.
    """
    estrategias = [_fetch_master_direct, _fetch_master_warmup, _fetch_master_subprocess]
    if abridor is not None:
        estrategias.insert(0, lambda u: _fetch_master_cookies(u, abridor))
    for strategy in estrategias:
        text = strategy(url)
        if text and '#EXT-X-STREAM-INF' in text:
            return text
    return None


def fetch_hls_variants(master_url, headers=None, abridor=None):
    """`headers` se ignora, se usan HEADERS_DM. Parámetro mantenido por compat.
    `abridor` es el opener con el que se pidió la metadata, si se tiene."""
    from urllib.parse import urljoin

    text = _fetch_master(master_url, abridor)
    if not text:
        return []

    variants = []
    current_bw = 0
    current_res = ''
    expecting = False
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        if line.startswith('#EXT-X-STREAM-INF'):
            bw_m = re.search(r'BANDWIDTH=(\d+)', line)
            res_m = re.search(r'RESOLUTION=(\d+x\d+)', line)
            current_bw = int(bw_m.group(1)) if bw_m else 0
            current_res = res_m.group(1) if res_m else ''
            expecting = True
        elif expecting and not line.startswith('#'):
            url = line if line.startswith('http') else urljoin(master_url, line)
            url = url.split('#')[0]  # quitar fragmentos #cell=cf4
            variants.append({'url': url, 'bandwidth': current_bw, 'resolution': current_res})
            expecting = False
    variants.sort(key=lambda x: x['bandwidth'], reverse=True)
    return variants


def resolve(vid, max_height=1080):
    """Resuelve un vid de DM a una variante HLS directa (vod*.cf.dmcdn.net).
    Devuelve {'url', 'mime', 'subs', 'headers'} o None si falla."""
    if not vid or not isinstance(vid, str) or not vid.strip():
        return None

    meta_url = f"https://www.dailymotion.com/player/metadata/video/{urllib.parse.quote(vid.strip())}"
    # La metadata va por el mismo opener que luego pedirá el master, para que
    # las cookies que deja lleguen a cdndirector.
    abridor = _abridor()
    try:
        data = json.loads(_get(abridor, meta_url))
        # DM016: el autor solo deja verlo en dailymotion.com. Pedida como la web
        # de DM (lo mismo que hace yt-dlp), la metadata sale en la mayoría de
        # casos; si en realidad es privado, la respuesta pasa a ser DM020.
        if isinstance(data, dict) and (data.get('error') or {}).get('code') == 'DM016':
            data = json.loads(_get(abridor, meta_url + '?app=com.dailymotion.neon'))
    except Exception as exc:
        _log(f"metadata error vid={vid}: {exc}", 'warning')
        return None

    if not isinstance(data, dict) or data.get('error'):
        return None

    qualities = data.get('qualities', {}) or {}
    subs = []
    for sub_list in (data.get('subtitles') or {}).values():
        if isinstance(sub_list, list):
            for s in sub_list:
                if isinstance(s, dict) and s.get('url'):
                    subs.append(s['url'])

    # MP4 directo, raro en la API actual.
    best_mp4, best_res = None, 0
    for res_key, fmts in qualities.items():
        if res_key == 'auto':
            continue
        try:
            res_val = int(res_key)
        except (ValueError, TypeError):
            continue
        if res_val > max_height:
            continue
        for fmt in fmts:
            if isinstance(fmt, dict) and fmt.get('type') == 'video/mp4' and res_val > best_res:
                best_mp4 = fmt.get('url')
                best_res = res_val
    if best_mp4:
        _log(f"MP4 directo {best_res}p vid={vid}", 'info')
        return {'url': best_mp4, 'mime': 'video/mp4', 'subs': subs, 'headers': HEADERS_DM}

    hls_master = None
    for item in qualities.get('auto', []) or []:
        if isinstance(item, dict) and item.get('type') == 'application/x-mpegURL':
            hls_master = item.get('url')
            if hls_master:
                break
    if not hls_master:
        _log(f"sin HLS en metadata vid={vid}", 'warning')
        return None

    variants = fetch_hls_variants(hls_master, abridor=abridor)
    if not variants:
        _log(f"sin variantes para vid={vid} (todas las estrategias fallaron)", 'error')
        return None

    filtered = []
    for v in variants:
        res = v.get('resolution', '')
        try:
            ancho, alto = (int(x) for x in res.split('x'))
            # El lado menor es la calidad real: en vertical (480x848) el limite
            # lo marca el ancho, y comparar contra el alto degrada sin motivo.
            calidad = min(ancho, alto)
        except (ValueError, IndexError):
            calidad = 0
        if calidad == 0 or calidad <= max_height:
            filtered.append(v)
    chosen = filtered[0] if filtered else variants[-1]
    _log(f"variante {chosen.get('resolution','?')} bw={chosen['bandwidth']} vid={vid}", 'info')
    return {'url': chosen['url'], 'mime': 'application/x-mpegURL', 'subs': subs, 'headers': HEADERS_DM}
