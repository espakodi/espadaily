# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
"""Arranque y parada del servidor de la WebApp.

Cada acción del plugin corre en un intérprete nuevo. El servidor vive en la invocación que
lo arrancó, que Kodi mantiene viva mientras sus hilos corren, y las demás invocaciones no
ven sus variables. Por eso el estado se publica en propiedades de la ventana Home y un hilo
vigilante del servidor atiende la orden de parada que deja cualquier otra invocación.
Sin esto, el autoarranque del servicio y cada "Abrir WebApp" levantaban un servidor más.
"""
import socket
import threading
import time
import uuid

import xbmc
import xbmcgui

_DEFAULT_PORT = 8089
_STOP_WAIT_S = 3.0
_START_WAIT_S = 5.0

# Prefijo propio, porque AtresDaily publica el suyo en la misma ventana.
_P_OWNER = 'espadaily.webapp.owner'
_P_PORT = 'espadaily.webapp.port'
_P_MODE = 'espadaily.webapp.mode'
_P_CMD = 'espadaily.webapp.cmd'
_P_STARTING = 'espadaily.webapp.starting'


def _win():
    return xbmcgui.Window(10000)


def get_lan_ip():
    """Obtiene la dirección IP LAN de la interfaz activa del dispositivo."""
    try:
        kodi_ip = xbmc.getIPAddress()
        if kodi_ip and kodi_ip not in ('', '127.0.0.1', '0.0.0.0'):
            return kodi_ip
    except Exception:
        pass
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return '127.0.0.1'


def _read_config():
    """Recupera la configuración de red persistente."""
    try:
        import ui_utils
        cfg = ui_utils.load_json('settings.json')
        lan = bool(cfg.get('webapp_lan_mode', False))
        port = int(cfg.get('webapp_port', _DEFAULT_PORT))
        if port < 1024 or port > 65535:
            port = _DEFAULT_PORT
        return lan, port
    except Exception:
        return False, _DEFAULT_PORT


def _build_url(port, lan_mode):
    is_android = xbmc.getCondVisibility("System.Platform.Android")
    ip = get_lan_ip() if (lan_mode or is_android) else '127.0.0.1'
    return f'http://{ip}:{port}/'


def _alive(port):
    try:
        with socket.create_connection(('127.0.0.1', int(port)), timeout=0.5):
            return True
    except (OSError, ValueError):
        return False


def _clear(owner):
    w = _win()
    if w.getProperty(_P_OWNER) == owner:
        for p in (_P_OWNER, _P_PORT, _P_MODE):
            w.clearProperty(p)


def _running():
    """(owner, port, mode) del servidor en marcha, o None. Si la invocación que lo alojaba
    murió sin avisar, el puerto ya no escucha y se limpia el estado huérfano."""
    w = _win()
    owner = w.getProperty(_P_OWNER)
    if not owner:
        return None
    port = w.getProperty(_P_PORT)
    if _alive(port):
        return owner, int(port), w.getProperty(_P_MODE)
    _clear(owner)
    return None


def _wait_until(cond, timeout):
    """Espera hasta que cond() sea cierta o pase el plazo. Devuelve cond() al salir."""
    monitor = xbmc.Monitor()
    limite = time.time() + timeout
    while not cond() and time.time() < limite:
        if monitor.waitForAbort(0.1):
            break
    return cond()


def _watch(srv, owner):
    """Hilo vigilante que para el servidor cuando otra invocación lo pide o Kodi se cierra."""
    w = _win()
    stop_cmd = 'stop:' + owner
    monitor = xbmc.Monitor()
    try:
        while not monitor.waitForAbort(0.5):
            # También se para si el estado publicado ya es de otro servidor (dos arranques a
            # la vez, o una invocación que lo dio por muerto). Nadie podría detenerlo y
            # seguiría ocupando el puerto.
            if w.getProperty(_P_CMD) == stop_cmd or w.getProperty(_P_OWNER) != owner:
                break
    finally:
        # shutdown() y después server_close(). Al revés se cierra el socket bajo los pies
        # de serve_forever.
        srv.shutdown()
        srv.server_close()
        try:
            _clear(owner)
            # La orden se retira al final y no al leerla; mientras siga puesta, las demás
            # invocaciones saben que este servidor se está parando y no lo reutilizan.
            if w.getProperty(_P_CMD) == stop_cmd:
                w.clearProperty(_P_CMD)
        except RuntimeError:
            pass  # Kodi ya está desmontando la interfaz
        xbmc.log('[EspaWebApp] Servidor detenido.', xbmc.LOGINFO)


def _request_stop(owner):
    """Pide la parada al vigilante y espera a que la confirme. True si quedó parado."""
    w = _win()
    w.setProperty(_P_CMD, 'stop:' + owner)
    if _wait_until(lambda: w.getProperty(_P_OWNER) != owner, _STOP_WAIT_S):
        return True
    return _running() is None


def ensure_running():
    """Arranca el servidor, o reutiliza el que ya corre si coincide la configuración.
    Devuelve la URL, o None si no se pudo arrancar."""
    lan_mode, cfg_port = _read_config()
    if xbmc.getCondVisibility("System.Platform.Android"):
        lan_mode = True
    desired_mode = 'lan' if lan_mode else 'local'
    w = _win()

    # Si otra invocación ya está arrancando (doble clic), se espera su servidor en vez de
    # levantar otro, que en Linux caería en el puerto siguiente y lo dejaría guardado.
    starting = w.getProperty(_P_STARTING)
    try:
        otro_arrancando = bool(starting) and time.time() - float(starting.split(':')[1]) < _START_WAIT_S
    except (IndexError, ValueError):
        otro_arrancando = False
    if otro_arrancando:
        _wait_until(lambda: not w.getProperty(_P_STARTING), _START_WAIT_S)

    running = _running()
    if running:
        owner, port, mode = running
        # Con una parada en curso no se reutiliza; se espera a que termine.
        parando = w.getProperty(_P_CMD) == 'stop:' + owner
        if not parando and mode == desired_mode and port == cfg_port:
            return _build_url(port, lan_mode)
        if not _request_stop(owner):
            xbmc.log('[EspaWebApp] El servidor anterior no respondió a la orden de parada', xbmc.LOGWARNING)
            return None

    marca = f'{uuid.uuid4().hex}:{time.time()}'
    w.setProperty(_P_STARTING, marca)
    try:
        host = '0.0.0.0' if lan_mode else '127.0.0.1'
        try:
            from .server import make_server
            srv, port = make_server(host=host, port=cfg_port)
        except Exception as e:
            xbmc.log(f'[EspaWebApp] Error al arrancar servidor: {e}', xbmc.LOGERROR)
            return None

        owner = uuid.uuid4().hex
        w.setProperty(_P_PORT, str(port))
        w.setProperty(_P_MODE, desired_mode)
        w.setProperty(_P_OWNER, owner)
        threading.Thread(target=srv.serve_forever, daemon=True, name='EspaWebApp').start()
        threading.Thread(target=_watch, args=(srv, owner), daemon=True, name='EspaWebAppWatch').start()
    finally:
        if w.getProperty(_P_STARTING) == marca:
            w.clearProperty(_P_STARTING)

    url = _build_url(port, lan_mode)
    xbmc.log(f'[EspaWebApp] Servidor iniciado en {url}', xbmc.LOGINFO)
    # Si el puerto pedido estaba ocupado, se guarda el que se ha usado.
    if port != cfg_port:
        _persist_port(port)
    return url


def restart_if_running():
    """Aplica un cambio de puerto o de modo al servidor en marcha; si está parado, no lo
    arranca. Devuelve la URL nueva, o None si no había servidor."""
    if _running() is None:
        return None
    return ensure_running()


def _persist_port(port):
    try:
        import ui_utils
        cfg = ui_utils.load_json('settings.json')
        cfg['webapp_port'] = int(port)
        ui_utils.save_json('settings.json', cfg)
        xbmc.log(f'[EspaWebApp] webapp_port actualizado a {port} en settings.json', xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f'[EspaWebApp] No se pudo persistir el puerto: {e}', xbmc.LOGWARNING)


def stop():
    """Para el servidor, lo aloje esta invocación u otra. True si queda parado."""
    running = _running()
    return True if running is None else _request_stop(running[0])


def get_url():
    """URL del servidor en marcha, o None si está parado."""
    running = _running()
    if running is None:
        return None
    return _build_url(running[1], running[2] == 'lan')


def open_in_browser(url):
    """Abre la URL en el navegador del sistema (o una actividad VIEW en Android)."""
    if xbmc.getCondVisibility("System.Platform.Android"):
        try:
            xbmc.executebuiltin(f"StartAndroidActivity(,android.intent.action.VIEW,,{url})")
        except Exception as e:
            xbmc.log(f'[EspaWebApp] No se pudo abrir el navegador (Android): {e}', xbmc.LOGWARNING)
    else:
        try:
            import webbrowser
            webbrowser.open(url)
        except Exception as e:
            xbmc.log(f'[EspaWebApp] No se pudo abrir el navegador: {e}', xbmc.LOGWARNING)
