# -*- coding: utf-8 -*-
# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
"""EPG en Texto - parrilla de programacion en texto, canales de EspaDaily."""
import gzip
import io
import json
import os
import re
import sys
import time
import urllib.parse
import xml.etree.ElementTree as ET
import zlib
from datetime import datetime, timedelta, timezone

import requests

import _user_agents
import core_settings
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_LOG     = "[EspaDaily-EPG]"
_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
_CACHE_FILE       = os.path.join(_PROFILE, "epg_texto_cache.json")
_CACHE_TTL        = 7200  # 2 horas
_TIMEOUT          = 30
_EPG_URL          = "https://epgshare01.online/epgshare01/epg_ripper_ES1.xml.gz"
_EPG_URL_FALLBACK = "https://raw.githubusercontent.com/davidmuma/EPG_dobleM/master/guiatv_sincolor.xml.gz"
# Tope de lo que se descomprime, por si una fuente mandara algo desmedido. Las guías
# completas rondan los 50 MB.
_MAX_XML = 200 * 1024 * 1024
# Y de lo que se descarga, porque la guía de una lista de canales la pone quien hizo la lista.
_MAX_DESCARGA = 100 * 1024 * 1024
# Canales nacionales con programa en emisión que hacen falta para quedarse con una fuente.
# Una guía atrasada solo trae días pasados y no llega a ninguno.
_MIN_NACIONALES = 5
_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")

_ACCENT_MAP = str.maketrans(
    "áéíóúñÁÉÍÓÚÑàèìòùÀÈÌÒÙäëïöüÄËÏÖÜâêîôûÂÊÎÔÛ",
    "aeiounAEIOUNaeiouAEIOUaeiouAEIOUaeiouAEIOU"
)

_PUNCT = ".· \t-_/\\(),;:'\"+&[]{}|"


def _norm(s):
    """Normaliza para emparejar: minusculas, sin acentos/espacios/puntuacion ni sufijos region/HD."""
    if not s:
        return ""
    s = s.strip().lower().translate(_ACCENT_MAP)
    for c in _PUNCT:
        s = s.replace(c, "")
    # Sufijos de region (uno solo)
    for suf in ("spain", "espana", "esp", "es", "gal", "cat", "eus"):
        if s.endswith(suf) and len(s) > len(suf):
            s = s[:-len(suf)]
            break
    # Sufijos de calidad (pueden repetirse)
    while True:
        prev = s
        for suf in ("fullhd", "uhd4k", "uhd", "fhd", "hd", "4k", "sd"):
            if s.endswith(suf) and len(s) > len(suf):
                s = s[:-len(suf)]
                break
        if s == prev:
            break
    return s


# Canales en EspaDaily, en orden LCN.
# Cada entrada: (nombre a mostrar, tupla de aliases ya normalizados a evaluar contra _norm(id) y _norm(display-name) del XML).
# Anade variantes que veas en distintos repositorios de EPG (epgshare01, davidmuma, etc.)
_CHANNELS = (
    ("La 1",        ("la1", "launo", "tve1", "rtve1", "tvela1", "rtvela1", "tve la1", "la1tve")),
    ("La 2",        ("la2", "lados", "tve2", "rtve2", "tvela2", "rtvela2", "tve la2", "la2tve")),
    ("Antena 3",    ("antena3", "antenatres", "a3", "antena3tv")),
    ("Cuatro",      ("cuatro", "canal4", "ch4", "4tv")),
    ("Telecinco",   ("telecinco", "tele5", "t5", "tele cinco", "5tv")),
    ("laSexta",     ("lasexta", "la6", "sexta", "lasextatv", "6tv")),
    ("Canal 24h",   ("24h", "canal24h", "canal24horas", "24horas", "tve24h", "rtve24h", "24horastve")),
    ("Teledeporte", ("teledeporte", "tdp", "tdptve", "rtvetdp")),
    ("Boing",       ("boing", "boingtv", "boinges")),
    ("Clan TVE",    ("clan", "clantve", "clantv", "tveclan", "rtveclan")),
    ("Neox",        ("neox", "neoxtv")),
    ("Nova",        ("nova", "novatv")),
    ("Mega",        ("mega", "megatv")),
    ("Energy",      ("energy", "energytv")),
    ("FDF",         ("fdf", "factoriadeficcion", "factoriaficcion")),
    ("Atreseries",  ("atreseries", "atresseries", "atre series", "atresseriestv")),
    ("Be Mad",      ("bemad", "bemadtv")),
    ("Divinity",    ("divinity", "divinitytv", "divinityes")),
)


def _icon(fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, "cat_epg_texto.png")
    if os.path.isfile(p):
        return p
    p2 = os.path.join(_MEDIA, "directo.png")
    return p2 if os.path.isfile(p2) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _utc_to_local(utc_dt):
    return utc_dt.replace(tzinfo=timezone.utc).astimezone().replace(tzinfo=None)


def _parse_epg_dt(s):
    # Sin strptime: bug #7980 lo rompe en threads de Kodi.
    if not s:
        return None
    s = s[:14] if len(s) >= 14 else (s[:12] + "00" if len(s) >= 12 else None)
    if not s or len(s) != 14 or not s.isdigit():
        return None
    try:
        return datetime(int(s[0:4]), int(s[4:6]), int(s[6:8]),
                        int(s[8:10]), int(s[10:12]), int(s[12:14]))
    except (ValueError, TypeError):
        return None


_XMLTV_TS_RE = re.compile(r'^\s*(\d{12}(?:\d{2})?)\s*(?:([+-])(\d{2}):?(\d{2}))?')


def _to_utc14(s):
    """Sello XMLTV ('20260923210000 +0200') a 14 dígitos en UTC, o None si no se entiende.

    Las fuentes publican en hora española (+0200/+0100). Guardar los 14 primeros dígitos
    tal cual y tratarlos como UTC desplazaba la guía 1-2 horas y marcaba como "ahora" el
    programa de hace dos horas. Sin desfase se toma como UTC, como dice el formato XMLTV.
    """
    m = _XMLTV_TS_RE.match(s or "")
    if not m:
        return None
    dt = _parse_epg_dt(m.group(1))
    if dt is None:
        return None
    if m.group(2):
        delta = timedelta(hours=int(m.group(3)), minutes=int(m.group(4)))
        dt = dt - delta if m.group(2) == "+" else dt + delta
    return dt.strftime("%Y%m%d%H%M%S")


def _fmt_time(ts_str):
    if ts_str is None:
        return ""
    utc_dt = _parse_epg_dt(ts_str)
    if utc_dt is None:
        return ts_str[:4] if ts_str else ""
    local_dt = _utc_to_local(utc_dt)
    return "{0:02d}:{1:02d}".format(local_dt.hour, local_dt.minute)


# Versión 3: la caché gana el campo fuente para recordar qué servidor sirvió la última vez.
_CACHE_VERSION = 3


def _load_cache():
    try:
        with open(_CACHE_FILE, "r", encoding="utf-8") as f:
            obj = json.load(f)
        if obj.get("v") == _CACHE_VERSION and time.time() - obj.get("ts", 0) < _CACHE_TTL:
            return obj.get("channels", {}), obj.get("programmes", {})
    except (OSError, ValueError, AttributeError, TypeError):
        pass
    return None, None


def _save_cache(channels, programmes, fuente):
    # Atómico, con tmp por proceso e hilo, porque la leen el menú EPG y el Modo TV a veces
    # a la vez, y un corte a mitad no puede dejarla rota.
    ok = core_settings.atomic_write_json(
        _CACHE_FILE, {"v": _CACHE_VERSION, "ts": time.time(), "fuente": fuente, "channels": channels,
                      "programmes": programmes}, ensure_ascii=False)
    if not ok:
        xbmc.log(f"{_LOG} No se pudo guardar la caché", xbmc.LOGWARNING)


def _fuente_anterior():
    """Fuente de la última guía guardada, aunque haya caducado."""
    try:
        with open(_CACHE_FILE, "r", encoding="utf-8") as f:
            return json.load(f).get("fuente")
    except (OSError, ValueError, AttributeError):
        return None


class GuiaDemasiadoGrande(ValueError):
    """La guía pasa de _MAX_DESCARGA."""


def _download_epg(url):
    """La guía tal como la sirve la fuente, comprimida o no."""
    headers = {"User-Agent": _user_agents.UA_DESKTOP, "Accept-Encoding": "gzip"}
    with requests.get(url, headers=headers, timeout=_TIMEOUT, stream=True) as resp:
        resp.raise_for_status()
        datos = bytearray()
        for trozo in resp.iter_content(65536):
            datos += trozo
            if len(datos) > _MAX_DESCARGA:
                raise GuiaDemasiadoGrande(f"la guía pasa de {_MAX_DESCARGA // (1024 * 1024)} MB")
        return bytes(datos)


# Lo que puede salir mal al bajar y leer una fuente; con cualquiera se prueba la siguiente.
_FALLOS_FUENTE = (requests.RequestException, OSError, EOFError, zlib.error, ET.ParseError, ValueError)


class _LectorConTope:
    """Fichero que da ValueError al pasar de `tope` bytes leídos."""

    def __init__(self, f, tope):
        self._f = f
        self._quedan = tope

    def read(self, n=-1):
        datos = self._f.read(n)
        self._quedan -= len(datos)
        if self._quedan < 0:
            raise ValueError("la guía descomprimida pasa del tope")
        return datos


def _parse_epg(datos, horas=26):
    """(canales, programas) de una guía XMLTV, comprimida con gzip o no, con lo que se emite desde
    2 h antes hasta `horas` después. Se lee por partes, porque una guía completa ronda los 50 MB."""
    channels = {}
    programmes = {}
    now_utc = datetime.now(timezone.utc).replace(tzinfo=None)
    cutoff_start = now_utc - timedelta(hours=2)
    cutoff_end = now_utc + timedelta(hours=horas)
    # Una guía trae la semana entera: lo que cae a más de un día de la ventana se descarta
    # por la fecha del sello, sin más cuentas. El día de margen cubre cualquier desfase horario.
    dia_min = (cutoff_start - timedelta(days=1)).strftime("%Y%m%d")
    dia_max = (cutoff_end + timedelta(days=1)).strftime("%Y%m%d")

    crudo = io.BytesIO(datos)
    with (gzip.GzipFile(fileobj=crudo) if datos[:2] == b"\x1f\x8b" else crudo) as fz:
        eventos = ET.iterparse(_LectorConTope(fz, _MAX_XML), events=("start", "end"))
        _, raiz = next(eventos)
        for evento, el in eventos:
            if evento != "end" or el.tag not in ("channel", "programme"):
                continue
            if el.tag == "channel":
                ch_id = el.get("id", "")
                names = [e.text for e in el.findall("display-name") if e.text]
                ch_name = names[0] if names else ch_id
                icon_el = el.find("icon")
                ch_icon = icon_el.get("src", "") if icon_el is not None else ""
                if ch_id:
                    channels[ch_id] = {"name": ch_name, "names": names, "icon": ch_icon}
            else:
                ch_id = el.get("channel", "")
                inicio = el.get("start", "")
                fin = el.get("stop", "")
                lejos = inicio.lstrip()[:8] > dia_max or (fin and fin.lstrip()[:8] < dia_min)
                start_s = None if lejos else _to_utc14(inicio)
                stop_s = (_to_utc14(fin) or "") if start_s else ""
                if ch_id and start_s:
                    start_dt = _parse_epg_dt(start_s)
                    # Por el final, para no perder lo que empezó hace rato y sigue en emisión.
                    fin_dt = _parse_epg_dt(stop_s) if stop_s else start_dt
                    if fin_dt >= cutoff_start and start_dt <= cutoff_end:
                        title_el = el.find("title")
                        desc_el = el.find("desc")
                        cat_el = el.find("category")
                        programmes.setdefault(ch_id, []).append({
                            "start": start_s,
                            "stop": stop_s,
                            "title": title_el.text if title_el is not None and title_el.text else "Sin título",
                            "desc": desc_el.text if desc_el is not None and desc_el.text else "",
                            "cat": cat_el.text if cat_el is not None and cat_el.text else "",
                        })
            raiz.clear()

    for progs in programmes.values():
        progs.sort(key=lambda x: x["start"])
    return channels, programmes


def _nacionales_en_emision(channels, programmes):
    """Cuántos canales de _resolve_channels(channels) tienen un programa en emisión ahora."""
    ahora = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    res = _resolve_channels(channels)
    return sum(1 for _, cid, _ in res
               if any(p["start"] <= ahora and (not p["stop"] or ahora < p["stop"]) for p in programmes.get(cid, [])))


def _fetch_epg():
    channels, programmes = _load_cache()
    if channels is not None:
        return channels, programmes

    # La primera fuente que tenga programas de ahora en los nacionales; si ninguna llega,
    # la que más tenga. Una fuente puede responder bien y traer solo días pasados.
    # La que sirvió la última vez va primero: con la principal atrasada, así no se baja
    # y se lee entera cada dos horas para nada. "Actualizar parrilla" borra la caché y
    # vuelve a empezar por la principal.
    fuentes = [_EPG_URL, _EPG_URL_FALLBACK]
    anterior = _fuente_anterior()
    if anterior in fuentes:
        fuentes.remove(anterior)
        fuentes.insert(0, anterior)
    mejor = None
    for url in fuentes:
        try:
            xbmc.log(f"{_LOG} Descargando EPG desde {url}...", xbmc.LOGINFO)
            chs, progs = _parse_epg(_download_epg(url))
        except _FALLOS_FUENTE as e:
            xbmc.log(f"{_LOG} Fuente EPG {url} falló: {e}", xbmc.LOGWARNING)
            continue
        en_emision = _nacionales_en_emision(chs, progs)
        if mejor is None or en_emision > mejor[2]:
            mejor = (chs, progs, en_emision, url)
        if en_emision >= _MIN_NACIONALES:
            break
        xbmc.log(f"{_LOG} {url}: {en_emision} canales nacionales con programa ahora", xbmc.LOGINFO)

    if mejor is None:
        xbmc.log(f"{_LOG} Todas las fuentes EPG fallaron; se devuelve vacío", xbmc.LOGERROR)
        return {}, {}

    channels, programmes, _, fuente = mejor
    _save_cache(channels, programmes, fuente)
    return channels, programmes


def _is_hd_id(cid, name):
    """Detecta si el canal es variante HD/UHD/4K (para preferir SD cuando hay duplicados)."""
    src = (cid + " " + (name or "")).lower()
    return any(tok in src for tok in (" hd", "_hd", "-hd", "hd ", ".hd", "hd.",
                                       "fhd", "uhd", "4k", "ultrahd"))


def _build_channel_index(xml_channels):
    """Mapa: clave normalizada -> [(es_hd, cid, info), ...]"""
    index = {}
    for cid, info in xml_channels.items():
        is_hd = _is_hd_id(cid, info.get("name", ""))
        sources = [cid] + list(info.get("names") or []) + [info.get("name", "")]
        for src in sources:
            n = _norm(src)
            if not n:
                continue
            entry = (is_hd, cid, info)
            bucket = index.setdefault(n, [])
            if entry not in bucket:
                bucket.append(entry)
    return index


def _resolve_channels(xml_channels):
    """Devuelve [(display_name, cid, info), ...] en orden _CHANNELS, prefiriendo SD sobre HD."""
    if not xml_channels:
        return []
    index = _build_channel_index(xml_channels)
    out = []
    seen = set()
    for display_name, aliases in _CHANNELS:
        best = None  # (is_hd, cid, info)
        for alias in aliases:
            n = _norm(alias)
            if not n:
                continue
            for entry in index.get(n, []):
                is_hd, cid, info = entry
                if cid in seen:
                    continue
                if best is None:
                    best = entry
                elif best[0] and not is_hd:
                    best = entry
                if best is not None and not best[0]:
                    break
            if best is not None and not best[0]:
                break
        if best is not None:
            _, cid, info = best
            out.append((display_name, cid, info))
            seen.add(cid)
        else:
            xbmc.log("{0} Canal no encontrado en EPG: {1}".format(_LOG, display_name), xbmc.LOGINFO)
    return out


def epg_texto_espadaily():
    h = int(sys.argv[1])
    xbmcplugin.setPluginCategory(h, "Programacion TV (EPG en texto)")
    try:
        xbmcgui.Dialog().notification("EPG", "Cargando parrilla...", xbmcgui.NOTIFICATION_INFO, 1500)
        channels, programmes = _fetch_epg()
    except Exception as e:
        xbmc.log("{0} Error: {1}".format(_LOG, e), xbmc.LOGERROR)
        li = xbmcgui.ListItem(label="[COLOR red]Error cargando EPG - comprueba la red[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    icon    = _icon()
    now_utc = datetime.now(timezone.utc).replace(tzinfo=None)
    matched = _resolve_channels(channels)

    if not matched:
        li = xbmcgui.ListItem(label="[COLOR grey]Sin datos EPG disponibles[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        li_r = xbmcgui.ListItem(label="[COLOR aqua][ Reintentar ][/COLOR]")
        li_r.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="epg_texto_refresh"), listitem=li_r, isFolder=True)
        xbmcplugin.endOfDirectory(h)
        return

    for display_name, ch_id, ch_info in matched:
        ch_icon = ch_info.get("icon") or icon
        progs   = programmes.get(ch_id, [])
        n_progs = len(progs)

        current = None
        for p in progs:
            s = _parse_epg_dt(p["start"])
            if s is None:
                continue
            e = _parse_epg_dt(p["stop"]) if p["stop"] else s + timedelta(hours=1)
            if e is None:
                e = s + timedelta(hours=1)
            if s <= now_utc < e:
                current = p
                break

        now_label = ("  [COLOR deepskyblue]{0}[/COLOR]".format(current["title"]) if current else "")
        label = "[B]{0}[/B]{1}  [COLOR grey]({2} prog.)[/COLOR]".format(display_name, now_label, n_progs)
        plot  = "{0}\n{1} programas en parrilla".format(display_name, n_progs)
        if current:
            plot += "\nAhora: {0}".format(current["title"])
            if current.get("desc"):
                plot += "\n{0}".format(current["desc"])

        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": ch_icon, "thumb": ch_icon})
        li.setInfo("video", {"title": display_name, "plot": plot})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="epg_texto_canal", ch_id=ch_id, ch_name=display_name),
            listitem=li,
            isFolder=True,
        )

    li_r = xbmcgui.ListItem(label="[COLOR aqua][ Actualizar parrilla ][/COLOR]")
    li_r.setArt({"icon": "DefaultIconInfo.png"})
    li_r.setInfo("video", {"plot": "Recarga la parrilla EPG."})
    li_r.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="epg_texto_refresh"), listitem=li_r, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def epg_texto_canal(ch_id, ch_name):
    h = int(sys.argv[1])
    if ch_name:
        xbmcplugin.setPluginCategory(h, ch_name)
    try:
        _channels, programmes = _fetch_epg()
    except Exception as e:
        xbmc.log("{0} Error canal: {1}".format(_LOG, e), xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    progs   = programmes.get(ch_id, [])
    icon    = _icon()
    now_utc = datetime.now(timezone.utc).replace(tzinfo=None)

    if not progs:
        li = xbmcgui.ListItem(label="[COLOR grey]Sin programacion disponible[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    prev_date = None
    for p in progs:
        start_utc = _parse_epg_dt(p["start"])
        if start_utc is None:
            continue
        is_now = False
        if p["stop"]:
            stop_utc = _parse_epg_dt(p["stop"])
            if stop_utc is not None:
                is_now = start_utc <= now_utc < stop_utc

        local_start = _utc_to_local(start_utc)
        date_str    = "{0:02d}/{1:02d}".format(local_start.day, local_start.month)

        if date_str != prev_date:
            prev_date = date_str
            sep = xbmcgui.ListItem(label="[COLOR gold]--  {0}  --[/COLOR]".format(date_str))
            sep.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=sep, isFolder=False)

        hora   = _fmt_time(p["start"])
        titulo = p["title"]
        desc   = p.get("desc", "")
        cat    = p.get("cat", "")

        if is_now:
            color = "gold"
            marca = "  [COLOR gold]EN CURSO[/COLOR]"
        else:
            color = "white"
            marca = ""

        label = "[B][COLOR {0}]{1}[/COLOR][/B]  {2}{3}".format(color, hora, titulo, marca)
        plot  = "{0}  {1}\n{2}".format(hora, titulo, desc)
        if cat:
            plot += "\n[{0}]".format(cat)

        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": icon})
        li.setInfo("video", {"title": titulo, "plot": plot})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="epg_texto_programa", title=titulo, plot=plot),
            listitem=li,
            isFolder=False,
        )

    xbmcplugin.endOfDirectory(h)


def epg_texto_programa(title, plot):
    xbmcgui.Dialog().textviewer(title, plot)


def epg_texto_refresh():
    try:
        os.remove(_CACHE_FILE)
    except OSError:
        pass
    try:
        channels, _ = _fetch_epg()
        if not channels:
            xbmcgui.Dialog().notification(
                "EPG", "Sin datos disponibles. Reintenta en unos minutos.",
                xbmcgui.NOTIFICATION_WARNING, 3000
            )
    except Exception as e:
        xbmc.log("{0} Refresh fallo: {1}".format(_LOG, e), xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            "EPG", "Error al actualizar - fuente caida",
            xbmcgui.NOTIFICATION_ERROR, 3000
        )
    xbmc.executebuiltin("Container.Update({0},replace)".format(_u(action="epg_texto_espadaily")))
