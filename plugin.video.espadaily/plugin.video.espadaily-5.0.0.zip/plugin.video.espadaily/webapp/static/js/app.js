import { API } from './api.js';
import { Icons } from './icons.js';
import { renderHome } from './ui/home.js';
import { makeCard, makeSkeleton } from './ui/grid.js';
import { openPlayer, closePlayer, isPlayerOpen } from './ui/player.js';
import { openSearch, closeSearch } from './ui/search.js';
import { renderLive } from './ui/live.js';
import { renderContinue } from './ui/continue.js';
import { toast } from './ui/toast.js';

// Estado global de la aplicación
const state = {
  page: 'home',                          // home | catalog | live | favorites | details
  opts: {},                              // opciones de la página actual
  stack: [],                             // pila de breadcrumbs: [{page, opts, title}]
  favSet: new Set(),                     // URLs de favoritos
  installPrompt: null,
};

const mainEl = document.getElementById('app-main');
const header = document.getElementById('app-header');
const offlineBanner = document.getElementById('offline-banner');

// Inicialización y eventos iniciales de arranque
async function init() {
  setupHeader();
  setupOffline();
  setupPWA();
  setupGlobalKeys();

  await loadFavSet();
  navigate('home');
}

// Configuración del elemento Header y barra de navegación
function setupHeader() {
  header.innerHTML = `
    <div class="header-logo">espa<span>daily</span></div>
    <nav class="header-nav">
      <button class="active" data-nav="home">Inicio</button>
      <button data-nav="continue">Seguir viendo</button>
      <button data-nav="catalog">Catálogo</button>
      <button data-nav="live">Directos</button>
      <button data-nav="favorites">Mi Lista</button>
    </nav>
    <div class="header-actions">
      <button id="btn-search" title="Buscar (/)">${Icons.search}</button>
      <button id="btn-hamburger" title="Menú">${Icons.menu}</button>
      <button id="btn-install" class="hidden" title="Instalar app">${Icons.install}</button>
    </div>
  `;

  document.querySelectorAll('header [data-nav], #nav-drawer [data-nav]').forEach(btn => {
    btn.addEventListener('click', () => {
      closeNavDrawer();
      const target = btn.dataset.nav;
      if (target === 'catalog') {
        navigate('catalog', { kind: 'catalog_root', title: 'Catálogo' }, { resetStack: true });
      } else {
        navigate(target);
      }
    });
  });

  document.getElementById('btn-search').addEventListener('click', () => {
    openSearch(playItem, navigateItem, state.favSet);
  });

  document.getElementById('btn-hamburger').addEventListener('click', openNavDrawer);
  document.getElementById('nav-drawer-backdrop').addEventListener('click', closeNavDrawer);
  document.getElementById('nav-drawer-close').addEventListener('click', closeNavDrawer);

  const onScroll = () => header.classList.toggle('scrolled', window.scrollY > 20);
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
}

function openNavDrawer() {
  document.getElementById('nav-drawer').classList.remove('hidden');
  document.body.style.overflow = 'hidden';
}

function closeNavDrawer() {
  document.getElementById('nav-drawer').classList.add('hidden');
  document.body.style.overflow = '';
}

function setActiveNav(page) {
  document.querySelectorAll('header [data-nav], #nav-drawer [data-nav]').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.nav === page);
  });
}

// Enrutador y gestor de navegación de vistas
async function navigate(page, opts = {}, { fromPopState = false, resetStack = false } = {}) {
  // Limpiar historial de breadcrumbs en páginas base
  if (['home', 'live', 'favorites', 'continue'].includes(page) || resetStack) {
    state.stack = [];
  }

  state.page = page;
  state.opts = opts;
  setActiveNav(page);
  window.scrollTo(0, 0);
  mainEl.innerHTML = '';

  try {
    if (page === 'home') {
      await renderHome(mainEl, { onPlay: playItem, onNavigate: navigateItem, favSet: state.favSet });
    } else if (page === 'catalog') {
      await renderListing(opts);
    } else if (page === 'details') {
      await renderDetails(opts);
    } else if (page === 'live') {
      await renderLive(mainEl, { onPlay: playItem });
    } else if (page === 'continue') {
      await renderContinue(mainEl, { onPlay: playItem, onNavigate: navigateItem, favSet: state.favSet });
    } else if (page === 'favorites') {
      await renderFavorites();
    }
  } catch (e) {
    mainEl.innerHTML = `<div class="empty-state">Error: ${escHtml(e.message)}</div>`;
    toast(`Error: ${e.message}`, 'error');
  }

  if (!fromPopState) {
    const urlPath = page === 'home' ? '/' : `/${page}`;
    history.pushState({ page, opts, stack: [...state.stack] }, '', urlPath);
  }
}

window.addEventListener('popstate', (e) => {
  if (e.state) {
    state.stack = e.state.stack || [];
    state.opts = e.state.opts || {};
    navigate(e.state.page || 'home', e.state.opts || {}, { fromPopState: true });
  } else {
    navigate('home', {}, { fromPopState: true });
  }
});

// Renderizado de listados y grillas de contenidos
async function renderListing(opts) {
  const wrap = document.createElement('div');
  wrap.className = 'grid-view';
  mainEl.appendChild(wrap);

  const title = opts.title || 'Catálogo';
  const apiParams = { ...opts };
  delete apiParams.title;
  delete apiParams.stack;
  // Tipo de listado por defecto
  if (!apiParams.kind) apiParams.kind = 'catalog_root';

  buildBreadcrumbHeader(wrap, title);

  const grid = document.createElement('div');
  grid.className = 'grid page-enter';
  makeSkeleton(12).forEach(c => grid.appendChild(c));
  wrap.appendChild(grid);

  let data;
  try {
    data = await API.list(apiParams);
  } catch (e) {
    grid.innerHTML = `<div class="empty-state">Error: ${escHtml(e.message)}</div>`;
    return;
  }

  renderItemsIntoGrid(grid, data);
}

// Vista de detalles de programa (temporadas y episodios)
async function renderDetails(opts) {
  const wrap = document.createElement('div');
  wrap.className = 'grid-view';
  mainEl.appendChild(wrap);

  buildBreadcrumbHeader(wrap, opts.title || 'Detalles');

  const grid = document.createElement('div');
  grid.className = 'grid page-enter';
  makeSkeleton(8).forEach(c => grid.appendChild(c));
  wrap.appendChild(grid);

  let data;
  try {
    data = await API.details(opts.url, opts.ctx || '');
  } catch (e) {
    grid.innerHTML = `<div class="empty-state">Error: ${escHtml(e.message)}</div>`;
    return;
  }

  // Mediaset no siempre se puede listar en la webapp (depende del HTML de mitele):
  // en vez de un "Sin contenido" seco, sugerimos abrirlo en Kodi.
  const emptyHtml = data.source === 'mediaset'
    ? `<div class="empty-state" style="line-height:1.7">
         No se pueden listar los episodios de este contenido en la webapp.<br>
         Ábrelo desde <b>EspaDaily en Kodi</b> para verlo.
       </div>`
    : '';
  renderItemsIntoGrid(grid, data, emptyHtml);
}

function renderItemsIntoGrid(grid, data, emptyHtml = '') {
  grid.innerHTML = '';
  if (!data.items?.length) {
    grid.innerHTML = emptyHtml || `<div class="empty-state">Sin contenido disponible</div>`;
    return;
  }
  for (const item of data.items) {
    grid.appendChild(makeCard(item, playItem, navigateItem, state.favSet, 'landscape'));
  }
}

function buildBreadcrumbHeader(wrap, currentTitle) {
  const headerRow = document.createElement('div');
  headerRow.className = 'grid-header';
  headerRow.innerHTML = `
    <button class="grid-back" title="Volver">${Icons.arrowLeft}</button>
    <h2 class="grid-title">${escHtml(currentTitle)}</h2>
  `;
  headerRow.querySelector('.grid-back').addEventListener('click', goBack);
  wrap.appendChild(headerRow);

  if (state.stack.length > 1) {
    const bc = document.createElement('div');
    bc.className = 'grid-breadcrumbs';
    const parts = ['<span data-bc="home">Inicio</span>'];
    state.stack.slice(0, -1).forEach((entry, i) => {
      parts.push(`<span data-bc="${i}">${escHtml(entry.title || '')}</span>`);
    });
    bc.innerHTML = parts.join(' › ');
    bc.querySelectorAll('[data-bc]').forEach(el => {
      el.addEventListener('click', () => {
        const idx = el.dataset.bc;
        if (idx === 'home') { state.stack = []; navigate('home'); return; }
        const n = parseInt(idx);
        state.stack = state.stack.slice(0, n + 1);
        const entry = state.stack[state.stack.length - 1];
        state.stack = state.stack.slice(0, -1);
        navigate(entry.page, entry.opts);
      });
    });
    wrap.appendChild(bc);
  }
}

function goBack() {
  if (state.stack.length === 0) {
    navigate('home');
    return;
  }
  const prev = state.stack.pop();
  // Restaurar el estado visual previo de la pila de navegación
  state.page = prev.page;
  state.opts = prev.opts;
  setActiveNav(prev.page);
  mainEl.innerHTML = '';
  // Renderiza sin volver a apilar
  if (prev.page === 'catalog') renderListing(prev.opts);
  else if (prev.page === 'details') renderDetails(prev.opts);
  else if (prev.page === 'home') renderHome(mainEl, { onPlay: playItem, onNavigate: navigateItem, favSet: state.favSet });
  else if (prev.page === 'favorites') renderFavorites();
  else navigate('home');
  history.pushState({ page: prev.page, opts: prev.opts, stack: [...state.stack] }, '', prev.page === 'home' ? '/' : `/${prev.page}`);
}

// Sección de contenidos favoritos del usuario
async function renderFavorites() {
  const wrap = document.createElement('div');
  wrap.className = 'grid-view page-enter';
  wrap.innerHTML = `
    <div class="grid-header">
      <button class="grid-back" title="Volver">${Icons.arrowLeft}</button>
      <h2 class="grid-title">Mi Lista</h2>
    </div>
  `;
  wrap.querySelector('.grid-back').addEventListener('click', () => navigate('home'));
  const grid = document.createElement('div');
  grid.className = 'grid';
  makeSkeleton(8).forEach(c => grid.appendChild(c));
  wrap.appendChild(grid);
  mainEl.appendChild(wrap);

  try {
    const data = await API.getFavorites();
    grid.innerHTML = '';
    if (!data.favorites?.length) {
      grid.innerHTML = `<div class="empty-state">No hay favoritos aún.<br>Pulsa el corazón en cualquier contenido para guardarlo aquí.</div>`;
      return;
    }
    for (const item of data.favorites) {
      const cardItem = {
        id: item.url,
        title: item.title,
        thumb: item.thumb,
        type: 'folder',
        navigate: { kind: 'details', url: item.url, ctx: item.title || '' },
        plot: '',
        duration: 0,
      };
      grid.appendChild(makeCard(cardItem, playItem, navigateItem, state.favSet, 'landscape'));
    }
  } catch (e) {
    grid.innerHTML = `<div class="empty-state">Error: ${escHtml(e.message)}</div>`;
  }
}

// Flujo de resolución de stream y reproducción
async function playItem(item) {
  if (!item.play) {
    toast('Este ítem no es reproducible', 'info');
    return;
  }

  // Canales con DRM (RTVE): se reproducen en Kodi, no en el navegador.
  if (item.play.kind === 'cast') {
    try {
      await API.cast(item.play);
      toast(`Reproduciendo en Kodi: ${item.title}`, 'info', 3500);
    } catch (e) {
      toast(`No se pudo enviar a Kodi: ${e.message}`, 'error', 5000);
    }
    return;
  }

  toast('Resolviendo stream…', 'info', 2000);
  let streamData;
  try {
    // Adjuntar miniatura original al backend para watch_history
    streamData = await API.resolve({
      ...item.play,
      title: item.play.title || item.title,
      thumb: item.thumb || '',
    });
  } catch (e) {
    toast(`No se pudo reproducir: ${e.message}`, 'error', 6000);
    // Para directos no tiene sentido caer a la busqueda en Dailymotion.
    if (!item.is_live) openSearch(playItem, navigateItem, state.favSet, item.title || '');
    return;
  }

  await openPlayer(item, streamData);
}

// Lógica de transición al seleccionar una tarjeta de directorio
function navigateItem(item) {
  if (!item.navigate) return;
  const nav = item.navigate;

  // Acceso directo a overlay de búsqueda lateral
  if (nav.kind === 'search_dm') {
    openSearch(playItem, navigateItem, state.favSet, nav.q || '');
    return;
  }

  // Registrar la vista previa en la pila de navegación
  state.stack.push({
    page: state.page,
    opts: { ...state.opts },
    title: state.opts.title || (state.page.charAt(0).toUpperCase() + state.page.slice(1)),
  });

  if (nav.kind === 'atresplayer_details' || nav.kind === 'details') {
    navigate('details', { url: nav.url, ctx: nav.ctx || '', title: item.title });
  } else {
    navigate('catalog', { ...nav, title: item.title });
  }
}

// Gestión de favoritos persistentes
export async function loadFavSet() {
  try {
    const data = await API.getFavorites();
    state.favSet = new Set((data.favorites || []).map(f => f.url));
  } catch {}
}

export function refreshFavCards() {
  // Sincronizar estado visual de los marcadores en pantalla sin refrescar grilla
  document.querySelectorAll('.card').forEach(card => {
    const url = card.dataset.navUrl;
    if (!url) return;
    const fav = state.favSet.has(url);
    const btn = card.querySelector('.fav-btn');
    if (btn) {
      btn.classList.toggle('active', fav);
      btn.innerHTML = fav ? Icons.heartFilled : Icons.heart;
      btn.title = fav ? 'Quitar de favoritos' : 'Añadir a favoritos';
    }
  });
}

// Vinculación de atajos de teclado globales
function setupGlobalKeys() {
  document.addEventListener('keydown', (e) => {
    // Desactivar atajos durante ingreso de texto o con el reproductor activo
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
    if (isPlayerOpen()) return;

    if (e.key === '/' || ((e.ctrlKey || e.metaKey) && e.key === 'k')) {
      e.preventDefault();
      openSearch(playItem, navigateItem, state.favSet);
    } else if (e.key === 'Escape') {
      if (state.stack.length > 0) goBack();
    }
  });
}

// Monitoreo del estado de conectividad a internet
function setupOffline() {
  const update = () => offlineBanner.classList.toggle('visible', !navigator.onLine);
  window.addEventListener('online', update);
  window.addEventListener('offline', update);
  update();
}

// Gestión de instalación de Progressive Web App (PWA)
function setupPWA() {
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    state.installPrompt = e;
    const btn = document.getElementById('btn-install');
    btn.classList.remove('hidden');
    btn.addEventListener('click', async () => {
      state.installPrompt.prompt();
      const { outcome } = await state.installPrompt.userChoice;
      if (outcome === 'accepted') btn.classList.add('hidden');
    });
  });
}

function escHtml(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// Exports para que otros módulos puedan disparar refresh
export { state, playItem, navigateItem };

init();
