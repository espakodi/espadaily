# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
#
# Búsqueda en Odysee (LBRY) sin API key. Las peticiones y la lectura de las respuestas las hace
# el conector (buscar_odysee, odysee_stream, odysee_directo), que se arregla en caliente.
import hashlib
import json
import os
import sys
import time
import urllib.parse
import urllib.error

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

import ui_utils

_CACHE_DIR = xbmcvfs.translatePath(
    "special://userdata/addon_data/plugin.video.espadaily/search_cache/")
_CACHE_TTL = 3600  # segundos


def _cache_get(key):
    path = os.path.join(_CACHE_DIR, key + ".json")
    try:
        if time.time() - os.path.getmtime(path) > _CACHE_TTL:
            return None
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except OSError:
        return None


def _cache_set(key, data):
    try:
        os.makedirs(_CACHE_DIR, exist_ok=True)
        tmp = os.path.join(_CACHE_DIR, key + ".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(tmp, os.path.join(_CACHE_DIR, key + ".json"))
    except OSError:
        pass


def _fmt_duration(secs):
    if not isinstance(secs, int) or secs <= 0:
        return ""
    h, rem = divmod(secs, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def search(query):
    query = (query or "").strip()
    if not query:
        return []
    key = "odysee_" + hashlib.md5(query.lower().encode()).hexdigest()[:16]
    cached = _cache_get(key)
    if cached is not None:
        return cached
    buscar = ui_utils.del_conector("buscar_odysee")
    if not buscar:
        return []
    results = buscar(query)
    if results:
        _cache_set(key, results)
    return results


def directo(r):
    """Dirección del CDN con cabeceras para un resultado de search(), o '' si no tiene sd_hash
    (entonces se reproduce por odysee_play)."""
    montar = getattr(sys.modules.get('connector'), 'odysee_directo', None)
    return montar(r.get("claim_id", ""), r.get("sd_hash", ""), r.get("media_type", "")) if montar else ""


def play_item(handle, name, claim_id):
    """Resuelve y reproduce un vídeo de Odysee. Llamado por default.py action=odysee_play."""
    stream = ui_utils.del_conector("odysee_stream")
    cabeceras = ui_utils.del_conector("odysee_cabeceras")
    if not (stream and cabeceras):
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    dp = xbmcgui.DialogProgress()
    dp.create("EspaDaily", "Resolviendo stream de Odysee...")
    try:
        streaming_url = stream(name, claim_id)
        dp.close()
    except Exception as e:
        dp.close()
        xbmc.log(f"[EspaDaily] Error resolviendo Odysee: {e}", xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok("EspaDaily", f"Error al resolver el stream:\n{e}")
        return

    if not streaming_url:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok("EspaDaily", "No se pudo obtener la URL de reproducción de Odysee.")
        return

    # El CDN devuelve 401 sin Referer; se adjunta vía sintaxis de cabeceras de Kodi.
    play_url = f"{streaming_url}|{cabeceras()}"
    xbmc.log(f"[EspaDaily] Odysee stream: {streaming_url}", xbmc.LOGINFO)
    li = xbmcgui.ListItem(path=play_url)
    xbmcplugin.setResolvedUrl(handle, True, li)


def render_results(handle, query):
    query = (query or "").strip()
    if not query:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    dp = xbmcgui.DialogProgress()
    dp.create("EspaDaily", f"Buscando en Odysee: {query}...")
    try:
        results = search(query)
        dp.close()
    except (urllib.error.URLError, OSError, ValueError) as e:
        dp.close()
        xbmc.log(f"[EspaDaily] Error buscando en Odysee: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("EspaDaily", f"Error al buscar en Odysee:\n{e}")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if not results:
        xbmcgui.Dialog().ok("EspaDaily", f"No se encontraron resultados para:\n{query}")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    addon_url = sys.argv[0]
    xbmcplugin.setContent(handle, 'videos')
    for r in results:
        # URL directa al CDN; Kodi no llama al addon al volver, el directorio queda cacheado.
        play_url = directo(r)
        if not play_url:
            play_url = addon_url + '?' + urllib.parse.urlencode(
                {'action': 'odysee_play', 'name': r['name'], 'claim_id': r['claim_id']})

        title = r["title"]
        thumb = r["thumb"] or "DefaultMusicVideos.png"

        li = xbmcgui.ListItem(label=title)
        li.setArt({'icon': 'DefaultMusicVideos.png', 'thumb': thumb,
                   'poster': thumb, 'fanart': thumb})
        plot_lines = []
        if r.get("channel"):     plot_lines.append(f"Canal: {r['channel']}")
        dur = _fmt_duration(r.get("duration", 0))
        if dur:                  plot_lines.append(f"Duración: {dur}")
        if r.get("description"): plot_lines.append(r["description"][:200])
        li.setInfo('video', {'plot': "\n".join(plot_lines) or title,
                             'title': title, 'duration': r.get("duration", 0),
                             'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')
        if not play_url.startswith(addon_url):
            li.setContentLookup(False)  # URL directa, sin que Kodi intente resolverla como plugin

        xbmcplugin.addDirectoryItem(handle=handle, url=play_url,
                                    listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(handle)
