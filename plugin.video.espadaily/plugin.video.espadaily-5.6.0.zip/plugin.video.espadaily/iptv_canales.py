# -*- coding: utf-8 -*-
# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
"""Canales AceStream de la raíz de TV en directo, en la ventana de lista con panel.

Es la pantalla de Canales de EKHorus (lib/channels_ui.py) sobre los canales que ya sabe leer
iptv_lists. La ventana es de un solo nivel, así que los niveles son una pila y Atrás sube en vez
de cerrar.
"""
import xbmcgui

import core_settings
import iptv_lists as L
import iptv_parse as P
import iptv_store
import list_screen
import ui_utils
from list_screen import Fila

# Pintar 1800 filas de golpe son más de dos segundos en una TV box, y nadie las va a recorrer.
POR_PAGINA = 300
# Nombres de muestra que caben en el panel sin desplazarlo. Uno más largo que LARGO_NOMBRE parte
# la línea, y el catálogo trae canales cuyo nombre es una dirección web entera.
EJEMPLOS = 8
LARGO_NOMBRE = 44

_SANO = 2  # estado de un enlace disponible

PISTA = '[B]OK[/B] abre    ·    [B]Derecha[/B] lee    ·    [B]Atrás[/B] vuelve'
PISTA_CANALES = '[B]OK[/B] lo ve    ·    [B]Menú[/B] opciones    ·    [B]Atrás[/B] vuelve'
ESTADO_CANALES = 'Con [B]Menú[/B] o pulsación larga lo añades a Favoritos o pruebas otro enlace'

RAIZ = 'raiz'
FACETA = 'faceta'
CANALES = 'canales'
BUSQUEDA = 'busqueda'


def _plot_grupo(canales, cabeza):
    """Panel de una fila que lleva a una lista. Con solo el número parecía el sitio donde iban a
    salir los canales; con unos nombres delante se lee como una muestra con la lista detrás."""
    lineas = [cabeza, '']
    for canal in canales[:EJEMPLOS]:
        nombre = canal['name']
        if len(nombre) > LARGO_NOMBRE:
            nombre = nombre[:LARGO_NOMBRE - 1].rstrip() + '…'
        lineas.append(f'·  {nombre}')
    if len(canales) > EJEMPLOS:
        lineas.append(f'·  y {len(canales) - EJEMPLOS} más')
    lineas += ['', '[B]Pulsa OK[/B] para abrir la lista.']
    return '\n'.join(lineas)


def _plot_canal(canal):
    lineas = [canal['name'], '']
    for campo, titulo in (('cats', 'Categorías'), ('countries', 'País'), ('langs', 'Idioma')):
        valores = [P.engine_label(campo, v) for v in canal.get(campo) or ()]
        if valores:
            lineas.append(f'[B]{titulo}[/B]  {", ".join(valores)}')
    if canal.get('status') != _SANO:
        lineas += ['', '[B]Enlace dudoso.[/B] Puede que no arranque o que se corte.']
    alts = len(canal.get('alts') or ())
    if alts:
        lineas += ['', f'Tiene {alts} enlace{"s" if alts > 1 else ""} de repuesto, en [B]Menú[/B] > '
                       'Probar otro enlace.']
    return '\n'.join(lineas)


def _fila_canal(canal):
    partes = [P.engine_label('cats', c) for c in canal.get('cats') or ()]
    partes += [P.engine_label('countries', c) for c in canal.get('countries') or ()]
    return Fila(clave=canal['url'],
                titulo=canal['name'],
                pista='  ·  '.join(partes[:3]),
                icono=canal.get('logo') or L._no_logo(),
                pastilla=None if canal.get('status') == _SANO else ('Dudoso', 'gris'),
                plot=_plot_canal(canal))


def _clave_favorito(canal):
    # La misma que pone add_fav de default.py a los canales de las listas, para que un canal
    # guardado desde la lista clásica también salga como guardado aquí.
    return f"iptv_play_fav_{canal['url']}"


class Explorador:
    """Estado de la navegación. Vive lo que dura una apertura de la ventana."""

    def __init__(self, canales):
        self.canales = canales
        self.idioma = L._kodi_lang()
        self.pila = [(RAIZ, '', '', 0)]
        self.por_url = {c['url']: c for c in canales}
        # (url, nombre) del canal que se verá al cerrar. Se ve fuera porque el vídeo no puede
        # arrancar con la ventana encima.
        self.elegido = None
        self.recargar = False
        self._facetas = {}

    @property
    def nivel(self):
        return self.pila[-1]

    def entrar(self, modo, campo='', clave=''):
        self.pila.append((modo, campo, clave, 0))

    def volver(self):
        """Sube un nivel y devuelve la posición de la fila de la que se entró, o None si ya
        estaba en la raíz."""
        if len(self.pila) <= 1:
            return None
        modo, campo, clave, _pagina = self.pila.pop()
        if modo == FACETA:
            origen = campo
        elif modo == BUSQUEDA:
            origen = 'buscar'
        else:
            origen = clave if campo else 'todos'
        return next((n for n, fila in enumerate(self.filas()) if fila.clave == origen), 0)

    def pasar_pagina(self):
        modo, campo, clave, pagina = self.pila[-1]
        self.pila[-1] = (modo, campo, clave, pagina + 1)

    def facetas(self, campo):
        if campo not in self._facetas:
            self._facetas[campo] = P.engine_facets(self.canales, campo,
                                                   P.engine_preferred(campo, self.idioma))
        return self._facetas[campo]

    def buscar(self, texto):
        """Entra en los resultados de texto. False si no hay ninguno."""
        buscado = P.fold(texto)
        if not any(buscado in P.fold(c['name']) or buscado in P.fold(c.get('group'))
                   for c in self.canales):
            return False
        self.entrar(BUSQUEDA, clave=texto)
        return True

    def lista_actual(self):
        modo, campo, clave, _pagina = self.nivel
        if modo == BUSQUEDA:
            buscado = P.fold(clave)
            return [c for c in self.canales
                    if buscado in P.fold(c['name']) or buscado in P.fold(c.get('group'))]
        if not campo:
            return self.canales
        return next((m for valor, _nombre, m in self.facetas(campo) if valor == clave), [])

    def filas(self):
        modo = self.nivel[0]
        if modo == RAIZ:
            return self._filas_raiz()
        if modo == FACETA:
            return self._filas_faceta()
        return self._filas_canales()

    def _filas_raiz(self):
        total = len(self.canales)
        filas = [
            Fila(clave='buscar', titulo='Buscar un canal', icono=L._icon('busqueda.png'),
                 plot='Busca por el nombre del canal o su categoría, sin importar mayúsculas '
                      'ni tildes.'),
            Fila(clave='todos', titulo='Todos los canales', valor=str(total),
                 icono=L._icon('directo.png'),
                 plot=_plot_grupo(self.canales, f'Los {total} canales, ordenados por fiabilidad '
                                                'del enlace y con los de tu idioma primero.')),
        ]
        for campo, titulo in P.ENGINE_FACETS:
            grupos = self.facetas(campo)
            if not grupos:
                continue
            if campo == 'pl':
                plot = ('Agrupa los canales como vienen agrupados de origen, con algunos que no '
                        'salen en las otras listas.')
            else:
                plot = f'Agrupa los {total} canales por este criterio.'
            filas.append(Fila(clave=campo, titulo=titulo, valor=str(len(grupos)),
                              icono=L._icon(L._ENGINE_FACET_ICON[campo]),
                              plot=f'{plot}\n\n[B]Pulsa OK[/B] para ver los {len(grupos)} grupos.'))
        filas.append(Fila(clave='', titulo='', sep=True))
        filas.append(Fila(clave='actualizar', titulo='Actualizar la lista',
                          icono=L._icon('adv_refrescar.png'),
                          plot='Vuelve a bajar la lista completa. Tarda unos segundos.'))
        return filas

    def _filas_faceta(self):
        campo = self.nivel[1]
        return [Fila(clave=valor, titulo=nombre, valor=str(len(canales)),
                     icono=L._facet_icon(campo, valor),
                     plot=_plot_grupo(canales, f'{len(canales)} canales en {nombre}.'))
                for valor, nombre, canales in self.facetas(campo)]

    def _filas_canales(self):
        lista = self.lista_actual()
        hasta = (self.nivel[3] + 1) * POR_PAGINA
        filas = [_fila_canal(c) for c in lista[:hasta]]
        if len(lista) > hasta:
            filas.append(Fila(clave='mas', titulo=f'Ver más  ({hasta} de {len(lista)})',
                              icono=L._icon('siguiente.png'),
                              plot='Añade otros canales a la lista.'))
        if not filas:
            filas.append(Fila(clave='', titulo='No hay canales aquí', sep=True))
        return filas

    def cabecera(self):
        modo, campo, clave, _pagina = self.nivel
        if modo == RAIZ:
            # Corto, porque el hueco del subtítulo son 316 px
            return L._ENGINE_NAME, f'{len(self.canales)} en directo'
        if modo == FACETA:
            return dict(P.ENGINE_FACETS)[campo], 'Elige uno para ver sus canales'
        if modo == BUSQUEDA:
            return f'"{clave}"', L._canales(len(self.lista_actual()))
        if not campo:
            return 'Todos los canales', 'Ordenados por fiabilidad'
        return P.engine_label(campo, clave), dict(P.ENGINE_FACETS)[campo]


def _al_pulsar(exp, fila):
    modo = exp.nivel[0]
    if fila.clave == 'mas':
        exp.pasar_pagina()
        return None
    if modo == RAIZ:
        if fila.clave == 'actualizar':
            exp.recargar = True
            return 'cerrar'
        if fila.clave == 'buscar':
            texto = ui_utils.get_text('Buscar canal').strip()
            if not texto:
                return None
            if not exp.buscar(texto):
                L._notify(f'Ningún canal coincide con "{texto}"')
                return None
        elif fila.clave == 'todos':
            exp.entrar(CANALES)
        else:
            exp.entrar(FACETA, campo=fila.clave)
        return 'inicio'
    if modo == FACETA:
        exp.entrar(CANALES, campo=exp.nivel[1], clave=fila.clave)
        return 'inicio'
    canal = exp.por_url.get(fila.clave)
    if canal is None:
        return None
    exp.elegido = (canal['url'], canal['name'])
    return 'cerrar'


def _al_menu(exp, fila):
    """Opciones de un canal. Solo los canales las tienen: el resto de filas abren una lista."""
    canal = exp.por_url.get(fila.clave)
    if exp.nivel[0] not in (CANALES, BUSQUEDA) or canal is None:
        return None
    clave = _clave_favorito(canal)
    guardado = any(f['url'] == clave for f in core_settings.get_favorites())
    opciones = ['Ver', 'Quitar de Favoritos' if guardado else 'Añadir a Favoritos']
    if canal.get('alts'):
        opciones.append('Probar otro enlace')
    elegida = xbmcgui.Dialog().contextmenu(opciones)
    if elegida == 0:
        return _al_pulsar(exp, fila)
    # La fila no enseña si el canal está guardado, así que el aviso es lo único que se ve
    if elegida == 1 and guardado:
        if core_settings.remove_favorite(clave):
            L._notify('Quitado de Favoritos')
    elif elegida == 1:
        nuevo = core_settings.add_favorite(canal['name'], clave,
                                           canal.get('logo') or 'DefaultAddonPVRClient.png', '',
                                           'iptv_play_fav', {'url': canal['url'], 'extra': ''})
        L._notify('Añadido a Favoritos' if nuevo else 'Ya está en Favoritos')
    elif elegida == 2:
        alts = canal['alts']
        sel = 0 if len(alts) == 1 else xbmcgui.Dialog().select(
            canal['name'], [f'Enlace de repuesto {n}' for n in range(1, len(alts) + 1)])
        if sel >= 0:
            exp.elegido = (P.engine_url(alts[sel]), canal['name'])
            return 'cerrar'
    return None


def _cabecera(exp, ventana):
    if ventana is None:
        return
    titulo, sub = exp.cabecera()
    en_canales = exp.nivel[0] in (CANALES, BUSQUEDA)
    ventana.set_cabecera(titulo=titulo, subtitulo=sub,
                         pista=PISTA_CANALES if en_canales else PISTA,
                         estado=ESTADO_CANALES if en_canales else '')


def _mostrar(exp):
    ventana = []

    def al_abrir(v):
        ventana.append(v)
        _cabecera(exp, v)

    def filas():
        # Repintar y cambiar de nivel van siempre juntos, así que la cabecera se pone aquí y no en
        # cada sitio que navega. En el primer pintado aún no hay ventana, y lo hace al_abrir.
        _cabecera(exp, ventana[0] if ventana else None)
        return exp.filas()

    titulo, sub = exp.cabecera()
    return list_screen.mostrar(titulo=titulo, subtitulo=sub, hacer_filas=filas,
                               al_pulsar=lambda fila: _al_pulsar(exp, fila),
                               al_menu=lambda fila: _al_menu(exp, fila),
                               al_volver=exp.volver, al_abrir=al_abrir, pista=PISTA)


def _ventana():
    """Abre la ventana. False si no se pudo construir, para ir a la lista clásica."""
    forzar = False
    # Un bucle y no recursión, porque Actualizar vuelve a abrir la ventana
    while True:
        canales = L.engine_root_channels(forzar)
        if not canales:
            return True
        exp = Explorador(canales)
        if not _mostrar(exp):
            return False
        if exp.elegido:
            url, nombre = exp.elegido
            L.play({'url': url, 'title': nombre})
        if not exp.recargar:
            return True
        forzar = True


def abrir():
    list_screen.ventana_o_lista('iptv_engine', _ventana,
                                lambda _h: L.open_list({'id': iptv_store.ENGINE_CACHE}))
