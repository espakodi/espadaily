# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
#
# Búsqueda en PeerTube (red federada) sin API key, vía la instancia peertube.tv,
# cuyo índice de búsqueda devuelve vídeos de muchas instancias federadas:
#   1) /search/videos devuelve metadatos (sin URLs de stream).
#   2) Al reproducir, /videos/{uuid} entrega los ficheros: MP4 progresivo si existe
#      (más compatible) o, en su defecto, el playlist HLS (PeerTube v6+ solo genera HLS).
# Las peticiones y la lectura de las respuestas las hace el conector (buscar_peertube,
# peertube_stream), que se arregla en caliente.
import hashlib
import json
import os
import sys
import time
import urllib.parse
import urllib.error

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import ui_utils

_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36")

_CACHE_DIR = xbmcvfs.translatePath(
    "special://userdata/addon_data/plugin.video.espadaily/search_cache/")
_CACHE_TTL = 3600  # segundos


def _cache_get(key):
    path = os.path.join(_CACHE_DIR, key + ".json")
    try:
        if time.time() - os.path.getmtime(path) > _CACHE_TTL:
            return None
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except OSError:
        return None


def _cache_set(key, data):
    # tmp único por proceso; dos búsquedas simultáneas de la misma query no se pisan
    # el temporal (cada invocación del plugin es un proceso distinto). os.replace es atómico.
    try:
        os.makedirs(_CACHE_DIR, exist_ok=True)
        tmp = os.path.join(_CACHE_DIR, f"{key}.{os.getpid()}.tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(tmp, os.path.join(_CACHE_DIR, key + ".json"))
    except OSError:
        pass


def _fmt_duration(secs):
    if not isinstance(secs, int) or secs <= 0:
        return ""
    h, rem = divmod(secs, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def search(query, count=30):
    query = (query or "").strip()
    if not query:
        return []
    key = "peertube_" + hashlib.md5(query.lower().encode()).hexdigest()[:16]
    cached = _cache_get(key)
    if cached is not None:
        return cached
    buscar = ui_utils.del_conector("buscar_peertube")
    if not buscar:
        return []
    results = buscar(query, count)
    _cache_set(key, results)
    return results


def play_item(handle, uuid):
    """Resuelve y reproduce un vídeo de PeerTube. Llamado por default.py action=peertube_play."""
    resolver = ui_utils.del_conector("peertube_stream")
    if not resolver:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    dp = xbmcgui.DialogProgress()
    dp.create("EspaDaily", "Resolviendo stream de PeerTube...")
    try:
        stream_url, kind = resolver(uuid)
        dp.close()
    except (urllib.error.URLError, OSError, ValueError) as e:
        dp.close()
        xbmc.log(f"[EspaDaily] Error resolviendo PeerTube: {e}", xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok("EspaDaily", f"Error al resolver el stream:\n{e}")
        return

    if not stream_url:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok("EspaDaily", "No se pudo obtener la URL de reproducción de PeerTube.")
        return

    if kind == "hls" and not _has_inputstream_adaptive():
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok("EspaDaily",
            "Este vídeo solo está disponible en formato HLS y requiere "
            "'InputStream Adaptive', que no está instalado o está deshabilitado en Kodi.\n\n"
            "Actívalo desde el repositorio oficial para reproducirlo.")
        return

    xbmc.log(f"[EspaDaily] PeerTube stream ({kind}): {stream_url}", xbmc.LOGINFO)
    li = xbmcgui.ListItem(path=stream_url)
    if kind == "hls":
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstreamaddon', 'inputstream.adaptive')  # compat Kodi 19
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        li.setProperty('inputstream.adaptive.stream_headers',
                       'User-Agent=' + _UA)
        li.setMimeType('application/x-mpegURL')
        li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(handle, True, li)


def _has_inputstream_adaptive():
    try:
        xbmcaddon.Addon('inputstream.adaptive')
        return True
    except Exception:
        return False


def render_results(handle, query):
    query = (query or "").strip()
    if not query:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    dp = xbmcgui.DialogProgress()
    dp.create("EspaDaily", f"Buscando en PeerTube: {query}...")
    try:
        results = search(query)
        dp.close()
    except (urllib.error.URLError, OSError, ValueError) as e:
        dp.close()
        xbmc.log(f"[EspaDaily] Error buscando en PeerTube: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("EspaDaily", f"Error al buscar en PeerTube:\n{e}")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if not results:
        xbmcgui.Dialog().ok("EspaDaily", f"No se encontraron resultados para:\n{query}")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    addon_url = sys.argv[0]
    xbmcplugin.setContent(handle, 'videos')
    for r in results:
        play_url = addon_url + '?' + urllib.parse.urlencode(
            {'action': 'peertube_play', 'uuid': r['uuid']})
        thumb = r["thumb"] or "DefaultMusicVideos.png"

        li = xbmcgui.ListItem(label=r["title"])
        li.setArt({'icon': 'DefaultMusicVideos.png', 'thumb': thumb,
                   'poster': thumb, 'fanart': thumb})
        plot_lines = []
        if r.get("channel"):     plot_lines.append(f"Canal: {r['channel']}")
        if r.get("host"):        plot_lines.append(f"Instancia: {r['host']}")
        dur = _fmt_duration(r.get("duration", 0))
        if dur:                  plot_lines.append(f"Duración: {dur}")
        if r.get("description"): plot_lines.append(r["description"][:200])
        li.setInfo('video', {'plot': "\n".join(plot_lines) or r["title"],
                             'title': r["title"], 'duration': r.get("duration", 0),
                             'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')

        xbmcplugin.addDirectoryItem(handle=handle, url=play_url,
                                    listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(handle)
