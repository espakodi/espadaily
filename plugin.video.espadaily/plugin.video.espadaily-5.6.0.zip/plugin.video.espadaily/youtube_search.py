# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
#
# Delega la reprodución de los videos a el addon plugin.video.youtube.
import hashlib
import json
import os
import time
import urllib.error

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

import ui_utils

_YT_THUMB = "https://i.ytimg.com/vi/{0}/hqdefault.jpg"
_YT_PLAY  = "plugin://plugin.video.youtube/play/?video_id={0}"

_CACHE_DIR = xbmcvfs.translatePath(
    "special://userdata/addon_data/plugin.video.espadaily/search_cache/")
_CACHE_TTL = 3600  # segundos


def _cache_get(key):
    path = os.path.join(_CACHE_DIR, key + ".json")
    try:
        if time.time() - os.path.getmtime(path) > _CACHE_TTL:
            return None
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except OSError:
        return None


def _cache_set(key, data):
    try:
        os.makedirs(_CACHE_DIR, exist_ok=True)
        tmp = os.path.join(_CACHE_DIR, key + ".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(tmp, os.path.join(_CACHE_DIR, key + ".json"))
    except OSError:
        pass


def search(query):
    """Vídeos de YouTube para la búsqueda. Los lee el conector (buscar_youtube), que se puede
    arreglar en caliente cuando YouTube cambia su página; aquí queda la caché de una hora."""
    query = (query or "").strip()
    if not query:
        return []
    key = "youtube_" + hashlib.md5(query.lower().encode()).hexdigest()[:16]
    cached = _cache_get(key)
    if cached is not None:
        return cached
    buscar = ui_utils.del_conector("buscar_youtube")
    if not buscar:
        return []
    results = buscar(query)
    _cache_set(key, results)
    return results


def render_results(handle, query):
    """Ejecuta la búsqueda y puebla el directorio de Kodi con los resultados obtenidos."""
    query = (query or "").strip()
    if not query:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    dp = xbmcgui.DialogProgress()
    dp.create("EspaDaily", f"Buscando en YouTube: {query}...")
    try:
        results = search(query)
        dp.close()
    except (urllib.error.URLError, OSError, ValueError) as e:
        dp.close()
        xbmc.log(f"[EspaDaily] Error buscando en YouTube: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("EspaDaily", f"Error al buscar en YouTube:\n{e}")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if not results:
        xbmcgui.Dialog().ok("EspaDaily", f"No se encontraron resultados para:\n{query}")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    xbmcplugin.setContent(handle, 'videos')
    for r in results:
        vid = r["vid"]
        title = r["title"]
        thumb = _YT_THUMB.format(vid)
        li = xbmcgui.ListItem(label=title)
        li.setArt({'icon': 'DefaultMusicVideos.png', 'thumb': thumb,
                   'poster': thumb, 'fanart': thumb})
        plot_lines = []
        if r.get("channel"):   plot_lines.append(f"Canal: {r['channel']}")
        if r.get("duration"):  plot_lines.append(f"Duración: {r['duration']}")
        if r.get("views"):     plot_lines.append(f"Vistas: {r['views']}")
        if r.get("published"): plot_lines.append(f"Subido: {r['published']}")
        li.setInfo('video', {'plot': "\n".join(plot_lines) or title,
                             'title': title, 'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=handle,
                                    url=_YT_PLAY.format(vid),
                                    listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(handle)
