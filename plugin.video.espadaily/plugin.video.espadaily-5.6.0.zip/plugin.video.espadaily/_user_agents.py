# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
"""User-Agent de navegador de escritorio (_user_agents.UA_DESKTOP). Se lee del conector
(UA_ESCRITORIO) cada vez, para poder cambiarlo en caliente si una web empieza a rechazarlo;
el de aquí es el de respaldo, con un conector anterior a la 5.6.0."""
import sys

_UA_DESKTOP = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/138.0.0.0 Safari/537.36"
)


def __getattr__(nombre):
    if nombre == "UA_DESKTOP":
        return getattr(sys.modules.get("connector"), "UA_ESCRITORIO", _UA_DESKTOP)
    raise AttributeError(f"module {__name__!r} has no attribute {nombre!r}")
