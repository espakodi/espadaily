# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
"""Canales públicos de Telegram. La descarga y la lectura de las páginas t.me/s/ las hace el
conector (escanear_telegram, escanear_telegram_paginas), que se arregla en caliente; aquí
quedan la misma interfaz y las comprobaciones de texto. No importa nada de Kodi, como
html_scanner. Sin conector (o con uno anterior a la 5.6.0) el canal sale vacío."""
import re
import sys

_MAX_PAGES = 3


def _del_conector(nombre):
    return getattr(sys.modules.get('connector'), nombre, None)


def scan_channel(channel_or_url, max_pages=_MAX_PAGES):
    """Enlaces de un canal PÚBLICO de Telegram (sin paginar bajo demanda, como url_remote)."""
    escanear = _del_conector("escanear_telegram")
    return escanear(channel_or_url, max_pages) if escanear else []


def scan_channel_paged(channel_or_url, max_pages=_MAX_PAGES, before_id=None):
    """(resultados, next_before_id) de un canal público, paginando hacia atrás desde
    ``before_id``. next_before_id es None al llegar al final del canal. Acepta @canal,
    t.me/canal, telegram.me/canal, https://t.me/s/canal o el nombre desnudo; los privados
    (t.me/+..., joinchat) no se pueden leer sin autenticación."""
    escanear = _del_conector("escanear_telegram_paginas")
    return escanear(channel_or_url, max_pages, before_id) if escanear else ([], None)


def is_telegram(text):
    """True si el texto parece referirse a un canal de Telegram (público o no)."""
    if not text:
        return False
    t = text.strip()
    low = t.lower()
    if t.startswith('@'):
        return True
    if 't.me/' in low or low.startswith('t.me') or 'telegram.me/' in low:
        return True
    # Handle desnudo: solo [a-z0-9_], 5+ chars, sin esquema ni punto (no es un dominio)
    return '://' not in t and '.' not in t and bool(re.match(r'^[a-zA-Z0-9_]{5,}$', t))


def is_private_invite(text):
    """True para enlaces de invitación a canales/grupos PRIVADOS (no escaneables)."""
    if not text:
        return False
    low = text.strip().lower()
    return (
        't.me/+' in low or 'telegram.me/+' in low
        or 't.me/joinchat/' in low or 'telegram.me/joinchat/' in low
        or low.lstrip('@').startswith('+')
    )
