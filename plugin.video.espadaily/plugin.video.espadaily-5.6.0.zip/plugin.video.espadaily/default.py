# -*- coding: utf-8 -*-
# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
"""
EspaDaily - Buscador multimedia para Kodi.

Gestiona historial, favoritos, categorias y listas IPTV.

Addon desarrollado por fullstackcurso y espakodi - RSDFA1laberot
Licencia: GPL-2.0-or-later (Si vas a usar este código, por favor, da crédito al desarrollador original e incluye esta licencia,
ademas intenta contribuir al proyecto original si los cambios no son significativos para no fragmentar el desarrollo y la comunidad).

Este addon se ha hecho intentando que todo sea lo mas legal posible. Si crees que algo no lo es, ponte en contacto.
"""
import sys
import html as _html

import os
import shutil
import time
import urllib.parse
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
import xbmcvfs
import json
import difflib
import unicodedata
import base64
import zipfile
import re
import zlib
import types as _connector_types
import hashlib
import core_settings
from movie_data import _get_movie_plot, _get_movie_genre, _get_movie_details
import category_manager
import ui_utils
import exploration_history
import estuary_palantir_compatibility

# Identidad del addon - GPL requiere mantener los avisos de copyright originales
xbmc.log(
    "[EspaDaily] Addon original por RubénSDFA1laberot - "
    "https://github.com/fullstackcurso - GPL-2.0-or-later",
    xbmc.LOGINFO,
)

# Firma de build original - no eliminar
_ORIGIN = "fullstackcurso-RubenSDFA1laberot-v1"

# Icono principal del addon
ICON_MAIN = ui_utils.media_icon('espadaily_icon.jpg')

def _integration_text(nombre):
    return (
        f"EspaDaily abrirá tu addon {nombre} con tu consulta. Asegúrate de tenerlo bien instalado y configurado.\n\n"
        f"El proceso utiliza un enlace estándar de Kodi (tipo plugin://) para abrir tu addon pasándole tu texto. EspaDaily solo actúa como un puente rápido para ahorrarte tener que pulsar atrás hasta el menú de Kodi, buscar... y volver a teclear todo el nombre.\n\n"
        f"Al tratarse de un simple enlace, tu privacidad y seguridad están garantizadas, ya que EspaDaily hace la entrega del texto y se aparta por completo. Esta función no modifica el código de {nombre}, no registra lo que buscas, lo que reproduces allí, ni interfiere con la configuración o los datos. Una vez allí, los resultados, la reproducción y todo el mérito son de {nombre} y sus creadores.\n\n"
        f"Nota: Puedes añadir, modificar o desactivar estos atajos en cualquier momento desde los ajustes de EspaDaily.\n\n"
        f"¿Continuar?"
    )

def _integration_plot(nombre, is_active):
    intro = f"Con esta opción EspaDaily abrirá tu addon {nombre} con tu consulta. Asegúrate de tenerlo bien instalado y configurado.\n\n"

    base_text = (
        f"El proceso utiliza un enlace estándar de Kodi (tipo plugin://) para abrir tu addon pasándole tu texto. EspaDaily solo actúa como un puente rápido para ahorrarte tener que pulsar atrás hasta el menú de Kodi, buscar... y volver a teclear todo el nombre.\n\n"
        f"Al tratarse de un simple enlace, tu privacidad y seguridad están garantizadas, ya que EspaDaily hace la entrega del texto y se aparta por completo. Esta función no modifica el código de {nombre}, no registra lo que buscas, lo que reproduces allí, ni interfiere con la configuración o los datos. Una vez allí, los resultados, la reproducción y todo el mérito son de {nombre} y sus creadores.\n\n"
    )
    if is_active:
        return intro + base_text + "[COLOR blue][I]Pulsa para DESACTIVAR esta búsqueda[/I][/COLOR]"
    else:
        return intro + base_text + "[COLOR blue][I]Pulsa para ACTIVAR esta búsqueda[/I][/COLOR]"

_INTEGRATION_FIRST_USE_TEXTS = {
    'alfa':     ('Alfa',     _integration_text('Alfa')),
    'jacktook': ('Jacktook', _integration_text('Jacktook')),
    'balandro': ('Balandro', _integration_text('Balandro')),
    'palantir': ('Palantir', _integration_text('Palantir')),
}

try:
    import requests
except ImportError:
    xbmc.log("[EspaDaily] requests module not available", xbmc.LOGERROR)
    sys.exit(1)

_RP = [
    "QCh2dT8lJHZ8JCEpPyYlengpciQ/K311IiV2QEBLJSImJnk=",
]
_BK = "X7-EspaDaily-Secure-441"
_RF = "f9866be7b0e7.sys"

_SYS_HEADER = (
    "# -*- coding: utf-8 -*-\n"
    "# ============================================================================\n"
    "# MODULO EXTERNO - EspaDaily\n"
    "# ============================================================================\n"
    "#\n"
    "# AVISO LEGAL Y CONDICIONES DE USO\n"
    "# =================================\n"
    "#\n"
    "# SEGURIDAD Y TRANSPARENCIA:\n"
    "# Este archivo se distribuye ofuscado. Esto se hace para:\n"
    "#   - Preservar detalles internos de implementacion y evitar\n"
    "#     su uso indebido para otros fines.\n"
    "#   - Comprimir el codigo para una descarga mas eficiente y permitir\n"
    "#     la verificacion de integridad del archivo.\n"
    "# Este modulo actua como cliente HTTP, de forma analoga a un navegador\n"
    "# web convencional.\n"
    "#\n"
    "# ACTUALIZACION REMOTA:\n"
    "# Este modulo se aloja de forma externa y puede ser actualizado por el\n"
    "# autor en cualquier momento para corregir errores, adaptarse a cambios\n"
    "# en las APIs de las plataformas o mejorar la compatibilidad. El formato\n"
    "# comprimido facilita una descarga rapida y permite al addon verificar\n"
    "# la integridad del archivo antes de su ejecucion.\n"
    "#\n"
    "# NATURALEZA DEL SOFTWARE:\n"
    "# Este archivo es un COMPONENTE EXTERNO y COMPLEMENTARIO del addon EspaDaily.\n"
    "# Facilita el acceso a contenidos publicados en plataformas web mediante\n"
    "# sus APIs publicas y el centro multimedia Kodi (Codigo Abierto).\n"
    "#\n"
    "# PROPIEDAD Y DISTRIBUCION:\n"
    "# Este modulo NO forma parte del repositorio publico del frontend EspaDaily.\n"
    "# Se distribuye bajo licencia \"Todos los Derechos Reservados\".\n"
    "# Queda prohibida su modificacion y redistribucion sin autorizacion expresa.\n"
    "#\n"
    "# CONTENIDO Y FUNCIONAMIENTO:\n"
    "# El codigo actua como cliente HTTP (equivalente a un navegador).\n"
    "# 1. NO aloja ni redistribuye contenido de terceros.\n"
    "# 2. Accede a las APIs publicas de los proveedores de contenido.\n"
    "# 3. Cuando se requiere autenticacion, utiliza exclusivamente las\n"
    "#    credenciales proporcionadas por el propio usuario.\n"
    "#\n"
    "# EXENCION DE RESPONSABILIDAD:\n"
    "# El autor no ofrece garantias de ningun tipo. El usuario es responsable\n"
    "# del uso que haga de este software y de cumplir con la legislacion y\n"
    "# terminos de servicio aplicables en su jurisdiccion.\n"
    "#\n"
    "# COOPERACION CON TITULARES DE DERECHOS:\n"
    "# Si usted es un titular de derechos y considera que este modulo le perjudica,\n"
    "# contacte con el autor para su desactivacion inmediata.\n"
    "# Existe voluntad total de cooperacion y cumplimiento normativo.\n"
    "#\n"
    "# © Copyright 2026 - Módulo Externo- Fernan2008x-xKodi\n"
    "# ============================================================================\n"
)

def _get_connector_path():
    return os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'connector.py')

def _get_loader_cache_path():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, 'connector_cache.json')

def _get_loader_config_path():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, 'loader_config.json')

def _load_custom_urls():
    """Carga URLs de emergencia guardadas por el usuario."""
    try:
        cfg = _get_loader_config_path()
        if os.path.exists(cfg):
            with open(cfg, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return data.get('custom_urls', [])
    except (OSError, ValueError, AttributeError) as e:
        xbmc.log(f"[EspaDaily] No se pueden leer las URL de emergencia del módulo: {e}", xbmc.LOGWARNING)
    return []

def _save_custom_url(url):
    """Guarda una URL de emergencia para futuros arranques."""
    existing = _load_custom_urls()
    if url not in existing:
        existing.append(url)
    try:
        with open(_get_loader_config_path(), 'w', encoding='utf-8') as f:
            json.dump({'custom_urls': existing}, f)
    except OSError as e:
        xbmc.log(f"[EspaDaily] No se ha podido guardar la URL de emergencia del módulo: {e}", xbmc.LOGWARNING)

def _get_sys_cache_dir():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    cache_dir = os.path.join(p, 'cache')
    if not os.path.exists(cache_dir): os.makedirs(cache_dir)
    return cache_dir

def _get_sys_path():
    return os.path.join(_get_sys_cache_dir(), _RF)

def _encode_sys(code_str):
    legal  = _SYS_HEADER.encode("utf-8")
    header = ("# AUTH-SIGNATURE: " + _BK + "\n").encode("utf-8")
    compressed = zlib.compress(code_str.encode("utf-8"), 9)
    body = base64.b64encode(compressed)
    return legal + header + body

def _decode_sys(raw_bytes):
    try:
        sig = ("# AUTH-SIGNATURE: " + _BK + "\n").encode("utf-8")
        if sig not in raw_bytes: return None
        blob = raw_bytes.split(sig, 1)[1].strip()
        return zlib.decompress(base64.b64decode(blob)).decode("utf-8")
    except Exception: return None

def _get_sys_hash():
    sys_path = _get_sys_path()
    if not os.path.exists(sys_path): return None
    try:
        with open(sys_path, "rb") as f: raw = f.read()
        code = _decode_sys(raw)
        if code is None: return None
        return hashlib.sha256(code.encode('utf-8')).hexdigest()
    except Exception: return None

def _save_sys(code_str):
    try:
        with open(_get_sys_path(), "wb") as f: f.write(_encode_sys(code_str))
        return True
    except Exception: return False

def _load_connector_module():
    sys_path = _get_sys_path()
    if not os.path.exists(sys_path): return None
    try:
        with open(sys_path, "rb") as f: raw = f.read()
        code = _decode_sys(raw)
        if code is None:
            xbmc.log("[EspaDaily] .sys invalido o token de integridad fallido", xbmc.LOGERROR)
            return None
        mod = _connector_types.ModuleType("connector")
        mod.__file__ = sys_path
        exec(compile(code, sys_path, "exec"), mod.__dict__)
        import sys as _sys
        _sys.modules["connector"] = mod
        return mod
    except Exception as e:
        xbmc.log("[EspaDaily] Error ejecutando connector: {0}".format(e), xbmc.LOGERROR)
        return None


# VERSION del conector que necesita este addon. Los conectores anteriores a la 5.6.0 no la llevan
# y cuentan como 1.
_CONECTOR_MINIMO = 2
# Con el publicado todavía viejo, no se vuelve a bajar en cada pantalla.
_REINTENTO_CONECTOR_S = 15 * 60


def _cargar_conector():
    """El conector de la caché. Si es anterior al que necesita el addon (recién actualizado, con
    el conector de ayer guardado), se descarga ya sin esperar a la comprobación de cada 24 h."""
    mod = _load_connector_module()
    if mod is None or getattr(mod, 'VERSION', 1) >= _CONECTOR_MINIMO:
        return mod
    cache_file = _get_loader_cache_path()
    try:
        with open(cache_file, 'r', encoding='utf-8') as f:
            ultima = json.load(f).get('last_check', 0)
    except (OSError, ValueError, AttributeError):
        ultima = 0
    if time.time() - ultima < _REINTENTO_CONECTOR_S:
        return mod
    try:
        os.remove(cache_file)
    except OSError:
        pass
    if _ensure_connector():
        mod = _load_connector_module() or mod
    # Sin conexión, _ensure_connector no la escribe, y sin ella se probaría en cada pantalla.
    try:
        with open(cache_file, 'w', encoding='utf-8') as f:
            json.dump({'last_check': time.time()}, f)
    except OSError:
        pass
    if getattr(mod, 'VERSION', 1) < _CONECTOR_MINIMO:
        xbmc.log(f"[EspaDaily] El conector {getattr(mod, 'VERSION', 1)} es anterior al que necesita "
                 f"esta versión ({_CONECTOR_MINIMO})", xbmc.LOGWARNING)
    return mod

def _get_local_hash():
    cp = _get_connector_path()
    if not os.path.exists(cp): return None
    try:
        with open(cp, 'r', encoding='utf-8') as f: c = f.read()
        return f"{len(c)}_{hash(c[:100])}_{hash(c[-100:])}"
    except Exception: return None

def _decode_remote_connector(text):
    try:
        lines = text.splitlines()
        bk_idx = next((i for i, l in enumerate(lines) if _BK in l), None)
        if bk_idx is None: return None
        blob = '\n'.join(lines[bk_idx + 1:]).strip()
        if not blob: return None
        return zlib.decompress(base64.b64decode(blob)).decode('utf-8')
    except Exception: return None

def _download_connector(url):
    ua_list = [{"User-Agent": "EspaDaily-Updater/SecureClient-v2 (Kr; Lnx)"}, None]
    for headers in ua_list:
        try:
            r = requests.get(url, headers=headers, timeout=15)
            if r.status_code == 200 and len(r.text) > 500:
                if _BK not in r.text: continue
                decoded = _decode_remote_connector(r.text)
                return decoded if decoded else r.text
        except Exception:
            pass
    return None

def _ninja_decode(encoded, shift=17):
    try:
        texto = base64.b64decode(encoded).decode('utf-8')
        descifrado = ''
        for char in texto:
            c_val = ord(char)
            if 32 <= c_val <= 126:
                c_val = 32 + ((c_val - 32 - shift) % 95)
            descifrado += chr(c_val)
        return descifrado[::-1]
    except Exception: return None

def _ensure_connector():
    # MODO DESARROLLO: si existe .dev_mode en la carpeta del addon,
    # Crear el archivo:  echo . > .dev_mode  (en la carpeta del addon)
    # Eliminar el archivo para volver al modo normal.
    dev_flag = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.dev_mode')
    if os.path.exists(dev_flag):
        xbmc.log("[EspaDaily] Modo desarrollo activo: connector local protegido", xbmc.LOGINFO)
        cp = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'connector.py')
        return os.path.exists(cp)
    _cp_old = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'connector.py')
    if os.path.exists(_cp_old) and not os.path.exists(_get_sys_path()):
        try:
            with open(_cp_old, 'r', encoding='utf-8') as _f: _old_code = _f.read()
            if _BK in _old_code and _save_sys(_old_code):
                xbmc.log("[EspaDaily] Migrado connector.py a .sys", xbmc.LOGINFO)
        except Exception as _e:
            xbmc.log("[EspaDaily] Fallo migrando connector.py: {0}".format(_e), xbmc.LOGWARNING)

    try:
        cache_file = _get_loader_cache_path()
        local_hash = _get_sys_hash()
        if os.path.exists(cache_file) and local_hash:
            with open(cache_file, 'r', encoding='utf-8') as f:
                cache = json.load(f)
            hours_passed = (time.time() - cache.get('last_check', 0)) / 3600
            if hours_passed < 24:
                return True
    except Exception: pass

    local_hash = _get_sys_hash()

    urls = []
    for b in _RP:
        try:
            url = _ninja_decode(b)
            if not (url and url.startswith("http")):
                url = base64.b64decode(b).decode('utf-8')
            if url: urls.append(url)
        except Exception: pass
    urls += _load_custom_urls()
    urls = [u for u in urls if u and u.strip()]
    if not urls:
        if local_hash: return True
        return _emergency_url_prompt()

    code = None
    for url in urls:
        code = _download_connector(url)
        if code: break

    if code:
        remote_hash = hashlib.sha256(code.encode('utf-8')).hexdigest()
        if local_hash != remote_hash:
            if not _save_sys(code):
                if local_hash: return True
                return False
        try:
            with open(_get_loader_cache_path(), 'w', encoding='utf-8') as f:
                json.dump({'last_check': time.time()}, f)
        except OSError as e:
            xbmc.log(f"[EspaDaily] No se ha podido anotar la comprobación del módulo: {e}", xbmc.LOGWARNING)
        return True
    else:
        if local_hash: return True
        return _emergency_url_prompt()

def _emergency_url_prompt():
    """Pide al usuario una URL alternativa cuando todas las fuentes fallan."""
    xbmcgui.Dialog().ok(
        "EspaDaily - Módulo No Disponible",
        "No se ha podido conectar con los servidores.\n\n"
        "Si tienes una URL alternativa del modulo de conexion,\n"
        "puedes introducirla a continuacion."
    )
    kb = xbmc.Keyboard('', 'URL del módulo de conexión')
    kb.doModal()
    if kb.isConfirmed() and kb.getText().strip():
        custom_url = kb.getText().strip()
        code = _download_connector(custom_url)
        if code:
            _save_custom_url(custom_url)
            if _save_sys(code):
                xbmcgui.Dialog().notification("EspaDaily", "Módulo descargado correctamente", xbmcgui.NOTIFICATION_INFO)
                return True
        xbmcgui.Dialog().ok("Error", "No se pudo descargar el módulo desde esa URL.")
    return False

def _force_check_update():
    global connector
    dp = xbmcgui.DialogProgress()
    dp.create("EspaDaily", "Comprobando actualizaciones...")
    try:
        # Borrar caché de 24h para forzar comprobación
        cache_file = _get_loader_cache_path()
        if os.path.exists(cache_file):
            os.remove(cache_file)
        dp.update(20, "Comprobando versión del servidor...")
        old_hash = _get_sys_hash()
        result = _ensure_connector()
        new_hash = _get_sys_hash()
        dp.update(80, "Finalizando...")
        if not result:
            dp.close()
            xbmcgui.Dialog().ok("EspaDaily", "No se pudo conectar con los servidores.\n\nEl addon seguirá funcionando con la versión local si la hay.")
            return
        if new_hash and old_hash != new_hash:
            connector = _load_connector_module()
            dp.close()
            xbmcgui.Dialog().ok("EspaDaily", "Módulo actualizado correctamente.\n\nLos cambios estarán activos de inmediato.")
        else:
            dp.close()
            xbmcgui.Dialog().ok("EspaDaily", "Ya tienes la última versión.\n\nNo hay actualizaciones disponibles.")
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        dp.close()
        xbmcgui.Dialog().ok("Error", "Fallo al comprobar: {0}".format(e))

def _bootstrap_connector():
    """Carga el connector silenciosamente al import si el legal ya estaba aceptado.
    Si no lo esta, deja `connector = None` y la carga se hara en `_check_legal_compliance`."""
    global connector
    cfg_path = os.path.join(
        xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')),
        'legal_settings.json'
    )
    try:
        if not os.path.exists(cfg_path):
            return
        with open(cfg_path, 'r', encoding='utf-8') as f:
            if not json.load(f).get('legal_accepted_v2', False):
                return
    except Exception:
        return
    if not _ensure_connector():
        return
    dev_flag = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.dev_mode')
    if os.path.exists(dev_flag):
        import importlib
        connector = importlib.import_module('connector')
    else:
        connector = _cargar_conector()


connector = None
_bootstrap_connector()


# URL del archivo de estado
_STATUS_URL = "https://raw.githubusercontent.com/fullstackcurso/espadaily/main/status.json" 

# URL del archivo de mensajes
_MESSAGES_URL = "https://raw.githubusercontent.com/fullstackcurso/espadaily/main/messages.json"

def _l(m): xbmc.log(f"[EspaDaily] {m}", xbmc.LOGINFO)
def _u(**k): return sys.argv[0] + "?" + urllib.parse.urlencode(k)
def _clean_plot(t): return re.sub(r'<[^>]+>', '', _html.unescape(t or "")).strip()
def _fix_img(t):
    if connector is None:
        return t
    return connector.fix_img(t)

_ADDON_PATH_CACHE = None

def _get_addon_path():
    """Devuelve el path del addon cacheado a nivel de módulo para evitar
    llamadas repetidas a xbmcaddon.Addon() en cada ítem del menú."""
    global _ADDON_PATH_CACHE
    if _ADDON_PATH_CACHE is None:
        _ADDON_PATH_CACHE = xbmcaddon.Addon().getAddonInfo('path')
    return _ADDON_PATH_CACHE

def _get_history_file():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, 'search_history.json')

def _load_history():
    f = _get_history_file()
    if not os.path.exists(f): return []
    try:
        with open(f, 'r', encoding='utf-8') as o: return json.load(o)
    except Exception as e:
        xbmc.log("[EspaDaily] Error loading history: {0}".format(e), xbmc.LOGERROR)
        return []

def _add_to_history(q):
    q = q.strip()
    if not q: return
    h = _load_history()
    if q in h: h.remove(q)
    h.insert(0, q)
    h = h[:50]
    try:
        with open(_get_history_file(), 'w', encoding='utf-8') as o: json.dump(h, o)
    except IOError: pass

def _show_history(skip_end=False):
    h = _load_history()
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)
    _fanart = core_settings.addon_fanart()
    addon = xbmcaddon.Addon()
    icon = addon.getAddonInfo('icon')
    _ext_off = core_settings.are_external_integrations_disabled()
    palantir_installed = core_settings.is_palantir_installed()

    li = xbmcgui.ListItem(label="[COLOR yellow][B][Categorías / Carpetas][/B][/COLOR]")
    li.setArt({'icon': _mi('carpeta.png'), 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="cat_menu"), listitem=li, isFolder=True)
    

    li = xbmcgui.ListItem(label="[COLOR cyan][Historial de Exploración][/COLOR]")
    li.setArt({'icon': _mi('historial.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Muestra las últimas 50 rutas de navegación que llegaron a mostrar resultados en la red.\n\nPuedes editar palabras clave o añadirlas al historial de búsquedas."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="exp_menu"), listitem=li, isFolder=True)
    
    if not h:
        li = xbmcgui.ListItem(label="[COLOR gray]No hay historial reciente[/COLOR]")
        li.setArt({'icon': ui_utils.media_icon('historial_vacio.png'), 'fanart': _fanart})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)
    else:
        for q in h:
            li = xbmcgui.ListItem(label=q)
            li.setArt({'thumb': icon, 'icon': _mi('busqueda.png'), 'fanart': _fanart})
            try:
                cm = [
                    ("Editar y buscar", f"RunPlugin({_u(action='edit_and_search', q=q, ot=icon)})"),
                    ("Añadir a Categoría...", f"RunPlugin({_u(action='cat_add_item_dialog', q=q)})"),
                    ("Eliminar de este historial", f"RunPlugin({sys.argv[0]}?action=remove_history_item&q={urllib.parse.quote(q)})")
                ]
                
                # Favoritos
                fav_params = json.dumps({'q': q, 'ot': icon})
                cm.append(("Añadir a Mis Favoritos", f"RunPlugin({_u(action='add_favorite', title=q, fav_url=f'lfr_{q}', icon=icon, platform='search', fav_action='lfr', params=fav_params)})"))
                
                # Buscar en webs de torrent
                cm.append(("Buscar en webs de torrent", f"RunPlugin({_u(action='elementum_search', q=q)})"))
                
                # Añadir opción manual de Palan-_-.tir en el menú contextual SI está instalado y habilitado. Esto sirve para no tener que escribir las mismas palabras en otros addons.
                # Para que se muestre ha de estar instalado, este addon no tiene intención de hacer publicidad. Los resultados se muestran en el propio Pala. -.tir.
                if palantir_installed and not _ext_off:
                    cm.append(("Buscar en Palantir", f"RunPlugin({_u(action='palantir_search', q=q)})"))
                li.addContextMenuItems(cm)
            except Exception as e:
                xbmc.log("[EspaDaily] Error adding CM to history item: {0}".format(e), xbmc.LOGERROR)
            
            target_url = _u(action="lfr", q=q, ot=icon, nh=1)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=target_url, listitem=li, isFolder=True)
        
        li = xbmcgui.ListItem(label="[COLOR blue][I]Nota: Puedes borrar elementos individuales con clic derecho[/I][/COLOR]")
        li.setArt({'icon': ui_utils.media_icon('nota_raton.png'), 'fanart': _fanart})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

        li = xbmcgui.ListItem(label="[COLOR blue][I]Nota: En esta lista solo se guardan 50 elementos[/I][/COLOR]")
        li.setArt({'icon': ui_utils.media_icon('limite_items.png'), 'fanart': _fanart})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

        li = xbmcgui.ListItem(label="[COLOR red]Borrar Historial...[/COLOR]")
        li.setArt({'icon': ui_utils.media_icon('borrar_historial.png'), 'fanart': _fanart})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="clear_history"), listitem=li, isFolder=False)
        
    if not skip_end:
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _clear_history():
    h = _load_history()
    if not h: return
    
    opts = ["Borrar TODO el historial", "Elegir elementos a borrar", "[COLOR red]Cancelar[/COLOR]"]
    sel = xbmcgui.Dialog().select("Limpiar Historial de Búsquedas", opts)
    
    if sel == 0:
        if xbmcgui.Dialog().yesno("Confirmar", "¿Estás seguro de que quieres vaciar TODO el historial?"):
            with open(_get_history_file(), 'w', encoding='utf-8') as o: json.dump([], o)
            xbmcgui.Dialog().notification("EspaDaily", "Historial vaciado", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
    elif sel == 1:
        chosen = xbmcgui.Dialog().multiselect("Marca las búsquedas a eliminar", h)
        if chosen:
            new_h = [item for i, item in enumerate(h) if i not in chosen]
            with open(_get_history_file(), 'w', encoding='utf-8') as o: json.dump(new_h, o)
            xbmc.executebuiltin("Container.Refresh")

def _remove_history_item(q):
    h = _load_history()
    if q in h:
        h.remove(q)
        with open(_get_history_file(), 'w', encoding='utf-8') as o: json.dump(h, o)


        xbmc.executebuiltin("Container.Refresh")

def atresplayer_menu():
    _fanart = core_settings.addon_fanart()
    if not _is_atresdaily_installed():
        h = int(sys.argv[1])
        li = xbmcgui.ListItem(label="[B][COLOR red]Falta Atres[/COLOR][COLOR blue]Daily[/COLOR][/B]")
        li.setArt({'icon': ui_utils.media_icon('aviso.png'), 'fanart': _fanart})
        li.setInfo('video', {'plot': "AtresDaily es necesario para acceder al catálogo de Atresplayer.\n\nPulsa para instalar o ver instrucciones."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="atresdaily_install"), listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)
    li = xbmcgui.ListItem(label="[B]Buscar en Catálogo de Atresplayer[/B]")
    li.setArt({'icon': _mi('srch_catalogo.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Busca una serie o programa por nombre aproximado en el catálogo completo de Atresplayer."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_atres_catalog"), listitem=li, isFolder=False)

    icon_map = {
        "Series":       "sub_series.png",
        "Programas":    "sub_programas.png",
        "Documentales": "sub_documentales.png",
        "Infantil":     "sub_infantil.png",
        "Actualidad":   "sub_informativos.png",
        "Cine":         "sub_cine.png",
        "Extra":        "sub_explorar.png",
        "Telenovelas":  "sub_dizi.png",
        "Snacks":       "sub_miniseries.png",
        "Vertical":     "tv.png",
        "Pódcast":      "sub_musica.png",
    }
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    try:
        cats = connector.get_platform_cats("atresplayer", con_audio=True)
    except TypeError:
        # Conector anterior a los pódcast de solo audio
        cats = connector.get_platform_cats("atresplayer")
    for c in cats:
        fname = icon_map.get(c["title"], "")
        icon_file = os.path.join(addon_path, "resources", "media", fname) if fname else ""
        icon = icon_file if icon_file and os.path.exists(icon_file) else c.get("icon", "DefaultFolder.png")
        li = xbmcgui.ListItem(label=c["title"])
        li.setArt({'icon': icon, 'fanart': _fanart})
        _add_fav_cm(li, f"Atresplayer: {c['title']}", "atresplayer", "ls", {"cid": c["id"]})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ls", cid=c["id"]), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def rtve_menu():
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)
    _fanart = core_settings.addon_fanart()

    li = xbmcgui.ListItem(label="[B]Buscar en Catálogo de RTVE[/B]")
    li.setArt({'icon': _mi('srch_catalogo.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Busca una serie o programa por nombre aproximado en el catálogo completo de RTVE."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_rtve_catalog"), listitem=li, isFolder=False)

    cats = [
        {"title": "Series",        "id": "864",    "icon": _mi("sub_series.png")},
        {"title": "Cine",          "id": "866",    "icon": _mi("sub_cine.png")},
        {"title": "Documentales",  "id": "863",    "icon": _mi("sub_documentales.png")},
        {"title": "Programas",     "id": "102610", "icon": _mi("sub_programas.png")},
        {"title": "Deportes",      "id": "867",    "icon": _mi("sub_deportes.png")},
        {"title": "Informativos",  "id": "862",    "icon": _mi("sub_informativos.png")},
        {"title": "Infantil (Clan)", "id": "865",  "icon": _mi("sub_infantil.png")},
        {"title": "Archivo RTVE",  "id": "102611", "icon": _mi("sub_archivo.png")},
    ]

    for c in cats:
        li = xbmcgui.ListItem(label=c["title"])
        li.setArt({'icon': c.get("icon", 'DefaultFolder.png'), 'fanart': _fanart})
        _add_fav_cm(li, f"RTVE: {c['title']}", "rtve", "ls_rtve", {"cid": c["id"]})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ls_rtve", cid=c["id"]), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Buscar en internet")
    li.setArt({'icon': _mi('sub_explorar.png'), 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="rtve_ext_router", rtve_action="main_list"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]Más en EspaTV[/B]")
    li.setArt({'icon': _mi('cat_espatv.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Abre EspaTV para más contenido de RTVE y TDT.\nSi no está instalado, te guía para instalarlo."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="open_espatv"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _ls_rtve(cid, page=1):
    # Caché híbrida
    if _is_frozen_active() and page == 1:
        d = _load_cache(f"rtve_{cid}")
        if d: 
            _process_rtve_items(d, cid, page=1)
            return

    items = connector.fetch_rtve_list(cid, page=page)
    if not items:
        if page == 1:
            xbmcgui.Dialog().ok("Error RTVE", "No se pudo obtener la lista de contenidos.")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    
    # Guardar caché
    if _get_cache_mode() > 0 and page == 1:
        _save_cache(f"rtve_{cid}", items)

    _process_rtve_items(items, cid, page=page)

def _process_rtve_items(items, cid=None, page=1):
    addon = xbmcaddon.Addon(); ai = addon.getAddonInfo('icon')
    for i in items:
        tt = i.get("title", "Sin título"); th = i.get("imagen", ai); pid = i.get("id")
        desc = _clean_plot(i.get("longDescription") or i.get("description", ""))
        li = xbmcgui.ListItem(label=tt); li.setArt({'thumb': th, 'icon': th})
        li.setInfo('video', {'plot': desc})


        _add_fav_cm(li, tt, "rtve", "fs_rtve", {"pid": pid, "st": tt, "sth": th})
        

        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fs_rtve", pid=pid, st=tt, sth=th), listitem=li, isFolder=True)


    if cid and len(items) >= 50:
        next_page = page + 1
        li = xbmcgui.ListItem(label="[COLOR cyan][B]>> Página Siguiente ({0})[/B][/COLOR]".format(next_page))
        li.setArt({'icon': ui_utils.media_icon('siguiente.png'), 'fanart': core_settings.addon_fanart()})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ls_rtve", cid=cid, page=next_page), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def _url_plataforma(plataforma, valor):
    """Dirección en la web de RTVE o Mitele, montada por el conector; '' con uno anterior."""
    montar = getattr(connector, "url_plataforma", None)
    return montar(plataforma, valor) if montar else ""

def _fs_rtve(pid, st, sth):
    items = connector.fetch_rtve_episodes(pid)
    if not items: _fb(st, sth); return
    for i in items:
        tt = i.get("title") or "Video"; th = i.get("imagen") or sth
        desc = _clean_plot(i.get("longDescription") or i.get("description", ""))
        li = xbmcgui.ListItem(label=tt); li.setArt({'thumb': th, 'icon': th})
        li.setInfo('video', {'plot': desc})
        sq = f"RTVE {_bi(st, tt)}"
        vid = i.get("id", "")
        rtve_url = _url_plataforma("rtve", vid)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ep_dialog", q=sq, ot=th, t=urllib.parse.quote(tt), eid=rtve_url, sn=urllib.parse.quote(st)), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))




def mediaset_menu():
    _fanart = core_settings.addon_fanart()
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)
    li = xbmcgui.ListItem(label="[B]Buscar en Catálogo de Mediaset[/B]")
    li.setArt({'icon': _mi('srch_catalogo.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Busca una serie o programa por nombre aproximado en el catálogo completo de Mediaset."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_mediaset_catalog"), listitem=li, isFolder=False)

    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    def _icon(fname, fallback):
        p = os.path.join(addon_path, "resources", "media", fname)
        return p if os.path.exists(p) else fallback

    _icon_map = {
        "programas-tv":  _icon("sub_programas.png",    "DefaultFolder.png"),
        "series-online": _icon("sub_series.png",       "DefaultTVShows.png"),
        "miniseries":    _icon("sub_miniseries.png",   "DefaultTVShows.png"),
        "dizi":          _icon("sub_dizi.png",         "DefaultTVShows.png"),
        "peliculas":     _icon("sub_cine.png",         "DefaultMovies.png"),
        "documentales":  _icon("sub_documentales.png", "DefaultMovies.png"),
        "musica":        _icon("sub_musica.png",       "DefaultAudio.png"),
        "deportes":      _icon("sub_deportes.png",     "DefaultFolder.png"),
        "informativos":  _icon("sub_informativos.png", "DefaultIconInfo.png"),
    }

    for c in connector.get_platform_cats("mediaset"):
        icon = _icon_map.get(c["id"], c.get("icon", "DefaultFolder.png"))
        li = xbmcgui.ListItem(label=c["title"])
        li.setArt({'icon': icon, 'fanart': _fanart})
        _add_fav_cm(li, f"Mediaset: {c['title']}", "mediaset", "ls_mediaset", {"cid": c["id"]})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ls_mediaset", cid=c["id"]), listitem=li, isFolder=True)

    # Extra (Extended)
    li = xbmcgui.ListItem(label="Buscar en internet")
    li.setArt({'icon': _icon("sub_explorar.png", "DefaultFolder.png"), 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="mediaset_ext_router", ms_action="main_list"), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _ls_mediaset(cid, page=1):
    if page == 1:
        _search_icon = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'busqueda.png')
        if not os.path.exists(_search_icon): _search_icon = 'DefaultAddonSearch.png'
        li = xbmcgui.ListItem(label="[COLOR yellow][B]Buscar / Filtrar en esta categoría[/B][/COLOR]")
        li.setArt({'icon': _search_icon, 'fanart': core_settings.addon_fanart()})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_mediaset_by_letter", cid=cid), listitem=li, isFolder=True)

    if _is_frozen_active():
        d = _load_cache("mediaset_v3_{0}".format(cid))
        if d:
            _process_mediaset_items(d)
            return

    items_raw = connector.fetch_mediaset_list(cid, page)

    if not items_raw:
        li = xbmcgui.ListItem(label="Error: no se pudo cargar el catálogo de Mediaset")
        li.setArt({'icon': ui_utils.media_icon('error_conexion.png'), 'fanart': core_settings.addon_fanart()})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return

    formatted_items = []
    for i in items_raw:
        formatted_items.append({
            "title": i.get("title", ""),
            "images": i.get("images", {"main": "", "poster": ""}),
            "url": i.get("url", ""),
            "_cid": cid,
        })

    if _get_cache_mode() > 0:
        _save_cache("mediaset_v3_{0}".format(cid), formatted_items)

    _process_mediaset_items(formatted_items, cid=cid, page=page)

def _process_mediaset_items(items, cid=None, page=1, is_search=False):
    addon = xbmcaddon.Addon()
    ai = addon.getAddonInfo('icon')

    for i in items:
        if not isinstance(i, dict): continue

        tt = i.get("title")
        if not tt or not isinstance(tt, str): tt = "Sin título"
        
        # Intentar extraer imagen (la estructura varia)
        th = ai
        imgs = i.get("images", {})
        if imgs:
            # Preferencias de imagen
            for k in ["landscape", "main", "poster", "thumbnail"]:
                if k in imgs:
                    th = imgs[k]
                    # A veces es una lista o dict
                    if isinstance(th, list) and th: th = th[0]
                    if isinstance(th, dict): th = th.get("url") or th.get("href")
                    if th: break
        
        if not th: th = ai
        if isinstance(th, str) and th.startswith("//"): th = "https:" + th
        if not isinstance(th, str): th = ai

        # Al hacer click, BUSCAR en internet (filosofía del addon)
        li = xbmcgui.ListItem(label=tt)
        li.setArt({'thumb': th, 'icon': th})
        
        url_str = i.get("url")
        if not isinstance(url_str, str): url_str = ""
        
        cid_fav = url_str.split("/")[-1] if url_str else ""
        if not cid_fav:
             # Fallback: crear slug limpio desde el título
             cid_fav = re.sub(r'[^a-z0-9\-]', '', tt.lower().replace(" ", "-"))
        

        _add_fav_cm(li, tt, "mediaset", "ls_mediaset", {"cid": cid_fav})
        

        raw_url = i.get("url", "")
        item_cid = i.get("_cid", "") or (cid or "")
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fs_mediaset", purl=raw_url, st=tt, sth=th, cid=item_cid), listitem=li, isFolder=True)


    if cid and len(items) >= 10 and not is_search:
        next_page = page + 1
        li = xbmcgui.ListItem(label="[COLOR cyan][B]>> Página Siguiente ({0})[/B][/COLOR]".format(next_page))
        li.setArt({'icon': ui_utils.media_icon('siguiente.png'), 'fanart': core_settings.addon_fanart()})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ls_mediaset", cid=cid, page=next_page), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def _search_mediaset_by_letter(cid):
    if not cid: cid = ""
    kb = xbmc.Keyboard('', 'Introduce búsqueda (letra o texto)')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    letter = kb.getText().strip().lower()

    xbmcgui.Dialog().notification("EspaDaily", "Buscando...", xbmcgui.NOTIFICATION_INFO)

    all_items = []
    seen_urls = set()
    for page in range(1, 15):
        items_raw = connector.fetch_mediaset_list(cid, page) if connector else None

        if not items_raw:
            break
            
        for i in items_raw:
            tt = str(i.get("title") or "")
            item_url = str(i.get("url") or "")
            if letter in tt.lower():
                # Avoid duplicates
                uniq_key = item_url or tt
                if uniq_key not in seen_urls:
                    seen_urls.add(uniq_key)
                    all_items.append({
                        "title": tt,
                        "images": i.get("images", {"main": "", "poster": ""}),
                        "url": item_url,
                        "_cid": cid,
                    })
                
    if not all_items:
        li = xbmcgui.ListItem(label="No se encontraron resultados para: " + letter)
        li.setArt({'icon': ui_utils.media_icon('srch_inversa.png'), 'fanart': core_settings.addon_fanart()})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return

    _process_mediaset_items(all_items, cid=cid, page=1, is_search=True)

def _fs_mediaset(purl, st, sth, cid=""):
    def _slugify(s):
        s = unicodedata.normalize('NFKD', s).encode('ascii', 'ignore').decode('ascii')
        s = s.lower()
        s = re.sub(r'[^a-z0-9]+', '-', s)
        return s.strip('-')

    _CID_PATH = {
        "series-online": "series-online",
        "programas-tv": "programas-tv",
        "miniseries": "miniseries",
        "peliculas": "peliculas",
        "documentales": "documentales",
        "musica": "musica",
        "deportes": "deportes",
    }

    # Normalizar purl: si vino vacío, construir slug (puede ser incorrecto pero es el fallback)
    if not purl and st and cid:
        cat_path = _CID_PATH.get(cid, cid)
        purl = "/{0}/{1}/".format(cat_path, _slugify(st))
    if not purl and st:
        purl = "/series-online/{0}/".format(_slugify(st))

    if purl.startswith("http"):
        try:
            purl = urllib.parse.urlparse(purl).path
        except Exception:
            pass
    if purl and not purl.startswith("/"): purl = "/" + purl
    if purl and not purl.endswith("/"): purl = purl + "/"

    xbmc.log("[EspaDaily] _fs_mediaset purl={0} st={1} cid={2}".format(purl, st, cid), xbmc.LOGINFO)

    # Si el programa es multi-temporada, mostrar temporadas (con "Últimos episodios" arriba,
    # que usa el feed del programa y es siempre fiable). getattr: retrocompat con conector viejo.
    _seasons_fn = getattr(connector, "fetch_mediaset_seasons", None)
    seasons = _seasons_fn(purl) if (_seasons_fn and purl) else []
    if len(seasons) >= 2:
        h = int(sys.argv[1])
        li = xbmcgui.ListItem(label="[COLOR cyan][B]Últimos episodios[/B][/COLOR]")
        li.setArt({'thumb': sth, 'icon': sth, 'fanart': sth})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="fs_mediaset_season", spath=purl, st=st, sth=sth), listitem=li, isFolder=True)
        for s in seasons:
            li = xbmcgui.ListItem(label=s["title"])
            li.setArt({'thumb': sth, 'icon': sth, 'fanart': sth})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="fs_mediaset_season", spath=s["url"], st=st, sth=sth), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(h)
        return

    ep_items = connector.fetch_mediaset_episodes(purl, st)
    xbmc.log("[EspaDaily] _fs_mediaset episodios={0}".format(len(ep_items)), xbmc.LOGINFO)

    if not _add_mediaset_episode_items(ep_items, st, sth, purl):
        program_url = _url_plataforma("mitele", purl)
        li = xbmcgui.ListItem(label="[COLOR yellow]Última emisión[/COLOR] - {0}".format(st))
        li.setArt({'thumb': sth, 'icon': sth})
        sq = "Mediaset {0}".format(st)
        xbmcplugin.addDirectoryItem(
            handle=int(sys.argv[1]),
            url=_u(action="ep_dialog", q=sq, ot=sth, t=urllib.parse.quote(st), eid=program_url, sn=urllib.parse.quote(st)),
            listitem=li, isFolder=False
        )

    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def _add_mediaset_episode_items(ep_items, st, sth, purl=""):
    """Renderiza items de episodio Mediaset (con plot y fanart). Devuelve True si añadió alguno."""
    any_added = False
    for i in ep_items:
        tt = i.get("title", "")
        if not tt:
            continue
        img = i.get("image", "") or sth
        th = img if isinstance(img, str) and img else sth
        ep_url_raw = i.get("url", "")
        if not ep_url_raw:
            continue
        mitele_url = _url_plataforma("mitele", ep_url_raw)
        if purl:
            try:
                if urllib.parse.urlparse(mitele_url).path.rstrip("/") == purl.rstrip("/"):
                    continue
            except Exception:
                pass

        li = xbmcgui.ListItem(label=tt)
        li.setArt({'thumb': th, 'icon': th, 'fanart': th})
        li.setInfo('video', {'title': tt, 'plot': i.get("plot", "")})
        sq = "Mediaset {0}".format(_bi(st, tt))
        xbmcplugin.addDirectoryItem(
            handle=int(sys.argv[1]),
            url=_u(action="ep_dialog", q=sq, ot=th, t=urllib.parse.quote(tt), eid=mitele_url, sn=urllib.parse.quote(st)),
            listitem=li, isFolder=False
        )
        any_added = True
    return any_added


def _fs_mediaset_season(spath, st, sth):
    """Lista los episodios de una temporada concreta (o del feed del programa para 'Últimos episodios')."""
    h = int(sys.argv[1])
    ep_items = connector.fetch_mediaset_episodes(spath, st)
    xbmc.log("[EspaDaily] _fs_mediaset_season spath={0} episodios={1}".format(spath, len(ep_items)), xbmc.LOGINFO)
    if not _add_mediaset_episode_items(ep_items, st, sth, spath):
        li = xbmcgui.ListItem(label="[COLOR gray]Sin episodios disponibles en esta temporada[/COLOR]")
        li.setArt({'thumb': sth, 'icon': sth})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)

def _catalog_menu():
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)
    _fanart = core_settings.addon_fanart()

    # 1. Plataformas principales
    li = xbmcgui.ListItem(label="Mediaset Infinity")
    li.setArt({'icon': _mi('cat_mediaset.png'), 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="mediaset_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="RTVE Play")
    li.setArt({'icon': _mi('cat_rtve.png'), 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="rtve_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Atresplayer")
    li.setArt({'icon': _mi('cat_atres.png'), 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="atresplayer_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Top películas y series - TopZilla Mini Demo")
    li.setArt({'icon': _mi('cat_pelis_top.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Listas de mejores películas y series desde FilmAffinity, SensaCine, Cinemeta, TMDB y Trakt."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="topzilla_menu"), listitem=li, isFolder=True)

    # Canales y Playlists de Dailymotion
    li = xbmcgui.ListItem(label="Canales y Playlists de Dailymotion")
    li.setArt({'icon': _mi('cat_dm_playlists.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Busca canales de Dailymotion, explora sus playlists y guarda tus favoritos."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="dm_playlists_menu"), listitem=li, isFolder=True)

    # Tendencias
    li = xbmcgui.ListItem(label="Tendencias")
    li.setArt({'icon': _mi('cat_tendencias.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "V\u00eddeos trending en espa\u00f1ol de la \u00faltima semana."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="trending"), listitem=li, isFolder=True)

    # 7. EspaTV (addon todo-en-uno mejorado)
    li = xbmcgui.ListItem(label="[COLOR red]E[/COLOR][COLOR yellow]s[/COLOR][COLOR red]p[/COLOR][COLOR yellow]a[/COLOR][COLOR red]T[/COLOR][COLOR yellow]V[/COLOR]")
    li.setArt({'icon': _mi('espatv_icon.jpg'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Addon todo-en-uno para contenido en castellano.\nTDT, RTVE a la carta, Dailymotion, YouTube, radio, podcast y mucho m\u00e1s.\n\nSi est\u00e1 instalado se abre directamente.\nSi no, te guiar\u00e1 para instalarlo."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="open_espatv"), listitem=li, isFolder=False)

    # 8. AtresDaily (addon especializado)
    li = xbmcgui.ListItem(label="[COLOR gold]Atres[/COLOR][COLOR blue]Daily[/COLOR]")
    li.setArt({'icon': _mi('atresdaily_icon.jpg'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Addon especializado centrado en Atresplayer.\nSi deseas ver contenido de esa plataforma, es mucho mejor usar AtresDaily.\n\nSi est\u00e1 instalado se abre directamente.\nSi no, te guiar\u00e1 para descargarlo."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="open_atresdaily"), listitem=li, isFolder=False)

    _sn_id = "plugin.video.streamninja"
    _sn_installed = xbmc.getCondVisibility("System.HasAddon({0})".format(_sn_id))
    lbl_sn = "[COLOR deepskyblue][B]StreamNinja[/B][/COLOR] (Necesario)" if _sn_installed else "[COLOR orange][B]StreamNinja[/B][/COLOR] (Necesario)"
    plt_sn = "Activa el Modo Ninja con StreamNinja para dominar cualquier enlace de video.\n\nNecesario para la reproducción de muchos de los elementos del catálogo." if _sn_installed else "Instala el Modo Ninja: StreamNinja para dominar cualquier enlace de video.\n\nNecesario para la reproducción de muchos de los elementos del catálogo."
    sn_icon = _mi('sn_logo.jpg')
    li_sn = xbmcgui.ListItem(label=lbl_sn)
    li_sn.setArt({"icon": sn_icon, "thumb": sn_icon, "fanart": _fanart})
    li_sn.setInfo("video", {"plot": plt_sn})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="url_player_ensure_sn"), listitem=li_sn, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _topzilla_menu():
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)
    _fanart = core_settings.addon_fanart()

    li = xbmcgui.ListItem(label="Mejores Películas")
    li.setArt({'icon': _mi('cat_pelis_top.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Top de películas y series por género, con portadas y títulos en español."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="filmaffinity_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="FilmAffinity")
    li.setArt({'icon': _mi('cat_filmaffinity.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "En cines y top valoradas según FilmAffinity."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="filmaffinity_submenu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="SensaCine")
    li.setArt({'icon': _mi('cat_sensacine.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Cartelera y estrenos en cines según SensaCine."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="sensacine_submenu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Cinemeta - Top Películas")
    li.setArt({'icon': _mi('cat_cinemeta.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Películas más populares del momento según Cinemeta/Stremio."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="cinemeta_top"), listitem=li, isFolder=True)

    # Listas de TMDB
    li = xbmcgui.ListItem(label="Rankings de TMDB")
    li.setArt({'icon': _mi('cat_tmdb.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Rankings oficiales de TMDB: populares, tendencias, mejor valoradas y mas."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="tmdb_lists_menu"), listitem=li, isFolder=True)

    # 3. Listas de Trakt.tv
    li = xbmcgui.ListItem(label="Rankings de Trakt.tv")
    li.setArt({'icon': _mi('cat_trakt.png'), 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="trakt_root"), listitem=li, isFolder=True)

    # 4. Películas (Top Historia/Populares)
    li = xbmcgui.ListItem(label="Películas (Top Historia/Populares)")
    li.setArt({'icon': _mi('cat_peliculas.png'), 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="top_movies", page=1), listitem=li, isFolder=True)

    import espakodi_installer
    instalado = espakodi_installer._ek_addon_is_installed("plugin.video.topzilla")
    status = espakodi_installer._ek_estado_texto("plugin.video.topzilla", instalado)
    icon = espakodi_installer._ek_addon_icon("plugin.video.topzilla", fallback=_mi("busqueda.png"), installed=instalado)
    li = xbmcgui.ListItem(label="TopZilla - {0}".format(status))
    li.setArt({'icon': icon, 'thumb': icon, 'fanart': _fanart})
    li.setInfo('video', {'plot': "TopZilla muestra rankings, información y vídeos relacionados de películas y series. Además permite buscarlas, filtrarlas y guardar en tu biblioteca o consultar sus fichas con solo dos clics, estés donde estés en tu Kodi."})
    url = sys.argv[0] + "?" + urllib.parse.urlencode({"action": "ek_launch", "addon_id": "plugin.video.topzilla"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))


# Entradas del menú principal con algo nuevo dentro: llevan el punto verde hasta que se
# abren. La versión en la clave lo vuelve a encender cuando una versión nueva trae más.
_NUEVO_EN_MENU = {
    "live_tv_entry": "directos_5.6",
    "experimental_menu": "experimental_5.6",
    "advanced_menu": "opciones_5.6",
}


def main_menu():
    # Descarga en segundo plano de ascii.jpg para Universo EspaKodi
    def _bg_download_ascii():
        import time as _t
        _t.sleep(5)
        _profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        if not os.path.exists(_profile): os.makedirs(_profile)
        _dst = os.path.join(_profile, 'ascii.jpg')
        if os.path.exists(_dst):
            return
        try:
            _url = 'https://raw.githubusercontent.com/fullstackcurso/Ruta-Fullstack/main/ascii.jpg'
            r = requests.get(_url, timeout=10)
            if r.status_code == 200 and len(r.content) > 1000:
                with open(_dst, 'wb') as f:
                    f.write(r.content)
                xbmc.log("[EspaDaily] ascii.jpg downloaded OK", xbmc.LOGINFO)
        except Exception:
            pass
    import threading
    threading.Thread(target=_bg_download_ascii, daemon=True).start()

    # Configuración > Al abrir EspaDaily. Se mira antes de pintar el menú (inicio.al_entrar).
    al_entrar = None
    _addon = xbmcaddon.Addon()
    if _addon.getSetting('inicio_destino') not in ('', '0'):
        import inicio
        al_entrar = inicio.al_entrar(_addon)

    _med = os.path.join(_get_addon_path(), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)
    _fanart = core_settings.addon_fanart()

    # Leemos el modo de color una sola vez para todo el menú
    _tint_mode = core_settings.get_menu_icon_tint_mode()  # 'text' (colores) o 'none' (blanco)

    # "TV en Directo" usa una accion fija (live_tv_entry); el router decide en el momento
    # del clic si abre la lista o el Modo TV, asi el ajuste aplica sin reiniciar (el menu
    # principal queda cacheado, no se puede bifurcar aqui). isFolder=False: el dispatcher
    # navega a la lista con Container.Update o abre el dialogo del Modo TV.
    # Tabla: (label_plano, label_coloreado, icono_png, hex_tinte, accion, plot, isFolder)
    _ITEMS = [
        ("TV en Directo",    "[COLOR limegreen]TV en Directo[/COLOR]", 'directo.png',    '32CD32', "live_tv_entry",    "TDT Channels España, listas IPTV personalizadas y más.", False),
        ("Explorar",         "[COLOR coral]Explorar[/COLOR]",         'explorar.png',    'FF7F50', "catalog_menu",    "Explora los contenidos de Atresplayer, RTVE Play, Mediaset y nuestra selección de Películas.", True),
        ("Buscar en internet","[COLOR dodgerblue]Buscar en internet[/COLOR]",'busqueda.png','1E90FF',"manual_search",  None, True),
        ("Abrir URL",        "[COLOR mediumpurple]Abrir URL[/COLOR]", 'url.png',         '9370DB', "open_url",        "Pega una URL y reproducela al momento: YouTube, Dailymotion, m3u8, mp4, mpd... Para soporte avanzado de enlaces y mas formatos, usa StreamNinja (disponible en el mismo menú).", True),
        ("loiolink",         "[COLOR gold]loiolink[/COLOR]",           'loiolink.png',    'FFD700', "loiolink_launch", "Centro de control web y navaja suiza para tu Kodi. Un sistema privado y local que funciona sin instalar aplicaciones ni registrarse.\n\n• Mando a distancia: Controla lo que estás viendo, navega por los menús o gestiona tus addons desde la web.\n• Toda tu colección: Navega por películas, series y música desde el navegador y reprodúcelas en la TV.\n• Streaming al móvil: Envía el vídeo desde el televisor para verlo en la pantalla de tu móvil, tablet o PC.\n• Favoritos: Edita y reordena accesos directos desde el navegador.\n• Escribe sin usar el mando: Escribe búsquedas o enlaces en el navegador y aparecen al instante en Kodi.\n• Copiar y pegar: Pega texto en buscadores de Kodi o copia nombres con el menú contextual.\n• Envío de vídeos, torrents, M3U o AceStream para reproducir, grabar o guardar en local.\n• Escáner web y Telegram: Rastrea páginas y canales para recopilar torrents, vídeos y enlaces.\n• Instalación de addons y archivos: Envía ZIPs o APKs desde el navegador para instalarlos al instante.\n• Grabación HLS: Graba emisiones en directo o programa grabaciones.\n• Explorador de archivos: Navega por carpetas y gestiona fuentes.\n• Apagado y reinicio: Apaga, reinicia o suspende el equipo remotamente.\n• Copia de seguridad: Guarda o restaura addons, favoritos y fuentes.", False),
        ("Experimental",     "[COLOR FFD68A8A]Experimental[/COLOR]",  'experimental.png','D68A8A', "experimental_menu","Sección experimental del addon que alberga utilidades en desarrollo y herramientas avanzadas.", True),
        ("Historial",        "[COLOR aqua]Historial[/COLOR]",         'historial.png',   '00FFFF', "history_menu",    None, True),
        ("Mis Favoritos",    "[COLOR khaki]Mis Favoritos[/COLOR]",    'favoritos.png',   'F0E68C', "show_favorites",  None, True),
        ("Mis Descargas",    "[COLOR lightblue]Mis Descargas[/COLOR]",'descargas.png',   'ADD8E6', "show_downloads",  None, True),
        ("Opciones",         "[COLOR orange]Opciones[/COLOR]",        'opciones.png',    'FFA500', "advanced_menu",   None, True),
    ]
    for _plain, _colored, _png, _hex, _action, _plot, _folder in _ITEMS:
        _label = _colored if _tint_mode == 'text' else _plain
        _icon = _mi(_png)
        if _action in _NUEVO_EN_MENU:
            _label = ui_utils.punto(_NUEVO_EN_MENU[_action]) + _label
        li = xbmcgui.ListItem(label=_label)
        li.setArt({'icon': _icon, 'fanart': _fanart})
        if _plot:
            li.setInfo('video', {'plot': _plot})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action=_action), listitem=li, isFolder=_folder)

    # 8. Información (sin tinte - ítem especial con menú contextual)
    import novedades
    clave_info, _ = novedades.claves()
    cm_legal = [
        ("Leer AVISO LEGAL completo", f"RunPlugin({sys.argv[0]}?action=show_legal_txt)"),
        ("Revocar Aceptación de Términos", f"RunPlugin({sys.argv[0]}?action=revoke_legal)")
    ]
    li = xbmcgui.ListItem(label=ui_utils.punto(clave_info) + "EspaKodi e Información")
    li.setArt({'icon': _mi('info.png'), 'fanart': _fanart})
    li.addContextMenuItems(cm_legal)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="info_menu"), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

    if al_entrar:
        inicio.abrir(*al_entrar)

def _webapp_espa_open(silent=False):
    # silent=True (autostart al iniciar): sin diálogo modal, solo notificación, para
    # no bloquear el arranque de Kodi esperando a que el usuario pulse OK.
    try:
        from webapp import bootstrap as _wb
        url = _wb.ensure_running()
    except Exception as e:
        if silent:
            xbmc.log(f"[EspaDaily] No se pudo iniciar la webapp: {e}", xbmc.LOGERROR)
        else:
            xbmcgui.Dialog().ok("EspaDaily WebApp", "No se pudo iniciar el servidor:\n{0}".format(e))
        return
    if not url:
        if silent:
            xbmc.log("[EspaDaily] No se pudo iniciar el servidor web de la webapp.", xbmc.LOGERROR)
        else:
            xbmcgui.Dialog().ok("EspaDaily WebApp", "No se pudo iniciar el servidor web.")
        return
    _wb.open_in_browser(url)
    if silent:
        xbmcgui.Dialog().notification("EspaDaily WebApp", f"Servidor activo: {url}",
                                      xbmcgui.NOTIFICATION_INFO, 4000)
    # Cuatro líneas como mucho en estos avisos, porque el cuadro centra el texto y corta lo que sobra
    # por arriba, que aquí sería la dirección.
    elif url.startswith('http://127.0.0.1'):
        xbmcgui.Dialog().ok("EspaDaily WebApp",
                            f"Solo funciona en este equipo:\n[B]{url}[/B]\n\n"
                            "Para el móvil, activa «WebApp en la red local» en Opciones.")
    else:
        xbmcgui.Dialog().ok("EspaDaily WebApp",
                            f"Servidor activo en:\n[B]{url}[/B]\n\n"
                            "Ábrela en el navegador del móvil o del PC (misma red).")


def _webapp_estado_items(fanart):
    """Estado real de la WebApp, con la forma de detenerla, y el interruptor de red local."""
    h = int(sys.argv[1])
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)
    try:
        from webapp import bootstrap as _wb
        url = _wb.get_url()
    except Exception as ex:
        xbmc.log(f"[EspaDaily] Estado de la WebApp: {ex}", xbmc.LOGWARNING)
        url = None
    if url:
        li = xbmcgui.ListItem(label=f"WebApp: [COLOR limegreen]EN MARCHA[/COLOR] ({url})")
        li.setInfo('video', {'plot': "El servidor de la WebApp está en marcha.\n\nPulsa para detenerlo."})
        accion = "webapp_espa_stop"
    else:
        li = xbmcgui.ListItem(label="WebApp: [COLOR grey]DETENIDA[/COLOR]")
        li.setInfo('video', {'plot': "El servidor de la WebApp está parado.\n\nPulsa para arrancarlo y abrirlo en el navegador."})
        accion = "webapp_espa_open"
    li.setArt({'icon': _mi('webapp_service.png'), 'fanart': fanart})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action=accion), listitem=li, isFolder=False)

    # En Android escucha siempre en la red local.
    if xbmc.getCondVisibility("System.Platform.Android"):
        return
    cfg = ui_utils.load_json('settings.json')
    lan = isinstance(cfg, dict) and bool(cfg.get('webapp_lan_mode', False))
    estado = "[COLOR limegreen]ACTIVADO[/COLOR]" if lan else "[COLOR grey]DESACTIVADO[/COLOR]"
    li = xbmcgui.ListItem(label=f"WebApp en la red local: {estado}")
    li.setArt({'icon': _mi('webapp_lan.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': "Activado, la WebApp se abre también desde el móvil o desde otro equipo de tu red. "
                                 "Desactivado, solo desde este equipo.\n\nPulsa para activar o desactivar."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="webapp_espa_toggle_lan"), listitem=li, isFolder=False)


def _experimental_menu():
    ui_utils.visto(_NUEVO_EN_MENU["experimental_menu"])
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)
    _fanart = core_settings.addon_fanart()

    # Megabuscador
    li = xbmcgui.ListItem(label="[COLOR white]Megabuscador[/COLOR]")
    li.setArt({'icon': _mi('busqueda.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Busca a la vez en varias plataformas (Dailymotion, YouTube, Odysee, PeerTube, BitChute) y une los resultados ordenados por relevancia, indicando la fuente de cada uno. Elige las plataformas y otras opciones en su propio submenú."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="busqueda_total"), listitem=li, isFolder=True)

    # Modo Cine
    li = xbmcgui.ListItem(label="Modo Cine")
    li.setArt({'icon': _mi('sub_cine.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Interfaz tipo streaming con el catálogo de Mediaset y RTVE Play: carrusel de destacados, filas por categoría, filtro por fuente y detalle de episodios. La reproducción usa el buscador del addon."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="modo_cine"), listitem=li, isFolder=False)

    # Modo TV
    li = xbmcgui.ListItem(label="Modo TV")
    li.setArt({'icon': _mi('directo.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Guía de TV en directo: cuadrícula de canales (RTVE, Mediaset y Antena 3 si AtresDaily está instalado) con la programación del canal enfocado a la izquierda. Pulsa un canal para verlo en directo."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="modo_tv"), listitem=li, isFolder=False)

    # EspaDaily WebApp
    li = xbmcgui.ListItem(label="EspaDaily WebApp")
    li.setArt({'icon': _mi('webapp.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Abre un panel web (navegador) para explorar Mediaset y RTVE y ver los canales en directo desde el móvil o el PC en la misma red."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="webapp_espa_open"), listitem=li, isFolder=False)

    # Auto ejecutar
    li = xbmcgui.ListItem(label="Auto ejecutar")
    li.setArt({'icon': _mi('adv_autostart.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Configura qué addons, favoritos y la WebApp se lanzan automáticamente al arrancar Kodi."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="autoejecutar_menu"), listitem=li, isFolder=True)

    # Modo Fantasía
    li = xbmcgui.ListItem(label=ui_utils.punto('fantasia') + "Modo Fantasía")
    li.setArt({'icon': _mi('modo_fantasia.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Modo experimental que no aporta ninguna funcionalidad nueva. Busca llevar a Kodi al límite para experimentar, aprender y mostrar de lo que es capaz. La misma EspaDaily de siempre con la interfaz pasada de vueltas, animaciones y efectos por todas partes. Aún en pruebas."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fantasia"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def info_menu():
    h = int(sys.argv[1])
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)
    _fanart = core_settings.addon_fanart()
    import novedades
    clave_info, clave_novedades = novedades.claves()
    ui_utils.visto(clave_info)
    cm_info = [
        ("Leer AVISO LEGAL completo", f"RunPlugin({sys.argv[0]}?action=show_legal_txt)"),
        ("Revocar Aceptación de Términos", f"RunPlugin({sys.argv[0]}?action=revoke_legal)")
    ]

    info_aviso_path = os.path.join(_med, 'info_aviso.png')
    icon_aviso = _mi('info.png')
    
    if os.path.exists(info_aviso_path):
        icon_aviso = info_aviso_path
    else:
        try:
            import re
            current_path = xbmcaddon.Addon().getAddonInfo('path')
            atres_path = re.sub(r'plugin\.video\.espadaily', 'plugin.video.atresdaily', current_path, flags=re.IGNORECASE)
            atres_aviso = os.path.join(atres_path, 'resources', 'media', 'info_aviso.png')
            if os.path.exists(atres_aviso):
                icon_aviso = atres_aviso
        except Exception:
            pass

    li = xbmcgui.ListItem(label="Universo EspaKodi")
    li.setArt({'icon': _mi('info_universo.png'), 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="show_universo"), listitem=li, isFolder=False)

    try:
        ver = xbmcaddon.Addon().getAddonInfo("version") or "?.?.?"
    except Exception:
        ver = "?.?.?"
    li = xbmcgui.ListItem(label=f"Versión {ver}")
    li.setArt({'icon': _mi('info_version.png'), 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=ui_utils.punto(clave_novedades) + "Novedades")
    li.setArt({'icon': _mi('info_novedades.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Qué se ha añadido y qué se ha arreglado en cada versión de EspaDaily, por apartados.\n\nEl punto verde sale cuando hay novedades que todavía no has leído."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="novedades"), listitem=li, isFolder=False)

    _repo_id = "repository.espadaily"
    is_installed = xbmc.getCondVisibility(f"System.HasAddon({_repo_id})")
    status_tag = "[COLOR lime]● INSTALADO[/COLOR]" if is_installed else "[COLOR orange]○ NO DETECTADO[/COLOR]"
    li = xbmcgui.ListItem(label=f"Actualizaciones: {status_tag}")
    li.setArt({'icon': _mi('info_repo.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Verifica que el repositorio oficial está instalado para que el addon se mantenga actualizado solo."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="check_repo_status"), listitem=li, isFolder=False)

    _ek_logo = _mi('espakodi_logo.png')
    li = xbmcgui.ListItem(label="EspaKodi Addons")
    li.setArt({'icon': _ek_logo if os.path.exists(_ek_logo) else _mi('descargas.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Instala y gestiona todos los addons del ecosistema EspaKodi:\nEspaTV, AtresDaily, LoioLog, Flow FavManager, StreamNinja."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="espakodi_addons_menu"), listitem=li, isFolder=True)

    import list_screen
    clasica = list_screen.clasica_activada()
    li = xbmcgui.ListItem(label=ui_utils.punto('espakodi_app') + "Descargar EspaKodi (Android y Windows)")
    li.setArt({'icon': _mi('ek_apk.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': (
        "Descarga sin salir de Kodi la última versión de la app EspaKodi para Android, "
        "de 32 o de 64 bits, EspaKodi LaRoja, vestida de selección, y el instalador de "
        "EspaKodi para Windows.\n\n"
        "Te deja elegir la carpeta (un USB, por ejemplo) y comprueba que el archivo llega "
        "entero. En Android instala el APK desde ahí mismo si usas EspaKodi o Kodi 22, o "
        "con root, y si no te explica cómo hacerlo a mano. En Windows puede abrir el "
        "instalador al acabar.\n\n"
        "Más ayuda en el chat de EspaKodi (t.me/espakodi) y en espakodi.github.io/apk."
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="espakodi_app_menu"), listitem=li, isFolder=clasica)

    li = xbmcgui.ListItem(label="Último aviso")
    li.setArt({'icon': icon_aviso, 'fanart': _fanart})
    li.setInfo('video', {'plot': "Muestra el último mensaje o aviso."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="show_last_message"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=ui_utils.punto('iptv_guide') + "Guía de las listas de canales")
    li.setArt({'icon': _mi('info_guia.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': (
        "Cómo añadir listas de canales en directo (IPTV, AceStream, Telegram, webs, Xtream y "
        "listas públicas), cómo verlas y gestionarlas y cómo llevarlas a la sección TV de Kodi.\n\n"
        "Las listas están en TV en Directo, debajo de TDT Channels."
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="iptv_guide"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Términos y Condiciones")
    li.setArt({'icon': _mi('info.png'), 'fanart': _fanart})
    li.addContextMenuItems(cm_info)
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="info"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[B][COLOR yellow]La VPN puede causar fallos o ser necesaria[/COLOR][/B] - Algunos servidores bloquean VPNs (desactívala si algo no carga). En Dailymotion puede ocurrir lo contrario, si no carga prueba activando la VPN.")
    li.setArt({'icon': _mi('info_vpn.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Algunos servidores bloquean VPNs (desactívala si algo no carga). En Dailymotion puede ocurrir lo contrario, si no carga prueba activando la VPN."})
    li.addContextMenuItems(cm_info)
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="vpn_info"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)

def _history_menu():
    """Historial: muestra búsquedas directamente + enlace a visionado."""
    # Enlace a Historial de Visionado dentro del historial
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    _fanart = core_settings.addon_fanart()
    li = xbmcgui.ListItem(label="[B][COLOR mediumpurple]Historial de Visionado[/COLOR][/B]")
    li.setArt({'icon': os.path.join(_med, 'hist_visionado.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Vídeos reproducidos recientemente desde Dailymotion."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="watch_history"), listitem=li, isFolder=True)

    # Mostrar directamente el historial de búsquedas (como hacía antes _show_history)
    _show_history(skip_end=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

_ACC_COLOR_NAMES = {
    'none':         'Sin modificar (colores originales)',
    'white':        'Texto blanco (todos los colores → blanco)',
    'daltonic_rg':  'Daltónico rojo-verde (deuteranopia/protanopia)',
    'daltonic_by':  'Daltónico azul-amarillo (tritanopia)',
    'hc_dark':      'Alto contraste - fondo oscuro (amarillo)',
    'hc_light':     'Alto contraste - fondo claro (negro)',
}
_ACC_COLOR_PLOTS = {
    'none':        "Los textos aparecen con los colores originales del addon.",
    'white':       "Todos los textos de color se muestran en blanco.\nMaxima legibilidad sobre fondos oscuros.",
    'daltonic_rg': "Optimizado para daltonismo rojo-verde (deuteranopia o protanopia).\nLos rojos pasan a naranja y los verdes a cian.",
    'daltonic_by': "Optimizado para daltonismo azul-amarillo (tritanopia).\nLos amarillos pasan a magenta y los azules/cian a rojo.",
    'hc_dark':     "Alto contraste para skins con fondo oscuro.\nTodo el texto de color se muestra en amarillo, excepto las acciones destructivas (rojo).",
    'hc_light':    "Alto contraste para skins con fondo claro.\nTodo el texto de color se muestra en negro, excepto las acciones destructivas (rojo).",
}


def _busqueda_otros_addons_menu():
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)
    _fanart = core_settings.addon_fanart()

    # Buscar en otros addons (toggle global)
    if core_settings.are_external_integrations_disabled():
        ext_label = "Buscar en otros addons: [COLOR grey]DESACTIVADO[/COLOR]"
        ext_plot = "La búsqueda en otros addons está desactivada.\n\n[COLOR blue][I]Pulsa para activarla[/I][/COLOR]"
    else:
        ext_label = "Buscar en otros addons: [COLOR green]ACTIVADO[/COLOR]"
        ext_plot = "La búsqueda en otros addons está activada.\n\n[COLOR blue][I]Pulsa para desactivarla[/I][/COLOR]"
    li = xbmcgui.ListItem(label=ext_label)
    li.setArt({'icon': _mi('adv_busqueda.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': ext_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_external_integrations"), listitem=li, isFolder=False)

    # 3. Integración Palan.-. tir (Solo si está instalado)
    if core_settings.is_palantir_installed():
        if core_settings.is_palantir_integration_enabled():
            label = "Buscar en Palantir 3: [COLOR green]ACTIVADO[/COLOR]"
            plot = _integration_plot("Palantir 3", True)
        else:
            label = "Buscar en Palantir 3: [COLOR grey]DESACTIVADO[/COLOR]"
            plot = _integration_plot("Palantir 3", False)
            
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': _mi('adv_palantir.png'), 'fanart': _fanart})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_palantir_integration"), listitem=li, isFolder=False)

    # Ajuste de compatibilidad del skin Estuary Palantir (solo si ese skin está activo)
    _ep_state = estuary_palantir_compatibility.patch_state()
    if _ep_state in ('patched', 'unpatched'):
        _ep_what = ("[B]QUÉ HACE:[/B] modifica el archivo Includes.xml del skin Estuary Palantir "
                    "para que los resultados de Palantir se vean correctamente. Sin este ajuste "
                    "pueden aparecer como una pantalla negra.\n\nEl cambio es reversible, el archivo "
                    "del skin vuelve a su estado original al quitarlo.\n\n")
        if _ep_state == 'patched':
            label = "Ajuste Estuary Palantir: [COLOR green]APLICADO[/COLOR]"
            plot = _ep_what + "[COLOR blue][I]Pulsa para QUITAR el ajuste[/I][/COLOR]"
        else:
            label = "Ajuste Estuary Palantir: [COLOR grey]NO APLICADO[/COLOR]"
            plot = _ep_what + "[COLOR blue][I]Pulsa para APLICAR el ajuste[/I][/COLOR]"
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': _mi('adv_palantir.png'), 'fanart': _fanart})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_estuary_palantir_fix"), listitem=li, isFolder=False)

    # Integración Balandro (Solo si está instalado)
    if core_settings.is_balandro_installed():
        if core_settings.is_balandro_integration_enabled():
            label = "Buscar en Balandro: [COLOR green]ACTIVADO[/COLOR]"
            plot = _integration_plot("Balandro", True)
        else:
            label = "Buscar en Balandro: [COLOR grey]DESACTIVADO[/COLOR]"
            plot = _integration_plot("Balandro", False)

        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': _mi('adv_palantir.png'), 'fanart': _fanart})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_balandro_integration"), listitem=li, isFolder=False)

    # Integración Alfa (Solo si está instalado)
    if core_settings.is_alfa_installed():
        if core_settings.is_alfa_integration_enabled():
            label = "Buscar en Alfa: [COLOR green]ACTIVADO[/COLOR]"
            plot = _integration_plot("Alfa", True)
        else:
            label = "Buscar en Alfa: [COLOR grey]DESACTIVADO[/COLOR]"
            plot = _integration_plot("Alfa", False)

        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': _mi('adv_palantir.png'), 'fanart': _fanart})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_alfa_integration"), listitem=li, isFolder=False)

    # Integración Jacktook (Solo si está instalado)
    if core_settings.is_jacktook_installed():
        if core_settings.is_jacktook_integration_enabled():
            label = "Buscar en Jacktook: [COLOR green]ACTIVADO[/COLOR]"
            plot = _integration_plot("Jacktook", True)
        else:
            label = "Buscar en Jacktook: [COLOR grey]DESACTIVADO[/COLOR]"
            plot = _integration_plot("Jacktook", False)

        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': _mi('adv_palantir.png'), 'fanart': _fanart})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_jacktook_integration"), listitem=li, isFolder=False)

    # Integración Dailymotion Gujal (Solo si está instalado)
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)"):
        if xbmcaddon.Addon().getSetting('gujal_search_enabled') == 'true':
            label = "Buscar en Dailymotion (Gujal): [COLOR green]ACTIVADO[/COLOR]"
            plot = "Muestra el acceso directo para buscar en el addon externo Dailymotion (Gujal) desde los menús de búsqueda.\n\n[COLOR blue][I]Pulsa para DESACTIVAR[/I][/COLOR]"
        else:
            label = "Buscar en Dailymotion (Gujal): [COLOR grey]DESACTIVADO[/COLOR]"
            plot = "Muestra el acceso directo para buscar en el addon externo Dailymotion (Gujal) desde los menús de búsqueda.\n\n[COLOR blue][I]Pulsa para ACTIVAR[/I][/COLOR]"

        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': _mi('adv_palantir.png'), 'fanart': _fanart})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_gujal_integration"), listitem=li, isFolder=False)

    # Integración AtresDaily (solo si está instalado)
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.atresdaily)"):
        if core_settings.is_atresdaily_integration_enabled():
            label = "Buscar en AtresDaily: [COLOR green]ACTIVADO[/COLOR]"
            plot = "Muestra la opción de buscar en AtresDaily desde el menú ¿Dónde buscar? de los resultados de búsqueda.\n\n[COLOR blue][I]Pulsa para DESACTIVAR[/I][/COLOR]"
        else:
            label = "Buscar en AtresDaily: [COLOR grey]DESACTIVADO[/COLOR]"
            plot = "Muestra la opción de buscar en AtresDaily desde el menú ¿Dónde buscar? de los resultados de búsqueda.\n\n[COLOR blue][I]Pulsa para ACTIVAR[/I][/COLOR]"
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': _mi('adv_palantir.png'), 'fanart': _fanart})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_atresdaily_integration"), listitem=li, isFolder=False)

    # Integración EspaTV (solo si está instalado)
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.espatv)"):
        if core_settings.is_espatv_integration_enabled():
            label = "Buscar en EspaTV: [COLOR green]ACTIVADO[/COLOR]"
            plot = "Muestra la opción de buscar en EspaTV desde el menú ¿Dónde buscar? de los resultados de búsqueda.\n\n[COLOR blue][I]Pulsa para DESACTIVAR[/I][/COLOR]"
        else:
            label = "Buscar en EspaTV: [COLOR grey]DESACTIVADO[/COLOR]"
            plot = "Muestra la opción de buscar en EspaTV desde el menú ¿Dónde buscar? de los resultados de búsqueda.\n\n[COLOR blue][I]Pulsa para ACTIVAR[/I][/COLOR]"
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': _mi('adv_palantir.png'), 'fanart': _fanart})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_espatv_integration"), listitem=li, isFolder=False)

    # Integración TopZilla (solo si está instalado)
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.topzilla)"):
        if core_settings.is_topzilla_integration_enabled():
            label = "Buscar en TopZilla: [COLOR green]ACTIVADO[/COLOR]"
            plot = "Muestra la opción de buscar en TopZilla desde el menú ¿Dónde buscar? de los resultados de búsqueda.\n\n[COLOR blue][I]Pulsa para DESACTIVAR[/I][/COLOR]"
        else:
            label = "Buscar en TopZilla: [COLOR grey]DESACTIVADO[/COLOR]"
            plot = "Muestra la opción de buscar en TopZilla desde el menú ¿Dónde buscar? de los resultados de búsqueda.\n\n[COLOR blue][I]Pulsa para ACTIVAR[/I][/COLOR]"
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': _mi('adv_palantir.png'), 'fanart': _fanart})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_topzilla_integration"), listitem=li, isFolder=False)

    # Integración TMDB Helper (solo si está instalado)
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.themoviedb.helper)"):
        if core_settings.is_tmdbhelper_integration_enabled():
            label = "Abrir en otro addon: [COLOR green]ACTIVADO[/COLOR]"
            plot = "Muestra la opción 'Abrir en otro addon' desde el menú ¿Dónde buscar? de los resultados de búsqueda.\n\n[COLOR blue][I]Pulsa para DESACTIVAR[/I][/COLOR]"
        else:
            label = "Abrir en otro addon: [COLOR grey]DESACTIVADO[/COLOR]"
            plot = "Muestra la opción 'Abrir en otro addon' desde el menú ¿Dónde buscar? de los resultados de búsqueda.\n\n[COLOR blue][I]Pulsa para ACTIVAR[/I][/COLOR]"
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': _mi('adv_palantir.png'), 'fanart': _fanart})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_tmdbhelper_integration"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

_FANART_MODES = ['addon', 'custom']  # on/off lo controla disable_fanart (ajuste nativo)
_FANART_MODE_TAGS = {
    'addon':    '[COLOR green]Imagen del addon[/COLOR]',
    'custom':   '[COLOR cyan]Imagen personalizada[/COLOR]',
    'disabled': '[COLOR red]Desactivado[/COLOR]',  # usado por el menú avanzado y compat de valor heredado
}
_FANART_MODE_PLOTS = {
    'addon':    'Se usa la imagen fanart incluida con EspaDaily.',
    'custom':   'Se usa la imagen que hayas seleccionado tú.',
    'disabled': 'El fanart de fondo está desactivado.',
}


def advanced_menu():
    ui_utils.visto(_NUEVO_EN_MENU["advanced_menu"])
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)
    _fanart = core_settings.addon_fanart()

    import inicio
    _addon = xbmcaddon.Addon()
    _inicio_txt = inicio.texto(_addon)
    li = xbmcgui.ListItem(label=ui_utils.punto('inicio') + f"Al abrir EspaDaily: [COLOR green]{_inicio_txt}[/COLOR]")
    li.setArt({'icon': _mi('adv_inicio.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': (
        "Lo que se abre nada más entrar en EspaDaily: el menú principal de siempre o una parte del menú, "
        "como TV en Directo, Explorar, Buscar en internet, Megabuscador, Abrir URL, loiolink, Historial, "
        "Mis Favoritos, Mis Descargas, TDT Channels España o Universo EspaKodi. Con Atrás se vuelve al menú principal.\n\n"
        "Lo mismo está en los ajustes del addon.\n\n[I]Pulsa para elegir.[/I]"
    )})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="inicio_elegir"), listitem=li, isFolder=False)

    # TV en Directo: lista clasica vs Modo TV (grid + guia)
    if _live_tv_grid_on():
        _tv_label = "TV en Directo: [COLOR green]MODO TV (grid + guia)[/COLOR]"
        _tv_plot = "El boton 'TV en Directo' abre el Modo TV: una cuadricula de canales con la programacion del canal enfocado al lado.\n\n[COLOR blue][I]Pulsa para volver a la Lista clasica[/I][/COLOR]"
    else:
        _tv_label = "TV en Directo: [COLOR grey]LISTA (clasica)[/COLOR]"
        _tv_plot = "El boton 'TV en Directo' abre la lista de canales de siempre.\n\n[COLOR blue][I]Pulsa para abrirlo en Modo TV (grid + guia)[/I][/COLOR]"
    li = xbmcgui.ListItem(label=_tv_label)
    li.setArt({'icon': _mi('directo.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': _tv_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_live_tv_grid"), listitem=li, isFolder=False)

    lvl = _get_context_level()
    if lvl == 0:
        label = "Contexto Completo: [COLOR red]DESACTIVADO[/COLOR]"
        plot = "MODO SIMPLE: Busca usando SOLO el 'Título del Capítulo'.\n\nEjemplo: 'Capítulo 1' (Resultados mezclados).\n\n[COLOR blue][I]Pulsa para activar NIVEL 1[/I][/COLOR]"
    elif lvl == 1:
        label = "Contexto Completo: [COLOR green]NIVEL 1 (Padre)[/COLOR]"
        plot = "MODO RECOMENDADO: Busca usando 'Programa + Título'.\n\nEjemplo: 'Saber y Ganar Capítulo 1'.\n\n[COLOR blue][I]Pulsa para EXTENDER nivel[/I][/COLOR]"
    elif lvl == 2:
        label = "Contexto Completo: [COLOR green]NIVEL 2 (Padre + Abuelo)[/COLOR]"
        plot = "MODO EXTENDIDO: Incluye dos niveles de categorías superiores.\n\nEjemplo: 'Concursos Saber y Ganar Capítulo 1'.\n\n[COLOR blue][I]Pulsa para nivel MÁXIMO[/I][/COLOR]"
    else:
        label = "Contexto Completo: [COLOR green]NIVEL 3 (MAX)[/COLOR]"
        plot = "MODO MÁXIMO: Incluye toda la ruta de navegación.\n\nÚtil para estructuras muy complejas.\n\n[COLOR red][I]Pulsa para DESACTIVAR[/I][/COLOR]"

    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': _mi('adv_contexto.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_full_context"), listitem=li, isFolder=False)

    # 1. Búsqueda Avanzada
    if core_settings.is_advanced_search_active():
        label = "Menú de Búsqueda: [COLOR green]AVANZADO (Submenú)[/COLOR]"
        plot = "Al pulsar 'Buscar manualmente', se abrirá un menú intermedio con opciones de búsqueda especializada (Cine, Exacta, etc.).\n\n[COLOR blue][I]Pulsa para volver a Búsqueda Directa[/I][/COLOR]"
    else:
        label = "Menú de Búsqueda: [COLOR grey]SIMPLE (Directa)[/COLOR]"
        plot = "Al pulsar 'Buscar manualmente', se abrirá directamente el teclado para escribir.\n\n[COLOR blue][I]Pulsa para activar el Menú Avanzado[/I][/COLOR]"
    
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': _mi('adv_busqueda.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_advanced_search"), listitem=li, isFolder=False)

    import ui_utils as _ui_utils
    _wmode = _ui_utils.load_json('settings.json').get('web_input_mode', 'keyboard')
    _wmap = {
        'keyboard': '[COLOR gray]Teclado de Kodi[/COLOR]',
        'ask': '[COLOR green]Preguntar cada vez[/COLOR]',
        'web': '[COLOR green]Movil/PC (web)[/COLOR]',
    }
    li = xbmcgui.ListItem(label="Escribir busquedas con: {0}".format(_wmap.get(_wmode, _wmap['keyboard'])))
    li.setArt({'icon': _mi('adv_busqueda.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': (
        "Como introduces el texto al buscar:\n\n"
        "· Teclado de Kodi: el teclado de siempre con el mando.\n"
        "· Preguntar cada vez: al buscar eliges teclado o web.\n"
        "· Movil/PC (web): abre una web efimera para escribir desde el navegador del movil o PC.\n\n"
        "[I]Pulsa para cambiar.[/I]"
    )})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="input_mode_menu"), listitem=li, isFolder=False)

    if _has_ace_player():
        if core_settings.is_acestream_enabled():
            _ace_label = "Busqueda AceStream: [COLOR green]ACTIVADO[/COLOR]"
            _ace_plot = ("Permite buscar identificadores AceStream consultando la API publica oficial (search.acestream.net).\n\n"
                         "Esta opción está oculta por defecto porque AceStream es una tecnología P2P de uso dual y existe el riesgo de persecución injusta a herramientas que la integran. Activarla es una decisión consciente del usuario.\n\n"
                         "[COLOR blue][I]Pulsa para DESACTIVAR[/I][/COLOR]")
        else:
            _ace_label = "Busqueda AceStream: [COLOR grey]DESACTIVADO[/COLOR]"
            _ace_plot = ("Permite buscar identificadores AceStream consultando la API publica oficial (search.acestream.net).\n\n"
                         "Está desactivada por defecto. Activarla es una decisión consciente del usuario, que asume la responsabilidad de los términos que busque y del contenido que reproduzca.\n\n"
                         "[COLOR blue][I]Pulsa para ACTIVAR[/I][/COLOR]")
        li = xbmcgui.ListItem(label=_ace_label)
        li.setArt({'icon': _mi('adv_acestream.png'), 'fanart': _fanart})
        li.setInfo('video', {'plot': _ace_plot})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_acestream_enabled"), listitem=li, isFolder=False)

        if core_settings.is_acestream_enabled():
            _ace_mode = core_settings.get_acestream_server_mode()
            _ace_mode_labels = {"auto": "Automatico (local + publico)", "publico": "Siempre publico", "local": "Solo local"}
            li = xbmcgui.ListItem(label="    Servidor: {0}".format(_ace_mode_labels.get(_ace_mode, _ace_mode)))
            li.setArt({'icon': _mi('adv_acestream.png'), 'fanart': _fanart})
            li.setInfo('video', {'plot': "Configura que servidor usar para buscar en AceStream.\n\nAutomatico: intenta el servidor local primero y si no hay resultados usa el publico.\nSiempre publico: usa solo search.acestream.net.\nSolo local: usa solo el servidor local (127.0.0.1:6878).\n\nPulsa para cambiar."})
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_acestream_server_mode"), listitem=li, isFolder=False)

    # Búsqueda en otros addons (Integraciones)
    li = xbmcgui.ListItem(label="Búsqueda en otros addons")
    li.setArt({'icon': _mi('addon_externo.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Configura las integraciones y opciones para buscar en otros addons desde EspaDaily."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="busqueda_otros_addons_menu"), listitem=li, isFolder=True)

    # Personalizar atajos de búsqueda
    li = xbmcgui.ListItem(label="Personalizar 'Donde buscar?'")
    li.setArt({'icon': _mi('url_config.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Añade, elimina o reordena los atajos que aparecen en el diálogo de búsqueda externa. Puedes añadir addons instalados, comandos personalizados o favoritos de Kodi."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ssm_menu"), listitem=li, isFolder=True)


    # 2. Debug
    if _is_debug_active():
        li = xbmcgui.ListItem(label="Modo Debug: [COLOR green]ACTIVADO[/COLOR]")
    else:
        li = xbmcgui.ListItem(label="Modo Debug: [COLOR red]DESACTIVADO[/COLOR]")
    li.setArt({'icon': _mi('adv_debug.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Activa el registro detallado de errores.\n\nPuedes generar un archivo de log interno para solucionar problemas. Puede ralentizar el addon."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_debug"), listitem=li, isFolder=False)

    # 2b. Dev Mode (solo visible con Debug activo)
    if _is_debug_active():
        dev_flag = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.dev_mode')
        is_dev = os.path.exists(dev_flag)
        if is_dev:
            dev_label = "   Modo Desarrollo: [COLOR green]ACTIVO[/COLOR]"
        else:
            dev_label = "   Modo Desarrollo: [COLOR grey]DESACTIVADO[/COLOR]"
        li = xbmcgui.ListItem(label=dev_label)
        li.setArt({'icon': _mi('adv_devmode.png'), 'fanart': _fanart})
        li.setInfo('video', {'plot': "Protege los módulos internos del addon.\nCuando está ACTIVO, el addon no se actualiza desde internet.\n\nDesactivar para recibir actualizaciones normales."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_dev_mode"), listitem=li, isFolder=False)

    # 2c. Log y Diagnóstico
    li = xbmcgui.ListItem(label="Log y Diagnóstico")
    li.setArt({'icon': _mi('adv_log.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Herramientas para ver y analizar el log de Kodi y del addon.\nFiltrar errores, buscar entradas, ver tamaño, etc."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="log_menu"), listitem=li, isFolder=True)

    # 3. Control de Caché (3 Estados)
    cmode = _get_cache_mode()
    if cmode == 0:
        label = "Caché: [COLOR grey]APAGADO (Estándar)[/COLOR]"
        plot = "MODO CLÁSICO (Por Defecto): El addon no guarda nada en el disco. Siempre descarga la información fresca de internet.\n\nEs el comportamiento original de Kodi. Más lento pero ahorra espacio."
    elif cmode == 1:
        label = "Caché: [COLOR yellow]GRABANDO (Segundo Plano)[/COLOR]"
        plot = "MODO PREPARACIÓN: El addon descarga de internet pero va guardando una copia en el disco silenciosamente.\n\nÚtil para ir construyendo tu librería local antes de activar el modo rápido."
    else:
        label = "Caché: [COLOR cyan]ACTIVADO (Híbrido)[/COLOR]"
        plot = "MODO ULTRA RÁPIDO: Carga los menús desde el disco al instante.\n\nSolo conecta a internet si es algo nuevo. Es la mejor experiencia de usuario."

    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': _mi('adv_cache.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_frozen"), listitem=li, isFolder=False)
        

    # 5. Orden y duración de resultados (submenú)
    li = xbmcgui.ListItem(label="Orden y duración de resultados")
    li.setArt({'icon': _mi('adv_priorizar.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Cómo se ordenan y filtran los resultados de Dailymotion: vídeos largos "
                                 "primero al abrir un programa de un catálogo, parecido o duración, ocultar "
                                 "clips cortos, recientes primero y exigir el número de capítulo o todas las "
                                 "palabras.\n\nLo mismo está en la pestaña Dailymotion de los ajustes del addon."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_order_menu"), listitem=li, isFolder=True)


    # 8b. Copias de Seguridad
    li = xbmcgui.ListItem(label="Copias de Seguridad")
    li.setArt({'icon': _mi('adv_backup.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Crea, restaura e importa copias ZIP de todos los datos del addon.\nHistorial, favoritos, categorías, instantáneas, configuración y más."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="backups_menu"), listitem=li, isFolder=True)

    # 8c. Ruta de Descargas
    dm_cfg = _load_dm_settings()
    d_path = dm_cfg.get('download_path', '')
    dl_label = "Ruta de Descargas: [COLOR green]{0}[/COLOR]".format(d_path) if d_path else "Ruta de Descargas: [COLOR grey]NO CONFIGURADA[/COLOR]"
    li = xbmcgui.ListItem(label=dl_label)
    li.setArt({'icon': _mi('adv_ruta_dl.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Selecciona la carpeta donde se guardarán los vídeos descargados."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="set_download_path"), listitem=li, isFolder=False)
    
    # 8d. Modo Anti-Errores Dailymotion (4 niveles)
    dm_level = dm_cfg.get('dm_safe_level', 0)
    if dm_level == 0:
        dm_label = "Modo Anti-Errores DM: [COLOR grey]DESACTIVADO[/COLOR]"
    elif dm_level == 1:
        dm_label = "Modo Anti-Errores DM: [COLOR green]BÁSICO[/COLOR]"
    elif dm_level == 2:
        dm_label = "Modo Anti-Errores DM: [COLOR gold]EXTREMO[/COLOR]"
    elif dm_level == 3:
        dm_label = "Modo Anti-Errores DM: [COLOR cyan]YT-DLP[/COLOR]"
    else:
        dm_label = "Modo Anti-Errores DM: [COLOR orange]ISA[/COLOR]"
    dm_plot = (
        "MODO ANTI-ERRORES DAILYMOTION:\n\n"
        "[B]DESACTIVADO:[/B] Conexión normal de EspaDaily.\n"
        "[B]BÁSICO:[/B] Simula teléfono móvil Android.\n"
        "[B]EXTREMO:[/B] Técnicas avanzadas (Subtítulos, Verificación de enlaces, etc).\n"
        "[B]YT-DLP:[/B] Usa yt-dlp. Recomendado en Windows donde el CDN bloquea Kodi.\n"
        "[B]ISA:[/B] inputstream.adaptive con headers Dailymotion. Prueba si falla sin VPN.\n\n"
        "[I]Pulsa para cambiar el nivel.[/I]"
    )
    li = xbmcgui.ListItem(label=dm_label)
    li.setArt({'icon': _mi('adv_anti_errores.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': dm_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="set_dm_safe_level"), listitem=li, isFolder=False)

    # 8d-bis. Listas de Dailymotion
    li = xbmcgui.ListItem(label="Listas de Dailymotion")
    li.setArt({'icon': _mi('adv_anti_errores.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Qué vídeos de Dailymotion se ocultan de las listas porque no se pueden "
                                 "ver (retirados, privados y directos que no están emitiendo) y si las "
                                 "búsquedas se rellenan con más resultados.\n\n"
                                 "Son los mismos ajustes que la pestaña Dailymotion de los ajustes del addon."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="dm_listas_menu"), listitem=li, isFolder=True)

    # Anti-Errores IPTV
    if core_settings.is_iptv_anti_errors_active():
        iptv_ae_label = "Anti-Errores IPTV: [COLOR green]ACTIVADO[/COLOR]"
        iptv_ae_plot = "MODO ANTI-ERRORES IPTV: ACTIVADO\n\nInyecta automáticamente un User-Agent de navegador en los streams IPTV/M3U que no tienen uno propio.\nEvita errores de reproducción en canales que bloquean clientes sin User-Agent.\n\n[COLOR blue][I]Pulsa para desactivar[/I][/COLOR]"
    else:
        iptv_ae_label = "Anti-Errores IPTV: [COLOR grey]DESACTIVADO[/COLOR]"
        iptv_ae_plot = "MODO ANTI-ERRORES IPTV: DESACTIVADO\n\nSi los canales IPTV fallan con 'Playback failed', activa este modo para inyectar un User-Agent de navegador automáticamente.\n\n[COLOR blue][I]Pulsa para activar[/I][/COLOR]"
    li = xbmcgui.ListItem(label=iptv_ae_label)
    li.setArt({'icon': _mi('adv_anti_errores_iptv.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': iptv_ae_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_iptv_anti_errors"), listitem=li, isFolder=False)

    # Fanart de fondo
    _fa_mode = core_settings.get_fanart_mode()
    if core_settings.is_fanart_disabled() or _fa_mode == 'disabled':
        _fa_tag = _FANART_MODE_TAGS['disabled']
    else:
        _fa_tag = _FANART_MODE_TAGS.get(_fa_mode, _fa_mode)
    li = xbmcgui.ListItem(label=f'Fanart de fondo:  {_fa_tag}')
    li.setArt({'icon': _mi('adv_fanart.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': 'Controla la imagen de fondo de los menús: usa la del addon, una imagen tuya o desactívala.'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action='fanart_menu'), listitem=li, isFolder=True)

    # Motor TDT (InputStream Adaptive vs Nativo)
    if core_settings.is_tdt_inputstream_active():
        tdt_eng_label = "Motor TDT: [COLOR green]INPUTSTREAM ADAPTIVE[/COLOR]"
        tdt_eng_plot = (
            "MOTOR TDT: INPUTSTREAM ADAPTIVE\n\n"
            "Usa el motor InputStream Adaptive para reproducir streams M3U8.\n"
            "Permite pausar el directo (TimeShift) y mejora la reconexion de red.\n\n"
            "[B]AVISO:[/B] Requiere el addon 'inputstream.adaptive' instalado en Kodi.\n\n"
            "[COLOR blue][I]Pulsa para volver al motor NATIVO[/I][/COLOR]"
        )
    else:
        tdt_eng_label = "Motor TDT: [COLOR grey]NATIVO (Por defecto)[/COLOR]"
        tdt_eng_plot = (
            "MOTOR TDT: NATIVO\n\n"
            "Usa el reproductor nativo de Kodi para los canales TDT/IPTV M3U8.\n"
            "Compatible con todos los sistemas. El directo no se puede pausar.\n\n"
            "[COLOR blue][I]Pulsa para activar INPUTSTREAM ADAPTIVE[/I][/COLOR]"
        )
    li = xbmcgui.ListItem(label=tdt_eng_label)
    li.setArt({'icon': _mi('adv_motor_tdt.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': tdt_eng_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_tdt_inputstream"), listitem=li, isFolder=False)

    # 8e. Modo de Descarga
    dl_mode = dm_cfg.get('dl_mode', 0)
    if dl_mode == 0:
        d_mode_txt = "[COLOR grey]DIRECTO (Normal)[/COLOR]"
    elif dl_mode == 1:
        d_mode_txt = "[COLOR green]SAFE MODE (Gujal)[/COLOR]"
    elif dl_mode == 2:
        d_mode_txt = "[COLOR gold]MODO ESPADAILY (HLS Process)[/COLOR]"
    elif dl_mode == 3:
        d_mode_txt = "[COLOR cyan]YT-DLP (Externo)[/COLOR]"
    else:
        d_mode_txt = "[COLOR magenta]ULTRA (Multi-hilo HLS+)[/COLOR]"
        
    dl_s_label = f"Modo de Descarga: {d_mode_txt}"
    dl_s_plot = (
        "MODO DE DESCARGA:\n\n"
        "[B]DIRECTO:[/B] Muestra menú para elegir calidad.\n"
        "[B]SAFE MODE:[/B] Descarga el mejor MP4 directo.\n"
        "[B]ESPADAILY:[/B] Descarga por segmentos HLS.\n"
        "[B]YT-DLP:[/B] Usa yt-dlp (mejor calidad). Requiere Python 3.10+.\n"
        "[B]ULTRA:[/B] Igual que YT-DLP (mejor calidad). Recomendado en PC."
    )
    li = xbmcgui.ListItem(label=dl_s_label)
    li.setArt({'icon': _mi('adv_modo_dl.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': dl_s_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="set_dl_mode"), listitem=li, isFolder=False)

    # 8f. Estado del Repositorio
    _repo_id = "repository.espadaily"
    _repo_installed = xbmc.getCondVisibility(f"System.HasAddon({_repo_id})")
    if _repo_installed:
        repo_label = "Repositorio: [COLOR green]INSTALADO[/COLOR]"
        repo_plot = (
            "El repositorio de EspaDaily está correctamente instalado.\n\n"
            "El addon se actualizará automáticamente cuando haya nuevas versiones disponibles.\n\n"
            "[I]No necesitas hacer nada más.[/I]"
        )
    else:
        repo_label = "Repositorio: [COLOR red]NO INSTALADO[/COLOR]"
        repo_plot = (
            "[COLOR red][B]¡ATENCIÓN![/B][/COLOR] El repositorio NO está instalado.\n\n"
            "Sin el repositorio, el addon [B]NO se actualizará automáticamente[/B]. "
            "Tendrás que instalar cada nueva versión manualmente.\n\n"
            "[COLOR yellow][B]INSTRUCCIONES PARA INSTALAR:[/B][/COLOR]\n\n"
            "1. Ve a Ajustes > Gestor de Archivos > Añadir fuente\n"
            "2. Escribe: https://fullstackcurso.github.io/espadaily/\n"
            "3. Ponle de nombre: espadaily\n"
            "4. Ve a Addons > Instalar desde un archivo ZIP\n"
            "5. Selecciona la fuente 'espadaily'\n"
            "6. Instala repository.espadaily-x.x.x.zip\n\n"
            "Una vez instalado, las actualizaciones serán automáticas.\n\n"
            "[I]Pulsa para ver las instrucciones en pantalla completa.[/I]"
        )
    li = xbmcgui.ListItem(label=repo_label)
    li.setArt({'icon': _mi('info_repo.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': repo_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="check_repo_status"), listitem=li, isFolder=False)

    # Colores del menú principal
    tint_mode = core_settings.get_menu_icon_tint_mode()
    tint_estado = "[COLOR limegreen]ACTIVADOS[/COLOR]" if tint_mode == 'text' else "[COLOR grey]DESACTIVADOS[/COLOR]"
    li = xbmcgui.ListItem(label=f"Colores del menú principal: {tint_estado}")
    li.setArt({'icon': _mi('adv_color_menu.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': """\
Controla si el texto del menú principal lleva colores o aparece en blanco.

● [COLOR grey]Desactivado[/COLOR]: texto blanco, limpio. Opción por defecto.

● [COLOR limegreen]Activado[/COLOR]: cada botón del menú lleva su color propio.

[COLOR blue][I]Pulsa para activar o desactivar.[/I][/COLOR]"""})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="acc_toggle_icon_tint"), listitem=li, isFolder=False)

    # Accesibilidad
    li = xbmcgui.ListItem(label="Accesibilidad")
    li.setArt({'icon': _mi('adv_accesibilidad.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Opciones de accesibilidad visual: modo de color, negrita forzada y sustitucion de simbolos.\n\nAdapta la apariencia del addon para distintas necesidades visuales (daltonismo, alto contraste, etc.)."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="accessibility_menu"), listitem=li, isFolder=True)

    # 8g. Limpieza (caches, almacenamiento y mantenimiento)
    li = xbmcgui.ListItem(label="Limpieza")
    li.setArt({'icon': _mi('adv_limpieza.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Opciones de limpieza del addon, almacenamiento y mantenimiento general de Kodi."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="limpieza_menu"), listitem=li, isFolder=True)

    # Inicio automático
    li = xbmcgui.ListItem(label="Inicio automático de addons")
    li.setArt({'icon': _mi('adv_autostart.png') or 'DefaultAddonService.png', 'fanart': _fanart})
    li.setInfo('video', {'plot': "Configura hasta 3 addons que se abriran automaticamente al arrancar Kodi."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="autostart_menu"), listitem=li, isFolder=True)

    # Inicio automático de favoritos
    li = xbmcgui.ListItem(label="Inicio automático de favoritos")
    li.setArt({'icon': _mi('adv_autostart.png') or 'DefaultAddonService.png', 'fanart': _fanart})
    li.setInfo('video', {'plot': "Configura hasta 3 favoritos de Kodi que se abrirán automáticamente al arrancar."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="autofav_menu"), listitem=li, isFolder=True)

    # Arrancar WebApp al iniciar
    webapp_on = xbmcaddon.Addon().getSetting('webapp_autostart') == 'true'
    webapp_estado = "[COLOR limegreen]ACTIVADO[/COLOR]" if webapp_on else "[COLOR grey]DESACTIVADO[/COLOR]"
    li = xbmcgui.ListItem(label=f"Arrancar WebApp al iniciar: {webapp_estado}")
    li.setArt({'icon': _mi('webapp_autostart.png') or 'DefaultAddonService.png', 'fanart': _fanart})
    li.setInfo('video', {'plot': "Al arrancar Kodi, levanta el servidor de la WebApp de EspaDaily y abre el navegador, sin tener que entrar al menú Experimental.\n\nPulsa para activar o desactivar."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_webapp_autostart"), listitem=li, isFolder=False)
    _webapp_estado_items(_fanart)

    # Modo Vintage CRT
    li = xbmcgui.ListItem(label="Modo Televisión Vintage (CRT)")
    li.setArt({'icon': _mi('crt_tv.png') or 'DefaultAddonProgram.png', 'fanart': _fanart})
    li.setInfo('video', {'plot': "Filtro estético que simula una televisión de tubo (CRT) antigua sobre el video: líneas de barrido, viñeta, marco curvo, tinte cálido, grano, barra de desincronización y parpadeo."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="crt_config_menu"), listitem=li, isFolder=True)

    # Minijuegos
    li = xbmcgui.ListItem(label=ui_utils.punto('minijuegos') + "Minijuegos")
    li.setArt({'icon': _mi('adv_minijuegos.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': (
        "Ajustes de los catorce minijuegos que esconden los separadores de los menús: el nivel de "
        "dificultad, los mandos en pantalla, el disparo automático en naves, el contador de "
        "rendimiento y borrar récords. Lo mismo está en la pestaña Minijuegos de los ajustes del addon."
    )})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="minijuegos_menu"), listitem=li, isFolder=True)

    # Añadir secciones a Favoritos de Kodi
    li = xbmcgui.ListItem(label="Añadir secciones a Favoritos de Kodi")
    li.setArt({'icon': _mi('favoritos.png') or 'DefaultFavourite.png', 'fanart': _fanart})
    li.setInfo('video', {'plot': "Añade las secciones del menú principal (TV en Directo, Explorar, Buscar, etc.) a los favoritos nativos de Kodi para acceder directamente desde el menú principal de Kodi."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="add_sections_to_kodi_favs"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def _add_sections_to_kodi_favs():
    sections = [
        ("TV en Directo",    "live_tv_menu",    'directo.png'),
        ("Explorar",         "catalog_menu",    'explorar.png'),
        ("Buscar en internet","manual_search",  'busqueda.png'),
        ("Abrir URL",        "open_url",        'url.png'),
        ("loiolink",         "loiolink_launch", 'loiolink.png'),
        ("Experimental",     "experimental_menu",'experimental.png'),
        ("Historial",        "history_menu",    'historial.png'),
        ("Mis Favoritos",    "show_favorites",  'favoritos.png'),
        ("Mis Descargas",    "show_downloads",  'descargas.png'),
        ("Opciones",         "advanced_menu",   'opciones.png'),
    ]
    labels = [s[0] for s in sections]
    selected = xbmcgui.Dialog().multiselect("Añadir a Favoritos de Kodi", labels)
    if not selected:
        return
    _addon_path = _get_addon_path()
    _med = os.path.join(_addon_path, 'resources', 'media')
    _fav_path = xbmcvfs.translatePath('special://masterprofile/favourites.xml')
    new_entries = []
    for idx in selected:
        if idx < 0 or idx >= len(sections):
            continue
        title, action, icon = sections[idx]
        thumb = os.path.join(_med, icon).replace('\\', '/')
        url = _u(action=action)
        command = 'ActivateWindow(10025,"{0}",return)'.format(url)
        new_entries.append((title, thumb, command))
    if not new_entries:
        return
    try:
        with open(_fav_path, 'r', encoding='utf-8') as f:
            raw = f.read().strip()
    except FileNotFoundError:
        raw = '<favourites>\n</favourites>'
    except Exception as e:
        xbmc.log(f"[EspaDaily] _add_sections_to_kodi_favs: error leyendo favourites.xml: {e}", xbmc.LOGWARNING)
        xbmcgui.Dialog().notification("EspaDaily", "Error al leer favourites.xml", xbmcgui.NOTIFICATION_ERROR)
        return
    lines = raw.splitlines()
    insert_idx = None
    for i in range(len(lines) - 1, -1, -1):
        if '</favourites>' in lines[i]:
            insert_idx = i
            break
    if insert_idx is None:
        xbmcgui.Dialog().notification("EspaDaily", "favourites.xml corrupto", xbmcgui.NOTIFICATION_ERROR)
        return
    # Eliminar entradas antiguas (mismo nombre) para reemplazar formato PlayMedia -> ActivateWindow
    selected_titles = {t for t, _, _ in new_entries}
    cleaned = []
    removed = 0
    for line in lines:
        m = re.search(r'<favourite\s+name="([^"]*)"', line)
        if m and m.group(1) in selected_titles:
            removed += 1
            continue
        cleaned.append(line)
    added = 0
    indent = '    '
    for title, thumb, command in new_entries:
        esc_title = title.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;').replace("'", '&apos;')
        esc_thumb = thumb.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')
        esc_cmd = command.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')
        cleaned.append('{0}<favourite name="{1}" thumb="{2}">{3}</favourite>'.format(indent, esc_title, esc_thumb, esc_cmd))
        added += 1
    new_raw = '\n'.join(cleaned) + '\n'
    try:
        with open(_fav_path, 'w', encoding='utf-8') as f:
            f.write(new_raw)
    except Exception as e:
        xbmc.log(f"[EspaDaily] _add_sections_to_kodi_favs: error escribiendo favourites.xml: {e}", xbmc.LOGWARNING)
        xbmcgui.Dialog().notification("EspaDaily", "Error al escribir favourites.xml", xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification("EspaDaily", f"Secciones anadidas a Favoritos de Kodi ({added})", xbmcgui.NOTIFICATION_INFO)
    xbmc.log(f"[EspaDaily] Anadidas {added} secciones a favourites.xml (eliminadas {removed} antiguas)", xbmc.LOGINFO)


def _acc_set_color_mode():
    modes = list(_ACC_COLOR_NAMES.keys())
    current = core_settings.get_acc_color_mode()
    idx = modes.index(current) if current in modes else 0
    chosen = xbmcgui.Dialog().select("Modo de color", list(_ACC_COLOR_NAMES.values()), preselect=idx)
    if chosen < 0:
        return
    core_settings.set_acc_color_mode(modes[chosen])
    xbmcgui.Dialog().notification("Accesibilidad", "Modo de color guardado. Reinicia Kodi para ver los cambios.", xbmcgui.NOTIFICATION_INFO, 4000)
    xbmc.executebuiltin("Container.Refresh")

def _acc_toggle_bold():
    new_val = not core_settings.get_acc_force_bold()
    core_settings.set_acc_force_bold(new_val)
    msg = "ACTIVADA" if new_val else "DESACTIVADA"
    xbmcgui.Dialog().notification("Accesibilidad", f"Negrita {msg}. Reinicia Kodi para ver los cambios.", xbmcgui.NOTIFICATION_INFO, 4000)
    xbmc.executebuiltin("Container.Refresh")

def _acc_toggle_symbols():
    new_val = not core_settings.get_acc_strip_symbols()
    core_settings.set_acc_strip_symbols(new_val)
    msg = "ACTIVADA" if new_val else "DESACTIVADA"
    xbmcgui.Dialog().notification("Accesibilidad", f"Sustitucion de simbolos {msg}. Reinicia Kodi para ver los cambios.", xbmcgui.NOTIFICATION_INFO, 4000)
    xbmc.executebuiltin("Container.Refresh")

def _acc_toggle_icon_tint():
    """Alterna los colores del menú principal activando o desactivando menu_colors_enabled."""
    addon = xbmcaddon.Addon()
    current = addon.getSetting('menu_colors_enabled') == 'true'
    addon.setSetting('menu_colors_enabled', 'false' if current else 'true')
    msg = "Colores del menú principal desactivados." if current else "Colores del menú principal activados."
    xbmcgui.Dialog().notification("Accesibilidad", msg, xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin("Container.Refresh")

def accessibility_menu():
    h = int(sys.argv[1])
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)
    _fanart = core_settings.addon_fanart()

    color_mode = core_settings.get_acc_color_mode()
    bold_on    = core_settings.get_acc_force_bold()
    strip_sym  = core_settings.get_acc_strip_symbols()

    color_name = _ACC_COLOR_NAMES.get(color_mode, color_mode)
    color_tag  = "[COLOR green]" if color_mode != 'none' else "[COLOR grey]"
    li = xbmcgui.ListItem(label=f"Modo de color: {color_tag}{color_name}[/COLOR]")
    li.setArt({'icon': _mi('adv_idioma.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': _ACC_COLOR_PLOTS.get(color_mode, "") + "\n\n[COLOR blue][I]Pulsa para cambiar el modo de color.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="acc_set_color"), listitem=li, isFolder=False)

    bold_tag = "[COLOR green]ACTIVADA[/COLOR]" if bold_on else "[COLOR red]DESACTIVADA[/COLOR]"
    li = xbmcgui.ListItem(label=f"Negrita forzada: {bold_tag}")
    li.setArt({'icon': _mi('adv_idioma.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Muestra todos los textos de los botones en negrita.\n\n[COLOR blue][I]Pulsa para activar/desactivar. Reinicia Kodi para ver los cambios.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="acc_toggle_bold"), listitem=li, isFolder=False)

    sym_tag = "[COLOR green]ACTIVADA[/COLOR]" if strip_sym else "[COLOR grey]DESACTIVADA[/COLOR]"
    li = xbmcgui.ListItem(label=f"Sustitucion de simbolos especiales: {sym_tag}")
    li.setArt({'icon': _mi('adv_idioma.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Reemplaza caracteres Unicode especiales (★ ● ▲ ▼ etc.) por equivalentes ASCII (* ^ v).\nUtil si tu skin no muestra correctamente estos caracteres.\n\n[COLOR blue][I]Pulsa para activar/desactivar. Reinicia Kodi para ver los cambios.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="acc_toggle_symbols"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def _check_repo_status():
    """Muestra el estado del repositorio y ofrece instalación si falta."""
    _repo_id = "repository.espadaily"
    installed = xbmc.getCondVisibility(f"System.HasAddon({_repo_id})")

    if not installed:
        # Deep scan: detecta el repo aunque esté deshabilitado o la carpeta tenga otro nombre
        try:
            import xml.etree.ElementTree as ET
            addons_path = xbmcvfs.translatePath("special://home/addons/")
            dirs, _ = xbmcvfs.listdir(addons_path)
            for d in dirs:
                if "repository" not in d.lower() and "espadaily" not in d.lower():
                    continue
                xml_vfs = f"special://home/addons/{d}/addon.xml"
                if not xbmcvfs.exists(xml_vfs):
                    continue
                try:
                    vf = xbmcvfs.File(xml_vfs)
                    content = vf.read()
                    vf.close()
                    root = ET.fromstring(content)
                    if root.attrib.get('id', '') == _repo_id:
                        installed = True
                        _enable_repo_addon(_repo_id)
                        break
                except Exception:
                    continue
        except Exception as e:
            xbmc.log(f"[EspaDaily] Deep scan repo: {e}", xbmc.LOGWARNING)

    if installed:
        xbmcgui.Dialog().ok(
            "Estado del Repositorio",
            "[COLOR green][B]● INSTALADO Y ACTIVO[/B][/COLOR]\n\n"
            "El repositorio oficial está configurado correctamente.\n\n"
            "El addon se actualizará automáticamente cuando haya nuevas versiones disponibles."
        )
    else:
        if xbmcgui.Dialog().yesno(
            "Repositorio No Detectado",
            "Para recibir mejoras y actualizaciones automáticas, es necesario\n"
            "instalar el repositorio oficial de EspaDaily.\n\n"
            "¿Deseas instalarlo ahora mismo?"
        ):
            _install_espadaily_repo()


def _enable_repo_addon(repo_id):
    """Habilita el addon vía JSON-RPC con 5 reintentos (UpdateLocalAddons es asíncrono)."""
    import json as _json
    payload = _json.dumps({"jsonrpc": "2.0", "method": "Addons.SetAddonEnabled",
                           "params": {"addonid": repo_id, "enabled": True}, "id": 1})
    for _ in range(5):
        response = xbmc.executeJSONRPC(payload)
        if '"error"' not in response:
            return
        xbmc.sleep(1000)


def _vfs_rmtree(path):
    """Eliminación recursiva VFS."""
    if not path.endswith('/'):
        path += '/'
    dirs, files = xbmcvfs.listdir(path)
    for f in files:
        xbmcvfs.delete(f"{path}{f}")
    for d in dirs:
        _vfs_rmtree(f"{path}{d}")
    xbmcvfs.rmdir(path)


def _repo_manual_instructions():
    xbmcgui.Dialog().ok(
        "Instalación Manual",
        "Añade esta fuente en Ajustes > Gestor de Archivos:\n\n"
        "[B][COLOR yellow]https://fullstackcurso.github.io/espadaily/[/COLOR][/B]\n\n"
        "Luego ve a Addons > Instalar desde un archivo ZIP\n"
        "y selecciona repository.espadaily-x.x.x.zip"
    )


_REPO_ICON_URL = "https://raw.githubusercontent.com/fullstackcurso/espadaily/main/plugin.video.espadaily/icon.png"
_PNG_MAGIC = b'\x89PNG\r\n\x1a\n'


def _download_repo_icon(dest_vfs):
    """Descarga icon.png del repositorio y lo escribe via VFS. No lanza excepciones."""
    try:
        import requests as _req
        r = _req.get(_REPO_ICON_URL, timeout=10)
        if r.status_code != 200:
            xbmc.log(f"[EspaDaily] Icono repo: HTTP {r.status_code}", xbmc.LOGWARNING)
            return False
        content = r.content
        # Validar que es un PNG real (magic bytes) y tamaño mínimo razonable
        if len(content) < 67 or not content.startswith(_PNG_MAGIC):
            xbmc.log("[EspaDaily] Icono repo: respuesta no es un PNG válido", xbmc.LOGWARNING)
            return False
        icon_path = dest_vfs.rstrip('/') + '/icon.png'
        v_file = xbmcvfs.File(icon_path, 'wb')
        ok = v_file.write(bytearray(content))
        v_file.close()
        if ok is False:
            xbmc.log("[EspaDaily] Icono repo: VFS write devolvió False", xbmc.LOGWARNING)
            return False
        return True
    except Exception as e:
        xbmc.log(f"[EspaDaily] Icono repo: excepción ignorada - {e}", xbmc.LOGWARNING)
        return False


def _install_espadaily_repo():
    """Instala el repositorio oficial: Capa 1 local → Capa 2 remota → Capa 3 manual."""
    _REPO_ID = "repository.espadaily"
    _DEST_VFS = f"special://home/addons/{_REPO_ID}"

    # CAPA 1: Instalación local desde recursos embebidos
    addon_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
    src_os = os.path.join(addon_path, "resources", _REPO_ID)
    if os.path.exists(src_os):
        try:
            if xbmcvfs.exists(_DEST_VFS):
                _vfs_rmtree(_DEST_VFS)
            xbmcvfs.mkdirs(_DEST_VFS + '/')
            for item in os.listdir(src_os):
                with open(os.path.join(src_os, item), 'rb') as fh:
                    content = fh.read()
                v_file = xbmcvfs.File(f"{_DEST_VFS}/{item}", 'wb')
                ok = v_file.write(content)
                v_file.close()
                if ok is False and len(content) > 0:
                    raise IOError(f"VFS write falló en {item}")
            _download_repo_icon(_DEST_VFS)
            xbmc.executebuiltin("UpdateLocalAddons()")
            xbmc.sleep(500)
            xbmc.executebuiltin(f"InstallAddon({_REPO_ID})")
            _enable_repo_addon(_REPO_ID)
            xbmcgui.Dialog().notification("EspaDaily", "Repositorio instalado con éxito", xbmcgui.NOTIFICATION_INFO, 3000)
            xbmc.executebuiltin("Container.Refresh")
            return
        except Exception as e:
            xbmc.log(f"[EspaDaily] Instalación local falló: {e}", xbmc.LOGWARNING)
            try:
                if xbmcvfs.exists(_DEST_VFS):
                    _vfs_rmtree(_DEST_VFS)
            except Exception:
                pass

    # CAPA 2: Descarga remota
    if not xbmcgui.Dialog().yesno(
        "Instalación local fallida",
        "La instalación local falló (restricciones del dispositivo).\n\n"
        "¿Deseas descargarlo directamente desde el servidor oficial?"
    ):
        _repo_manual_instructions()
        return

    _REPO_URL = "https://fullstackcurso.github.io/espadaily/repository.espadaily-1.0.0.zip"
    zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"), "espadaily_repo.zip")
    dp = xbmcgui.DialogProgress()
    dp.create("EspaDaily", "Preparando descarga...")
    try:
        import requests as _req, zipfile as _zf
        dp.update(10, "Descargando repositorio...")
        r = _req.get(_REPO_URL, stream=True, timeout=30)
        if r.status_code != 200:
            raise IOError(f"Error HTTP {r.status_code}")
        total = int(r.headers.get("content-length", 0))
        downloaded = 0
        with open(zip_path, "wb") as fh:
            for chunk in r.iter_content(chunk_size=65536):
                if dp.iscanceled():
                    dp.close()
                    return
                if chunk:
                    fh.write(chunk)
                    downloaded += len(chunk)
                    if total:
                        dp.update(10 + int(downloaded / total * 60), "Descargando repositorio...")
        dp.update(75, "Instalando en Kodi (VFS)...")
        with _zf.ZipFile(zip_path, "r") as zf:
            for member in zf.infolist():
                if member.is_dir():
                    continue
                # Por VFS se escribe donde diga el nombre de la entrada, y ahí no limpia nada
                # como extractall(). Se descarta lo que saldría de addons/.
                partes = member.filename.replace('\\', '/').split('/')
                if member.filename.startswith(('/', '\\')) or ':' in partes[0] or '..' in partes:
                    raise IOError(f"Entrada no válida en el zip: {member.filename}")
                vfs_dest = f"special://home/addons/{member.filename}"
                parent_dir = "special://home/addons/" + "/".join(member.filename.split("/")[:-1])
                if parent_dir and not xbmcvfs.exists(parent_dir):
                    xbmcvfs.mkdirs(parent_dir)
                content = zf.read(member)
                v_file = xbmcvfs.File(vfs_dest, "wb")
                ok = v_file.write(content)
                v_file.close()
                if ok is False and len(content) > 0:
                    raise IOError(f"VFS write falló en {vfs_dest}")
        dp.update(90, "Descargando icono...")
        _download_repo_icon(_DEST_VFS)
        dp.update(95, "Activando repositorio...")
        xbmc.executebuiltin("UpdateLocalAddons()")
        xbmc.sleep(1000)
        xbmc.executebuiltin(f"InstallAddon({_REPO_ID})")
        _enable_repo_addon(_REPO_ID)
        dp.update(100)
        dp.close()
        xbmcgui.Dialog().notification("EspaDaily", "Repositorio instalado con éxito", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        dp.close()
        xbmc.log(f"[EspaDaily] Descarga remota falló: {e}", xbmc.LOGERROR)
        try:
            if xbmcvfs.exists(_DEST_VFS):
                _vfs_rmtree(_DEST_VFS)
        except Exception:
            pass
        _repo_manual_instructions()
    finally:
        if os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except Exception:
                pass


def _toggle_dev_mode():
    """Activa o desactiva el modo desarrollo creando/eliminando .dev_mode."""
    dev_flag = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.dev_mode')
    if os.path.exists(dev_flag):
        try:
            os.remove(dev_flag)
            xbmcgui.Dialog().notification("EspaDaily", "Modo Desarrollo DESACTIVADO", xbmcgui.NOTIFICATION_INFO)
        except Exception as e:
            xbmcgui.Dialog().ok("Error", "No se pudo desactivar: {0}".format(e))
    else:
        try:
            with open(dev_flag, 'w') as f:
                f.write('dev')
            xbmcgui.Dialog().notification("EspaDaily", "Modo Desarrollo ACTIVO", xbmcgui.NOTIFICATION_WARNING)
        except Exception as e:
            xbmcgui.Dialog().ok("Error", "No se pudo activar: {0}".format(e))
    xbmc.executebuiltin("Container.Refresh")

def _get_debug_state_file():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, 'debug_state.json')

def _is_debug_active():
    f = _get_debug_state_file()
    if not os.path.exists(f): return False
    try:
        with open(f, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False

def _toggle_debug():
    new_state = not _is_debug_active()
    
    # Advertencia de seguridad SIEMPRE (tanto al activar como al desactivar)
    action_str = "activar" if new_state else "desactivar"
    if not xbmcgui.Dialog().yesno("ADVERTENCIA DE SEGURIDAD", 
        f"[COLOR red]ALERTA:[/COLOR] Vas a {action_str} el Modo Debug.\n\n"
        "Si no sabes lo que estás haciendo, esto podría causar errores o inestabilidad en el addon.\n"
        "¿Estás seguro de continuar?"):
        return


    log_to_file = False
    if new_state:
        if xbmcgui.Dialog().yesno("Generar Log de Errores", 
            "¿Quieres generar un archivo LOG en la raíz del addon con los errores del addon?\n\n"
            "Esto creará 'espadaily_errors.log' en la carpeta del plugin."):
            log_to_file = True
            # Crear archivo con cabecera
            try:
                base_dir = os.path.dirname(os.path.abspath(__file__))
                log_file = os.path.join(base_dir, 'espadaily_errors.log')
                ts = time.strftime('%Y-%m-%d %H:%M:%S')
                with open(log_file, 'a', encoding='utf-8') as lf:
                    lf.write(f"[{ts}] --- INICIO DE SESIÓN DE DEBUG ---\n")
            except Exception: pass
    else:
        # Desactivando: Borrar archivo de log
        try:
            base_dir = os.path.dirname(os.path.abspath(__file__))
            log_file = os.path.join(base_dir, 'espadaily_errors.log')
            if os.path.exists(log_file):
                os.remove(log_file)
        except Exception: pass

    with open(_get_debug_state_file(), 'w', encoding='utf-8') as o: json.dump({'active': new_state, 'log_to_file': log_to_file}, o)
    
    msg = "ACTIVADO" if new_state else "DESACTIVADO"
    if log_to_file: msg += " (Con Log Propio)"
    xbmcgui.Dialog().notification("EspaDaily", f"Modo Debug {msg}", xbmcgui.NOTIFICATION_INFO)
    # Forzamos viaje al menu principal rompiendo la cache con un timestamp
    xbmc.executebuiltin(f"Container.Update({sys.argv[0]}?reload={int(time.time())}, replace)")

def _log_error(msg):
    xbmc.log(f"[EspaDaily ERROR] {msg}", xbmc.LOGERROR)
    try:
        f = _get_debug_state_file()
        if os.path.exists(f):
            with open(f, 'r', encoding='utf-8') as fh:
                st = json.load(fh)
            if st.get('active') and st.get('log_to_file'):
                base_dir = os.path.dirname(os.path.abspath(__file__))
                log_file = os.path.join(base_dir, 'espadaily_errors.log')
                ts = time.strftime('%Y-%m-%d %H:%M:%S')
                with open(log_file, 'a', encoding='utf-8') as lf:
                    lf.write(f"[{ts}] {msg}\n")
    except (OSError, ValueError):
        # El error ya está en el log de Kodi; el archivo de depuración es una copia.
        pass

def _view_error_log():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    log_file = os.path.join(base_dir, 'espadaily_errors.log')
    
    if not os.path.exists(log_file):
        xbmcgui.Dialog().ok("Error", "No existe el archivo de log.\nActiva el Modo Debug y genera errores primero.")
        return

    opts = ["Ver archivo completo", "Últimas 50 líneas", "Últimas 20 líneas", "Últimas 10 líneas"]
    sel = xbmcgui.Dialog().select("¿Qué deseas ver?", opts)
    if sel < 0: return
    
    try:
        with open(log_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            
        content = ""
        if not lines:
            content = "[El archivo está vacío]"
        else:
            if sel == 0: # Todo
                content = "".join(lines)
            elif sel == 1: # 50
                content = "".join(lines[-50:])
            elif sel == 2: # 20
                content = "".join(lines[-20:])
            elif sel == 3: # 10
                content = "".join(lines[-10:])
                
        xbmcgui.Dialog().textviewer("Log de Errores - EspaDaily", content)
    except Exception as e:
        xbmcgui.Dialog().ok("Error Leyendo Log", str(e))

def _get_frozen_state_file():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, 'frozen_state.json')

def _is_frozen_active():

    return _get_cache_mode() == 2

def _get_cache_mode():
    f = _get_frozen_state_file()
    if not os.path.exists(f): return 0 # Default OFF
    try:
        with open(f, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        # Migrar formato booleano antiguo
        val = data.get('active', 0)
        if val is True: return 2
        if val is False: return 0
        return int(val)
    except Exception: return 0

def _toggle_frozen():
    curr = _get_cache_mode()
    # Cycle: 0 -> 1 -> 2 -> 0
    new_mode = (curr + 1) % 3
    
    with open(_get_frozen_state_file(), 'w', encoding='utf-8') as o: json.dump({'active': new_mode}, o)
    
    if new_mode == 0:
        msg = "Caché APAGADA: Datos temporales eliminados"
        # Borrar caché API automáticamente al apagar
        _clear_api_cache_only()
    elif new_mode == 1:
        msg = "Caché: GRABANDO en segundo plano"
    else:
        msg = "Caché: HÍBRIDA (Ultra Rápida)"
        
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _clear_api_cache_only():
    # Solo borrar archivos en api_cache, preservar historial y ajustes
    try:
        cd = _get_cache_dir()
        if os.path.exists(cd):
            for f in os.listdir(cd):
                if f.endswith(".json"):
                    os.remove(os.path.join(cd, f))
    except OSError as e:
        xbmc.log(f"[EspaDaily] No se ha podido vaciar la caché de la API: {e}", xbmc.LOGWARNING)

def _toggle_prioritize_match():
    new_state = not core_settings.is_prioritize_match_active()
    core_settings.set_prioritize_match(new_state)
    msg = "MODO PRECISIÓN ACTIVADO" if new_state else "MODO DURACIÓN (ESTÁNDAR)"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_recent():
    new_state = not core_settings.is_recent_active()
    core_settings.set_recent_active(new_state)
    msg = "ORDEN RECIENTE ACTIVADO" if new_state else "ORDEN RELEVANCIA REINSTAURADO"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _set_min_duration_filter():
    opts = ["Desactivado", "Más de 2 min", "Más de 5 min", "Más de 10 min", "Más de 20 min (Solo Full)"]
    vals = [0, 2, 5, 10, 20]
    sel = xbmcgui.Dialog().select("Ocultar vídeos más cortos que...", opts)
    if sel < 0: return
    core_settings.set_min_duration(vals[sel])
    xbmc.executebuiltin("Container.Refresh")

def _toggle_iptv_anti_errors():
    new_state = not core_settings.is_iptv_anti_errors_active()
    core_settings.set_iptv_anti_errors(new_state)
    msg = "ACTIVADO" if new_state else "DESACTIVADO"
    xbmcgui.Dialog().notification("Anti-Errores IPTV", f"Modo Anti-Errores IPTV {msg}", xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_tdt_inputstream():
    new_state = not core_settings.is_tdt_inputstream_active()
    if new_state:
        if not ui_utils.addon_listo("inputstream.adaptive", "InputStream Adaptive",
                "Has activado InputStream Adaptive, pero el componente no está instalado en Kodi.\n\n"
                "Instala 'InputStream Adaptive' desde el repositorio oficial de Kodi antes de usar este modo."):
            return
    core_settings.set_tdt_inputstream(new_state)
    msg = "InputStream Adaptive ACTIVADO" if new_state else "Motor NATIVO restaurado"
    xbmcgui.Dialog().notification("Motor TDT", msg, xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_palantir_integration():
    new_state = not core_settings.is_palantir_integration_enabled()
    core_settings.set_palantir_integration_enabled(new_state)
    msg = "Buscar en Palantir 3: ACTIVADO" if new_state else "Buscar en Palantir 3: DESACTIVADO"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_balandro_integration():
    new_state = not core_settings.is_balandro_integration_enabled()
    core_settings.set_balandro_integration_enabled(new_state)

    if new_state:
        xbmcgui.Dialog().ok("Buscar en Balandro", "AVISO IMPORTANTE:\n\nEspaDaily NO está afiliado ni relacionado con el addon Balandro ni sus desarrolladores.\n\nEsta función es simplemente un ATAJO de búsqueda externa para facilitar la navegación.")

    msg = "Buscar en Balandro: ACTIVADO" if new_state else "Buscar en Balandro: DESACTIVADO"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_alfa_integration():
    new_state = not core_settings.is_alfa_integration_enabled()
    core_settings.set_alfa_integration_enabled(new_state)
    msg = "Buscar en Alfa: ACTIVADO" if new_state else "Buscar en Alfa: DESACTIVADO"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_jacktook_integration():
    new_state = not core_settings.is_jacktook_integration_enabled()
    core_settings.set_jacktook_integration_enabled(new_state)
    msg = "Buscar en Jacktook: ACTIVADO" if new_state else "Buscar en Jacktook: DESACTIVADO"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_atresdaily_integration():
    new_state = not core_settings.is_atresdaily_integration_enabled()
    core_settings.set_atresdaily_integration_enabled(new_state)
    msg = "Buscar en AtresDaily: ACTIVADO" if new_state else "Buscar en AtresDaily: DESACTIVADO"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_espatv_integration():
    new_state = not core_settings.is_espatv_integration_enabled()
    core_settings.set_espatv_integration_enabled(new_state)
    msg = "Buscar en EspaTV: ACTIVADO" if new_state else "Buscar en EspaTV: DESACTIVADO"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_topzilla_integration():
    new_state = not core_settings.is_topzilla_integration_enabled()
    core_settings.set_topzilla_integration_enabled(new_state)
    msg = "Buscar en TopZilla: ACTIVADO" if new_state else "Buscar en TopZilla: DESACTIVADO"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_tmdbhelper_integration():
    new_state = not core_settings.is_tmdbhelper_integration_enabled()
    core_settings.set_tmdbhelper_integration_enabled(new_state)
    msg = "Abrir en otro addon: ACTIVADO" if new_state else "Abrir en otro addon: DESACTIVADO"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_gujal_integration():
    current_state = xbmcaddon.Addon().getSetting('gujal_search_enabled') == 'true'
    new_state = not current_state
    xbmcaddon.Addon().setSetting('gujal_search_enabled', 'true' if new_state else 'false')
    msg = "Buscar en Dailymotion (Gujal): ACTIVADO" if new_state else "Buscar en Dailymotion (Gujal): DESACTIVADO"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_external_integrations():
    new_state = not core_settings.are_external_integrations_disabled()
    core_settings.set_external_integrations_disabled(new_state)
    msg = "Buscar en otros addons: DESACTIVADO" if new_state else "Buscar en otros addons: ACTIVADO"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_webapp_autostart():
    new_state = xbmcaddon.Addon().getSetting('webapp_autostart') != 'true'
    xbmcaddon.Addon().setSetting('webapp_autostart', 'true' if new_state else 'false')
    msg = "Arrancar WebApp al iniciar: ACTIVADO" if new_state else "Arrancar WebApp al iniciar: DESACTIVADO"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    if new_state and xbmcgui.Dialog().yesno("EspaDaily WebApp",
                                            "Se arrancará sola la próxima vez que abras Kodi.\n\n¿Arrancarla también ahora?"):
        _webapp_espa_open()
    xbmc.executebuiltin("Container.Refresh")


def _bi(context, title):
    return core_settings.build_query(title, context)

def _is_full_context_active():
    return core_settings.get_context_level() > 0

def _live_tv_grid_on():
    """True si 'TV en Directo' debe abrir el Modo TV (grid). Default: lista."""
    return xbmcaddon.Addon().getSetting('live_tv_grid_mode') == 'true'

def _get_context_level():
    return core_settings.get_context_level()

def _toggle_full_context():
    new_level = core_settings.cycle_context_level()
    
    if new_level == 0:
         msg = "[COLOR red]DESACTIVADO[/COLOR]"
         detail = "Búsqueda simple: Solo Título.\n\n[COLOR blue][I]Pulsa otra vez para NIVEL 1[/I][/COLOR]"
    elif new_level == 1:
         msg = "[COLOR green]NIVEL 1 (Padre)[/COLOR]"
         detail = "Búsqueda: Padre + Título (ej. Serie + Capítulo).\n\n[COLOR blue][I]Pulsa otra vez para EXTENDER nivel[/I][/COLOR]"
    elif new_level == 2:
         msg = "[COLOR green]NIVEL 2 (Padre + Abuelo)[/COLOR]"
         detail = "Búsqueda: Abuelo + Padre + Título.\n\n[COLOR blue][I]Pulsa otra vez para nivel MÁXIMO[/I][/COLOR]"
    else:
         msg = "[COLOR green]NIVEL 3 (MAX)[/COLOR]"
         detail = "Búsqueda: Ruta completa + Título.\n\n[COLOR red][I]Pulsa otra vez para DESACTIVAR[/I][/COLOR]"

    xbmcgui.Dialog().ok("EspaDaily", f"Contexto Completo: {msg}\n{detail}")
    xbmc.executebuiltin("Container.Refresh")

def _get_cache_dir():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    cd = os.path.join(p, 'api_cache')
    if not os.path.exists(cd): os.makedirs(cd)
    return cd

def _save_cache(key, data):
    try:
        f = os.path.join(_get_cache_dir(), f"{key}.json")
    except OSError as e:
        xbmc.log(f"[EspaDaily] Sin carpeta para la caché {key}: {e}", xbmc.LOGWARNING)
        return
    core_settings.atomic_write_json(f, data)

def _load_cache(key):
    f = os.path.join(_get_cache_dir(), f"{key}.json")
    if os.path.exists(f):
        try:
            with open(f, 'r', encoding='utf-8') as o: return json.load(o)
        except Exception: pass
    return None

def _sanitized_info():
    t = (
        "[B]EspaDaily[/B]\nAddon desarrollado por RubénSDFA1laberot\n\n"
        
        "[B]AVISO LEGAL Y TÉCNICO IMPORTANTE:[/B]\n\n"
        
        "[B]1. No Afiliación:[/B]\n"
        "Este proyecto es independiente. NO tiene ninguna afiliación, acuerdo ni vinculación con Atresplayer, RTVE, Mediaset ni ninguna entidad oficial. Las marcas comerciales se utilizan con fin únicamente descriptivo para organizar los menús de búsqueda.\n\n"
        
        "[B]2. Naturaleza Técnica (Agregador de Búsqueda):[/B]\n"
        "Este software actúa exclusivamente como una herramienta de automatización. NO contiene, aloja ni sube contenido protegido.\n"
        "• El addon nunca interactúa, descifra ni elude la seguridad de los servidores de las cadenas oficiales.\n"
        "• Funciona realizando búsquedas de texto en servidores públicos de terceros, mostrando resultados que ya son accesibles públicamente en cualquier navegador web.\n\n"
        
        "[B]3. Responsabilidad del Usuario:[/B]\n"
        "El desarrollador no tiene control sobre los resultados encontrados. El usuario es el único responsable de verificar la legalidad del acceso a dichos contenidos según las leyes de su país de residencia. Este addon se proporciona \"tal cual\", sin garantías de ningún tipo.\n\n"
        
        "[B]4. Propósito:[/B]\n"
        "Es GRATUITO, sin ánimo de lucro y está desarrollado de buena fe con fines educativos y de investigación tecnológica.\n\n"
        
        "[B]Contacto y Retirada:[/B]\n"
        "Si usted es titular de derechos y considera que este software le perjudica, puede solicitar la retirada de funcionalidad relacionada a través del canal de Telegram o GitHub.\n\n"
        
        "[B]¿Qué puedo encontrar?[/B]\n"
        "El addon intenta filtrar los resultados con la mayor precisión posible, pero la precisión depende totalmente del contenido disponible públicamente en ese momento.\n"
        "• Es posible encontrar capítulos o películas completas.\n"
        "• A veces solo aparecerán tráilers, resúmenes o clips.\n"
        "• En ocasiones pueden aparecer resultados solo relacionados o similares.\n"
        "El addon NO garantiza qué resultados aparecen, ya que depende exclusivamente de lo que otros usuarios hayan compartido en la red."
    )
    xbmcgui.Dialog().textviewer("Información - RubénSDFA1laberot", t)

def _info():
    t = (
        "[B]AVISO LEGAL Y TÉCNICO IMPORTANTE:[/B]\n\n"

        "[B]1. Gratuito y sin ánimo de lucro:[/B]\n"
        "Este addon es completamente GRATUITO y siempre lo será. Si alguien te lo ha vendido, te han estafado. Cualquier etiqueta tipo \"Premium\" o equivalente hace referencia a la suscripción de la plataforma de origen; no a este addon.\n\n"

        "[B]2. Responsabilidad del Usuario:[/B]\n"
        "El desarrollador no tiene control sobre los resultados encontrados en servidores externos. El usuario es el único responsable de verificar la legalidad del acceso a dichos contenidos según las leyes de su país de residencia. Este addon se proporciona \"tal cual\", sin garantías de ningún tipo.\n\n"

        "[B]3. No Afiliación:[/B]\n"
        "Este proyecto es independiente. NO tiene ninguna afiliación, acuerdo ni vinculación con ninguna cadena de televisión, plataforma ni entidad oficial. Las marcas comerciales se utilizan con fin únicamente descriptivo para organizar los menús de búsqueda.\n\n"

        "[B]4. Naturaleza Técnica (Agregador de Búsqueda):[/B]\n"
        "Este software actúa exclusivamente como una herramienta de automatización. NO contiene, aloja ni sube contenido protegido.\n"
        "• El addon nunca interactúa, descifra ni elude la seguridad de servidores de terceros.\n"
        "• Funciona realizando búsquedas de texto en servidores públicos de terceros, mostrando resultados que ya son accesibles públicamente en cualquier navegador web.\n\n"

        "[B]5. Propósito:[/B]\n"
        "Proyecto amateur. Sin publicidad ni recolección de hábitos de uso.\n\n"
        
        "[B]Contacto y Retirada:[/B]\n"
        "Si usted es titular de derechos y considera que este software le perjudica, puede solicitar la retirada de funcionalidad relacionada a través de los canales indicados en el repositorio oficial.\n\n"

        "[B]¿Qué puedo encontrar?[/B]\n"
        "El addon intenta filtrar los resultados con la mayor precisión posible, pero la precisión depende totalmente del contenido disponible públicamente en ese momento.\n"
        "• A veces solo aparecerán tráilers, resúmenes o clips.\n"
        "• En ocasiones pueden aparecer resultados solo relacionados o similares.\n"
        "El addon NO garantiza qué resultados aparecen, ya que depende exclusivamente de lo que otros usuarios hayan compartido en la red.\n\n"
        "[COLOR red][B]AVISO LEGAL:[/B][/COLOR] El uso de este addon implica la lectura y aceptación estricta del documento [B]AVISO_LEGAL.txt[/B] incluido en esta instalación."
    )
    xbmcgui.Dialog().textviewer("Información de EspaDaily", t)

def _web_info():
    t = (
        "https://espatv.github.io\n\n"
        "------------------------------------------------\n\n"
        "[B]Visita nuestra web para más proyectos como este.[/B]\n\n"
        "Allí encontrarás nuestros proyectos y actualizaciones.\n"
        "Cualquier apoyo o difusión de nuestros proyectos se agradece enormemente.\n\n"
    )
    xbmcgui.Dialog().textviewer("Más en...", t)

def _version_notes():
    t = (
        "[B]GUÍA DE USUARIO & NOTAS V2.0.1[/B]\n\n"
        "¡Bienvenido a EspaDaily v2! Estas son las novedades:\n\n"
        "------------------------------------------------\n"
        "[B]NOVEDADES V2.0.1[/B]\n\n"
        "• [B]Descarga ULTRA:[/B] Nuevo modo de descarga multi-hilo (4 conexiones paralelas) para descargar vídeos HLS a máxima velocidad.\n"
        "• [B]Corrección Android:[/B] Solucionado error 'bool object is not iterable' que causaba cierres inesperados en búsquedas.\n"
        "• [B]Puntuaciones corregidas:[/B] Los porcentajes de coincidencia ya no superan el 100%.\n"
        "• [B]Elementum:[/B] Ahora muestra aviso si Elementum no está instalado en vez de no hacer nada.\n\n"
        "------------------------------------------------\n"
        "[B]¿CÓMO FUNCIONA?[/B]\n"
        "EspaDaily es un explorador de catálogos. Tú navegas por los menús de Atresplayer, RTVE o Mediaset y, al elegir un contenido, el addon [B]busca automáticamente[/B] enlaces públicos en internet que coincidan.\n\n"
        "------------------------------------------------\n"
        "[B]HERRAMIENTAS PRINCIPALES[/B]\n\n"
        "• [B]Mis Favoritos:[/B] Guarda programas o series para acceder rápido. Pulsa clic derecho en cualquier ítem y elige 'Añadir a Favoritos'.\n"
        "• [B]Historial:[/B] Guarda tus últimas 50 búsquedas automáticamente.\n"
        "• [B]Instantáneas:[/B] Crea una copia de seguridad local de TODOS los menús del addon. Útil para navegar si falla internet o los servidores.\n"
        "• [B]Mis Descargas:[/B] Gestiona los vídeos que hayas guardado localmente.\n\n"
        "------------------------------------------------\n"
        "[B]GUÍA DE OPCIONES AVANZADAS[/B]\n\n"
        "• [B]Contexto Completo:[/B] Es la opción más importante. Define qué texto se busca en internet.\n"
        "   - [I]Desactivado:[/I] Busca solo el título del capítulo (Ej: 'Capítulo 1').\n"
        "   - [I]Nivel 1 (Recomendado):[/I] Busca Serie + Capítulo (Ej: 'Cuéntame Capítulo 1').\n"
        "   - [I]Nivel 2/MAX:[/I] Añade más datos de la ruta para búsquedas muy específicas.\n\n"
        "• [B]Priorizar Ajuste vs Duración:[/B]\n"
        "   - [I]Duración:[/I] Prefiere vídeos largos (evita clips cortos).\n"
        "   - [I]Ajuste:[/I] Prefiere títulos que coincidan exactamente, aunque sean cortos.\n\n"
        "• [B]Filtro Anti-Trailers:[/B] Oculta automáticamente vídeos de menos de X minutos.\n\n"
        "• [B]Filtro Temporal:[/B] Decide si prefieres ver primero los resultados más nuevos (Reciente) o los que mejor coinciden (Relevancia).\n\n"
        "• [B]Control de Caché:[/B]\n"
        "   - [I]Apagado:[/I] Siempre carga de internet (más lento, menos espacio).\n"
        "   - [I]Híbrido:[/I] Guarda los menús en disco para que navegar sea instantáneo.\n\n"
        "• [B]Otras Utilidades:[/B]\n"
        "   - [I]Refrescar:[/I] Recarga el addon si notas que algún menú no se actualiza.\n"
        "   - [I]Backup:[/I] Exporta tu historial e instantáneas a un archivo ZIP para llevarlos a otro Kodi.\n"
        "   - [I]Modo Debug:[/I] Actívalo solo si tienes problemas graves para generar un registro de errores.\n"
        "   - [I]Borrar Caché:[/I] Elimina datos temporales. Úsalo si tienes problemas de espacio o errores visuales.\n\n"
        "------------------------------------------------\n"
        "¡Que disfrutes de EspaDaily v2!"
    )
    xbmcgui.Dialog().textviewer("Guía y Notas v2.0.1", t)

def _version_notes_v1():
    t = (
        "[B]GUÍA DE USUARIO & NOTAS V1.0.0[/B]\n\n"
        "¡Bienvenido a EspaDaily! Aquí tienes todo lo que necesitas saber para sacarle el máximo partido.\n\n"
        "------------------------------------------------\n"
        "[B]¿CÓMO FUNCIONA?[/B]\n"
        "EspaDaily es un explorador de catálogos. Tú navegas por los menús de Atresplayer, RTVE o Mediaset y, al elegir un contenido, el addon [B]busca automáticamente[/B] enlaces públicos en internet que coincidan.\n\n"
        "------------------------------------------------\n"
        "[B]HERRAMIENTAS PRINCIPALES[/B]\n\n"
        "• [B]Mis Favoritos:[/B] Guarda programas o series para acceder rápido.\n"
        "• [B]Historial:[/B] Guarda tus últimas 50 búsquedas automáticamente.\n"
        "• [B]Instantáneas:[/B] Copia de seguridad local de los menús del addon.\n"
        "• [B]Mis Descargas:[/B] Gestiona los vídeos guardados localmente.\n\n"
        "------------------------------------------------\n"
        "¡Que disfrutes de esta primera versión!"
    )
    xbmcgui.Dialog().textviewer("Notas v1.0.0", t)

def _manual_search():
    if core_settings.is_advanced_search_active():
        _advanced_search_menu()
        return

    kb = xbmc.Keyboard('', 'Introduce el nombre a buscar')
    kb.doModal()
    if kb.isConfirmed():
        q = kb.getText()
        if q:
            _add_to_history(q)
            _lfd(q, "", nh=True)

def _get_movies_list():
    return [
        "Avatar", "Vengadores: Endgame", "Avatar: El sentido del agua", "Titanic", "Star Wars: El despertar de la fuerza",
        "Vengadores: Infinity War", "Spider-Man: No Way Home", "Jurassic World", "El rey león", "Los Vengadores",
        "Fast & Furious 7", "Top Gun: Maverick", "Frozen II", "Barbie", "Vengadores: La era de Ultrón",
        "Super Mario Bros.: La película", "Black Panther", "Harry Potter y las Reliquias de la Muerte - Parte 2",
        "Star Wars: Los últimos Jedi", "Jurassic World: El reino caído", "Frozen", "La bella y la bestia",
        "Los Increíbles 2", "El destino de los furiosos", "Iron Man 3", "Minions", "Capitán América: Civil War",
        "Aquaman", "El Señor de los Anillos: El retorno del Rey", "Spider-Man: Lejos de casa", "Capitana Marvel",
        "Transformers: El lado oscuro de la luna", "Skyfall", "Transformers: La era de la extinción",
        "El caballero oscuro: La leyenda renace", "Joker", "Star Wars: El ascenso de Skywalker", "Toy Story 4",
        "Toy Story 3", "Piratas del Caribe: El cofre del hombre muerto", "El rey león (1994)", "Buscando a Dory",
        "Star Wars: La amenaza fantasma", "Alicia en el país de las maravillas", "Zootrópolis", "Harry Potter y la piedra filosofal",
        "Gru, mi villano favorito 3", "Buscando a Nemo", "Harry Potter y la Orden del Fénix", "Harry Potter y el misterio del príncipe",
        "El Señor de los Anillos: Las dos torres", "Shrek 2", "Bohemian Rhapsody", "El Señor de los Anillos: La comunidad del anillo",
        "Harry Potter y las Reliquias de la Muerte - Parte 1", "El Hobbit: Un viaje inesperado", "El caballero oscuro",
        "Jumanji: Bienvenidos a la jungla", "Harry Potter y el cáliz de fuego", "Spider-Man 3", "Transformers: La venganza de los caídos",
        "Spider-Man: Homecoming", "Ice Age 3: El origen de los dinosaurios", "Ice Age 4: La formación de los continentes",
        "El libro de la selva", "Batman v Superman: El amanecer de la justicia", "El Hobbit: La desolación de Smaug",
        "El Hobbit: La batalla de los cinco ejércitos", "Thor: Ragnarok", "Guardianes de la Galaxia Vol. 2",
        "Inside Out (Del revés)", "Venom", "Thor: Love and Thunder", "Deadpool 2", "Deadpool", "Star Wars: La venganza de los Sith",
        "Spider-Man", "Wonder Woman", "Independence Day", "Animales fantásticos y dónde encontrarlos", "Shrek Tercero",
        "Coco", "Jumanji: Siguiente nivel", "Harry Potter y la cámara secreta", "Star Wars: Una nueva esperanza",
        "ET El extraterrestre", "Misión Imposible: Fallout", "2012", "Indiana Jones y el reino de la calavera de cristal",
        "Fast & Furious 6", "Piratas del Caribe: En el fin del mundo", "El código Da Vinci", "X-Men: Días del futuro pasado",
        "Madagascar 3: De marcha por Europa", "Las crónicas de Narnia: El león, la bruja y el armario", "Man of Steel",
        "Monstruos University", "Matrix Reloaded", "Up", "Gravity", "Capitán América: El Soldado de Invierno",
        "La saga Crepúsculo: Amanecer - Parte 2", "La saga Crepúsculo: Amanecer - Parte 1", "La saga Crepúsculo: Luna nueva",
        "La saga Crepúsculo: Eclipse", "Forrest Gump", "El sexto sentido", "Interestelar", "Origen", "Gladiator",
        "Salvar al soldado Ryan", "La lista de Schindler", "El Padrino", "El Padrino Parte II", "Cadena perpetua",
        "Pulp Fiction", "El club de la lucha", "Matrix", "Goodfellas (Uno de los nuestros)", "Seven", "El silencio de los corderos",
        "La vida es bella", "Ciudad de Dios", "El viaje de Chihiro", "Parásitos", "Psicosis", "Casablanca",
        "El bueno, el feo y el malo", "12 hombres sin piedad", "La milla verde", "El gran dictador", "Cinema Paradiso",
        "Regreso al futuro", "Terminator 2: El juicio final", "Alien, el octavo pasajero", "Apocalypse Now",
        "Django desencadenado", "El resplandor", "WALL-E", "La princesa Mononoke", "Oldboy", "Amélie", "El laberinto del fauno"
    ]

"""
SISTEMA DE MENSAJES / AVISOS (messages.json)
============================================

Este sistema comprueba si hay novedades en el archivo "messages.json" de mi GitHub
y muestra una ventana emergente al usuario cuando entra al addon.

Configuración en messages.json:
-------------------------------
1. "id": ¡IMPORTANTE! Es el identificador del mensaje (ej: "aviso_v2").
   - El addon guarda qué IDs ya ha visto el usuario.
   - Para que salga un mensaje NUEVO, cambiar el "id" (ej: de "aviso_v1" a "aviso_v2").
   
2. "title": El título de la ventana emergente.

3. "message": El texto del aviso. Usa \n para saltos de línea.

4. "repeat": Cuántas veces se mostrará este mensaje al usuario.
   - 1  -> Se muestra solo la primera vez que entre (y nunca más).
   - 3  -> Se muestra las primeras 3 veces (para asegurar que lo lea).
   - -1 -> Se muestra SIEMPRE (infinito) cada vez que entre.
   - 0  -> Mensaje desactivado (no lo muestra nadie).

Ejemplo:
  {
    "id": "noticia_importante_enero",
    "title": "Mantenimiento",
    "message": "Mañana habrá cortes por mantenimiento.",
    "repeat": 1
  }
"""
def _check_messages():
    # Comprobar si hay mensajes remotos para mostrar
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    sf = os.path.join(p, 'messages_state.json')
    
    try:
        import time
        import re
        import json
        url = f"{_MESSAGES_URL}?_cb={int(time.time())}"
        r = requests.get(url, timeout=5)
        # Fail Open: Si no hay fichero o error, no hacemos nada y seguimos
        if r.status_code != 200: return
        
        clean_json = re.sub(r',\s*([\]}])', r'\1', r.text)
        data = json.loads(clean_json)
        
        # Soportar formato viejo (objeto unico) y formato nuevo (lista)
        if isinstance(data, dict) and "messages" in data:
            msgs = data["messages"]
        elif isinstance(data, list):
            msgs = data
        else:
            msgs = [data] # Treat as single message object
            
        # Cargar estado local (cuantas veces se ha visto cada ID)
        st = {}
        if os.path.exists(sf):
            try:
                with open(sf, 'r', encoding='utf-8') as f: st = json.load(f)
            except Exception: pass
            
        params_changed = False
        
        for msg in msgs:
            mid = msg.get("id")
            # Repeticion por defecto = 1 si no existe
            mrep = msg.get("repeat", 1) 
            
            # Si no hay ID o repeat es 0, saltamos este mensaje
            if not mid or mrep == 0: continue
            
            # Vemos cuantas veces ha visto este mensaje concreto
            views = st.get(mid, 0)
            
            show_it = False
            if mrep == -1: show_it = True    # Siempre
            elif views < mrep: show_it = True # Aun no ha llegado al limite
            
            if show_it:
                # Mostrar Dialogo
        
                body = msg.get("text") or msg.get("message", "")
                title = msg.get("title", "Aviso EspaDaily")
                
                # Usar Dialog().ok para tener botón de aceptar/cerrar
        
                color = msg.get("color", "white")
                formatted_text = f"[COLOR {color}][B]{title}[/B][/COLOR]\n\n{body}"
                
                xbmcgui.Dialog().ok("Aviso EspaDaily", formatted_text)
                
                # Incrementar contador y guardar
                st[mid] = views + 1
                params_changed = True
        
        if params_changed:
            with open(sf, 'w', encoding='utf-8') as f: json.dump(st, f)
            
    except Exception as e:
        _log_error(f"Error checking messages: {str(e)}")



# Cumplimiento legal y control remoto

def _get_legal_settings_path():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, 'legal_settings.json')

def _load_legal_settings():
    f = _get_legal_settings_path()
    if not os.path.exists(f):
        return {}
    try:
        with open(f, 'r', encoding='utf-8') as fp:
            return json.load(fp)
    except (json.JSONDecodeError, IOError):
        return {}

def _save_legal_settings(data):
    try:
        with open(_get_legal_settings_path(), 'w', encoding='utf-8') as fp:
            json.dump(data, fp, ensure_ascii=False)
    except IOError:
        pass

def _load_connector_blocking():
    global connector
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        if _ensure_connector():
            dev_flag = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.dev_mode')
            if os.path.exists(dev_flag):
                import importlib
                connector = importlib.import_module('connector')
            else:
                connector = _cargar_conector()
    except Exception as e:
        xbmc.log(f"[EspaDaily] Error cargando connector: {e}", xbmc.LOGERROR)
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    return connector is not None


def _require_connector():
    """Asegura que `connector` está cargado, pasando por el gate legal si hace falta.
    Devuelve True si está listo para usar, False si la accion debe abortar."""
    if connector is not None:
        return True
    return _check_legal_compliance()


_CONNECTOR_DOWNLOAD_FAILED_MSG = (
    "No se pudo descargar el módulo de conexión.\n\n"
    "Comprueba tu conexión a Internet y vuelve a intentarlo más tarde."
)


class LegalScrollDialog(xbmcgui.WindowXMLDialog):
    def onInit(self):
        try:
            textbox = self.getControl(1)
            textbox.setText(getattr(self, '_legal_text', ''))
            textbox.autoScroll(2000, 4500, 0)
        except Exception as e:
            xbmc.log("[EspaDaily] LegalScrollDialog onInit error: {0}".format(e), xbmc.LOGWARNING)

    def onAction(self, action):
        if action.getId() in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_STOP):
            self.close()

    def onClick(self, controlId):
        if controlId == 10:
            self.close()


def _check_legal_compliance():
    """Verifica que el usuario haya aceptado los terminos legales.
    Devuelve True si puede continuar, False si debe bloquearse."""
    global connector
    cfg = _load_legal_settings()
    if cfg.get('legal_accepted_v2', False):
        if connector is None:
            if not _load_connector_blocking():
                xbmcgui.Dialog().ok("EspaDaily", _CONNECTOR_DOWNLOAD_FAILED_MSG)
                return False
        return True

    addon = xbmcaddon.Addon()
    legal_path = os.path.join(addon.getAddonInfo('path'), 'AVISO_LEGAL.txt')
    legal_text = "[B]No se encontró el archivo AVISO_LEGAL.txt[/B]"
    if os.path.exists(legal_path):
        try:
            with open(legal_path, 'r', encoding='utf-8') as f:
                legal_text = f.read()
        except IOError:
            pass

    try:
        dlg = LegalScrollDialog('dialog_legal.xml', addon.getAddonInfo('path'), 'Default', '1080i')
        dlg._legal_text = legal_text
        dlg.doModal()
        del dlg
    except Exception as e:
        xbmc.log("[EspaDaily] LegalScrollDialog fallo, usando textviewer: {0}".format(e), xbmc.LOGERROR)
        xbmcgui.Dialog().textviewer("Aviso Legal y Terminos de Uso", legal_text)

    prompt_msg = (
        "[COLOR red][B]CONSENTIMIENTO REQUERIDO[/B][/COLOR]\n\n"
        "¿Confirmas haber leído el Aviso Legal y aceptas voluntariamente "
        "la política integral de uso de EspaDaily?"
    )
    user_accepts = xbmcgui.Dialog().yesno(
        "Términos y Condiciones",
        prompt_msg,
        yeslabel="SÍ, ACEPTO",
        nolabel="RECHAZAR"
    )

    if user_accepts:
        cfg['legal_accepted_v2'] = True
        _save_legal_settings(cfg)
        verify_cfg = _load_legal_settings()
        if not verify_cfg.get('legal_accepted_v2', False):
            xbmcgui.Dialog().ok("Error del Sistema", "No se pudo guardar el consentimiento en el disco.\nRevisa el espacio y los permisos de la carpeta profile.")
            return False
        try:
            import stats
            stats.activar()
        except Exception as ex:
            xbmc.log(f"[EspaDaily] Telemetría: {ex}", xbmc.LOGDEBUG)

        xbmcgui.Dialog().ok("EspaDaily", "¡Términos Aceptados!\n\nEl sistema se reiniciará para aplicar los cambios.")
        xbmc.executebuiltin(f"RunAddon({xbmcaddon.Addon().getAddonInfo('id')})")
        return False

    xbmcgui.Dialog().notification("EspaDaily", "Acceso denegado. Términos rechazados.", xbmcgui.NOTIFICATION_WARNING)
    return False

def _leer_status():
    """status.json del repositorio, o el incluido en el addon si no hay red. None si no hay ninguno."""
    try:
        # Se consulta de forma síncrona al abrir el addon, así que con plazo corto.
        r = requests.get(_STATUS_URL, timeout=5)
        if r.status_code == 200:
            data = r.json()
            if isinstance(data, dict):
                return data
    except (requests.RequestException, ValueError):
        pass
    try:
        with open(os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'status.json'), 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, dict) else None
    except (OSError, ValueError):
        return None


def _motivo_de_bloqueo():
    """Texto que mostrar si el addon no debe usarse (desactivado, o versión inferior a la
    mínima); None si se puede usar.

    El veredicto se recalcula en cada llamada con los últimos datos de status.json y la
    versión instalada. Antes un "desactivado" guardado bloqueaba una semana aunque se
    retirase, y sin red ni caché se volvía a pedir status.json (10 s) en cada pantalla.
    """
    # Corre en cada invocación, y un fallo aquí (caché corrupta, un status.json con tipos
    # raros) dejaría el addon entero inservible. Ante cualquier error se deja usar y queda
    # en el log.
    try:
        return _calcular_bloqueo()
    except Exception as ex:
        xbmc.log(f"[EspaDaily] Comprobación de estado fallida, se ignora: {ex}", xbmc.LOGWARNING)
        return None


def _calcular_bloqueo():
    ruta = os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')), 'validity_cache.json')
    try:
        with open(ruta, 'r', encoding='utf-8') as f:
            st = json.load(f)
    except (OSError, ValueError):
        st = {}
    if not isinstance(st, dict):
        st = {}
    data = st.get('data') if isinstance(st.get('data'), dict) else None
    last = st.get('last_check')
    if not isinstance(last, (int, float)):
        last = 0

    # Semanal si todo va bien; cada hora si está bloqueado o nunca se ha podido leer, para
    # salir pronto del bloqueo sin lanzar una petición en cada apertura del addon.
    ttl = 604800 if data is not None and not st.get('bloqueado') else 3600
    refrescado = time.time() - last > ttl
    if refrescado:
        data = _leer_status() or data
        st = {'last_check': time.time(), 'data': data}

    motivo = None
    if data is not None:
        def pv(v): return [int(x) for x in str(v).replace('v', '').split('.') if x.isdigit()]
        cur_v = xbmcaddon.Addon().getAddonInfo('version')
        min_v = data.get('min_version', '0.0.0')
        if not data.get('allowed', True):
            motivo = str(data.get('message') or "Este addon ha sido desactivado por el desarrollador.")
        elif pv(cur_v) < pv(min_v):
            motivo = str(data.get('message') or
                         f"Tu versión ({cur_v}) es anterior a la mínima requerida ({min_v}). Actualiza el addon.")

    if refrescado or st.get('bloqueado') != bool(motivo):
        st['bloqueado'] = bool(motivo)
        core_settings.atomic_write_json(ruta, st)
    return motivo

def _show_legal_text():
    """Muestra el texto completo del AVISO_LEGAL.txt."""
    addon = xbmcaddon.Addon()
    legal_path = os.path.join(addon.getAddonInfo('path'), 'AVISO_LEGAL.txt')
    if os.path.exists(legal_path):
        try:
            with open(legal_path, 'r', encoding='utf-8') as f:
                text = f.read()
            xbmcgui.Dialog().textviewer("Aviso Legal - EspaDaily", text)
        except IOError:
            xbmcgui.Dialog().ok("Error", "No se pudo leer el archivo de aviso legal.")
    else:
        xbmcgui.Dialog().ok("Error", "Archivo AVISO_LEGAL.txt no encontrado.")

def _revoke_legal():
    """Revoca la aceptacion de terminos. Borra el connector descargado y la cache
    asociada para que en la siguiente aceptacion se vuelva a descargar."""
    global connector
    if xbmcgui.Dialog().yesno(
        "Revocar Aceptación",
        "¿Seguro que quieres revocar tu aceptación de los términos?\n\n"
        "Se eliminará el módulo de conexión descargado. La próxima vez que "
        "abras el addon tendrás que aceptar de nuevo y se descargará otra vez."
    ):
        cfg = _load_legal_settings()
        cfg['legal_accepted_v2'] = False
        _save_legal_settings(cfg)
        for _path in (_get_sys_path(), _get_loader_cache_path()):
            try:
                if os.path.exists(_path):
                    os.remove(_path)
            except OSError as _e:
                xbmc.log(f"[EspaDaily] No se pudo borrar {_path}: {_e}", xbmc.LOGWARNING)
        connector = None
        xbmcgui.Dialog().notification(
            "EspaDaily", "Aceptación revocada", xbmcgui.NOTIFICATION_INFO
        )


def _get_top_movies_cache_path():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, "top_movies_thumbs.json")

def _load_top_movies_cache():
    path = _get_top_movies_cache_path()
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception: pass
    return {}

def _fetch_tmdb_poster(title):
    try:
        r = core_settings.peticion_tmdb(
            "/search/movie",
            {"api_key": core_settings._ESPADAILY_TMDB_API_KEY, "query": title, "language": "es-ES"},
            timeout=8
        )
        if r.status_code == 200:
            results = r.json().get("results", [])
            if results and results[0].get("poster_path"):
                return f"https://image.tmdb.org/t/p/w342{results[0]['poster_path']}"
    except Exception:
        pass
    return None


def _top_movies(page):
    try: page = int(page)
    except (ValueError, TypeError): page = 1
    per_page = 50
    movies = _get_movies_list()
    total = len(movies)
    start = (page - 1) * per_page
    end = start + per_page
    page_items = movies[start:end]

    addon = xbmcaddon.Addon()
    ai = addon.getAddonInfo('icon')
    af = core_settings.addon_fanart()

    # SISTEMA DE CACHÉ DE IMÁGENES
    cache_path = _get_top_movies_cache_path()
    cache_file_exists = os.path.exists(cache_path)
    cache = _load_top_movies_cache()
    user_cleared = cache_file_exists and len(cache) == 0

    if not user_cleared:
        # Auto-cargar solo si el usuario no borró la caché intencionalmente
        missing = [m for m in page_items if m not in cache]
        if missing:
            try:
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor(max_workers=10) as ex:
                    futures = {ex.submit(_fetch_tmdb_poster, m): m for m in missing}
                    for fut in concurrent.futures.as_completed(futures, timeout=15):
                        m = futures[fut]
                        try:
                            url = fut.result()
                            if url:
                                cache[m] = url
                        except Exception:
                            pass
                if any(m in cache for m in missing):
                    with open(cache_path, 'w', encoding='utf-8') as f:
                        json.dump(cache, f)
            except Exception as e:
                xbmc.log(f"[EspaDaily] TMDB fetch paralelo: {e}", xbmc.LOGWARNING)

    has_cache = len(cache) > 0

    if user_cleared:
        # El usuario borró la caché: mostrar botón manual para recargar si quiere
        li = xbmcgui.ListItem(label="[COLOR yellow][B]Descargar carátulas[/B][/COLOR]")
        li.setArt({'icon': ui_utils.media_icon('cat_caratulas.png'), 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'plot': "Descarga las carátulas de todas las películas y las guarda permanentemente."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="cache_top_movies_covers"), listitem=li, isFolder=False)
    elif has_cache:
        li = xbmcgui.ListItem(label="[COLOR red][B]Borrar carátulas guardadas[/B][/COLOR]")
        li.setArt({'icon': ui_utils.media_icon('borrar_caratulas.png'), 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'plot': "Elimina las fotos guardadas para liberar espacio. No se recargarán automáticamente."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="clear_top_movies_cache"), listitem=li, isFolder=False)

    for m in page_items:
        li = xbmcgui.ListItem(label=m)

        thumb = cache.get(m, ai)

        _genre   = _get_movie_genre(m)
        _details = _get_movie_details(m)
        _plot = (
            f"[COLOR gold][B]Género:[/B][/COLOR] [COLOR deepskyblue]{_genre}[/COLOR]  |  "
            f"[COLOR gold][B]Año:[/B][/COLOR] [COLOR deepskyblue]{_details[0]}[/COLOR]  |  "
            f"[COLOR gold][B]Nota IMDb:[/B][/COLOR] [COLOR deepskyblue]{_details[1]}[/COLOR]\n"
            f"[COLOR gold][B]Director:[/B][/COLOR] [COLOR deepskyblue]{_details[2]}[/COLOR]\n\n"
            f"{_get_movie_plot(m)}"
        )

        li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb, 'fanart': af})
        li.setInfo('video', {
            'title': m,
            'plot': _plot,
            'genre': _genre,
            'year': int(_details[0]),
            'rating': float(_details[1]),
            'director': _details[2]
        })
        
        # Context Menu
        cm = []
        cm.append(("Buscar en webs de torrent", f"RunPlugin({_u(action='elementum_search', q=m)})"))
        if core_settings.is_palantir_installed() and not core_settings.are_external_integrations_disabled():
            cm.append(("Buscar en Palantir 3", f"RunPlugin({_u(action='palantir_search', q=m)})"))
        
        # Favoritos - Construir URL antes para evitar problemas con caracteres especiales
        fav_url = _u(action='add_favorite', title=m, fav_url=m, icon=thumb, platform='Legendarias', fav_action='lfr', params=json.dumps({'q': m}))
        cm.append(("Añadir a Mis Favoritos", f"RunPlugin({fav_url})"))
        li.addContextMenuItems(cm)
        
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_alt_prompt", q=m, ot=thumb, mode="movie"), listitem=li, isFolder=False)
    
    if end < total:
        li = xbmcgui.ListItem(label=f"Siguiente Página ({page + 1}) >>")
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="top_movies", page=page+1), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _cache_top_movies_covers():
    if not xbmcgui.Dialog().yesno("EspaDaily",
        "¿Quieres descargar las carátulas de las 130+ películas top?\n\n"
        "Se descargarán en paralelo. Tardará menos de un minuto."):
        return

    import metadata_enricher as me

    movies = _get_movies_list()
    enrich_targets = [
        {'title': m, 'year': _get_movie_details(m)[0], 'media_type': 'movie'}
        for m in movies
    ]

    pDialog = xbmcgui.DialogProgress()
    pDialog.create("EspaDaily", "Descargando carátulas Top...")
    was_cancelled = False
    try:
        me.batch_fetch_with_progress(enrich_targets, pDialog, max_workers=10)
        was_cancelled = pDialog.iscanceled()
    finally:
        pDialog.close()

    if was_cancelled:
        return

    cache = {}
    for target in enrich_targets:
        m = target['title']
        meta = me.enrich(title=m, year=target['year'], media_type='movie', use_cache_only=True)
        if meta and meta.get('poster'):
            cache[m] = meta.get('poster')

    if cache:
        path = _get_top_movies_cache_path()
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(cache, f)
        os.replace(tmp, path)
        xbmcgui.Dialog().notification("EspaDaily", "Carátulas guardadas correctamente", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")
    else:
        xbmcgui.Dialog().notification("EspaDaily", "No se encontraron carátulas", xbmcgui.NOTIFICATION_WARNING)

def _clear_top_movies_cache():
    try:
        with open(_get_top_movies_cache_path(), 'w', encoding='utf-8') as f:
            json.dump({}, f)
        xbmcgui.Dialog().notification("EspaDaily", "Carátulas eliminadas. No se recargarán automáticamente.", xbmcgui.NOTIFICATION_INFO, 4000)
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmc.log(f"[EspaDaily] Error borrando caché carátulas: {e}", xbmc.LOGWARNING)

def _ls(cid, page=0):
    # Caché híbrida
    if _is_frozen_active() and page == 0:
        d = _load_cache(f"atres_{cid}")
        if d:
            _process_atres_items(d, cid, page=0)
            return

    items = connector.fetch_atres_list(cid, page=page)
    if not items:
        if page == 0:
            xbmcgui.Dialog().ok("Error", "No se pudo obtener la lista de contenidos.")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    
    # Guardar caché
    if _get_cache_mode() > 0 and page == 0:
        _save_cache(f"atres_{cid}", items)

    _process_atres_items(items, cid, page=page)

def _process_atres_items(items, cid, page=0):
    addon = xbmcaddon.Addon(); ai = addon.getAddonInfo('icon'); af = core_settings.addon_fanart()
    for i in items:
        try:
            tt = i.get("title", "Sin título"); im = i.get("image", {}); tr = im.get("pathHorizontal") or im.get("pathVertical"); th = _fix_img(tr)
            if not th:
                try: dr = _sr(tt); th = dr[0].get("thumbnail_720_url") or dr[0].get("thumbnail_360_url") if dr else ai
                except Exception: th = ai
            if not th: th = ai
            fa = th if th != ai else af
            lk = i.get("link", {}); au = lk.get("href")
            if not au: continue
            tag = i.get("tagType", "")
            is_open = i.get("open", False)
            is_prem = tag in ("EXCLUSIVE", "ORIGINAL", "PREVIEW") and not is_open
            label = f"{tt} [COLOR gray][ATP+?][/COLOR]" if is_prem else tt
            li = xbmcgui.ListItem(label=label); li.setArt({'thumb': th, 'icon': th, 'fanart': fa})
            li.setInfo('video', {'title': tt, 'plot': i.get('description', '')})


            _add_fav_cm(li, tt, "atresplayer", "fs", {"au": au, "st": tt, "sth": th})
            

            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fs", au=au, st=tt, sth=th), listitem=li, isFolder=True)

        except Exception as e:
            _log_error(f"Error al procesar item Atresplayer: {e}")
            continue

    # Paginacion: si hay items suficientes, probablemente hay mas paginas
    if len(items) >= 10:
        next_page = page + 1
        li = xbmcgui.ListItem(label="[COLOR cyan][B]>> Página Siguiente ({0})[/B][/COLOR]".format(next_page))
        li.setArt({'icon': ui_utils.media_icon('siguiente.png'), 'fanart': core_settings.addon_fanart()})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ls", cid=cid, page=next_page), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=False)

def _human_size(n):
    if n < 1024:
        return "{0} B".format(n)
    if n < 1024 * 1024:
        return "{0:.1f} KB".format(n / 1024)
    return "{0:.1f} MB".format(n / (1024 * 1024))


def _limpieza_menu():
    h = int(sys.argv[1])
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)
    _fanart = core_settings.addon_fanart()

    # 1. Limpieza del Addon
    li = xbmcgui.ListItem(label="Limpieza del Addon (Cachés, BD, Reset)")
    li.setArt({'icon': _mi('adv_limpieza.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Opciones para liberar espacio: borrar cachés temporales del addon, compactar la base de metadatos o restablecer el addon a estado de fábrica."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="cleanup_menu"), listitem=li, isFolder=True)

    # 2. Limpiar caché / almacenamiento
    li = xbmcgui.ListItem(label="Limpiar caché / almacenamiento")
    li.setArt({'icon': _mi('adv_limpieza.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Muestra cuánto ocupa cada caché del addon y permite borrarlas. Tus favoritos, historial y ajustes nunca se tocan."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="storage_menu"), listitem=li, isFolder=True)

    # 3. Limpieza y mantenimiento de Kodi
    li = xbmcgui.ListItem(label="Limpieza y mantenimiento de Kodi")
    li.setArt({'icon': _mi('adv_limpieza.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Mantenimiento general de Kodi: paquetes de instalación, miniaturas en desuso, compactar bases de datos y copia de tu configuración de Kodi."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="kodi_maintenance_menu"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def _cleanup_menu():
    h = int(sys.argv[1])
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)
    _fanart = core_settings.addon_fanart()

    li = xbmcgui.ListItem(label="[COLOR yellow]Limpiar caché (recomendado)[/COLOR]")
    li.setArt({'icon': _mi('adv_cache.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Borra archivos de cache temporales como el catálogo de programas, la guía EPG, miniaturas TMDB y metadatos de FilmAffinity, SensaCine y CineMeta.\n\nNo afecta a tus favoritos, historial, Trakt ni configuración.\n\nEn la mayoría de ocasiones no merece la pena, la cantidad de espacio que se libera es minuscula."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="cleanup_caches"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR cyan]Compactar base de metadatos[/COLOR]")
    li.setArt({'icon': ui_utils.media_icon('compactar_db.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Elimina las entradas caducadas (mas de 30 días) de la base de datos de metadatos TMDB y compacta el archivo.\n\nMantiene los datos recientes y libera el espacio que ocupaban los caducados."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="vacuum_metadata_db"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR red]Restablecer addon (factory reset)[/COLOR]")
    li.setArt({'icon': ui_utils.media_icon('reset_addon.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "BORRA TODOS LOS DATOS DEL ADDON y deja la instalación como recien instalada.\n\nSe pierden los favoritos, el historial completo, Trakt, las categorías propias, los canales DM guardados, los marcadores y la configuración completa.\n\nUsalo solo si el addon esta corrupto o quieres empezar de cero. Esta acción NO se puede deshacer."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="clear_cache"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def _cleanup_caches():
    if not xbmcgui.Dialog().yesno(
        "EspaDaily - Limpieza",
        "Borrar los archivos de cache temporales?\n\nNo afecta a tus favoritos, historial, Trakt ni configuración."
    ):
        return

    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    freed = 0

    cache_files = [
        'epg_texto_cache.json',
        'espadaily_cinemeta_cache.json',
        'espadaily_fa_cache.json',
        'espadaily_sc_cache.json',
        'espadaily_tmdb_lists_cache.json',
        'top_movies_thumbs.json',
    ]
    for fn in cache_files:
        fp = os.path.join(profile, fn)
        if os.path.exists(fp):
            try:
                freed += os.path.getsize(fp)
                os.remove(fp)
            except OSError:
                pass

    api_cache_dir = os.path.join(profile, 'api_cache')
    if os.path.isdir(api_cache_dir):
        for fn in os.listdir(api_cache_dir):
            if fn.endswith('.json'):
                fp = os.path.join(api_cache_dir, fn)
                try:
                    freed += os.path.getsize(fp)
                    os.remove(fp)
                except OSError:
                    pass

    ytdlp_dir = os.path.join(profile, 'packages', 'yt_dlp')
    if os.path.isdir(ytdlp_dir):
        try:
            import shutil
            for root, _dirs, files in os.walk(ytdlp_dir):
                for f in files:
                    try:
                        freed += os.path.getsize(os.path.join(root, f))
                    except OSError:
                        pass
            shutil.rmtree(ytdlp_dir, ignore_errors=True)
        except Exception:
            pass

    active_ids = None
    try:
        lists = core_settings.get_trakt_lists()
        if lists is not None:
            active_ids = {str(l.get('id')) for l in lists if l.get('id') is not None}
    except Exception:
        active_ids = None
    if active_ids is not None and os.path.isdir(profile):
        for fn in os.listdir(profile):
            if fn.startswith('trakt_thumbs_') and fn.endswith('.json'):
                list_id = fn[len('trakt_thumbs_'):-len('.json')]
                if list_id not in active_ids:
                    fp = os.path.join(profile, fn)
                    try:
                        freed += os.path.getsize(fp)
                        os.remove(fp)
                    except OSError:
                        pass

    xbmcgui.Dialog().ok(
        "EspaDaily - Limpieza",
        "Cache borrada.\n\nSe han liberado {0}.".format(_human_size(freed))
    )
    xbmc.executebuiltin("Container.Refresh")


def _vacuum_metadata_db_action():
    if not xbmcgui.Dialog().yesno(
        "EspaDaily - Compactar metadatos",
        "Eliminar entradas caducadas (mas de 30 días) y compactar la base de datos?\n\nLos metadatos recientes se conservan."
    ):
        return
    try:
        import metadata_enricher
        deleted, freed = metadata_enricher.prune_and_vacuum()
        xbmcgui.Dialog().ok(
            "EspaDaily - Compactar metadatos",
            "Se han borrado {0} entradas y liberado {1}.".format(deleted, _human_size(freed))
        )
    except Exception as e:
        xbmcgui.Dialog().ok("EspaDaily - Error", "No se pudo compactar.\n\n{0}".format(str(e)))
    xbmc.executebuiltin("Container.Refresh")


def _clear_cache():
    if not xbmcgui.Dialog().yesno(
        "EspaDaily - Restablecer addon",
        "Vas a BORRAR TODOS LOS DATOS DEL ADDON y dejarlo como recien instalado.\n\nSe perderan los favoritos, el historial, Trakt, las categorías propias, los marcadores, los canales y la configuración completa.\n\nEsta acción NO se puede deshacer. Continuar?",
        nolabel="Cancelar",
        yeslabel="Restablecer"
    ):
        return

    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    borrar = [os.path.join(p, f) for f in os.listdir(p) if f.endswith(".json")] if os.path.exists(p) else []
    sys_path = _get_sys_path()
    if os.path.exists(sys_path):
        borrar.append(sys_path)
    quedan = 0
    for ruta in borrar:
        try:
            os.remove(ruta)
        except OSError as e:
            quedan += 1
            xbmc.log(f"[EspaDaily] Restablecer: no se ha podido borrar {ruta}: {e}", xbmc.LOGWARNING)
    if quedan:
        xbmcgui.Dialog().notification("EspaDaily", f"Restablecido, pero {quedan} archivo(s) no se han podido borrar",
                                      xbmcgui.NOTIFICATION_WARNING, 5000)
    else:
        xbmcgui.Dialog().notification("EspaDaily", "Addon restablecido", xbmcgui.NOTIFICATION_INFO)
    # Refrescar para reflejar cambios (ej: debug desactivado)
    xbmc.executebuiltin("Container.Refresh")

def _fs(au, st, sth="", pu=""):
    if pu and au == pu: _fb(st, sth); return
    d = connector.fetch_atres_format(au)
    if not d: _fb(st, sth); return
    ss = d.get("seasons", []); rw = d.get("rows", []); id_ = d.get("items", []) or d.get("itemRows", [])
    fmt_prem = d.get("premium", False)
    erh = None
    for ro in rw:
        if ro.get("type") == "EPISODE": erh = ro.get("href"); break
    if erh: _lfr(erh, st, sth, fmt_prem); return
    if id_: _rel(id_, st, sth, fmt_prem); return
    if len(ss) > 1:
        for s in ss:
            t = s.get("title", "Temporada"); sh = s.get("link", {}).get("href")
            if sh and sh != au:
                li = xbmcgui.ListItem(label=t); li.setArt({'thumb': sth, 'icon': sth})
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fs", au=sh, st=st, sth=sth, pu=au), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(int(sys.argv[1])); return
    elif len(ss) == 1:
        sh = ss[0].get("link", {}).get("href")
        if sh and sh != au: _fs(sh, st, sth, pu=au); return
    _fb(st, sth)

def _fb(st, sth):
    li = xbmcgui.ListItem(label=f"Buscar '{st}' en Internet..."); li.setArt({'thumb': sth, 'icon': sth})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="lfr", q=st, ot=sth), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _lfr(ru, st, sth="", fmt_prem=False, pagina=0):
    desde = getattr(connector, "fetch_atres_episodes_desde", None)
    siguiente = None
    if desde and "/row/search" in ru:
        items, siguiente = desde(ru, pagina)
    else:
        items = connector.fetch_atres_episodes(ru)
    if not items:
        _fb(st, sth)
        return
    mas = None
    if siguiente is not None:
        bloque = getattr(connector, "_ATP_MAX_PAGINAS_CAPS", 4)
        mas = (siguiente // bloque + 1,
               _u(action="lfr_atres", ru=ru, st=st, sth=sth, prem="1" if fmt_prem else "", pagina=siguiente))
    _rel(items, st, sth, fmt_prem, mas=mas)

def _search_tmdbhelper(title):
    if not xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.themoviedb.helper)"):
        if xbmcgui.Dialog().yesno("TMDB Helper",
                "TMDB Helper no está instalado o está deshabilitado.\n¿Deseas instalarlo ahora?",
                yeslabel="Instalar", nolabel="Cancelar"):
            xbmc.executebuiltin("InstallAddon(plugin.video.themoviedb.helper)")
        return
    tmdb_id, enrich_type = 0, "movie"
    try:
        import metadata_enricher as me
        for _mt in ("movie", "show"):
            meta = me.enrich(title=title, media_type=_mt)
            _tid = int((meta.get("ids") or {}).get("tmdb", 0) or 0) if meta else 0
            if _tid:
                tmdb_id, enrich_type = _tid, _mt
                break
    except Exception as e:
        xbmc.log("[EspaDaily] tmdbhelper enrich: {0}".format(e), xbmc.LOGWARNING)
    if not tmdb_id:
        xbmcgui.Dialog().notification("EspaDaily", "No se pudo identificar en TMDB", xbmcgui.NOTIFICATION_WARNING)
        return
    tmdb_type = "movie" if enrich_type == "movie" else "tv"
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.themoviedb.helper/?info=play&tmdb_type={0}&tmdb_id={1})".format(tmdb_type, tmdb_id))


def _ep_dialog(q, ot, t="", eid="", sn=""):
    import url_player as _up
    title = urllib.parse.unquote(t) if t else q
    sn_installed = xbmc.getCondVisibility("System.HasAddon({0})".format(_up._SN_ID))
    sn_label = "[B]Reproducir con StreamNinja[/B]" if sn_installed else "[B]Instalar StreamNinja[/B]"
    opts = [sn_label]
    acts = ["sn"]
    opts.append("[B]Buscar en internet[/B]")
    acts.append("buscar")
    opts.append("[B]Buscar en Megabuscador[/B]")
    acts.append("megabuscador")
    _ext_off = core_settings.are_external_integrations_disabled()
    _gujal_on = xbmcaddon.Addon().getSetting('gujal_search_enabled') == 'true'
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
        opts.append("[COLOR red]Buscar en YouTube[/COLOR]")
        acts.append("youtube")
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)"):
        opts.append("[COLOR FFD2691E]Buscar en webs de torrent[/COLOR]")
        acts.append("elementum")
    if not _ext_off and xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)"):
        opts.append("[COLOR deepskyblue]Buscar en addon Dailymotion (Gujal)[/COLOR]")
        acts.append("dm_gujal")
    if not _ext_off and xbmc.getCondVisibility("System.HasAddon(plugin.video.palantir3)"):
        opts.append("[COLOR orange]Buscar en Palantir[/COLOR]")
        acts.append("palantir")
    if not _ext_off and xbmc.getCondVisibility("System.HasAddon(plugin.video.balandro)"):
        opts.append("[COLOR chartreuse]Buscar en Balandro[/COLOR]")
        acts.append("balandro")
    if not _ext_off and xbmc.getCondVisibility("System.HasAddon(plugin.video.jacktook)"):
        opts.append("[COLOR mediumpurple]Buscar en Jacktook[/COLOR]")
        acts.append("jacktook")
    if not _ext_off and xbmc.getCondVisibility("System.HasAddon(plugin.video.alfa)"):
        opts.append("[COLOR cyan]Buscar en Alfa[/COLOR]")
        acts.append("alfa")
    if not _ext_off and xbmc.getCondVisibility("System.HasAddon(plugin.video.themoviedb.helper)") and core_settings.is_tmdbhelper_integration_enabled():
        opts.append("[COLOR plum]Abrir en otro addon[/COLOR]")
        acts.append("tmdbhelper")
    if not _ext_off and xbmc.getCondVisibility("System.HasAddon(plugin.video.atresdaily)"):
        opts.append("[COLOR gold]Buscar en AtresDaily[/COLOR]")
        acts.append("atresdaily")
    if not _ext_off and xbmc.getCondVisibility("System.HasAddon(plugin.video.espatv)"):
        opts.append("[COLOR gold]Buscar en EspaTV[/COLOR]")
        acts.append("espatv")
    if not _ext_off and xbmc.getCondVisibility("System.HasAddon(plugin.video.topzilla)"):
        opts.append("[COLOR gold]Buscar en TopZilla[/COLOR]")
        acts.append("topzilla")
    try:
        import search_shortcuts_manager as _ssm
        for _s in _ssm.load_active_shortcuts():
            if _s.get('type') == 'builtin':
                continue
            opts.append(_s.get('name', '?'))
            acts.append(('custom', _s))
    except Exception:
        pass
    sel = xbmcgui.Dialog().select(title, opts)
    if sel < 0:
        return
    act = acts[sel]
    if isinstance(act, tuple) and act[0] == 'custom':
        _cmd = act[1].get('command', '')
        # Un atajo a un addon desactivado no hacía nada; ahora se ofrece activarlo.
        _aid = act[1].get('addon_id')
        if _cmd and (not _aid or ui_utils.addon_listo(_aid, act[1].get('name') or _aid)):
            xbmc.executebuiltin(_cmd.replace('{query}', urllib.parse.quote_plus(q)))
        return
    if act == "buscar":
        xbmc.executebuiltin("Container.Update({0})".format(_u(action="lfr", q=q, ot=ot)))
    elif act == "megabuscador":
        xbmc.executebuiltin("Container.Update({0})".format(_u(action='bt_run', q=q)))
    elif act == "sn":
        if _up.streamninja_check_or_install():
            xbmc.log("[EspaDaily] ep_dialog SN eid={0}".format(eid), xbmc.LOGINFO)
            if eid:
                ep_plugin_url = "{0}?action=play_media&url={1}".format(sys.argv[0], urllib.parse.quote(eid, safe=""))
                safe_url = urllib.parse.quote(ep_plugin_url, safe="")
                xbmc.log("[EspaDaily] ep_dialog SN plugin_url={0}".format(ep_plugin_url), xbmc.LOGINFO)
                xbmc.executebuiltin("RunPlugin(plugin://{0}/?action=url_play&url={1})".format(_up._SN_ID, safe_url))
            else:
                xbmc.log("[EspaDaily] ep_dialog SN sin eid, abriendo SN home", xbmc.LOGWARNING)
                _up.streamninja_open_or_install()
    elif act == "elementum":
        kb = xbmc.Keyboard(q, 'Buscar en webs de torrent')
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            _search_elementum(kb.getText())
    elif act == "youtube":
        xbmc.executebuiltin("Container.Update({0})".format(_u(action='yt_html_search', q=q)))
    elif act == "dm_gujal":
        _search_dailymotion_gujal(q)
    elif act == "palantir":
        if not core_settings.is_palantir_integration_enabled():
            xbmcgui.Dialog().ok("EspaDaily",
                "La búsqueda en Palantir 3 está desactivada.\n\n"
                "Actívala en:\nOpciones → Búsqueda en otros addons → Buscar en Palantir 3")
            return
        kb = xbmc.Keyboard(q, 'Buscar en Palantir 3')
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            _search_palantir(kb.getText())
    elif act == "balandro":
        _search_balandro_from_results(q)
    elif act == "jacktook":
        _search_jacktook_from_results(q)
    elif act == "alfa":
        _search_alfa_from_results(q)
    elif act == "tmdbhelper":
        _search_tmdbhelper(urllib.parse.unquote(sn) if sn else title)
    elif act == "atresdaily":
        _search_in_addon('plugin.video.atresdaily', q, ot)
    elif act == "espatv":
        _search_in_addon('plugin.video.espatv', q, ot)
    elif act == "topzilla":
        _search_in_addon('plugin.video.topzilla', q, ot)


def _rel(items, st, sth="", fmt_prem=False, mas=None):
    for i in items:
        tt = i.get("title", "Capítulo"); en = i.get("name", ""); dt = f"{en} - {tt}" if en else tt

        sq = _bi(st, f"{tt} {en}" if en else tt)
        im = i.get("image", {}); tr = im.get("pathHorizontal") or im.get("pathVertical"); th = _fix_img(tr) or sth
        tag = i.get("tagType", "")
        is_open = i.get("open", False)
        is_prem_ep = (tag in ("EXCLUSIVE", "ORIGINAL", "PREVIEW") or fmt_prem) and not is_open
        ep_label = f"{dt} [COLOR gray][ATP+?][/COLOR]" if is_prem_ep else dt
        li = xbmcgui.ListItem(label=ep_label); li.setArt({'thumb': th, 'icon': th, 'fanart': th})
        li.setInfo('video', {'title': dt, 'plot': i.get('description', '')})

        # Menú contextual: añadir a favoritos (episodio individual)
        _add_fav_cm(li, dt, "atresplayer", "lfr", {"q": sq, "ot": th})

        eid = i.get("id", "")
        if not eid:
            h = i.get("link", {}).get("href", "")
            m = re.search(r'/episode/([a-fA-F0-9]{20,30})', h)
            if m: eid = m.group(1)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ep_dialog", q=sq, ot=th, t=urllib.parse.quote(dt), eid=eid, sn=urllib.parse.quote(st)), listitem=li, isFolder=False)
    if mas:
        numero, url_mas = mas
        li = xbmcgui.ListItem(label=f"[COLOR cyan][B]>> Página Siguiente ({numero})[/B][/COLOR]")
        li.setArt({'icon': ui_utils.media_icon('siguiente.png'), 'fanart': core_settings.addon_fanart()})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url_mas, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _clean_title(t):
    # Si hay dos partes separadas por " : ", quedarse con la segunda (suele ser el titulo real)
    if " : " in t: parts = t.split(" : "); t = parts[1] if len(parts[1]) > len(parts[0]) else parts[0]
    return t.strip() # Devolver limpio

def _lfd(q, ot, mode="", extra_params=None, nh=None, largos_primero=False):
    cq = _clean_title(q)
    rs = []
    min_m = core_settings.get_min_duration()
    if min_m > 0:
        # Los cortos se piden ya filtrados a la API; quitarlos después dejaría la lista a medias.
        extra_params = dict(extra_params or {})
        extra_params.setdefault("longer_than", min_m)
    
    if mode == "movie":
        # Intentar varias combinaciones para encontrar contenido en español
        variations = [
            f"{cq} pelicula completa castellano",
            f"{cq} pelicula completa español",
            f"{cq} pelicula completa",
            f"{cq} completa español",
            f"{cq} castellano",
            cq # Como ultimo recurso, el titulo limpio a secas
        ]
        
        for v in variations:
            rs = _sr(v, extra_params)
            if rs: break # Si encontramos algo, nos quedamos con ello
            
    elif mode == "exact":
        # Busca exactamente lo que el usuario escribió
        rs = _sr(q, extra_params)

    elif mode == "keywords":
        # Busca solo por palabras clave de más de 3 letras
        kw = " ".join([w for w in re.findall(r'\w+', q) if len(w) > 3])
        if kw: rs = _sr(kw, extra_params)

    else:
        # Logica estandar para series/programas (o User, Long, Short)
        # Si es modo User/Long/Short, el 'q' puede ser el termino de busqueda normal, y 'extra_params' lleva el filtro.
        # Intentamos con titulo limpio primero
        rs = _sr(cq, extra_params) 
        if not rs and cq != q: rs = _sr(q, extra_params) # Intentar con el original si el limpio falla
    
    if not rs and mode not in ["exact", "keywords"]: 
        # Ultimo intento: buscar solo palabras clave (mayores de 3 letras)
        kw = " ".join([w for w in re.findall(r'\w+', q) if len(w) > 3])
        if kw: rs = _sr(kw, extra_params)
    
    # Botón de alternativas de búsqueda al inicio de resultados
    _ext_off_alt = core_settings.are_external_integrations_disabled()
    _has_alt_addons = (
        xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)") or
        xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)") or
        (not _ext_off_alt and (
            xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)") or
            xbmc.getCondVisibility("System.HasAddon(plugin.video.palantir3)") or
            xbmc.getCondVisibility("System.HasAddon(plugin.video.balandro)") or
            xbmc.getCondVisibility("System.HasAddon(plugin.video.jacktook)") or
            xbmc.getCondVisibility("System.HasAddon(plugin.video.alfa)") or
            xbmc.getCondVisibility("System.HasAddon(plugin.video.themoviedb.helper)")
        ))
    )
    if _has_alt_addons:
        _alt_label = "[COLOR yellow][B]¿No es lo que buscas?[/B][/COLOR]"
    else:
        _alt_label = "[COLOR yellow][B]Editar búsqueda y reintentar[/B][/COLOR]"
    li_alt = xbmcgui.ListItem(label=_alt_label)
    li_alt.setArt({'icon': ui_utils.media_icon('srch_repetir.png'), 'thumb': ui_utils.media_icon('srch_repetir.png'), 'fanart': core_settings.addon_fanart()})
    li_alt.setInfo('video', {'plot': "Busca en otros addons instalados o edita tu búsqueda."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_alt_prompt", q=cq, ot=ot, mode=mode), listitem=li_alt, isFolder=False)

    if not rs: 
        xbmcgui.Dialog().notification("EspaDaily", "No se encontraron resultados", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    
    sr = _puntuar(cq, rs, largos_primero=largos_primero, peliculas=(mode == "movie"))[:25]
    
    if not sr: 

        if xbmcgui.Dialog().yesno("EspaDaily", "No se encontraron coincidencias relevantes.\n\n¿Quieres editar las palabras clave y probar otra vez?"):
             kb = xbmc.Keyboard(q, 'Editar Búsqueda')
             kb.doModal()
             if kb.isConfirmed():
                 nq = kb.getText()
                 if nq:
                     xbmc.executebuiltin(f"Container.Update({_u(action='lfr', q=nq, ot=ot)})")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    
    # GUARDAR RUTA DE EXPLORACIÓN (solo si hay resultados válidos y no viene del historial)
    if not nh:
        exploration_history.add_exploration(q)
    
    min_dur = core_settings.get_min_duration() * 60
    for _, pct, v in sr:
        vt = v.get("title", "Video"); vi = v.get("id"); ow = v.get("owner.username", "Unknown"); du = v.get("duration", 0)
        try: du = int(du)
        except (ValueError, TypeError): du = 0
        
        # FILTRO ESTRICTO DE DURACIÓN
        if min_dur > 0 and du < min_dur: continue
        dth = v.get("thumbnail_url") or v.get("thumbnail_360_url") or ot
        
        # En modo pelicula mostramos el titulo completo del video encontrado
        if mode == "movie":
             lb = vt
        else:
             lb = f"{vt} ({pct}% match)"

        li = xbmcgui.ListItem(label=lb); li.setArt({'thumb': dth, 'icon': dth})
        li.setInfo('video', {'title': vt, 'plot': f"Subido por: {ow}\nDuración: {du}s", 'duration': du})
        li.setProperty("IsPlayable", "true")
        
        # MENU CONTEXTUAL PARA DESCARGAR Y PALANTIR
        cm = []
        if core_settings.is_palantir_installed() and not core_settings.are_external_integrations_disabled():
            cm.append(("Buscar en Palantir 3", f"RunPlugin({_u(action='palantir_search', q=vt)})"))

        cm.append(("Descargar Video", f"RunPlugin({_u(action='download_video', vid=vi, title=vt)})"))
        cm.append(("Abrir en el navegador", f"RunPlugin({_u(action='dm_open_browser', url=vi)})"))
        li.addContextMenuItems(cm)

        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="pv", vid=vi, title=urllib.parse.quote(vt)), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


_DM_MOTIVOS = {
    "DM003": "Este directo no está emitiendo ahora",
    "DM007": "Su autor lo bloquea en tu país. Con una VPN de otro país puede funcionar",
    "DM016": "Su autor solo deja verlo en la web de Dailymotion",
    "DM020": "Su autor lo ha hecho privado",
}


def _dm_motivo(error):
    code = error.get("code") if isinstance(error, dict) else error
    return _DM_MOTIVOS.get(str(code), "Este vídeo ya no está disponible en Dailymotion")


def _dm_parar_video_anterior():
    try:
        if xbmc.Player().isPlayingVideo():
            xbmc.Player().stop()
    except Exception as exc:
        xbmc.log(f"[EspaDaily] Error al parar video anterior: {exc}", xbmc.LOGWARNING)


def _dm_entregar(url, mime=None, subs=None):
    li = xbmcgui.ListItem(path=url)
    if mime:
        li.setMimeType(mime)
    li.setContentLookup(False)
    if subs and isinstance(subs, list):
        li.setSubtitles(subs)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)


def _dm_fallo(texto):
    try:
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
    except Exception as e:
        # Sin petición de reproducción que cerrar (llamado desde un menú), no hay nada que resolver.
        xbmc.log(f"[EspaDaily] setResolvedUrl tras un fallo de Dailymotion: {e}", xbmc.LOGDEBUG)
    xbmcgui.Dialog().notification("EspaDaily", texto, xbmcgui.NOTIFICATION_ERROR, 5000)


def _dm_por_ytdlp(vid):
    """Lo que saca yt-dlp del vídeo (por el conector), o None si no está o falla."""
    resolver = ui_utils.del_conector("resolve_dm_ytdlp")
    if not resolver:
        return None
    try:
        return resolver(vid)
    except Exception as exc:
        xbmc.log(f"[EspaDaily] yt-dlp con {vid}: {exc}", xbmc.LOGWARNING)
        return None


def _pv(vid, title=""):
    """Gestor principal de reproducción de vídeos Dailymotion."""
    try:
        _dm_parar_video_anterior()

        dm_cfg = _load_dm_settings()
        dm_level = dm_cfg.get('dm_safe_level', 0)
        try:
            max_quality = int(dm_cfg.get('dm_max_quality', 1080))
        except (ValueError, TypeError):
            max_quality = 1080

        d = connector.resolve_video(vid)
        if not d:
            _dm_fallo("Sin conexión con Dailymotion")
            return
        if "error" in d:
            _dm_fallo(_dm_motivo(d["error"]))
            return

        v_title = d.get('title', vid)
        v_thumb = d.get('thumbnail_url') or d.get('thumbnail_360_url', '')
        v_duration = d.get('duration', 0)

        def _record_history():
            try:
                _add_watch_entry(vid, v_title, thumb=v_thumb, duration=v_duration)
            except Exception:
                pass

        _is_windows = xbmc.getCondVisibility("System.Platform.Windows")

        if dm_level == 4:
            result = connector.play_dm(vid, dm_level=1, max_quality=max_quality)
            if result and result.get('url'):
                raw_url = result['url']
                url_part = raw_url.split('|', 1)[0] if '|' in raw_url else raw_url
                headers_part = raw_url.split('|', 1)[1] if '|' in raw_url else ''
                _isa_h = headers_part if headers_part else urllib.parse.urlencode({
                    'User-Agent': "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36",
                    'Referer': "https://www.dailymotion.com/",
                    'Origin': "https://www.dailymotion.com",
                })
                li = xbmcgui.ListItem(path=url_part)
                li.setMimeType(result.get('mime', 'application/x-mpegURL'))
                li.setContentLookup(False)
                li.setProperty("inputstream", "inputstream.adaptive")
                li.setProperty("inputstream.adaptive.manifest_type", "hls")
                li.setProperty("inputstream.adaptive.manifest_headers", _isa_h)
                li.setProperty("inputstream.adaptive.stream_headers", _isa_h)
                subs = result.get('subs')
                if subs and isinstance(subs, list):
                    li.setSubtitles(subs)
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)
                _record_history()
            else:
                _dm_fallo("No se pudo obtener URL para InputStream Adaptive")
            return

        probado_ytdlp = False
        if dm_level == 3:
            probado_ytdlp = True
            info = _dm_por_ytdlp(vid)
            if info and info.get("url"):
                _dm_entregar(info["url"])
                _record_history()
                return
            xbmc.log("[EspaDaily] yt-dlp no está o no devolvió URL, continuando como nivel 0", xbmc.LOGINFO)
            dm_level = 0

        if not _is_windows:
            r = connector.play_dm(vid, dm_level=dm_level, max_quality=max_quality)
            if r and r.get("url"):
                _dm_entregar(r["url"], mime=r.get("mime"), subs=r.get("subs"))
                _record_history()
                return
            if r and "error" in r:
                _dm_fallo(_dm_motivo(r["error"]))
                return

        if _is_windows:
            r = connector.play_dm(vid, dm_level=dm_level, max_quality=max_quality)
            # Sin ninguna variante, el conector devuelve el master de cdndirector, que en
            # Windows da 403: se sigue con la variante del conector y yt-dlp.
            if r and r.get("url") and "cdndirector." not in r["url"]:
                _dm_entregar(r["url"], mime=r.get("mime"), subs=r.get("subs"))
                _record_history()
                return
            if r and "error" in r:
                _dm_fallo(_dm_motivo(r["error"]))
                return

            variante = ui_utils.del_conector("resolve_dm_variant")
            if variante:
                try:
                    res = variante(vid, max_height=max_quality)
                except Exception as exc:
                    xbmc.log(f"[EspaDaily] resolve_dm_variant falló: {exc}", xbmc.LOGWARNING)
                    res = None
                if res and res.get("url"):
                    _dm_entregar(res["url"], mime=res.get("mime"), subs=res.get("subs"))
                    _record_history()
                    return

            if not probado_ytdlp:
                info = _dm_por_ytdlp(vid)
                if info and info.get("url"):
                    _dm_entregar(info["url"])
                    _record_history()
                    return

        if xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.dailymotion_com)"):
            _dm_entregar(f"plugin://plugin.video.dailymotion_com/?url={vid}&mode=playVideo")
            _record_history()
            return

        if _is_windows:
            dm_web_url = connector.dm_web(vid) if hasattr(connector, "dm_web") else ""
            if dm_web_url and xbmcgui.Dialog().yesno(
                "Error Kodi/Windows",
                "Dailymotion suele bloquear Kodi en plataformas Windows devolviendo errores 403 HTTP.\n\n"
                "No se pudo resolver el enlace nativamente.\n¿Quieres abrir este episodio en el Navegador Web?\n\n"
                "[I](Si eliges 'No' cancelará la reproducción)[/I]",
                yeslabel="Navegador Web", nolabel="Cancelar"
            ):
                try:
                    import webbrowser
                    webbrowser.open(dm_web_url)
                    xbmcgui.Dialog().notification("EspaDaily", "Enlace enviado al navegador", xbmcgui.NOTIFICATION_INFO)
                except Exception:
                    xbmcgui.Dialog().ok("EspaDaily", f"Abre la siguiente URL en tu navegador de internet:\n\n{dm_web_url}")
                _record_history()
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
                return
            else:
                _dm_fallo("Este vídeo ya no está disponible en Dailymotion")
                return

        _dm_fallo("Este vídeo ya no está disponible en Dailymotion")
        return

    except Exception as e:
        xbmc.log(f"[EspaDaily] Error al reproducir el vídeo {vid}: {e}", xbmc.LOGERROR)
        _dm_fallo("Error al reproducir el vídeo")

def _download_video(vid, title):
    if not vid: return
    # Las cabeceras y la dirección de Dailymotion las da el conector.
    cabeceras = ui_utils.del_conector("dm_cabeceras")
    dm_web = ui_utils.del_conector("dm_web")
    if not (cabeceras and dm_web):
        return

    try:
        d = connector.resolve_video(vid)
        if not d:
            xbmcgui.Dialog().ok("EspaDaily", "No se pudo resolver el video para descarga.")
            return
        qs = d.get("qualities") or {}
        
        all_links = []
        
        # 1. Buscar enlaces MP4 directos
        for res_key, formats in qs.items():
            if res_key == "auto": continue
            for f in formats:
                u = f.get("url")
                if not u: continue
                if f.get("type") == "video/mp4":
                    res_val = int(res_key) if res_key.isdigit() else 0
                    all_links.append({'label': f"{res_key}p (Descarga Directa MP4)", 'url': u, 'res': res_val, 'type': 'mp4'})
        
        # 2. Buscar HLS (M3U8) como fallback
        m3u8_master = ""
        if "auto" in qs:
            for s in qs["auto"]:
                if s.get("type") == "application/x-mpegURL":
                    m3u8_master = s.get("url", "")
                    vs = connector.fetch_hls_variants(m3u8_master)
                    for v in vs:
                        rs_str = v['label'].split(' ')[0]
                        res_val = int(rs_str.split('x')[1]) if 'x' in rs_str else 0
                        all_links.append({'label': f"{rs_str} (HLS por Segmentos .TS)", 'url': v['url'], 'res': res_val, 'type': 'hls'})
                    if m3u8_master:
                        all_links.append({'label': "ULTRA (Mejor calidad via yt-dlp)", 'url': m3u8_master, 'res': 99999, 'type': 'ultra'})

        # Ordenar por resolucion
        all_links.sort(key=lambda x: x['res'], reverse=True)

        if not all_links:
            xbmcgui.Dialog().ok("EspaDaily", "No se han encontrado enlaces de descarga para este contenido.\n\nEl servidor puede estar bloqueando el acceso directo a este video.")
            return

        # Leer modo de descarga configurado
        dm_cfg = _load_dm_settings()
        dl_mode = dm_cfg.get('dl_mode', 0)

        # Modo 0 (DIRECTO): Mostrar menú de selección (comportamiento actual)
        if dl_mode == 0:
            lbs = [l['label'] for l in all_links]
            sel = xbmcgui.Dialog().select("Selecciona Calidad de Descarga", lbs)
            if sel < 0: return
            target = all_links[sel]
        # Modo 1 (SAFE MODE): Mejor MP4 directo disponible
        elif dl_mode == 1:
            mp4s = [l for l in all_links if l['type'] == 'mp4']
            if mp4s:
                target = mp4s[0]
            else:
                xbmcgui.Dialog().ok("EspaDaily", "No hay enlaces MP4 directos.\nCambia a modo ULTRA en ajustes.")
                return
        # Modo 2 (ESPADAILY): Mejor HLS disponible
        elif dl_mode == 2:
            hls_links = [l for l in all_links if l['type'] == 'hls']
            if hls_links:
                target = hls_links[0]
            else:
                xbmcgui.Dialog().ok("EspaDaily", "No hay enlaces HLS disponibles.\nCambia a modo ULTRA en ajustes.")
                return
        # Modo 3 (YT-DLP) y 4 (ULTRA): Usar yt-dlp
        else:
            ultra = [l for l in all_links if l['type'] == 'ultra']
            if ultra:
                target = ultra[0]
            else:
                mp4s = [l for l in all_links if l['type'] == 'mp4']
                target = mp4s[0] if mp4s else all_links[0]
        
        # Pedir directorio de destino
        path = xbmcgui.Dialog().browse(3, 'Selecciona dónde guardar el video', 'video', '', False, False, dm_cfg.get('download_path', ''))
        if not path: return
        
        # Confirmar HLS si aplica
        if target['type'] == 'hls':
            if not xbmcgui.Dialog().yesno("Descarga HLS", "Este video no tiene enlace directo.\nSe bajará por segmentos y se unirán al final.\n\nEs un proceso lento. ¿Continuar?"):
                return

        # Preparar nombres de archivo
        safe_title = "".join([c for c in title if c.isalnum() or c in ' -_']).strip()
        if not safe_title: safe_title = vid
        ext = ".mp4" if target['type'] in ('mp4', 'ultra') else ".ts"
        dest = os.path.join(path, f"{safe_title}{ext}")
        

        if target['type'] == 'mp4':
            _do_download_direct(target['url'], dest, title, vid, cabeceras(movil=True))
        elif target['type'] == 'ultra':
            _do_download_ultra(vid, dest, title, dm_web(vid))
        else:
            _do_download_hls(target['url'], dest, title, cabeceras(movil=True))
            
    except Exception as e:
        _log_error(f"Download Error video {vid}: {str(e)}")
        xbmcgui.Dialog().ok("EspaDaily Error", f"Error al preparar descarga: {str(e)}")

def _do_download_direct(url, dest, title, vid, dm_h):
    dp = xbmcgui.DialogProgress()
    dp.create("Descargando MP4", f"Conectando: {title}")
    tmp_dest = dest + ".tmp"
    try:
        clean_url = url.split('|')[0] if '|' in url else url
        with requests.get(clean_url, headers=dm_h, stream=True, timeout=30) as r:
            # Sin esto, la página de un 403 se guardaba como vídeo.
            r.raise_for_status()
            total = int(r.headers.get('content-length', 0))
            done = 0
            with open(tmp_dest, 'wb') as f:
                for chunk in r.iter_content(chunk_size=1024*256):
                    if dp.iscanceled(): break
                    f.write(chunk)
                    done += len(chunk)
                    if total > 0:
                        percent = int(done * 100 / total)
                        msg = f"Descargado: {done/(1024*1024):.1f}MB / {total/(1024*1024):.1f}MB"
                        dp.update(percent, msg)
        cancelled = dp.iscanceled()
        dp.close()
        if not cancelled:
            os.replace(tmp_dest, dest)
            # Antes usaba un vid que no existía aquí, y el NameError llegaba tras guardar el
            # vídeo y se anunciaba "Error en transferencia" con la descarga ya hecha.
            core_settings.log_download(title, dest, vid)
            xbmcgui.Dialog().ok("¡Éxito!", f"Video guardado correctamente en:\n{dest}")
        elif os.path.exists(tmp_dest):
            os.remove(tmp_dest)
    except Exception as e:
        if 'dp' in locals(): dp.close()
        if os.path.exists(tmp_dest): os.remove(tmp_dest)
        _log_error(f"Error Direct DL: {str(e)}")
        xbmcgui.Dialog().ok("Error", f"Error en transferencia: {str(e)}")

def _do_download_hls(playlist_url, dest, title, dm_h):
    dp = xbmcgui.DialogProgress()
    dp.create("Descargando HLS", "Obteniendo segmentos...")
    clean_url = playlist_url.split('|')[0] if '|' in playlist_url else playlist_url
    # Antes del try, porque si fallaba la descarga de la lista el except usaba tmp_dest sin asignar.
    tmp_dest = dest + ".tmp"
    try:
        params = urllib.parse.urlsplit(clean_url).query

        r = requests.get(clean_url, headers=dm_h, timeout=15)
        r.raise_for_status()
        m3u8_content = r.text
        segments = [l.strip() for l in m3u8_content.splitlines() if l.strip() and not l.startswith('#')]
        total_seg = len(segments)

        if total_seg == 0:
            dp.close()
            xbmcgui.Dialog().ok("Error", "La lista de reproducción está vacía."); return

        with open(tmp_dest, 'wb') as f_out:
            for idx, seg_name in enumerate(segments):
                if dp.iscanceled(): break

                # urljoin y no concatenar, porque una URI que empieza por "/" es relativa a la
                # raíz del host. Los parámetros de la lista siguen yendo a los segmentos
                # relativos que no traen los suyos, como antes.
                seg_url = urllib.parse.urljoin(clean_url, seg_name)
                if params and not seg_name.startswith('http') and '?' not in seg_name:
                    seg_url += '?' + params

                success = False
                for attempt in range(3):
                    try:
                        sr = requests.get(seg_url, headers=dm_h, timeout=12)
                        # Sin mirar el código, la página de un 403 o 404 acababa dentro del vídeo.
                        if sr.status_code == 200:
                            f_out.write(sr.content)
                            success = True
                            break
                    except requests.RequestException:
                        pass
                    if attempt < 2:
                        time.sleep(1 << attempt)

                if not success: raise Exception(f"Fallo crítico en segmento {idx+1}")
                
                percent = int((idx + 1) * 100 / total_seg)
                msg = f"Segmento {idx+1}/{total_seg} - {title}"
                dp.update(percent, msg)
        
        cancelled = dp.iscanceled()
        dp.close()
        if not cancelled:
            os.replace(tmp_dest, dest)
            core_settings.log_download(title, dest, "HLS")
            xbmcgui.Dialog().ok("¡Completado!", f"El video HLS se ha unido y guardado en:\n{dest}")
        elif os.path.exists(tmp_dest):
            os.remove(tmp_dest)
    except Exception as e:
        if 'dp' in locals(): dp.close()
        if os.path.exists(tmp_dest): os.remove(tmp_dest)
        _log_error(f"HLS Merge Error: {str(e)}")
        xbmcgui.Dialog().ok("Error Union HLS", f"Fallo: {str(e)}")

def _get_ytdlp_pkg_path():
    """Devuelve la ruta de paquetes yt-dlp en addon_data."""
    profile = xbmcvfs.translatePath(
        xbmcaddon.Addon().getAddonInfo('profile')
    )
    pkg_path = os.path.join(profile, "packages")
    if not os.path.exists(pkg_path):
        os.makedirs(pkg_path)
    return pkg_path


def _ensure_ytdlp():
    """Descarga yt-dlp wheel desde PyPI si no existe en addon_data/packages."""
    import io
    pkg_path = _get_ytdlp_pkg_path()
    ytdlp_dir = os.path.join(pkg_path, "yt_dlp")
    if os.path.isdir(ytdlp_dir):
        return True

    try:
        pypi_r = requests.get("https://pypi.org/pypi/yt-dlp/json", timeout=15)
        if pypi_r.status_code != 200:
            return False
        whl_url = None
        for u in pypi_r.json().get("urls", []):
            if u["filename"].endswith(".whl") and "py3-none-any" in u["filename"]:
                whl_url = u["url"]
                break
        if not whl_url:
            return False
        whl_r = requests.get(whl_url, timeout=120)
        if whl_r.status_code != 200:
            return False
        whl_data = io.BytesIO(whl_r.content)
        with zipfile.ZipFile(whl_data) as zf:
            for member in zf.namelist():
                if member.startswith("yt_dlp/"):
                    zf.extract(member, pkg_path)
        return os.path.isdir(ytdlp_dir)
    except Exception as e:
        _log_error(f"Error descargando yt-dlp: {str(e)}")
    return False


def _find_system_python():
    """Busca un Python del sistema >= 3.10 que pueda ejecutar yt-dlp."""
    import subprocess
    no_win = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
    for py in ["python", "python3", "py"]:
        try:
            r = subprocess.run(
                [py, "-c", "import sys; v=sys.version_info; print(f'{v.major}.{v.minor}'); assert v >= (3,10)"],
                capture_output=True, text=True, timeout=5,
                creationflags=no_win
            )
            if r.returncode == 0:
                return py
        except Exception:
            continue
    return None


def _write_dl_helper(pkg_path, url, dest, progress_file):
    """Genera un script Python que descarga con yt-dlp y escribe progreso."""
    helper_path = os.path.join(pkg_path, "_dl_helper.py")
    script = f'''
import sys, os, json
sys.path.insert(0, {repr(pkg_path)})
import yt_dlp

progress_file = {repr(progress_file)}

def hook(d):
    info = {{"status": d.get("status", ""), "percent": 0, "text": ""}}
    if d["status"] == "downloading":
        total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
        done = d.get("downloaded_bytes", 0)
        speed = d.get("speed") or 0
        if total > 0:
            info["percent"] = int(done * 100 / total)
            mb_d = done / (1024*1024)
            mb_t = total / (1024*1024)
            sp = speed / (1024*1024) if speed else 0
            info["text"] = f"{{mb_d:.1f}}MB / {{mb_t:.1f}}MB ({{sp:.1f}} MB/s)"
        elif done > 0:
            info["percent"] = 50
            info["text"] = f"Descargando: {{done/(1024*1024):.1f}}MB"
    elif d["status"] == "finished":
        info["percent"] = 95
        info["text"] = "Finalizando..."
    with open(progress_file, "w") as f:
        json.dump(info, f)

opts = {{
    "format": "best[ext=mp4]/best",
    "outtmpl": {repr(dest)},
    "quiet": True,
    "no_warnings": True,
    "progress_hooks": [hook],
    "noprogress": True,
}}
url = {repr(url)}
try:
    ydl = yt_dlp.YoutubeDL(opts)
    ydl.download([url])
    with open(progress_file, "w") as f:
        json.dump({{"status": "done", "percent": 100, "text": "Completado"}}, f)
except Exception as e:
    with open(progress_file, "w") as f:
        json.dump({{"status": "error", "percent": 0, "text": str(e)[:300]}}, f)
'''
    with open(helper_path, 'w', encoding='utf-8') as f:
        f.write(script)
    return helper_path


def _do_download_ultra(vid, dest, title, url):
    """Modo ULTRA: Descarga via yt-dlp (helper script + system Python). `url` es la del vídeo
    en la web de Dailymotion, que da el conector."""
    import subprocess

    # El id acaba dentro de un script que ejecuta el Python del sistema. Llega en la URL del
    # plugin, que puede lanzar cualquiera (otro addon, un favorito, JSON-RPC), así que solo
    # se aceptan ids de Dailymotion.
    if not re.fullmatch(r'[A-Za-z0-9]{1,32}', vid or ''):
        xbmcgui.Dialog().ok("EspaDaily", "Identificador de vídeo no válido.")
        return

    # Android/dispositivos sin Python del sistema: informar
    if xbmc.getCondVisibility("System.Platform.Android"):
        xbmcgui.Dialog().ok(
            "EspaDaily",
            "Las descargas de Dailymotion no están\n"
            "disponibles en Android.\n\n"
            "Dailymotion bloquea descargas directas.\n"
            "Usa un PC con Python 3.10+ instalado."
        )
        return

    try:
        if xbmcvfs.exists(dest):
            if not xbmcgui.Dialog().yesno("EspaDaily", "El archivo ya existe. ¿Sobrescribir?"): return
            xbmcvfs.delete(dest)

        dp = xbmcgui.DialogProgress()
        dp.create("Descargando (Modo ULTRA)", "Preparando...")

        if not dest.endswith(".mp4"):
            dest = os.path.splitext(dest)[0] + ".mp4"

        # 1. Buscar Python del sistema >= 3.10
        dp.update(2, "Buscando Python del sistema...")
        py_cmd = _find_system_python()
        if not py_cmd:
            dp.close()
            xbmcgui.Dialog().ok(
                "EspaDaily",
                "Se necesita Python 3.10+ instalado en el sistema.\n\n"
                "Descárgalo de python.org e instálalo\n"
                "marcando 'Add to PATH'.\n\n"
                "Después reinicia Kodi."
            )
            return

        # 2. Descargar yt-dlp si no existe
        pkg_path = _get_ytdlp_pkg_path()
        ytdlp_dir = os.path.join(pkg_path, "yt_dlp")
        if not os.path.isdir(ytdlp_dir):
            dp.update(5, "Descargando componente yt-dlp (~3MB)...")
            if not _ensure_ytdlp():
                dp.close()
                xbmcgui.Dialog().ok("EspaDaily", "Error descargando yt-dlp.\nComprueba tu conexión a internet.")
                return

        # 3. Generar y ejecutar script auxiliar
        dp.update(10, "Iniciando descarga...")
        progress_file = os.path.join(pkg_path, "_dl_progress.json")
        if os.path.exists(progress_file):
            os.remove(progress_file)

        helper_path = _write_dl_helper(pkg_path, url, dest, progress_file)
        no_win = getattr(subprocess, 'CREATE_NO_WINDOW', 0)

        # stdout a DEVNULL, porque nadie lo lee y una tubería llena bloquearía al proceso.
        proc = subprocess.Popen(
            [py_cmd, helper_path],
            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
            creationflags=no_win
        )

        # 4. Polling de progreso. waitForAbort y no time.sleep, para que al cerrar Kodi no
        # siga descargando.
        monitor = xbmc.Monitor()
        cancelled = False
        while proc.poll() is None:
            if dp.iscanceled() or monitor.waitForAbort(0.5):
                cancelled = True
                proc.kill()
                proc.wait(5)
                break
            if os.path.exists(progress_file):
                try:
                    with open(progress_file, 'r') as f:
                        info = json.loads(f.read())
                    dp.update(info.get("percent", 0), info.get("text", "Descargando..."))
                except (OSError, ValueError):
                    pass  # el ayudante lo está reescribiendo

        dp.close()

        # Limpiar script auxiliar
        for tmp in [helper_path, progress_file]:
            if os.path.exists(tmp):
                try: os.remove(tmp)
                except OSError: pass

        if cancelled:
            # yt-dlp deja también .ytdl y, en las listas HLS, fragmentos .part-FragN.
            carpeta, base = os.path.split(dest)
            try:
                restos = [n for n in os.listdir(carpeta)
                          if n in (base, base + '.part', base + '.ytdl') or n.startswith(base + '.part-Frag')]
            except OSError:
                restos = []
            for n in restos:
                try: os.remove(os.path.join(carpeta, n))
                except OSError: pass
            return

        # Leer resultado final
        if proc.returncode == 0 and os.path.exists(dest):
            core_settings.log_download(title, dest, "MP4 (ULTRA)")
            xbmcgui.Dialog().ok("EspaDaily", "¡Descarga ULTRA completada!")
        else:
            stderr = ""
            try:
                stderr = proc.stderr.read().decode('utf-8', errors='replace')[:200]
            except Exception:
                pass
            raise Exception(f"yt-dlp falló (código {proc.returncode}): {stderr}")

    except Exception as e:
        if 'dp' in locals(): dp.close()
        for ext in [".part", ".tmp"]:
            p = dest + ext
            if os.path.exists(p):
                try: os.remove(p)
                except Exception: pass
        _log_error(f"Ultra Error: {str(e)}")
        xbmcgui.Dialog().ok("Error Ultra", f"Fallo en descarga Ultra:\n{str(e)}")

def _sr(q, extra_params=None):
    # access_error dice qué vídeos no se pueden ver; con él, filtrar_dm_borrados no
    # tiene que hacer otra consulta. Se piden de más por los que se van a ocultar.
    p = {"fields": "id,title,owner.username,duration,thumbnail_360_url,thumbnail_720_url,access_error",
         "limit": ui_utils.dm_limite_lista(50)}
    if core_settings.is_recent_active():
        p["sort"] = "recent"
    if extra_params:
        p.update(extra_params)
    rs = None
    if connector:
        try:
            rs = connector.search_dailymotion(q, p)
        except Exception as e:
            xbmc.log(f"[EspaDaily] búsqueda DM por el conector: {e}", xbmc.LOGWARNING)
    return ui_utils.filtrar_dm_borrados(rs or [], cuantos=50)

def _puntuar(q, rs, largos_primero=False, peliculas=False):
    """Resultados ordenados por parecido con la búsqueda: [(puntos, %, vídeo)]. Lo calcula el
    conector (puntuar_dm, que también usa la WebApp) con los ajustes de búsqueda del addon."""
    puntuar = ui_utils.del_conector("puntuar_dm")
    if not puntuar:
        return []
    addon = xbmcaddon.Addon()
    return puntuar(q, rs, largos_primero=largos_primero, peliculas=peliculas,
                   por_duracion=not core_settings.is_prioritize_match_active(),
                   exigir_numero=addon.getSetting('dm_exigir_numero') == 'true',
                   exigir_palabras=addon.getSetting('dm_exigir_palabras') == 'true')


def _gsr(q, rs, mode=""):
    """Resultados ordenados por parecido, como [(puntos, vídeo)]. _show_fav_news se
    queda con los de más de 0,35 puntos."""
    return [(s, v) for s, _, v in _puntuar(q, rs, peliculas=(mode == "movie"))]



def _show_fav_news():
    """Agregador: Busca contenido reciente de los favoritos con margen dinámico."""
    favs = core_settings.get_favorites()
    if not favs:
        xbmcgui.Dialog().notification("EspaDaily", "No tienes favoritos guardados", xbmcgui.NOTIFICATION_WARNING)
        return
        
    # 1. Preguntar margen
    opts = [
        "Últimas 24 horas",
        "Últimas 48 horas (Recomendado)",
        "Última semana (7 días)",
        "Último mes (30 días - Lento)"
    ]
    sel = xbmcgui.Dialog().select("Margen de búsqueda de Novedades", opts)
    if sel < 0: return # Cancelado
    
    margins = [86400, 172800, 604800, 2592000]
    time_limit = int(time.time()) - margins[sel]
    sel_label = opts[sel]

    pdp = xbmcgui.DialogProgress()
    pdp.create("Novedades de mis Favoritos", f"Buscando: {sel_label}...")
    
    all_results = []
    
    queries = []
    seen = set()
    for f in favs:
        q = None
        if f.get('action') == 'lfr':
            params = f.get('params')
            q = params.get('q') if isinstance(params, dict) else None
        elif f.get('action') in ['ls', 'ls_rtve', 'ls_mediaset', 'fs', 'fs_rtve']:
            q = str(f.get('title') or '')
            if ": " in q: q = q.split(": ")[-1]

        # Un favorito con campos de tipo raro no puede dejar sin Novedades a los demás.
        if isinstance(q, str) and q and q.lower() not in seen:
            queries.append(q)
            seen.add(q.lower())
            
    if not queries:
        pdp.close()
        xbmcgui.Dialog().ok("Mi Periódico", "No hay series o búsquedas en favoritos para analizar.")
        return

    total = len(queries)
    for i, q in enumerate(queries):
        if pdp.iscanceled(): break
        pdp.update(int((i / max(total, 1)) * 100), f"Analizando: [B]{q}[/B]")
        
        rs = _sr(q, {"created_after": time_limit})
        if rs:
            sr = _gsr(q, rs, mode="keywords") 
            for score, v in sr:
                if score > 0.35: # Filtro de calidad para evitar basura
                    vid = v.get("id")
                    if not any(r[1].get("id") == vid for r in all_results):
                        all_results.append((score, v, q))

    pdp.close()
    
    if not all_results:
        xbmcgui.Dialog().ok("Novedades de mis Favoritos", f"No se han encontrado novedades en '{sel_label}' para tus favoritos.")
        return

    # Mostrar resultados consolidados
    h = int(sys.argv[1])
    all_results.sort(key=lambda x: x[0], reverse=True)
    xbmcplugin.setContent(h, 'videos')
    
    for score, v, origin in all_results:
        vt = v.get("title", "Video"); vi = v.get("id"); ow = v.get("owner.username", "Unknown"); du = v.get("duration", 0)
        try: du = int(du)
        except (ValueError, TypeError): du = 0
        dth = v.get("thumbnail_url") or v.get("thumbnail_360_url")
        
        label = f"[COLOR yellow][{origin}][/COLOR] {vt}"
        li = xbmcgui.ListItem(label=label)
        li.setArt({'thumb': dth, 'icon': dth})
        li.setInfo('video', {'title': vt, 'plot': f"Favorito: {origin}\nSubido por: {ow}\nDuración: {du}s", 'duration': du})
        li.setProperty("IsPlayable", "true")
        
        cm = []
        if core_settings.is_palantir_installed() and not core_settings.are_external_integrations_disabled():
            cm.append(("Buscar en Palantir 3", f"RunPlugin({_u(action='palantir_search', q=vt)})"))
        cm.append(("Descargar Video", f"RunPlugin({_u(action='download_video', vid=vi, title=vt)})"))
        cm.append(("Abrir en el navegador", f"RunPlugin({_u(action='dm_open_browser', url=vi)})"))
        li.addContextMenuItems(cm)

        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="pv", vid=vi, title=urllib.parse.quote(vt)), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)

def _show_favorites():
    favs = core_settings.get_favorites()
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)
    _fanart = core_settings.addon_fanart()

    _FLOWFAV_REPO_ID = 'repository.flowfavmanager'
    _FLOWFAV_ADDON_ID = 'plugin.program.flowfavmanager'
    try:
        xbmcaddon.Addon(_FLOWFAV_ADDON_ID)
        li_flow = xbmcgui.ListItem(label="[COLOR violet][B]Flow FavManager[/B][/COLOR]")
        li_flow.setArt({'icon': _mi('fav_gestor.png'), 'fanart': _fanart})
        li_flow.setInfo('video', {'plot': 'Abre el editor avanzado de favoritos de Kodi.\nOrganiza, personaliza colores, iconos, formatos, crea secciones, perfiles y copias de seguridad.'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="open_flowfav"), listitem=li_flow, isFolder=False)
    except Exception:
        li_flow = xbmcgui.ListItem(label="[COLOR gray]Flow FavManager (No instalado)[/COLOR]")
        li_flow.setArt({'icon': _mi('fav_gestor.png'), 'fanart': _fanart})
        li_flow.setInfo('video', {'plot': 'Gestor avanzado de favoritos para Kodi.\nPulsa para instalar o ver instrucciones.'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="flowfav_install"), listitem=li_flow, isFolder=False)


    cats = category_manager.load_cats()
    if cats:
         li_c = xbmcgui.ListItem(label=f"[COLOR yellow][B]Mis Categorías ({len(cats)})[/B][/COLOR]")
         li_c.setArt({'icon': _mi('categorias_usuario.png'), 'fanart': _fanart})
         li_c.setInfo('video', {'plot': "Accede a tus carpetas y listas personalizadas ('Infantil', 'Noticias', etc).\n\nPuedes crear nuevas categorías desde el menú principal."})
         xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="cat_menu"), listitem=li_c, isFolder=True)


    if favs:
         li_n = xbmcgui.ListItem(label="[COLOR yellow][B]Novedades de mis Favoritos[/B][/COLOR]")
         li_n.setArt({'icon': _mi('fav_novedades.png'), 'fanart': _fanart})
         li_n.setInfo('video', {'plot': "Analiza automáticamente tus favoritos y busca contenido subido recientemente.\n\nPodrás elegir el margen de tiempo (24h, 48h, 7 días...).\n\nIdeal para ver qué hay de nuevo sin ir sección por sección."})
         xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fav_news"), listitem=li_n, isFolder=True)


    if not favs:
        if not cats: # Only show 'empty' if no cats either
             li = xbmcgui.ListItem(label="No tienes favoritos guardados")
             li.setArt({'icon': _mi('fav_vacio.png'), 'fanart': _fanart})
             li.setInfo('video', {'plot': "Haz clic derecho en cualquier programa o serie y selecciona 'Añadir a Mis Favoritos' para guardarlo aquí."})
             xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)
    else:
        # Favoritos cuya acción abre un teclado (no idempotente): folder=False, para que al
        # cancelar o volver atrás no se relance el prompt ni se salga del addon. El resto (lfr,
        # fs..., contenido navegable) se queda como carpeta.
        prompt_fav_actions = {"execute_adv_search", "search_atres_catalog", "search_mediaset_catalog",
                              "search_rtve_catalog", "search_elementum_prompt", "multi_search", "bt_search"}
        for f in favs:
            # Tipos comprobados, porque un favorites.json antiguo o editado a mano con un número o una
            # lista en estos campos tumbaba el menú entero.
            f = dict(f, title=str(f.get('title') or f['url']),
                     icon=f.get('icon') if isinstance(f.get('icon'), str) and f.get('icon') else ICON_MAIN,
                     action=f.get('action') if isinstance(f.get('action'), str) and f.get('action') else 'search',
                     params=f.get('params') if isinstance(f.get('params'), dict) else {})
            li = xbmcgui.ListItem(label=f['title'])
            li.setArt({'icon': f['icon'], 'thumb': f['icon'], 'fanart': _fanart})
        
            cm = []
            

            if core_settings.is_palantir_installed() and not core_settings.are_external_integrations_disabled():
                cm.append(("Buscar en Palantir 3", f"RunPlugin({_u(action='palantir_search', q=f['title'])})"))
            
            # Buscar en torrents (Elementum). Los torrents en sí son legales. Es más, en muchas webs los enlaces son legales.
            # Solo busca el tíulo, no enlaces. Los enlaces los buscará Elementum por su cuenta y riesgo.
            cm.append(("Buscar en webs de torrent", f"RunPlugin({_u(action='elementum_search', q=f['title'])})"))


            cm.append(("Editar nombre y buscar", f"RunPlugin({_u(action='edit_and_search', q=f['title'], ot=f['icon'])})"))

            cm.append(("Renombrar...", f"RunPlugin({_u(action='fav_rename', fav_url=f['url'], old_title=f['title'])})"))
            cm.append(("Mover arriba", f"RunPlugin({_u(action='fav_move_up', fav_url=f['url'])})"))
            cm.append(("Mover abajo", f"RunPlugin({_u(action='fav_move_down', fav_url=f['url'])})"))
            

            # Usar 'cat_move_from_favs' para MOVER (borra de favs y añade a cat) en lugar de solo añadir.
            cm.append(("Mover a Categoría...", f"RunPlugin({_u(action='cat_move_from_favs', fav_url=f['url'], q=f['title'])})"))
            

            cm.append(("Eliminar de Favoritos", f"RunPlugin({_u(action='remove_favorite', fav_url=f['url'])})"))
            
            li.addContextMenuItems(cm)
            
            # Reconstruir la URL con la acción y parámetros guardados
            # URL que se abre al hacer clic en el favorito:
            u_params = f"action={f['action']}"
            for k,v in f.get('params', {}).items():
                u_params += f"&{k}={urllib.parse.quote(str(v))}"
            

            if f['action'] == 'lfr' and '&nh=' not in u_params:
                u_params += "&nh=1"

            # play_dm reproduce con setResolvedUrl, que exige un ítem IsPlayable y no carpeta.
            reproducible = f['action'] == 'play_dm'
            if reproducible:
                li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sys.argv[0]+"?"+u_params, listitem=li,
                                        isFolder=not reproducible and f['action'] not in prompt_fav_actions)


    _bfav_icon = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'adv_backup.png')
    li = xbmcgui.ListItem(label="[COLOR cyan]Backup de Favoritos[/COLOR]")
    li.setArt({'icon': _bfav_icon, 'fanart': _fanart})
    li.setInfo('video', {'plot': "Exportar o importar favoritos en formato JSON."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fav_backup_menu"), listitem=li, isFolder=True)



    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _fav_backup_menu():
    h = int(sys.argv[1])
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    _fanart = core_settings.addon_fanart()
    li = xbmcgui.ListItem(label="[COLOR cyan]Exportar Favoritos...[/COLOR]")
    li.setArt({'icon': os.path.join(_med, 'backup_favs.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Guarda tus favoritos principales en un archivo JSON para compartirlos."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="fav_export"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR cyan]Importar Favoritos...[/COLOR]")
    li.setArt({'icon': ui_utils.media_icon('backup_restore.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Carga favoritos desde un archivo JSON."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="fav_import"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)

def _show_downloads():
    dls = core_settings.get_downloads()
    if not dls:
        li = xbmcgui.ListItem(label="No hay historial de descargas")
        li.setArt({'icon': ui_utils.media_icon('descargas_vacias.png'), 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'plot': "Cuando descargues un vídeo con éxito, aparecerá aquí.\nPuedes descargar vídeos desde los resultados de búsqueda pulsando clic derecho.\n\nDescargo de responsabilidad:\nEspaDaily no almacena ni distribuye contenido.\nLas descargas se realizan directamente desde las fuentes públicas de internet.\nEl usuario es el único responsable del uso que haga de esta función y de cumplir la legislación vigente en su país."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)
    else:
        import grabaciones
        grabando = {info.get('ruta'): k for k, info in grabaciones.en_marcha().items() if info.get('ruta')}
        for d in dls:
            path = d.get('path', '')
            title = d.get('title', 'Desconocido')
            date = d.get('date', '')

            k = grabando.get(path)
            if k:
                stop = f"RunPlugin({_u(action='iptv_record_stop', k=k, refresh='1')})"
                icon_path = ui_utils.media_icon("archivo_video.png")
                li = xbmcgui.ListItem(label=f"{grabaciones.MARCA}{title} ({date})")
                li.setArt({'icon': icon_path, 'thumb': icon_path})
                li.setInfo('video', {'title': title, 'plot': f"{path}\n\nSe está grabando. Púlsala para pararla."})
                li.addContextMenuItems([("Parar la grabación", stop)])
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action='iptv_record_stop', k=k, ask='1', refresh='1'), listitem=li, isFolder=False)
                continue

            if not os.path.exists(path):
                label = f"[COLOR grey][ELIMINADO][/COLOR] {title}"
                is_valid = False
            else:
                label = f"{title} ({date})"
                is_valid = True
                
            li = xbmcgui.ListItem(label=label)
            li.setArt({'icon': 'DefaultVideo.png'})
            li.setInfo('video', {'title': title, 'plot': f"Archivo: {path}\nDescargado el: {date}"})
            
            cm = [("Quitar del historial", f"RunPlugin({_u(action='remove_download', dl_path=path)})")]
            if is_valid:
                 li.setProperty("IsPlayable", "true")
                 cm.append(("[COLOR red]ELIMINAR ARCHIVO DEL DISCO[/COLOR]", f"RunPlugin({_u(action='delete_download_file', dl_path=path, title=title)})"))
             
                 u = path
            else:
                 u = ""
                 
            li.addContextMenuItems(cm)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=li, isFolder=False if is_valid else True)
        
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _add_fav_cm(li, title, platform, action, params):
    # URL para favoritos
    # ID unico para no duplicar (Atr3splay3r usa 'au')
    id_val = params.get('cid') or params.get('pid') or params.get('url') or params.get('au') or params.get('q')
    if not id_val:
        # Fallback: hash de params
        id_val = str(hash(json.dumps(params, sort_keys=True)))
    fav_url = f"{action}_{id_val}"
    params_json = json.dumps(params)
    li.addContextMenuItems([
        ("Añadir a Mis Favoritos", f"RunPlugin({_u(action='add_favorite', title=title, fav_url=fav_url, icon=li.getArt('icon'), platform=platform, fav_action=action, params=params_json)})")
    ])

def _delete_download_file(path, title):
    if xbmcgui.Dialog().yesno("Eliminar Archivo", f"¿Estás seguro de que quieres eliminar físicamente el archivo?\n\n[B]{title}[/B]\n\nEsta acción eliminará el archivo de tu disco duro para siempre."):
        try:
            if os.path.exists(path):
                os.remove(path)
                core_settings.remove_download(path)
                xbmcgui.Dialog().notification("EspaDaily", "Archivo eliminado satisfactoriamente", xbmcgui.NOTIFICATION_INFO)
                xbmc.executebuiltin("Container.Refresh")
            else:
                xbmcgui.Dialog().ok("EspaDaily", "El archivo ya no existe en esa ruta.")
                core_settings.remove_download(path)
                xbmc.executebuiltin("Container.Refresh")
        except Exception as e:
            xbmcgui.Dialog().ok("EspaDaily Error", f"No se pudo eliminar: {str(e)}")



def _get_snapshot_dir():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    sd = os.path.join(p, 'snapshots')
    if not os.path.exists(sd): os.makedirs(sd)
    return sd

def _get_platform_cats(platform):
    return connector.get_platform_cats(platform)

def _fetch_list_data(platform, cid):
    return connector.fetch_list_data(platform, cid)
    
def _toggle_snapshot_context():
    core_settings.cycle_snapshot_context()
    xbmc.executebuiltin("Container.Refresh")

def _snapshot_context_help():
    t = (
        "[B]CONTEXTO DE BÚSQUEDA EN INSTANTÁNEAS[/B]\n\n"
        "Define cómo se construye la búsqueda al abrir contenido guardado.\n\n"
        
        "[B]Ejemplo: 'El Hormiguero' en 'Programas' de 'Atresplayer'[/B]\n\n"
        
        "[B]• CLÁSICO (Recomendado):[/B]\n"
        "  - Atresplayer: 'El Hormiguero'\n"
        "  - RTVE: 'RTVE El Hormiguero'\n"
        "  - Mediaset: 'Mediaset El Hormiguero'\n\n"
        
        "[B]• Nivel 0 (Solo Título):[/B]\n"
        "  - 'El Hormiguero'\n\n"
        
        "[B]• Nivel 1 (Categoría):[/B]\n"
        "  - 'Programas El Hormiguero'\n\n"
        
        "[B]• Nivel 2 (Plataforma+Categoría):[/B]\n"
        "  - 'Atresplayer Programas El Hormiguero'\n\n"
        
        "[B]¿CUÁL ELEGIR?[/B]\n"
        "CLÁSICO es la opción más segura y probada. Los niveles avanzados "
        "pueden mejorar la precisión en algunos casos, pero también pueden "
        "fallar si no hay vídeos con esas palabras exactas en el título."
    )
    xbmcgui.Dialog().textviewer("Ayuda: Contexto de Búsqueda", t)

def _snapshot_info():
    t = (
        "Es recomendable crear una instantánea periódicamente.\n\n"
        "Esto te permite acceder a los menús guardados incluso si se corta el acceso "
        "a las listas online, el servidor falla o el addon deja de recibir actualizaciones de contenido.\n\n"
        "Esta opción también puede ser interesante para cargar backups o listas compartidas por otros usuarios."
    )
    xbmcgui.Dialog().textviewer("Recomendación de Instantáneas", t)

def snapshots_menu():
    _fanart = core_settings.addon_fanart()

    msg = "Es recomendable crear una instantánea periódicamente por si se corta el acceso a las listas online, falla el servidor o el contenido deja de actualizarse."
    li = xbmcgui.ListItem(label=f"[COLOR cyan][B]RECOMENDACIÓN:[/B][/COLOR] {msg}")
    li.setInfo('video', {'plot': "Es recomendable crear una instantánea periódicamente. Esto te permite acceder a los menús guardados incluso si se corta el acceso a las listas online, el servidor falla o el addon deja de recibir actualizaciones de contenido.\n\nEsta opción también puede ser interesante para cargar backups o listas compartidas por otros usuarios."})
    li.setArt({'icon': ui_utils.media_icon('info.png'), 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="snapshot_info"), listitem=li, isFolder=False)

    # 1. Crear
    li = xbmcgui.ListItem(label="[COLOR green][B]+ CREAR NUEVA INSTANTÁNEA[/B][/COLOR]")
    li.setArt({'icon': ui_utils.media_icon('snapshot_create.png'), 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="create_snapshot"), listitem=li, isFolder=False)

    # 2. Borrar (listar para borrar)
    li = xbmcgui.ListItem(label="[COLOR red]BORRAR INSTANTÁNEAS...[/COLOR]")
    li.setArt({'icon': ui_utils.media_icon('snapshot_delete.png'), 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="delete_snapshot_menu"), listitem=li, isFolder=True)

    # 3. Exportar (NUEVO)
    li = xbmcgui.ListItem(label="[COLOR yellow]EXPORTAR INSTANTÁNEAS...[/COLOR]")
    li.setArt({'icon': ui_utils.media_icon('snapshot_export.png'), 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="export_snapshot_menu"), listitem=li, isFolder=True)

    # 4. Importar (NUEVO)
    li = xbmcgui.ListItem(label="[COLOR orange]IMPORTAR INSTANTÁNEA...[/COLOR]")
    li.setArt({'icon': ui_utils.media_icon('snapshot_import.png'), 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="import_snapshot_menu"), listitem=li, isFolder=True)

    # 5. Contexto de Búsqueda (INDEPENDIENTE)
    curr_ctx = core_settings.get_snapshot_context_level()
    ctx_labels = {-1: "CLÁSICO (Recomendado)", 0: "APAGADO (Solo Título)", 1: "Nivel 1 (Categoría)", 2: "Nivel 2 (Plataforma+Cat)"}
    label_txt = ctx_labels.get(curr_ctx, "Desconocido")

    li = xbmcgui.ListItem(label=f"Contexto de Búsqueda: [COLOR yellow]{label_txt}[/COLOR]")
    li.setArt({'icon': ui_utils.media_icon('adv_contexto.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Pulsa para cambiar el modo. Ver [?] Ayuda para más detalles."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_snapshot_context"), listitem=li, isFolder=False)

    # 4. Botón de Ayuda
    li = xbmcgui.ListItem(label="[COLOR blue][?] Ayuda: ¿Qué es el Contexto de Búsqueda?[/COLOR]")
    li.setArt({'icon': ui_utils.media_icon('info.png'), 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="snapshot_context_help"), listitem=li, isFolder=False)

    # 5. Listar existentes
    sd = _get_snapshot_dir()
    files = sorted([f for f in os.listdir(sd) if f.endswith('.json')], reverse=True)

    addon = xbmcaddon.Addon()
    icon = addon.getAddonInfo('icon')

    for f in files:
        # Formato: snapshot_YYYYMMDD_HHMMSS.json
        try:
            ts_str = f.replace("instantaneas_espadaily_", "").replace("snapshot_", "").replace(".json", "")
            # Simple parsing manually
            date_str = f"{ts_str[6:8]}/{ts_str[4:6]}/{ts_str[0:4]} {ts_str[9:11]}:{ts_str[11:13]}"
            li = xbmcgui.ListItem(label=f"Instantánea: {date_str}")
            li.setArt({'icon': ui_utils.media_icon('adv_snapshot.png'), 'thumb': icon, 'fanart': _fanart})
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="view_snapshot", file=f, path="root"), listitem=li, isFolder=True)
        except Exception: continue

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _create_snapshot():
    # 1. Elegir alcance (Scope)
    scope_opts = ["Todo el Catálogo (Atresplayer + RTVE + Mediaset)", "Seleccionar plataformas..."]
    scope_sel = xbmcgui.Dialog().select("¿Qué quieres guardar?", scope_opts)
    if scope_sel < 0: return

    platforms = ["atresplayer", "rtve", "mediaset"]
    selected_platforms = []
    
    if scope_sel == 0:
        selected_platforms = platforms
    else:
        # Multiselect dialog
        labels = ["Atresplayer", "RTVE Play", "Mediaset Infinity"]

        initial_sel = [0, 1, 2] 
        ms_res = xbmcgui.Dialog().multiselect("Selecciona plataformas", labels, preselect=initial_sel)
        if not ms_res: return # Cancelled or empty
        
        for idx in ms_res:
            selected_platforms.append(platforms[idx])

    if not selected_platforms: return

    # 2. Elegir Tipo
    opts = ["Actualizable (Conectada)", "Independiente (Desconectada)"]
    sel = xbmcgui.Dialog().select("Tipo de Instantánea", opts)
    if sel < 0: return
    
    is_dynamic = (sel == 0)
    
    # Confirmacion final
    plat_str = ", ".join([p.upper() for p in selected_platforms])
    if not xbmcgui.Dialog().yesno("Crear Instantánea", f"Se guardarán: {plat_str}.\n\nEste proceso puede tardar unos segundos.\n¿Continuar?"):
        return

    pDialog = xbmcgui.DialogProgress()
    pDialog.create('Creando Instantánea', 'Inicializando...')
    
    data = {
        "timestamp": int(time.time()),
        "type": "dynamic" if is_dynamic else "static",
        "content": {}
    }
    
    total_steps = 0
    for p in selected_platforms: total_steps += len(_get_platform_cats(p))
    
    current_step = 0
    
    for plt in selected_platforms:
        data["content"][plt] = {}
        cats = _get_platform_cats(plt)
        
        for c in cats:
            if pDialog.iscanceled(): 
                pDialog.close()
                return
            
            percentage = int((current_step / total_steps) * 100)
            pDialog.update(percentage, f"Escaneando {plt}...\nCategoría: {c['title']}")
            
            items = _fetch_list_data(plt, c["id"])
            data["content"][plt][c["title"]] = {
                "icon": c.get("icon"),
                "items": items
            }
            current_step += 1

    pDialog.update(100, "Guardando archivo...")
    
    # Save
    ts = time.strftime("%Y%m%d_%H%M%S")
    fname = f"instantaneas_espadaily_{ts}.json"
    fpath = os.path.join(_get_snapshot_dir(), fname)
    
    with open(fpath, 'w', encoding='utf-8') as f:
        json.dump(data, f)
        
    pDialog.close()
    xbmcgui.Dialog().notification("EspaDaily", "Instantánea creada correctamente", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _view_snapshot(f, path):
    # El nombre llega en la URL del plugin; basename() impide leer fuera de la carpeta.
    fpath = os.path.join(_get_snapshot_dir(), os.path.basename(f or ''))
    try:
        with open(fpath, 'r', encoding='utf-8') as fo:
            data = json.load(fo)
    except (OSError, ValueError) as ex:
        # Es una carpeta, y sin endOfDirectory Kodi espera el listado y suma su propio error.
        xbmc.log(f"[EspaDaily] Instantánea ilegible {f}: {ex}", xbmc.LOGWARNING)
        xbmcgui.Dialog().notification("EspaDaily", "No se pudo abrir la instantánea", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    _fanart = core_settings.addon_fanart()

    content = data.get("content", {})

    if path == "root":

        platforms = [
            {"id": "atresplayer", "label": "Atresplayer", "icon": ui_utils.media_icon('cat_atres.png')},
            {"id": "rtve", "label": "RTVE Play", "icon": ui_utils.media_icon('cat_rtve.png')},
            {"id": "mediaset", "label": "Mediaset Infinity", "icon": ui_utils.media_icon('cat_mediaset.png')},
        ]
        for p in platforms:
            li = xbmcgui.ListItem(label=p["label"])
            li.setArt({'icon': p['icon'], 'fanart': _fanart})
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="view_snapshot", file=f, path=p["id"]), listitem=li, isFolder=True)
            
    elif "/" not in path:
    
        plt = path
        cats_data = content.get(plt, {})
        for cat_title, cat_data in cats_data.items():
            li = xbmcgui.ListItem(label=cat_title)
            li.setArt({'icon': cat_data.get("icon") or ui_utils.media_icon('carpeta.png'), 'fanart': _fanart})
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="view_snapshot", file=f, path=f"{plt}/{cat_title}"), listitem=li, isFolder=True)
            
    else:
    
        parts = path.split("/")
        plt = parts[0]
        cat = parts[1]
        
        items = content.get(plt, {}).get(cat, {}).get("items", [])
        
        for i in items:
            tt = i.get("title")
            th = i.get("image")
            

            

            snap_mode = core_settings.get_snapshot_context_level()
            
            q = tt
            
            if snap_mode == -1:

                if plt == "mediaset": q = f"Mediaset {tt}"
                elif plt == "rtve": q = f"RTVE {tt}"
                else: q = tt # Atr3splay3r default
                
            else:

                # Construir cadena de contexto: "Plataforma || Categoria"
                
                plt_clean = plt
                if plt == "mediaset": plt_clean = "Mediaset"
                elif plt == "rtve": plt_clean = "RTVE"
                elif plt == "atresplayer": plt_clean = "Atresplayer"
                
                ctx_data = f"{plt_clean}||{cat}"
                
                # Forzar el nivel especifico de los ajustes de instantanea
                q = core_settings.build_query(tt, ctx_data, force_level=snap_mode)
            
            li = xbmcgui.ListItem(label=tt)
            li.setArt({'thumb': th, 'icon': th})
            li.setInfo('video', {'title': tt, 'plot': i.get('plot', '')})
            

            snap_type = data.get("type", "static")
            
            if snap_type == "dynamic" and i.get("action_type"):
                # DINAMICO: Reconectar con plataforma
                at = i.get("action_type")
                pm = i.get("params", {})
                
                # Caso especial para M3d1as3t href
                if at == "ls_mediaset" and i.get("href"):

                     pass 
                
                # Construir URL con parametros originales
                url_params = {"action": at}
                url_params.update(pm)
                
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(**url_params), listitem=li, isFolder=True)
            
            else:
                # ESTATICO: Buscar en la red
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="lfr", q=q, ot=th), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _delete_snapshot_menu():
    sd = _get_snapshot_dir()
    files = sorted([f for f in os.listdir(sd) if f.endswith('.json')], reverse=True)
    
    for f in files:
        ts_str = f.replace("instantaneas_espadaily_", "").replace("snapshot_", "").replace(".json", "")
        date_str = f"{ts_str[6:8]}/{ts_str[4:6]}/{ts_str[0:4]} {ts_str[9:11]}:{ts_str[11:13]}"
        
        li = xbmcgui.ListItem(label=f"[BORRAR] {date_str}")
        li.setArt({'icon': ui_utils.media_icon('snapshot_delete.png'), 'fanart': core_settings.addon_fanart()})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="delete_snapshot", file=f), listitem=li, isFolder=False)
        
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _delete_snapshot(f):
    if xbmcgui.Dialog().yesno("Borrar Instantánea", "¿Estás seguro de querer borrar esta instantánea?"):
        try:
            # El nombre llega en la URL del plugin, y sin basename() un "../" borraría fuera.
            os.remove(os.path.join(_get_snapshot_dir(), os.path.basename(f or '')))
            xbmcgui.Dialog().notification("EspaDaily", "Borrada correctamente", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
        except OSError as ex:
            xbmcgui.Dialog().ok("EspaDaily", f"No se pudo borrar: {ex}")


def _import_backup():
    f = xbmcgui.Dialog().browse(1, 'Seleccionar Backup', 'files', '.zip', False, False, '')
    if not f: return

    file_labels = {
        'settings.json': 'Configuración General',
        'favorites.json': 'Favoritos',
        'search_history.json': 'Historial de Búsquedas',
        'history.json': 'Historial (v1)',
        'custom_categories.json': 'Categorías Personalizadas',
        'exploration_history.json': 'Historial de Navegación',
        'dm_settings.json': 'Ajustes Dailymotion',
        'watch_history.json': 'Historial de Visionado',
        'custom_iptv.json': 'Listas IPTV Personalizadas (antiguas)',
        'custom_iptv_lists.json': 'Listas de canales',
        'url_history.json': 'Historial de direcciones web',
        'url_bookmarks.json': 'Marcadores de direcciones web',
    }
    mergeable = ['favorites.json', 'search_history.json', 'history.json', 'exploration_history.json',
                 'watch_history.json', 'url_history.json', 'url_bookmarks.json']
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    fallidos = []

    # zipfile solo abre rutas locales; una copia en una carpeta de red se trae antes a temp.
    copia_local = None
    if not os.path.exists(f):
        copia_local = os.path.join(xbmcvfs.translatePath('special://temp/'), 'espadaily_import.zip')
        if not xbmcvfs.copy(f, copia_local):
            xbmcgui.Dialog().ok("Error", "No se pudo leer la copia de seguridad.")
            return
        f = copia_local

    try:
        with zipfile.ZipFile(f, 'r') as zf:
            available = zf.namelist()
        known = [fz for fz in available if fz in file_labels]
        if 'custom_iptv_lists.json' in known and 'custom_iptv.json' in known:
            # Las antiguas pasaron a las nuevas al guardar la primera vez: ya están dentro.
            known.remove('custom_iptv.json')

        cache_files = [fz for fz in available if fz.startswith("cat_cache_") and fz.endswith(".json")]
        if cache_files:
            known.append('__cache__')
            file_labels['__cache__'] = 'Caché de Categorías ({0})'.format(len(cache_files))
    
        snap_files = [fz for fz in available if fz.startswith('snapshots/') and fz.endswith('.json')]
        if snap_files:
            known.append('__snapshots__')
            file_labels['__snapshots__'] = 'Instantáneas ({0})'.format(len(snap_files))

        if not known:
            xbmcgui.Dialog().ok("EspaDaily", "Este archivo no contiene datos reconocidos.")
            return

        options = [file_labels.get(fz, fz) for fz in known]
        selected = xbmcgui.Dialog().multiselect("¿Qué deseas importar?", options,
                                                preselect=list(range(len(options))))
        if selected is None or len(selected) == 0: return

        files_to_restore = [known[i] for i in selected]
        restored = 0
        with zipfile.ZipFile(f, 'r') as zf:
            for fz in files_to_restore:
                if fz in ('custom_iptv_lists.json', 'custom_iptv.json'):
                    # Pasan por las listas de canales: con las listas nuevas ya creadas,
                    # un custom_iptv.json copiado al perfil no se leería nunca.
                    import iptv_lists
                    if iptv_lists.restore_from_backup(zf, fz):
                        restored += 1
                    continue
                if fz == '__snapshots__':
                    sd = os.path.join(p, 'snapshots')
                    if not os.path.exists(sd): os.makedirs(sd)
                    for sf in snap_files:
                        data = zf.read(sf)
                        with open(os.path.join(sd, os.path.basename(sf)), 'wb') as f_out:
                            f_out.write(data)
                        restored += 1
                    continue
                if fz == '__cache__':
                    for cf in cache_files:
                        data = zf.read(cf)
                        # El nombre sale del zip, y sin basename un "../" escribiría fuera del perfil.
                        with open(os.path.join(p, os.path.basename(cf)), 'wb') as f_out:
                            f_out.write(data)
                        restored += 1
                    continue
                dest_path = os.path.join(p, fz)
                if fz in mergeable and os.path.exists(dest_path):
                    choice = xbmcgui.Dialog().select(file_labels[fz],
                        ["Sustituir (borrar actual)", "Añadir (fusionar con actual)", "Omitir"])
                    if choice == 2 or choice == -1: continue
                    elif choice == 1:
                        merged = None
                        try:
                            with open(dest_path, 'r', encoding='utf-8') as fh: current = json.load(fh)
                            with zf.open(fz) as zfile: backup = json.load(zfile)
                            if isinstance(current, list) and isinstance(backup, list):
                                merged = current + [x for x in backup if x not in current]
                            elif isinstance(current, dict) and isinstance(backup, dict):
                                merged = {**current, **backup}
                        except (OSError, ValueError, KeyError) as ex:
                            xbmc.log(f"[EspaDaily] Error fusionando {fz}: {ex}", xbmc.LOGWARNING)
                        # Se pidió fusionar, así que si no se puede se omite. Antes caía a
                        # sustituir y se perdían los datos actuales sin avisar.
                        if merged is not None and core_settings.atomic_write_json(dest_path, merged, ensure_ascii=False):
                            restored += 1
                        else:
                            fallidos.append(file_labels[fz])
                        continue
                resolved = os.path.realpath(os.path.join(p, fz))
                # Con separador, porque sin él una carpeta hermana ("profile2") también pasaba.
                if not resolved.startswith(os.path.realpath(p) + os.sep):
                    continue
                zf.extract(fz, p)
                restored += 1

        msg = f"Se restauraron {restored} elementos."
        if fallidos:
            msg += "\n\nNo se pudo fusionar y se ha dejado como estaba:\n" + "\n".join(fallidos)
        xbmcgui.Dialog().ok("Importación Completa", msg)
        xbmc.executebuiltin("Container.Refresh")

    except Exception as e:
        xbmcgui.Dialog().ok("Error", "Fallo al importar:\n{0}".format(e))
    finally:
        if copia_local:
            try:
                os.remove(copia_local)
            except OSError:
                pass

def _export_snapshot_menu():
    # 1. Listar disponibles
    sd = _get_snapshot_dir()
    files = sorted([f for f in os.listdir(sd) if f.endswith('.json')], reverse=True)
    
    if not files:
        xbmcgui.Dialog().notification("EspaDaily", "No hay instantáneas para exportar", xbmcgui.NOTIFICATION_WARNING)
        return

    # Formatear nombres para el diálogo
    display_list = []
    for f in files:
        ts_str = f.replace("instantaneas_espadaily_", "").replace("snapshot_", "").replace(".json", "")
        # Intentar formatear fecha si es posible
        try:
             date_str = f"{ts_str[6:8]}/{ts_str[4:6]}/{ts_str[0:4]} {ts_str[9:11]}:{ts_str[11:13]}"
             display_list.append(date_str)
        except Exception:
             display_list.append(f) # Fallback

    # 2. Selección múltiple
    sel = xbmcgui.Dialog().multiselect("Seleccionar instantáneas a exportar", display_list)
    if not sel: return
    
    # 3. Elegir destino
    dest_folder = xbmcgui.Dialog().browse(0, 'Exportar a...', 'files', '', False, False, '')
    if not dest_folder: return
    
    # 4. Copiar archivos. Con xbmcvfs y no shutil, porque browse() puede devolver una
    # carpeta de red.
    count = sum(1 for idx in sel
                if xbmcvfs.copy(os.path.join(sd, files[idx]), _vfs_join(dest_folder, files[idx])))
    if count == len(sel):
        xbmcgui.Dialog().notification("EspaDaily", f"{count} instantáneas exportadas", xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().ok("Error", f"Se exportaron {count} de {len(sel)} instantáneas.\nComprueba que la carpeta admite escritura.")

def _export_favorites():
    """Exporta solo la lista de favoritos principales (favorites.json)"""
    favs = core_settings.get_favorites()
    if not favs:
        xbmcgui.Dialog().notification("EspaDaily", "No hay favoritos para exportar", xbmcgui.NOTIFICATION_INFO)
        return
        
    ts = time.strftime("%Y%m%d_%H%M")
    default_name = f"espadaily_favoritos_{ts}.json"
    
    d = xbmcgui.Dialog().browse(3, 'Guardar Favoritos', 'files', '', False, False, default_name)
    if not d: return

    # browse(3) devuelve una carpeta, que puede ser de red, así que xbmcvfs y no open().
    destino = _vfs_join(d, default_name)
    with xbmcvfs.File(destino, 'w') as fh:
        ok = fh.write(json.dumps(favs, ensure_ascii=False, indent=2).encode('utf-8'))
    if ok:
        xbmcgui.Dialog().ok("Exportar Favoritos", f"Guardado correctamente:\n{default_name}\n\nElementos: {len(favs)}")
    else:
        xbmcgui.Dialog().ok("Error", "No se pudo escribir el archivo en esa carpeta.")

def _import_favorites():
    """Importa lista de favoritos desde JSON"""
    f = xbmcgui.Dialog().browse(1, 'Seleccionar archivo de favoritos', 'files', '.json', False, False, '')
    if not f: return

    # Con xbmcvfs, porque browse() puede devolver una carpeta de red.
    with xbmcvfs.File(f) as fh:
        raw = bytes(fh.readBytes())
    try:
        data = json.loads(raw.decode('utf-8-sig'))
    except (ValueError, UnicodeDecodeError) as e:
        xbmcgui.Dialog().ok("Error", f"Archivo no válido o corrupto: {e}")
        return

    # Antes solo se miraba el primero, y una entrada sin sus campos a mitad de la lista
    # cortaba la importación con KeyError. Sin 'url' un favorito no se puede abrir ni borrar.
    new_favs = [x for x in data if isinstance(x, dict) and isinstance(x.get('url'), str) and x['url']] \
        if isinstance(data, list) else []
    if not new_favs:
        xbmcgui.Dialog().ok("Error", "El archivo no contiene favoritos de EspaDaily válidos.")
        return
    descartados = len(data) - len(new_favs)
    aviso = f" ({descartados} sin URL descartados)" if descartados else ""

    opts = ["Fusionar (Añadir nuevos)", "Reemplazar lista completa"]
    sel = xbmcgui.Dialog().select("¿Cómo importar?", opts)
    if sel < 0: return

    if sel == 0:
        added = 0
        for item in new_favs:
            params = item.get('params') if isinstance(item.get('params'), dict) else {}
            if core_settings.add_favorite(item.get('title') or item['url'], item['url'], item.get('icon', ''),
                                          item.get('platform', ''), item.get('action') or 'search', params):
                added += 1
        xbmcgui.Dialog().notification("EspaDaily", f"{added} favoritos añadidos{aviso}", xbmcgui.NOTIFICATION_INFO)
    else:
        profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        if not core_settings.atomic_write_json(os.path.join(profile, 'favorites.json'), new_favs, ensure_ascii=False):
            xbmcgui.Dialog().ok("Error", "No se pudo guardar la lista de favoritos.")
            return
        xbmcgui.Dialog().notification("EspaDaily", f"Lista reemplazada{aviso}", xbmcgui.NOTIFICATION_INFO)

    xbmc.executebuiltin("Container.Refresh")

def _import_snapshot_menu():
    # 1. Seleccionar archivo .json
    f = xbmcgui.Dialog().browse(1, 'Seleccionar Instantánea', 'files', '.json', False, False, '')
    if not f: return
    

    # Copiar a la carpeta de instantaneas
    
    sd = _get_snapshot_dir()
    fname = os.path.basename(f)
    dest = os.path.join(sd, fname)
    
    # Preguntar si sobreescribir si ya existe
    if os.path.exists(dest):
        if not xbmcgui.Dialog().yesno("EspaDaily", "Esta instantánea ya existe.\n¿Sobrescribir?"):
            return
            
    try:
        import shutil
        shutil.copy2(f, dest)
        xbmcgui.Dialog().notification("EspaDaily", "Instantánea importada con éxito", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Error al importar:\n{str(e)}")
        
def _toggle_advanced_search():
    new_state = not core_settings.is_advanced_search_active()
    core_settings.set_advanced_search_active(new_state)
    msg = "MENÚ AVANZADO ACTIVADO" if new_state else "BÚSQUEDA DIRECTA (SIMPLE)"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_live_tv_grid():
    addon = xbmcaddon.Addon()
    new_state = not (addon.getSetting('live_tv_grid_mode') == 'true')
    addon.setSetting('live_tv_grid_mode', 'true' if new_state else 'false')
    msg = "TV en Directo: MODO TV (grid)" if new_state else "TV en Directo: LISTA"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _advanced_search_menu():
    import ui_utils
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)
    _fanart = core_settings.addon_fanart()
    # === CATÁLOGOS OFICIALES ===
    li = xbmcgui.ListItem(label="[B]- CATÁLOGOS OFICIALES -[/B]")
    li.setArt({'icon': _mi('separador.png'), 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="separador"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Buscar en Catálogo de Atresplayer")
    li.setArt({'icon': _mi('cat_atres.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Busca directamente en el catálogo oficial de Atresplayer por nombre aproximado."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_atres_catalog"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Buscar en Catálogo de Mediaset")
    li.setArt({'icon': _mi('cat_mediaset.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Busca directamente en el catálogo oficial de Mediaset (Mitele) por nombre aproximado."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_mediaset_catalog"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Buscar en Catálogo de RTVE")
    li.setArt({'icon': _mi('cat_rtve.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Busca directamente en el catálogo oficial de RTVE Play por nombre aproximado."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_rtve_catalog"), listitem=li, isFolder=False)

    # === BÚSQUEDAS BÁSICAS ===
    li = xbmcgui.ListItem(label="[B]- BÚSQUEDAS BÁSICAS -[/B]")
    li.setArt({'icon': _mi('separador.png'), 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="separador"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Búsqueda Estándar (Por Título)")
    li.setArt({'icon': _mi('busqueda.png'), 'fanart': _fanart})
    _add_fav_cm(li, "Búsqueda Estándar", "search", "execute_adv_search", {"mode": ""})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode=""), listitem=li, isFolder=False)
    
    li = xbmcgui.ListItem(label="Búsqueda en Megabuscador")
    li.setArt({'icon': _mi('busqueda.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Busca a la vez en Dailymotion, YouTube, Odysee, PeerTube y BitChute. Los resultados se ordenan por relevancia."})
    _add_fav_cm(li, "Búsqueda en Megabuscador", "search", "bt_search", {})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="bt_search"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Búsqueda de Películas (Modo Cine)")
    li.setArt({'icon': _mi('cat_peliculas.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Optimiza la búsqueda para encontrar películas completas en castellano.\nPrueba variantes como 'pelicula completa', 'castellano', etc."})
    _add_fav_cm(li, "Búsqueda de Películas", "search", "execute_adv_search", {"mode": "movie"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="movie"), listitem=li, isFolder=False)
    
    li = xbmcgui.ListItem(label="Búsqueda de Series (Temporada + Capítulo)")
    li.setArt({'icon': _mi('srch_series.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Introduce el nombre de la serie y el addon te pedirá número de temporada y capítulo.\nConstruye automáticamente la mejor query posible."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="series"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Buscar en Webs P2P (Elementum)")
    li.setArt({'icon': _mi('srch_torrent.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Busca torrents en webs P2P a través del addon Elementum.\nRequiere tener Elementum instalado."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_elementum_prompt"), listitem=li, isFolder=False)

    if _has_ace_player() and core_settings.is_acestream_enabled():
        li = xbmcgui.ListItem(label="Herramientas AceStream")
        li.setArt({'icon': _mi('adv_acestream.png'), 'fanart': _fanart})
        li.setInfo('video', {'plot': "Centro de herramientas AceStream.\nBuscar por t\u00e9rmino, por nombre, historial, reproducir enlace directo, escanear webs y opciones de proxy."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="acestream_tools_menu"), listitem=li, isFolder=True)

    # === MEGABUSCADOR ===
    li = xbmcgui.ListItem(label="[B]- MEGABUSCADOR -[/B]")
    li.setArt({'icon': _mi('separador.png'), 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="separador"), listitem=li, isFolder=False)

    ui_utils.add_item(action="bt_search", title="Buscar en todas las plataformas", thumbnail=ui_utils.media_icon("busqueda.png"), folder=False, plot="Busca a la vez en Dailymotion, YouTube, Odysee, PeerTube y BitChute. Los resultados se ordenan por relevancia indicando la fuente de cada uno.")
    ui_utils.add_item(action="busqueda_total", title="[COLOR white]Configurar fuentes y ranking[/COLOR]", thumbnail=ui_utils.media_icon("bt_ranking.png"), folder=True, plot="Activa o desactiva plataformas, ajusta el ranking, filtra clips cortos, configura proxy o gestiona las opciones de ordenación.")

    # === FILTROS DE DURACIÓN ===
    li = xbmcgui.ListItem(label="[B]- FILTROS DE DURACIÓN -[/B]")
    li.setArt({'icon': _mi('separador.png'), 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="separador"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Búsqueda de Vídeos Largos (+20 min)")
    li.setArt({'icon': _mi('adv_videos_largos.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Filtra los resultados para mostrar solo vídeos de más de 20 minutos.\nIdeal para encontrar episodios completos o películas."})
    _add_fav_cm(li, "Vídeos Largos (+20 min)", "search", "execute_adv_search", {"mode": "long"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="long"), listitem=li, isFolder=False)
    
    li = xbmcgui.ListItem(label="Búsqueda de Vídeos Cortos (-10 min)")
    li.setArt({'icon': _mi('adv_videos_cortos.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Filtra los resultados para mostrar solo vídeos de menos de 10 minutos.\nIdeal para buscar clips, canciones o sketches."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="short"), listitem=li, isFolder=False)

    # === FILTROS TEMPORALES ===
    li = xbmcgui.ListItem(label="[B]- FILTROS TEMPORALES -[/B]")
    li.setArt({'icon': _mi('separador.png'), 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="separador"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Contenido de Hoy (Últimas 24h)")
    li.setArt({'icon': _mi('adv_hoy.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Muestra solo vídeos subidos en las últimas 24 horas.\nPerfecto para informativos y programas diarios."})
    _add_fav_cm(li, "Contenido de Hoy (24h)", "search", "execute_adv_search", {"mode": "recent_24h"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="recent_24h"), listitem=li, isFolder=False)
    
    li = xbmcgui.ListItem(label="Contenido de Esta Semana")
    li.setArt({'icon': _mi('adv_semana.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Muestra solo vídeos subidos en los últimos 7 días."})
    _add_fav_cm(li, "Contenido de esta Semana", "search", "execute_adv_search", {"mode": "recent_week"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="recent_week"), listitem=li, isFolder=False)
    
    li = xbmcgui.ListItem(label="Contenido de Este Mes")
    li.setArt({'icon': _mi('adv_mes.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Muestra solo vídeos subidos en los últimos 30 días."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="recent_month"), listitem=li, isFolder=False)

    # === FILTROS DE CALIDAD E IDIOMA ===
    li = xbmcgui.ListItem(label="[B]- CALIDAD E IDIOMA -[/B]")
    li.setArt({'icon': _mi('separador.png'), 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="separador"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Solo HD (Alta Definición)")
    li.setArt({'icon': _mi('adv_hd.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Filtra para mostrar únicamente vídeos en HD (720p o superior)."})
    _add_fav_cm(li, "Solo HD", "search", "execute_adv_search", {"mode": "hd"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="hd"), listitem=li, isFolder=False)
    
    li = xbmcgui.ListItem(label="Solo Contenido en Español")
    li.setArt({'icon': _mi('adv_idioma.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Filtra para mostrar solo vídeos con idioma español configurado."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="spanish"), listitem=li, isFolder=False)

    # === FILTROS AVANZADOS ===
    li = xbmcgui.ListItem(label="[B]- FILTROS AVANZADOS -[/B]")
    li.setArt({'icon': _mi('separador.png'), 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="separador"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Búsqueda por Usuario / Canal")
    li.setArt({'icon': _mi('adv_usuario.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Busca contenido subido ÚNICAMENTE por un usuario específico (ej: 'rtve', 'atresplayer').\n\nPuedes filtrar por texto dentro del canal."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="user"), listitem=li, isFolder=False)
    
    li = xbmcgui.ListItem(label="Búsqueda Inversa (Excluir palabras)")
    li.setArt({'icon': _mi('srch_inversa.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Busca X pero EXCLUYENDO resultados que contengan ciertas palabras.\nÚtil para evitar 'trailer', 'making of', 'clip', etc."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="exclude"), listitem=li, isFolder=False)
    
    li = xbmcgui.ListItem(label="Búsqueda Exacta (Sin limpieza)")
    li.setArt({'icon': _mi('adv_exacta.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Busca EXACTAMENTE lo que escribas, sin intentar limpiar el título ni quitar paréntesis."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="exact"), listitem=li, isFolder=False)
    
    li = xbmcgui.ListItem(label="Búsqueda por Palabras Clave")
    li.setArt({'icon': _mi('adv_palabras.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Extrae solo las palabras importantes (más de 3 letras) y busca por ellas. Útil si el título oficial es muy largo o complejo."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="keywords"), listitem=li, isFolder=False)

    # === UTILIDADES ===
    li = xbmcgui.ListItem(label="[B]- UTILIDADES -[/B]")
    li.setArt({'icon': _mi('separador.png'), 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="separador"), listitem=li, isFolder=False)
    
    li = xbmcgui.ListItem(label="Repetir Última Búsqueda (con filtros)")
    li.setArt({'icon': _mi('adv_repetir.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Toma la última búsqueda de tu historial y te permite ejecutarla con cualquiera de los filtros anteriores."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="repeat_last"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Búsqueda Múltiple (varios términos)")
    li.setArt({'icon': _mi('adv_multiple.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Busca varios términos separados por comas en Dailymotion.\nEjemplo: 'saber y ganar, pasapalabra, el hormiguero'"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="multi_search"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _adv_search_navigate(**kwargs):
    """Navega a la fase idempotente de la búsqueda avanzada vía Container.Update.
    El prompt (teclado/web) no queda en el back stack: volver atrás regresa al menú y
    re-renderizar el contenedor no relanza el teclado (kodi#GetDirectory re-ejecuta la URL)."""
    url = _u(action="execute_adv_search", ready="1", **kwargs)
    xbmc.executebuiltin(f'Container.Update("{url}")')

def _execute_adv_search(mode, p):
    h = int(sys.argv[1])

    # FASE 2 (idempotente): la query ya viaja en la URL. Renderiza sin pedir nada, de modo que
    # al volver de la reproducción o pulsar atrás NO reaparece el teclado.
    if p.get("ready"):
        q = p.get("q", "")
        if mode == "user":
            _lfd(q if q else " ", "", mode="user", extra_params={"owner": p.get("owner", "")}, nh=True)
            return
        if mode == "exclude":
            exclude_words = [w.strip().lower() for w in p.get("exclude", "").split(",") if w.strip()] or None
            _lfd_with_exclusions(q, "", exclude_words)
            return
        ep = None
        if mode == "long":
            ep = {"longer_than": 20}
        elif mode == "short":
            ep = {"shorter_than": 10}
        elif mode == "recent_24h":
            ep = {"created_after": int(time.time()) - 86400, "sort": "recent"}
        elif mode == "recent_week":
            ep = {"created_after": int(time.time()) - 604800, "sort": "recent"}
        elif mode == "recent_month":
            ep = {"created_after": int(time.time()) - 2592000, "sort": "recent"}
        elif mode == "hd":
            ep = {"hd": 1}
        elif mode == "spanish":
            ep = {"language": "es"}
        _lfd(q, "", mode=mode, extra_params=ep or {}, nh=True)
        return

    # FASE 1: pide los términos (teclado/web) y navega a la fase idempotente.
    if mode == "user":
        user = ui_utils.get_text('Introduce el ID de Usuario/Canal').strip()
        if not user:
            xbmcplugin.endOfDirectory(h, succeeded=False)
            return
        q = ui_utils.get_text(f'Buscar en canal de {user} (Opcional, vacío = últimos vídeos)').strip()
        if q: _add_to_history(q)
        _adv_search_navigate(mode="user", q=q, owner=user)
        return

    if mode == "series":
        series_name = ui_utils.get_text('Nombre de la Serie').strip()
        if not series_name:
            xbmcplugin.endOfDirectory(h, succeeded=False)
            return
        season = ui_utils.get_text('Número de Temporada (vacío = cualquiera)').strip()
        episode = ui_utils.get_text('Número de Capítulo (vacío = cualquiera)').strip()
        q = series_name
        if season:
            q += f" T{season}"
        if episode:
            q += f" Capitulo {episode}"
        _add_to_history(q)
        _adv_search_navigate(mode="", q=q)
        return

    if mode == "exclude":
        q = ui_utils.get_text('¿Qué quieres buscar?').strip()
        if not q:
            xbmcplugin.endOfDirectory(h, succeeded=False)
            return
        exclude = ui_utils.get_text('Palabras a EXCLUIR (separadas por coma)', 'trailer, clip, making of')
        _add_to_history(q)
        _adv_search_navigate(mode="exclude", q=q, exclude=exclude)
        return

    if mode == "repeat_last":
        history = _load_history()
        if not history:
            xbmcgui.Dialog().notification("EspaDaily", "No hay historial", xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.endOfDirectory(h, succeeded=False)
            return
        filters = [
            ("Sin filtros (Estándar)", ""),
            ("Modo Cine (Películas)", "movie"),
            ("Solo +20 min", "long"),
            ("Solo -10 min", "short"),
            ("Solo HD", "hd"),
            ("Solo Español", "spanish"),
            ("Últimas 24h", "recent_24h"),
            ("Última Semana", "recent_week"),
        ]
        sel = xbmcgui.Dialog().select(f"Repetir: '{history[0]}' con filtro...", [f[0] for f in filters])
        if sel < 0:
            xbmcplugin.endOfDirectory(h, succeeded=False)
            return
        _adv_search_navigate(mode=filters[sel][1], q=history[0])
        return

    q = ui_utils.get_text('Búsqueda Avanzada').strip()
    if not q:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    _add_to_history(q)
    _adv_search_navigate(mode=mode, q=q)

def _lfd_with_exclusions(q, ot, exclude_words):
    """Special version of _lfd that filters out results containing excluded words."""
    cq = _clean_title(q)
    min_m = core_settings.get_min_duration()
    ep = {"longer_than": min_m} if min_m > 0 else None
    rs = _sr(cq, ep)
    if not rs and cq != q: rs = _sr(q, ep)
    
    if not rs:
        xbmcgui.Dialog().notification("EspaDaily", "No se encontraron resultados", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    
    # Filter out excluded words
    if exclude_words:
        filtered = []
        for r in rs:
            title_lower = r.get("title", "").lower()
            if not any(ex in title_lower for ex in exclude_words):
                filtered.append(r)
        rs = filtered
    
    if not rs:
        xbmcgui.Dialog().notification("EspaDaily", "Todos los resultados fueron excluidos", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    
    sr = _puntuar(cq, rs)[:25]
    
    if not sr:
        xbmcgui.Dialog().notification("EspaDaily", "Sin coincidencias relevantes", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    
    min_dur = core_settings.get_min_duration() * 60
    for _, pct, v in sr:
        vt = v.get("title", "Video"); vi = v.get("id"); ow = v.get("owner.username", "Unknown"); du = v.get("duration", 0)
        try: du = int(du)
        except (ValueError, TypeError): du = 0
        
        if min_dur > 0 and du < min_dur: continue
        dth = v.get("thumbnail_url") or v.get("thumbnail_360_url") or ot
        
        lb = f"{vt} ({pct}% match)"

        li = xbmcgui.ListItem(label=lb); li.setArt({'thumb': dth, 'icon': dth})
        li.setInfo('video', {'title': vt, 'plot': f"Subido por: {ow}\nDuración: {du}s", 'duration': du})
        li.setProperty("IsPlayable", "true")
        li.addContextMenuItems([("Descargar Video", f"RunPlugin({_u(action='download_video', vid=vi, title=vt)})"), ("Abrir en el navegador", f"RunPlugin({_u(action='dm_open_browser', url=vi)})")])

        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="pv", vid=vi, title=urllib.parse.quote(vt)), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _p3_b64encode(value):
    """Implementación local de la codificación de Palantir 3"""
    if not isinstance(value, bytes):
        value = str(value).encode()
    value = base64.b64encode(value)
    length = len(value)
    part = int(length / 4)
    value = re.sub(b'=', b'', value)
    # Pa.-..-. lantir reversible encoding: reverse 1/4 and 3/4
    encoded = value[:part][::-1] + value[part:][::-1]
    return urllib.parse.quote(encoded.decode())

def _ensure_palantir_fix_ready():
    """Aplica el ajuste del skin Estuary Palantir si hace falta (con consentimiento).
    Devuelve True si se puede continuar con la búsqueda ahora; False si se acaba de aplicar el
    ajuste (el skin se recarga) y conviene que el usuario repita la acción."""
    if estuary_palantir_compatibility.ensure_palantir_skin_patched() == 'applied':
        xbmcgui.Dialog().ok("EspaDaily",
            "Ajuste de compatibilidad aplicado y skin recargado.\n\n"
            "Vuelve a pulsar \"Buscar en Palantir\" para ver los resultados.")
        return False
    return True

def _search_palantir(query):
    if not query: return

    if core_settings.are_external_integrations_disabled():
        xbmcgui.Dialog().ok("EspaDaily",
            "La búsqueda en otros addons está desactivada globalmente.\n\n"
            "Actívala en:\nOpciones → Búsqueda en otros addons → Buscar en otros addons")
        return

    if not core_settings.is_palantir_integration_enabled():
        xbmcgui.Dialog().ok("EspaDaily",
            "La búsqueda en Palantir 3 está desactivada.\n\n"
            "Actívala en:\nOpciones → Búsqueda en otros addons → Buscar en Palantir 3")
        return

    # Comprobar si Pala.-.- .-.- ntir está instalado
    if not ui_utils.addon_listo("plugin.video.palantir3", "Palantir 3",
            "El addon Palantir 3 no parece estar instalado.\n\nEsta función requiere Palantir 3 para funcionar."):
        return

    # Cubre todos los flujos (incluidos los context-menu que llaman aquí directamente).
    if not _ensure_palantir_fix_ready():
        return

    # Item para Palantir
    # P3Item serializado
    item_dict = {
        "action": "buscar3",
        "sql": f"rebuscar {query}",
        "label": query
    }
    
    # Pala-.-.--.- ntir 3 usa codificacion propia
    # El item va como string repr de dict
    encoded_item = _p3_b64encode(str(item_dict))
    
    # Pala-.-..-.- ntir 3 usa ventana HOME (10000) para estado
    # Propiedades para saltarse el teclado
    window = xbmcgui.Window(10000)
    window.setProperty("p3_play", "true")
    window.setProperty("p3_item_buscar", encoded_item)
    
    # Lanzar busqueda en Pala.-.--.-- ntir 3 via plugin://
    # ActivateWindow para abrir resultados
    plugin_url = f"plugin://plugin.video.palantir3/?{encoded_item}"
    
    _l(f"Enviando búsqueda a Palantir 3: {query}")
    _l(f"URL generada: {plugin_url}")
    
    # Container.Update para que al volver atras no se quede en Palantir
    xbmc.executebuiltin(f"Container.Update({plugin_url})")


    # Si aparece un diálogo de OK y no ha cambiado el contenedor, es que ha fallado
    start_watch = time.time()
    while time.time() - start_watch < 15: # 15 segundos de margen
        xbmc.sleep(500)
        

        if xbmc.getInfoLabel("Container.PluginName") == "plugin.video.palantir3":
            return


        if xbmc.getCondVisibility("Window.IsActive(okdialog)"):


            while xbmc.getCondVisibility("Window.IsActive(okdialog)"):
                xbmc.sleep(500)
            

            xbmc.sleep(500)
            if xbmc.getInfoLabel("Container.PluginName") != "plugin.video.palantir3":
                if xbmcgui.Dialog().yesno("EspaDaily", f"Palantir no ha encontrado resultados para:\n[B]{query}[/B]\n\n¿Quieres editar el texto y reintentar?"):
                    kb = xbmc.Keyboard(query, 'Editar búsqueda Palantir')
                    kb.doModal()
                    if kb.isConfirmed():
                        nq = kb.getText()
                        if nq: _search_palantir(nq)
            return

def _search_elementum(query):
    """Busca en Elementum con verificación de instalación."""
    if not query: return
    
    if not ui_utils.addon_listo("plugin.video.elementum", "Elementum",
            "El addon Elementum no está instalado.\n\n"
            "Esta función requiere Elementum para buscar torrents en webs como 1337x, RARBG, etc.\n\n"
            "Puedes instalarlo desde el repositorio oficial de Kodi o desde GitHub."):
        return
    
    # Abrir búsqueda en Elementum
    elementum_url = f"plugin://plugin.video.elementum/search?q={urllib.parse.quote(query)}"
    xbmc.executebuiltin(f"Container.Update({elementum_url})")


def _search_elementum_prompt():
    kb = xbmc.Keyboard('', 'Buscar en Webs P2P (Elementum)')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    _search_elementum(kb.getText().strip())


def _search_youtube_from_results():
    if not ui_utils.addon_listo("plugin.video.youtube", "YouTube",
            "El plugin de YouTube no está instalado.\n\n"
            "Es necesario para reproducir los videos encontrados."):
        return
    kb = xbmc.Keyboard('', 'Buscar en YouTube')
    kb.doModal()
    if kb.isConfirmed():
        texto = kb.getText().strip()
        if texto:
            import urllib.parse as _up
            url = sys.argv[0] + '?' + _up.urlencode({'action': 'yt_html_search', 'q': texto})
            xbmc.executebuiltin(f"Container.Update({url})")

def _search_odysee_from_results():
    kb = xbmc.Keyboard('', 'Buscar en Odysee')
    kb.doModal()
    if kb.isConfirmed():
        texto = kb.getText().strip()
        if texto:
            import urllib.parse as _up
            url = sys.argv[0] + '?' + _up.urlencode({'action': 'odysee_search', 'q': texto})
            xbmc.executebuiltin(f"Container.Update({url})")

def _search_peertube_from_results():
    kb = xbmc.Keyboard('', 'Buscar en PeerTube')
    kb.doModal()
    if kb.isConfirmed():
        texto = kb.getText().strip()
        if texto:
            import urllib.parse as _up
            url = sys.argv[0] + '?' + _up.urlencode({'action': 'peertube_search', 'q': texto})
            xbmc.executebuiltin(f"Container.Update({url})")

def _search_bitchute_from_results():
    kb = xbmc.Keyboard('', 'Buscar en BitChute')
    kb.doModal()
    if kb.isConfirmed():
        texto = kb.getText().strip()
        if texto:
            import urllib.parse as _up
            url = sys.argv[0] + '?' + _up.urlencode({'action': 'bitchute_search', 'q': texto})
            xbmc.executebuiltin(f"Container.Update({url})")

def _has_ace_player():
    # AddonIsEnabled, porque desde Kodi 19 HasAddon también es cierto con el addon desactivado.
    return (xbmc.getCondVisibility("System.AddonIsEnabled(script.module.horus)")
            or xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.streamninja)"))


def _acestream_available():
    return _has_ace_player() and core_settings.is_acestream_enabled()


def _acestream_tools_menu():
    """Submen\u00fa con todas las herramientas AceStream, antes inaccesibles desde la interfaz."""
    if not _acestream_available():
        xbmcgui.Dialog().notification("EspaDaily", "AceStream no disponible", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    h = int(sys.argv[1])
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)
    _fanart = core_settings.addon_fanart()

    li = xbmcgui.ListItem(label="Buscar por t\u00e9rmino (API P\u00fablica)")
    li.setArt({'icon': _mi('busqueda.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Busca en la red p\u00fablica de AceStream por palabra clave."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="search_acestream_prompt"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Buscar por Nombre Exacto")
    li.setArt({'icon': _mi('srch_exacta.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Busca en AceStream usando el nombre exacto del canal o contenido."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="acestream_search_name"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Reproducir Enlace Directo (acestream://)")
    li.setArt({'icon': _mi('adv_acestream.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Introduce una URL acestream:// o un enlace para reproducir directamente."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="acestream_enter_url"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Reproducir por Hash ID")
    li.setArt({'icon': _mi('adv_acestream.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Introduce el hash ID de un stream AceStream para reproducirlo directamente."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="acestream_enter_id"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Escanear Web o Telegram")
    li.setArt({'icon': _mi('scan_web.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Extrae enlaces AceStream de una p\u00e1gina web o canal p\u00fablico de Telegram."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="acestream_scan_url"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Historial de AceStream")
    li.setArt({'icon': _mi('historial.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Ver y gestionar el historial de streams AceStream reproducidos."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="acestream_show_history"), listitem=li, isFolder=True)

    # Proxy
    ap = _ace_proxy_cfg()
    proxy_state = "[COLOR lime]ACTIVADO[/COLOR]" if ap['enabled'] else "[COLOR red]DESACTIVADO[/COLOR]"
    proxy_addr = ap['addr'] if ap['addr'] else "Ninguno"

    li = xbmcgui.ListItem(label="[B]\u2014 PROXY ACESTREAM \u2014[/B]")
    li.setArt({'icon': _mi('info.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': f"Estado actual: {proxy_state}\nServidor: {proxy_addr}\n\nEl proxy permite buscar en servidores públicos de AceStream cuando están bloqueados por tu operadora."})
    xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=f"Activar / Desactivar Proxy: {proxy_state}")
    li.setArt({'icon': _mi('bt_proxy.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Activa o desactiva el uso del proxy para las búsquedas de AceStream.\n\nÚtil si el servidor de búsqueda público está bloqueado."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="acestream_proxy_toggle"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Buscar Proxy P\u00fablico Autom\u00e1tico")
    li.setArt({'icon': _mi('bt_proxy_find.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Busca y configura automáticamente un proxy público gratuito y funcional.\n\nEsto puede tardar unos segundos mientras se verifica la conexión."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="acestream_proxy_find"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Configurar Proxy Manual")
    li.setArt({'icon': _mi('opciones.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Introduce manualmente la dirección de un proxy HTTP.\n\nFormato soportado: host:puerto o usuario:clave@host:puerto"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="acestream_proxy_manual"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Limpiar Proxy Guardado")
    li.setArt({'icon': _mi('bt_proxy_clear.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Borra la configuración del proxy actual y desactiva su uso."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="acestream_proxy_clear"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def _search_acestream_prompt():
    if not _acestream_available():
        xbmcgui.Dialog().notification("EspaDaily", "Busqueda AceStream no disponible", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    kb = xbmc.Keyboard('', 'Buscar en AceStream')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    query = kb.getText().strip()
    _search_acestream_results(query)


def _toggle_acestream_server_mode():
    new_mode = core_settings.cycle_acestream_server_mode()
    labels = {"auto": "Automatico (local + publico)", "publico": "Siempre publico", "local": "Solo local"}
    xbmcgui.Dialog().notification("AceStream", "Servidor: {0}".format(labels.get(new_mode, new_mode)), xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def _toggle_acestream_enabled():
    if not _has_ace_player() and not core_settings.is_acestream_enabled():
        xbmcgui.Dialog().notification("EspaDaily", "Necesitas EKHorus o StreamNinja instalado", xbmcgui.NOTIFICATION_INFO, 3000)
        return
    new_state = not core_settings.is_acestream_enabled()
    core_settings.set_acestream_enabled(new_state)
    msg = "Búsqueda AceStream activada" if new_state else "Búsqueda AceStream desactivada"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin("Container.Refresh")


def _search_acestream_results(query):
    h = int(sys.argv[1])
    if not _acestream_available():
        xbmcgui.Dialog().notification("EspaDaily", "Busqueda AceStream no disponible", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    if not query:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    buscar = ui_utils.del_conector("buscar_acestream")
    if not buscar:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    progress = xbmcgui.DialogProgressBG()
    try:
        progress.create("AceStream", "Buscando: {0}".format(query))
    except Exception:
        progress = None

    ap = _ace_proxy_cfg()
    proxy = None
    if ap['enabled'] and ap['addr']:
        purl = _proxy_url(ap['addr'])
        proxy = {'http': purl, 'https': purl}

    try:
        busqueda = buscar(query, core_settings.get_acestream_server_mode(), proxy)
    finally:
        if progress:
            try: progress.close()
            except Exception: pass
    results = busqueda["resultados"]
    last_state, last_error, used_endpoint = busqueda["estado"], busqueda["error"], busqueda["fuente"]

    if not results:
        if last_state == "empty":
            xbmcgui.Dialog().ok("AceStream", "Sin resultados para: {0}".format(query))
            xbmcplugin.endOfDirectory(h, succeeded=True)
        else:
            xbmcgui.Dialog().ok("Buscar en AceStream",
                "No se pudo realizar la busqueda.\n\n"
                "Detalle: {0}".format(last_error or "error desconocido"))
            xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    xbmc.log("[espadaily] AceStream search returned {0} results from {1}".format(len(results), used_endpoint), xbmc.LOGINFO)

    xbmcplugin.setPluginCategory(h, "AceStream: {0}".format(query))
    xbmcplugin.setContent(h, "videos")

    for item in results:
        if not isinstance(item, dict):
            continue
        name = _KODI_TAG_RE.sub('', str(item.get("name") or item.get("title") or "Sin nombre")).strip() or "Sin nombre"
        infohash = str(item.get("infohash") or item.get("id") or "").strip()
        if not infohash:
            continue

        categories = item.get("categories") or []
        if not isinstance(categories, list):
            categories = [categories] if categories else []
        categories = [str(c) for c in categories if c]

        availability = item.get("availability") or 0
        try:
            availability = float(availability)
            if availability > 1:
                availability = availability / 100.0
        except (TypeError, ValueError):
            availability = 0

        plot_lines = []
        if categories:
            plot_lines.append("Categoria: {0}".format(", ".join(categories)))
        desc = str(item.get("description") or "").strip()
        if desc:
            plot_lines.append(desc)
        if availability > 0:
            plot_lines.append("Disponibilidad: {0:.0f}%".format(availability * 100))
        plot = "\n".join(plot_lines) if plot_lines else name

        li = xbmcgui.ListItem(label=name)
        li.setInfo("video", {"title": name, "plot": plot})
        li.setArt({"icon": ui_utils.media_icon('p2p.png')})
        li.setProperty("IsPlayable", "true")
        _add_fav_cm(li, name, "acestream", "play_ace_result", {"infohash": infohash, "name": name})
        play_url = _u(action="play_ace_result", infohash=infohash, name=name)
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def _play_ace_result(infohash, name):
    """Reproduce un resultado AceStream desde un item de lista (búsqueda, escaneo,
    historial). Contexto de resolución: SIEMPRE via setResolvedUrl (no PlayMedia), que
    encadena sin abrir un segundo busydialog (xbmc/xbmc#24526 crashea Kodi con dos)."""
    import acestream_player
    h = int(sys.argv[1])

    cid = acestream_player.content_id(infohash or "")
    if not cid:
        xbmc.log("[espadaily] _play_ace_result: infohash invalido: {0}".format(infohash), xbmc.LOGWARNING)
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification("EspaDaily", "Hash AceStream invalido", xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    target = None
    if xbmc.getCondVisibility("System.AddonIsEnabled(script.module.horus)"):
        target = acestream_player.horus_target(cid)
    elif acestream_player.engine_ready():
        target = acestream_player.direct_stream_url(cid)
    elif not xbmc.getCondVisibility(f"System.AddonIsEnabled({acestream_player.STREAMNINJA_ID})"):
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok(
            "EspaDaily",
            "No se detectó el motor AceStream en este equipo (127.0.0.1:6878).\n\n"
            "Arranca el motor AceStream, o instala EKHorus (script.module.horus) o StreamNinja.\n\n"
            "Los dos necesitan además el motor AceStream instalado en el sistema.",
        )
        return

    try:
        _add_watch_entry("acestream://" + cid, name or cid[:12])
    except Exception as e:
        xbmc.log("[espadaily] _play_ace_result: _add_watch_entry failed: {0}".format(e), xbmc.LOGERROR)

    if target is None:
        acestream_player.pasar_a_streamninja(h, cid)
        return

    li = xbmcgui.ListItem(path=target)
    li.setProperty("IsPlayable", "true")
    if target.startswith("http://"):
        li.setContentLookup(False)  # stream MPEG-TS directo del motor
    xbmcplugin.setResolvedUrl(h, True, li)


_CATALOG_CACHE_TTL = 86400  # 24h

def _get_cached_catalog(cache_key, fetch_fn):
    """Devuelve el catálogo desde caché si está fresco (<24h), si no lo reescanea."""
    try:
        cached = _load_cache(cache_key)
        if isinstance(cached, dict) and isinstance(cached.get("ts"), (int, float)) and isinstance(cached.get("data"), dict):
            age = time.time() - cached["ts"]
            if age < _CATALOG_CACHE_TTL and cached["data"]:
                return cached["data"]
    except Exception:
        pass
    try:
        data = fetch_fn()
    except Exception:
        data = {}
    if data:
        try:
            _save_cache(cache_key, {"ts": time.time(), "data": data})
        except Exception:
            pass
    return data


def _catalog_fuzzy_search(query, catalog):
    if not catalog or not isinstance(catalog, dict):
        return []
    q = (query or "").strip().lower()
    if not q:
        return []
    all_items = []
    for cat_name, cat_items in catalog.items():
        if not isinstance(cat_items, list):
            continue
        for item in cat_items:
            if not isinstance(item, dict):
                continue
            t = str(item.get("t") or item.get("title") or "")
            u = str(item.get("u") or item.get("url") or "")
            th = str(item.get("th") or item.get("thumbnail") or "")
            p = str(item.get("p") or item.get("plot") or "")
            if t:
                all_items.append({"title": t, "url": u, "thumb": th, "plot": p, "category": str(cat_name)})
    # Dedup: misma key (título normalizado) solo aparece una vez, con el mejor score
    # y preferiblemente con URL navegable.
    best = {}
    for prog in all_items:
        tl = prog["title"].lower()
        if not tl:
            continue
        if q in tl:
            score = 0.95 + (len(q) / max(len(tl), 1)) * 0.05
        else:
            try:
                score = difflib.SequenceMatcher(None, q, tl).ratio()
            except Exception:
                score = 0.0
        if score <= 0.3:
            continue
        key = tl.strip()
        current = best.get(key)
        if current is None:
            best[key] = (score, prog)
        else:
            cur_score, cur_prog = current
            # Sustituir si mejor score, o mismo score pero URL navegable
            if score > cur_score or (score == cur_score and prog.get("url") and not cur_prog.get("url")):
                best[key] = (score, prog)
    scored = list(best.values())
    scored.sort(key=lambda x: x[0], reverse=True)
    return scored[:20]


def _search_atresplayer_catalog(p):
    if not p.get("ready"):
        query = ui_utils.get_text('Buscar en Catálogo de Atresplayer').strip()
        if not query:
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
            return
        xbmc.executebuiltin(f'Container.Update("{_u(action="search_atres_catalog", q=query, ready="1")}")')
        return
    query = p.get("q", "")
    try:
        catalog = _get_cached_catalog("catalog_atresplayer", connector._fetch_all_atres_catalog)
    except Exception as e:
        xbmcgui.Dialog().ok("EspaDaily", f"Error al obtener el catálogo: {str(e)}")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    if not catalog:
        xbmcgui.Dialog().ok("EspaDaily", "No se pudo obtener el catálogo de Atresplayer.")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    results = _catalog_fuzzy_search(query, catalog)
    if not results:
        if xbmcgui.Dialog().yesno("EspaDaily", f"No se encontró '[B]{query}[/B]' en el catálogo de Atresplayer.\n\n¿Buscar en Dailymotion?"):
            _lfd(query, "")
        else:
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    h = int(sys.argv[1])
    for score, prog in results:
        pct = int(score * 100)
        label = f"[B]{prog['title']}[/B] [COLOR gray]({prog['category']})[/COLOR] [COLOR lime]{pct}%[/COLOR]"
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': prog['thumb'] or 'DefaultVideo.png', 'thumb': prog['thumb']})
        li.setInfo('video', {'plot': prog['plot'] or f"{prog['title']} - {prog['category']} ({pct}%)"})
        if prog['url']:
            nav_url = _u(action="fs", au=prog['url'], st=prog['title'], sth=prog['thumb'])
        else:
            nav_url = _u(action="lfr", q=prog['title'], ot=prog['thumb'])
        xbmcplugin.addDirectoryItem(handle=h, url=nav_url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def _search_mediaset_catalog(p):
    if not p.get("ready"):
        query = ui_utils.get_text('Buscar en Catálogo de Mediaset').strip()
        if not query:
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
            return
        xbmc.executebuiltin(f'Container.Update("{_u(action="search_mediaset_catalog", q=query, ready="1")}")')
        return
    query = p.get("q", "")
    try:
        catalog = _get_cached_catalog("catalog_mediaset", connector._fetch_all_mediaset_catalog)
    except Exception as e:
        xbmcgui.Dialog().ok("EspaDaily", f"Error al obtener el catálogo: {str(e)}")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    if not catalog:
        xbmcgui.Dialog().ok("EspaDaily", "No se pudo obtener el catálogo de Mediaset.")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    results = _catalog_fuzzy_search(query, catalog)
    if not results:
        if xbmcgui.Dialog().yesno("EspaDaily", f"No se encontró '[B]{query}[/B]' en el catálogo de Mediaset.\n\n¿Buscar en Dailymotion?"):
            _lfd(query, "")
        else:
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    h = int(sys.argv[1])
    for score, prog in results:
        pct = int(score * 100)
        if prog['url']:
            suffix = ""
            nav_url = _u(action="fs_mediaset", purl=prog['url'], st=prog['title'], sth=prog['thumb'], cid="")
        else:
            suffix = " [COLOR gray][Internet][/COLOR]"
            nav_url = _u(action="lfr", q=prog['title'], ot=prog['thumb'])
        label = f"[B]{prog['title']}[/B] [COLOR gray]({prog['category']})[/COLOR] [COLOR lime]{pct}%[/COLOR]{suffix}"
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': prog['thumb'] or 'DefaultVideo.png', 'thumb': prog['thumb']})
        plot = prog['plot'] or f"{prog['title']} - {prog['category']} ({pct}%)"
        if not prog['url']:
            plot += "\n[COLOR gray]Sin enlace directo a Mediaset - abrirá búsqueda en Dailymotion.[/COLOR]"
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=h, url=nav_url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def _search_rtve_catalog(p):
    if not p.get("ready"):
        query = ui_utils.get_text('Buscar en Catálogo de RTVE').strip()
        if not query:
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
            return
        xbmc.executebuiltin(f'Container.Update("{_u(action="search_rtve_catalog", q=query, ready="1")}")')
        return
    query = p.get("q", "")
    try:
        catalog = _get_cached_catalog("catalog_rtve", connector._fetch_all_rtve_catalog)
    except Exception as e:
        xbmcgui.Dialog().ok("EspaDaily", f"Error al obtener el catálogo: {str(e)}")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    if not catalog:
        xbmcgui.Dialog().ok("EspaDaily", "No se pudo obtener el catálogo de RTVE.")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    results = _catalog_fuzzy_search(query, catalog)
    if not results:
        if xbmcgui.Dialog().yesno("EspaDaily", f"No se encontró '[B]{query}[/B]' en el catálogo de RTVE.\n\n¿Buscar en Dailymotion?"):
            _lfd(query, "")
        else:
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    h = int(sys.argv[1])
    for score, prog in results:
        pct = int(score * 100)
        label = f"[B]{prog['title']}[/B] [COLOR gray]({prog['category']})[/COLOR] [COLOR lime]{pct}%[/COLOR]"
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': prog['thumb'] or 'DefaultVideo.png', 'thumb': prog['thumb']})
        li.setInfo('video', {'plot': prog['plot'] or f"{prog['title']} - {prog['category']} ({pct}%)"})
        if prog['url']:
            nav_url = _u(action="fs_rtve", pid=prog['url'], st=prog['title'], sth=prog['thumb'])
        else:
            nav_url = _u(action="lfr", q=prog['title'], ot=prog['thumb'])
        xbmcplugin.addDirectoryItem(handle=h, url=nav_url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


_TDT_JSON_URL = "https://www.tdtchannels.com/lists/tv.json"
_TDT_M3U_URL = "https://www.tdtchannels.com/lists/tv.m3u8"
_DM_SAVED_CHANNELS_FILE = "dm_saved_channels.json"
_tdt_json_cache = {"data": None}

def _load_dm_saved_channels():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    fp = os.path.join(p, _DM_SAVED_CHANNELS_FILE)
    if not os.path.exists(fp): return []
    try:
        with open(fp, 'r', encoding='utf-8') as f: return json.load(f)
    except (json.JSONDecodeError, IOError): return []

def _save_dm_saved_channels(channels):
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    fp = os.path.join(p, _DM_SAVED_CHANNELS_FILE)
    try:
        with open(fp, 'w', encoding='utf-8') as f: json.dump(channels, f, ensure_ascii=False)
    except IOError: pass

def _parse_m3u_content(text):
    lines = text.splitlines()
    channels = []
    cur_name, cur_logo, cur_group = "", "", ""
    for line in lines:
        line = line.strip()
        if line.startswith("#EXTINF:"):
            cur_name = line.split(",", 1)[-1].strip() if "," in line else "Canal"
            m = re.search(r'tvg-logo="([^"]*)"', line)
            cur_logo = m.group(1) if m else ""
            m2 = re.search(r'group-title="([^"]*)"', line)
            cur_group = m2.group(1) if m2 else ""
        elif line and not line.startswith("#"):
            channels.append({"name": cur_name or "Canal", "url": line, "logo": cur_logo, "group": cur_group})
            cur_name, cur_logo, cur_group = "", "", ""
    return channels

def _render_m3u_channels(channels, source_label=""):
    h = int(sys.argv[1])
    xbmcplugin.setContent(h, 'videos')
    for ch in channels:
        label = ch["name"]
        if ch["group"]:
            label = "[COLOR gray][{0}][/COLOR] {1}".format(ch["group"], ch["name"])
        li = xbmcgui.ListItem(label=label)
        thumb = ch["logo"] or "DefaultAddonPVRClient.png"
        li.setArt({'icon': thumb, 'thumb': thumb})
        plot = "Canal: {0}".format(ch["name"])
        if ch["group"]: plot += "\nGrupo: {0}".format(ch["group"])
        if source_label: plot += "\n\n{0}".format(source_label)
        li.setInfo('video', {'title': ch["name"], 'plot': plot})
        cm = [("A\u00f1adir a Favoritos", "RunPlugin({0})".format(
            _u(action="add_favorite", title=ch["name"], fav_url=ch["url"], icon=thumb, platform="tdt", fav_action="play_tdt", params=json.dumps({}))
        ))]
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="play_tdt", url=ch["url"], title=ch["name"]), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)

# SLYGUY ADDON INSTALLER
_SLYGUY_REPO_ID = "repository.slyguy"
_SLYGUY_REPO_ZIP = "https://k.slyguy.xyz/repository.slyguy.zip"

def _slyguy_install(addon_id, addon_name):
    """Abre un addon de SlyGuy (Pluto TV, Samsung TV Plus), encendiéndolo si está apagado o
    instalándolo con su repositorio, que se reutiliza si ya está."""
    import espakodi_installer
    if not espakodi_installer.reactivar(addon_id):
        if not xbmcgui.Dialog().yesno(
                "EspaDaily", f"{addon_name} no está instalado.\n\n¿Instalarlo ahora con el repositorio de SlyGuy?"):
            return
        if not espakodi_installer.instalar_con_repo(addon_id, _SLYGUY_REPO_ID, _SLYGUY_REPO_ZIP, addon_name):
            return
    xbmcgui.Dialog().notification("EspaDaily", f"Abriendo {addon_name}...", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin(f"RunAddon({addon_id})")

def _atresdaily_install():
    _show_atresdaily_instructions()

def _open_espatv():
    _ek_espatv_launch()

def _is_atresdaily_installed():
    """Verifica si atresdaily está instalado (cualquier versión)."""
    try:
        xbmcaddon.Addon("plugin.video.atresdaily")
        return True
    except Exception:
        return False

# Conservado un ciclo: tras wrappear _open_atresdaily/_atresdaily_install ya no
# tiene callers en el flujo nuevo. Eliminar en la proxima limpieza.
def _show_atresdaily_instructions():
    xbmcgui.Dialog().textviewer("Instalar AtresDaily",
        "[B]A\u00f1adir v\u00eda repositorio[/B]\n\n"
        "1. Ajustes \u2192 Explorador de archivos \u2192 A\u00f1adir fuente.\n"
        "   URL: https://espatv.github.io/atresdaily/\n"
        "   (Debe terminar en .io/atresdaily/, no la del navegador)\n"
        "   Nombre: atresdaily \u2192 Aceptar.\n\n"
        "2. Add-ons \u2192 cajita abierta (arriba izquierda) \u2192 Instalar desde archivo zip.\n"
        "   (Si salta aviso de seguridad: Ajustes \u2192 activar \"Or\u00edgenes desconocidos\")\n"
        "   Seleccionar fuente atresdaily \u2192 repository.atresdaily-1.0.1.zip.\n\n"
        "3. Cuando aparezca \"Add-on instalado\":\n"
        "   Instalar desde repositorio \u2192 AtresDaily Repository \u2192 Add-ons de v\u00eddeo \u2192 AtresDaily \u2192 Instalar.\n\n"
        "[B]V\u00eda ZIP[/B]\n\n"
        "Descargar el .zip desde github.com\n"
        "Add-ons \u2192 cajita \u2192 Instalar desde archivo zip \u2192 seleccionar el archivo.")

def _open_atresdaily():
    _ek_atresdaily_launch()

def live_tv_menu():
    ui_utils.visto(_NUEVO_EN_MENU["live_tv_entry"])
    h = int(sys.argv[1])
    _fanart = core_settings.addon_fanart()

    _LCN = {
        "La 1": 1, "La 2": 2, "Antena 3": 3, "Cuatro": 4, "Telecinco": 5,
        "laSexta": 6, "Canal 24h": 7, "Teledeporte": 8, "Boing": 9,
        "Clan TVE": 10, "Neox": 11, "Nova": 12, "Mega": 13, "Energy": 14,
        "Factoría de Ficción": 15, "Atreseries": 16, "Be Mad": 17, "Divinity": 18,
    }

    channels = []

    for c in connector._RTVE_LIVE_CHANNELS:
        channels.append({
            'name': c['name'], 'logo': c['logo'],
            'action': 'play_live_rtve', 'params': {'video_id': c['video_id']},
            'plot': c.get('plot', ''),
        })

    for c in connector._MEDIASET_LIVE_CHANNELS:
        logo = connector._MEDIASET_CH_LOGOS.get(c['id'], 'DefaultAddonPVRClient.png')
        channels.append({
            'name': c['name'], 'logo': logo,
            'action': 'play_live_mediaset', 'params': {'url': c['url']},
            'plot': "Canal en directo: {0}".format(c['name']),
        })

    if _is_atresdaily_installed():
        try:
            for c in connector.get_live_channels():
                ch_name = c.get('title') or c.get('name') or "Canal"
                ch_id = c.get('id', '')
                logo = connector._ATRES_CH_LOGOS.get(ch_id, 'DefaultAddonPVRClient.png')
                channels.append({
                    'name': ch_name, 'logo': logo,
                    'action': 'play_live_atres', 'params': {'ch_id': ch_id},
                    'plot': "Canal en directo: {0}".format(ch_name),
                })
        except Exception as e:
            # Sin los de Atresplayer la lista sigue con los demás canales.
            xbmc.log(f"[EspaDaily] Directos de Atresplayer: {e}", xbmc.LOGWARNING)

    channels.sort(key=lambda x: _LCN.get(x['name'], 99))

    _media_epg = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')

    def _ext_icon(addon_id, sub="icon.png", fb='DefaultAddonPVRClient.png'):
        p = xbmcvfs.translatePath("special://home/addons/{0}/{1}".format(addon_id, sub))
        return p if xbmcvfs.exists(p) else fb

    _espanime = "plugin.video.espanime"
    _epg_icon = _ext_icon(_espanime, "resources/media/calendar.png",
                          os.path.join(_media_epg, 'directo.png'))
    li_epg = xbmcgui.ListItem(label="[B]Programación TV (EPG en texto)[/B]")
    li_epg.setArt({'icon': _epg_icon, 'thumb': _epg_icon, 'fanart': _fanart})
    li_epg.setInfo('video', {'plot': "Parrilla de programación en texto de los canales disponibles en EspaDaily.\nActualizacion automática cada 2 horas."})
    li_epg.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="epg_texto_espadaily"), listitem=li_epg, isFolder=True)

    for ch in channels:
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(ch['name']))
        li.setArt({'icon': ch['logo'], 'thumb': ch['logo'], 'fanart': _fanart})
        li.setInfo('video', {'title': ch['name'], 'plot': ch['plot']})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action=ch['action'], **ch['params']),
                                    listitem=li, isFolder=False)

    _sn_id = "plugin.video.streamninja"
    _sn_installed = xbmc.getCondVisibility("System.HasAddon({0})".format(_sn_id))
    lbl_sn = "[COLOR deepskyblue][B]StreamNinja[/B][/COLOR] (Necesario)" if _sn_installed else "[COLOR orange][B]StreamNinja[/B][/COLOR] (Necesario)"
    plt_sn = "Activa el Modo Ninja con StreamNinja para dominar cualquier enlace de video.\n\nNecesario para la reproducción de muchos de los canales de TV." if _sn_installed else "Instala el Modo Ninja: StreamNinja para dominar cualquier enlace de video.\n\nNecesario para la reproducción de muchos de los canales de TV."
    _media = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    sn_icon = os.path.join(_media, 'sn_logo.jpg')
    li_sn = xbmcgui.ListItem(label=lbl_sn)
    li_sn.setArt({"icon": sn_icon, "thumb": sn_icon, "fanart": _fanart})
    li_sn.setInfo("video", {"plot": plt_sn})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="url_player_ensure_sn"), listitem=li_sn, isFolder=False)

    li = xbmcgui.ListItem(label="[B]M\u00e1s canales de televisi\u00f3n[/B]")
    li.setArt({'icon': os.path.join(_media, 'tv.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Lista completa de canales TDT espa\u00f1oles.\n\nIncluye nacionales, auton\u00f3micos, tem\u00e1ticos y m\u00e1s."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="tdt_channels_json"), listitem=li, isFolder=True)

    # Pluto TV y Samsung TV Plus (SlyGuy)
    li = xbmcgui.ListItem(label="[B]Pluto TV[/B]")
    li.setArt({'icon': _ext_icon("slyguy.pluto.tv.provider"), 'fanart': _fanart})
    li.setInfo('video', {'plot': "TV gratuita con canales tem\u00e1ticos (cine, series, noticias...).\nRequiere addon SlyGuy (se instala autom\u00e1ticamente)."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="slyguy_install", addon_id="slyguy.pluto.tv.provider", title="Pluto TV"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[B]Samsung TV Plus[/B]")
    li.setArt({'icon': _ext_icon("slyguy.samsung.tv.plus"), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Canales de TV gratuitos de Samsung.\nRequiere addon SlyGuy (se instala autom\u00e1ticamente)."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="slyguy_install", addon_id="slyguy.samsung.tv.plus", title="Samsung TV Plus"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[B][COLOR red]E[/COLOR][COLOR yellow]s[/COLOR][COLOR red]p[/COLOR][COLOR yellow]a[/COLOR][COLOR red]T[/COLOR][COLOR yellow]V[/COLOR][/B]")
    li.setArt({'icon': _ext_icon("plugin.video.espatv"), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Addon todo-en-uno para contenido en castellano.\nTDT, RTVE a la carta, Dailymotion, YouTube, radio, podcast y mucho m\u00e1s.\n\nSi est\u00e1 instalado se abre directamente.\nSi no, te guiar\u00e1 para instalarlo."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="open_espatv"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="TDT Channels Espa\u00f1a (M3U)")
    li.setArt({'icon': os.path.join(_media, 'tdt.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Lista M3U alternativa."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="tdt_channels"), listitem=li, isFolder=True)

    import iptv_lists
    iptv_lists.add_menu_items()
    xbmcplugin.endOfDirectory(h)

def live_mediaset_menu():
    h = int(sys.argv[1])
    _fanart = core_settings.addon_fanart()
    for c in connector._MEDIASET_LIVE_CHANNELS:
        ch_id = c["id"]; name = c["name"]; url = c["url"]
        thumb = connector._MEDIASET_CH_LOGOS.get(ch_id, "DefaultAddonPVRClient.png")
        li = xbmcgui.ListItem(label=f"[B]{name}[/B]")
        li.setArt({'icon': thumb, 'thumb': thumb, 'fanart': _fanart})
        li.setInfo('video', {'title': name, 'plot': f"Canal en directo: {name}"})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="play_live_mediaset", url=url), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)

def play_live_mediaset(url):
    import url_player as _up
    if not _up.streamninja_check_or_install():
        return
    sn_url = f"plugin://plugin.video.streamninja/?action=url_play&url={urllib.parse.quote(url, safe='')}"
    xbmc.executebuiltin(f'RunPlugin({sn_url})')

def live_atres_menu():
    h = int(sys.argv[1])
    _fanart = core_settings.addon_fanart()
    if not _is_atresdaily_installed():
        li = xbmcgui.ListItem(label="[B][COLOR red]Atres[/COLOR][COLOR blue]Daily[/COLOR][COLOR red] no está instalado[/COLOR][/B]")
        li.setArt({'icon': ui_utils.media_icon('aviso.png'), 'fanart': _fanart})
        li.setInfo('video', {'plot': "AtresDaily es necesario para acceder a los canales en directo de Antena 3.\n\nPulsa para instalar o ver instrucciones."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="atresdaily_install"), listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    for c in connector.get_live_channels():
        ch_id = c.get("id", ""); name = c.get("title") or c.get("name") or "Canal"
        thumb = connector._ATRES_CH_LOGOS.get(ch_id, "DefaultAddonPVRClient.png")
        li = xbmcgui.ListItem(label=f"[B]{name}[/B]")
        li.setArt({'icon': thumb, 'thumb': thumb, 'fanart': _fanart})
        li.setInfo('video', {'title': name})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="play_live_atres", ch_id=ch_id), listitem=li, isFolder=False)

    li_a3 = xbmcgui.ListItem(label="[B]En Directo A3[/B]")
    li_a3.setArt({'icon': ui_utils.media_icon('cat_atres.png'), 'fanart': _fanart})
    li_a3.setInfo('video', {'plot': "Programación en directo del grupo Antena 3 ahora mismo."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="live_atres_now"), listitem=li_a3, isFolder=True)
    li_note = xbmcgui.ListItem(label="[COLOR yellow]NOTA: Los directos pueden fallar con VPN activa[/COLOR]")
    li_note.setArt({'icon': ui_utils.media_icon('info_vpn.png'), 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li_note, isFolder=False)
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)

def play_live_atres(ch_id):
    if not _is_atresdaily_installed():
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification("EspaDaily", "AtresDaily no está instalado.", xbmcgui.NOTIFICATION_WARNING, 4000)
        return
    stream = connector.resolve_live_channel(ch_id)
    if stream:
        ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        stream += "|User-Agent=" + urllib.parse.quote(ua)
        li = xbmcgui.ListItem(path=stream)
        li.setMimeType("application/x-mpegURL")
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
    else:
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification("EspaDaily", "Emisión no disponible", xbmcgui.NOTIFICATION_ERROR)

def live_atres_now():
    h = int(sys.argv[1])
    _fanart = core_settings.addon_fanart()
    if not _is_atresdaily_installed():
        li = xbmcgui.ListItem(label="[B][COLOR red]AtresDaily no está instalado[/COLOR][/B]")
        li.setArt({'icon': ui_utils.media_icon('aviso.png'), 'fanart': _fanart})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="atresdaily_install"), listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return
    items = connector.fetch_live_schedule()
    if not items:
        li = xbmcgui.ListItem(label="Sin datos de emisión disponibles")
        li.setArt({'icon': ui_utils.media_icon('tv_sin_emision.png'), 'fanart': _fanart})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return
    for item in items:
        title = item.get("title") or item.get("name", "Emisión")
        link = item.get("link") or {}
        href = link.get("href", "")
        ch_id = item.get("mainChannel") or item.get("contentId")
        if not ch_id and "/" in href:
            ch_id = href.rstrip("/").split("/")[-1]
        if not ch_id:
            continue
        img_data = item.get("image") or item.get("images") or {}
        img = img_data.get("pathHorizontal") if isinstance(img_data, dict) else None
        thumb = _fix_img(img) if img else "DefaultAddonPVRClient.png"
        channel_name = link.get("url", "").replace("/directos/", "").replace("/", "").title()
        label = f"{title} [COLOR yellow]({channel_name})[/COLOR]" if channel_name else title
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': thumb, 'thumb': thumb, 'fanart': thumb})
        li.setInfo('video', {'title': title})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="play_live_atres", ch_id=ch_id), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)

def play_atres_episode(eid):
    h = int(sys.argv[1])
    if not _is_atresdaily_installed():
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification("EspaDaily", "AtresDaily no está instalado.", xbmcgui.NOTIFICATION_WARNING, 4000)
        return
    cabeceras = ui_utils.del_conector("cabeceras_reproduccion")
    if not cabeceras:
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return
    resolver = getattr(connector, "resolve_atres_media", None)
    if resolver:
        media = resolver(eid)
    else:
        src = connector.resolve_atres_episode(eid)
        media = {"url": src, "mime": "application/x-mpegURL"} if src else None
    if media:
        li = xbmcgui.ListItem(path=f"{media['url']}|{cabeceras('atres')}")
        li.setInfo('music' if media["mime"].startswith("audio/") else 'video', {'title': 'Atresplayer'})
        li.setMimeType(media["mime"])
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(h, True, li)
    else:
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification("EspaDaily", "Contenido no disponible en Atresplayer (requiere premium o no existe)", xbmcgui.NOTIFICATION_WARNING, 4000)

def live_rtve_menu():
    h = int(sys.argv[1])
    _fanart = core_settings.addon_fanart()
    for c in connector._RTVE_LIVE_CHANNELS:
        li = xbmcgui.ListItem(label=f"[B]{c['name']}[/B]")
        li.setArt({'icon': c['logo'], 'thumb': c['logo'], 'fanart': _fanart})
        li.setInfo('video', {'title': c['name'], 'plot': c['plot']})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="play_live_rtve", video_id=c['video_id']), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)

def play_live_rtve(video_id):
    cabeceras = ui_utils.del_conector("cabeceras_reproduccion")
    if not cabeceras:
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        return
    result = connector.resolve_rtve_live(video_id)
    headers_str = cabeceras("rtve")
    li = xbmcgui.ListItem(path=result["url"])
    li.setProperty("inputstream", "inputstream.adaptive")
    li.setProperty("inputstream.adaptive.manifest_type", "mpd")
    li.setProperty("inputstream.adaptive.manifest_headers", headers_str)
    li.setProperty("inputstream.adaptive.stream_headers", headers_str)
    if result["license_url"]:
        li.setProperty("inputstream.adaptive.license_type", "com.widevine.alpha")
        li.setProperty("inputstream.adaptive.license_key", result["license_url"])
    li.setMimeType("application/dash+xml")
    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)

def tdt_channels_json():
    h = int(sys.argv[1])
    dp = xbmcgui.DialogProgress()
    dp.create("TDT Channels", "Descargando lista actualizada...")
    try:
        dp.update(30, "Conectando con tdtchannels.com...")
        r = requests.get(_TDT_JSON_URL, timeout=15)
        if r.status_code != 200: raise Exception("Error HTTP {0}".format(r.status_code))
        dp.update(70, "Procesando canales...")
        data = r.json()
        dp.close()
        countries = data.get("countries", [])
        if not countries:
            xbmcgui.Dialog().ok("TDT Channels", "No se encontraron datos.")
            xbmcplugin.endOfDirectory(h); return
        _tdt_json_cache["data"] = countries[0].get("ambits", [])
        for ambit in _tdt_json_cache["data"]:
            name = ambit.get("name", "Sin nombre")
            num = len(ambit.get("channels", []))
            li = xbmcgui.ListItem(label=f"[B]{name}[/B] [COLOR gray]({num})[/COLOR]")
            thumb = ui_utils.media_icon("carpeta.png")
            li.setArt({'icon': thumb, 'thumb': thumb, 'fanart': core_settings.addon_fanart()})
            li.setInfo('video', {'plot': f"Categoría: {name}\nCanales: {num}"})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="tdt_json_ambit", url=name), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(h)
    except Exception as e:
        dp.close()
        _log_error("Error TDT JSON: {0}".format(e))
        xbmcgui.Dialog().ok("TDT Channels", "No se pudo cargar:\n{0}".format(e))
        try: xbmcplugin.endOfDirectory(h)
        except Exception: pass

def tdt_json_ambit(ambit_name):
    """Muestra los canales de un ámbito concreto del JSON de TDT Channels."""
    h = int(sys.argv[1])
    ambits = _tdt_json_cache.get("data")
    if not ambits:
        try:
            r = requests.get(_TDT_JSON_URL, timeout=15)
            data = r.json()
            countries = data.get("countries", [])
            ambits = countries[0].get("ambits", []) if countries else []
            _tdt_json_cache["data"] = ambits
        except Exception as e:
            xbmcgui.Dialog().ok("TDT Channels", f"No se pudo descargar: {e}")
            xbmcplugin.endOfDirectory(h)
            return

    if not ambits:
        xbmcplugin.endOfDirectory(h)
        return

    ambit = next((a for a in ambits if a.get("name") == ambit_name), None)
    if not ambit:
        xbmcgui.Dialog().ok("TDT Channels", f"Categoría '{ambit_name}' no encontrada.")
        xbmcplugin.endOfDirectory(h)
        return

    xbmcplugin.setContent(h, 'videos')
    import grabaciones
    estado_grabar = grabaciones.estado()

    for ch in ambit.get("channels", []):
        name = ch.get("name", "Canal")
        logo = ch.get("logo", "")
        options = ch.get("options", [])
        extra_info = ch.get("extra_info", [])
        # Kodi solo reproduce las opciones m3u8 y mp4. Las de YouTube y las de tipo "stream"
        # (reproductores web de Twitch, Dailymotion...) se abren como la web del canal.
        playables = [o for o in options if o.get("url") and o.get("format", "").lower() in ("m3u8", "mp4", "")]
        externas = [o["url"] for o in options if o.get("url") and o not in playables]
        web_url = ch.get("web", "") or (externas[0] if externas else "")

        stream_url = playables[0]["url"] if playables else ""
        stream_format = playables[0].get("format", "") if playables else ""

        # Grabar, solo los HLS (el JSON dice el formato de cada enlace)
        rec_mark, rec_entry = "", None
        if stream_url and stream_format == "m3u8" and grabaciones.admite(stream_url):
            rec_mark, rec_entry = grabaciones.entrada(
                estado_grabar, stream_url, grabaciones.orden_tdt(stream_url, name, ch.get("epg_id")))

        # Etiqueta
        label = rec_mark + name
        if "GEO" in extra_info:
            label += " [COLOR orange][GEO][/COLOR]"

        thumb = logo or ui_utils.media_icon("directo.png")
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': thumb, 'thumb': thumb})

        if stream_url:
            opts_text = "\n".join([f"  • {o['url'][:60]}..." for o in playables[:4]])
            li.setInfo('video', {
                'title': name,
                'plot': f"Canal: {name}\nCategoría: {ambit_name}\nFormato: {stream_format}\n\nStreams disponibles ({len(playables)}):\n{opts_text}"
            })

            cm = []
            cm.append(("Añadir a Mis Favoritos", f"RunPlugin({_u(action='add_favorite', title=name, fav_url=stream_url, icon=thumb, platform='tdt', fav_action='play_tdt', params=json.dumps({'url': stream_url, 'title': name}))})"))
            if len(playables) > 1:
                cm.append(("Probar otro stream", f"RunPlugin({_u(action='play_tdt', url=playables[1]['url'], title=name)})"))
            if rec_entry:
                cm.append(rec_entry)
            li.addContextMenuItems(cm)

            play_url = _u(action="play_tdt", url=stream_url, title=name)
            xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

        elif web_url:
            label = f"{name} [COLOR skyblue][WEB][/COLOR]"
            if "GEO" in extra_info:
                label += " [COLOR orange][GEO][/COLOR]"
            li = xbmcgui.ListItem(label=label)
            li.setArt({'icon': thumb, 'thumb': thumb})
            li.setInfo('video', {
                'title': name,
                'plot': f"Canal: {name}\nCategoría: {ambit_name}\n\nEste canal no tiene una emisión que Kodi pueda reproducir.\nSe abrirá fuera de Kodi (navegador o app de YouTube):\n{web_url}"
            })
            open_url = _u(action="open_browser_url", url=web_url)
            xbmcplugin.addDirectoryItem(handle=h, url=open_url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h)

def open_browser_url(url):
    """Abre una URL en el navegador. Soporta Android (TV/Fire Stick) y PC."""
    h = int(sys.argv[1])
    abierto = False
    try:
        if xbmc.getCondVisibility("System.Platform.Android"):
            # Unas comillas romperían la orden; en una dirección de verdad no aparecen.
            if '"' not in url:
                xbmc.executebuiltin(f'StartAndroidActivity("","android.intent.action.VIEW","","{url}")')
                abierto = True
        else:
            import webbrowser
            # Sin navegador (LibreELEC, un Linux sin escritorio) devuelve False, sin excepción.
            abierto = webbrowser.open(url)
    except Exception as e:
        # webbrowser y el intent de Android fallan de formas distintas según el aparato.
        xbmc.log(f"[EspaDaily] No se pudo abrir {url} en el navegador: {e}", xbmc.LOGWARNING)
    finally:
        # Se cierra antes de avisar, para que Kodi no siga con la rueda de espera detrás.
        if h >= 0:
            xbmcplugin.endOfDirectory(h, succeeded=False)
    if abierto:
        xbmcgui.Dialog().notification("EspaDaily", "Abriendo en el navegador...", xbmcgui.NOTIFICATION_INFO, 2000)
    else:
        xbmcgui.Dialog().ok("Abrir en navegador",
                            f"No se pudo abrir el navegador automáticamente.\n\nAbre esta URL manualmente:\n{url}")

def tdt_channels():
    h = int(sys.argv[1])
    dp = xbmcgui.DialogProgress()
    dp.create("TDT Channels", "Descargando lista M3U...")
    try:
        dp.update(30, "Conectando...")
        r = requests.get(_TDT_M3U_URL, timeout=15)
        if r.status_code != 200: raise Exception("Error HTTP {0}".format(r.status_code))
        dp.update(70, "Procesando canales...")
        channels = _parse_m3u_content(r.text)
        dp.close()
        if not channels:
            xbmcgui.Dialog().ok("TDT Channels", "No se encontraron canales.")
            xbmcplugin.endOfDirectory(h); return
        _render_m3u_channels(channels, "TDT Channels Espa\u00f1a")
    except Exception as e:
        dp.close()
        _log_error("Error TDT M3U: {0}".format(e))
        xbmcgui.Dialog().ok("TDT Channels", "No se pudo cargar:\n{0}".format(e))
        try: xbmcplugin.endOfDirectory(h)
        except Exception: pass

def play_tdt(url, title=""):
    try:
        is_m3u8 = '.m3u8' in url.lower().split('|')[0]
        ua = ""
        use_ia = False

        if core_settings.is_iptv_anti_errors_active() and '|' not in url:
            ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

        if is_m3u8 and core_settings.is_tdt_inputstream_active():
            if xbmc.getCondVisibility("System.AddonIsEnabled(inputstream.adaptive)"):
                use_ia = True
            else:
                xbmc.log("[EspaDaily] InputStream Adaptive activado pero no instalado.", xbmc.LOGWARNING)

        if use_ia:
            play_url = url.split('|')[0]
        elif ua and '|' not in url:
            play_url = url + "|User-Agent=" + urllib.parse.quote(ua)
        else:
            play_url = url

        li = xbmcgui.ListItem(path=play_url)
        if title: li.setInfo('video', {'title': title})
        if is_m3u8: li.setMimeType('application/x-mpegURL')
        li.setContentLookup(False)

        if use_ia:
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstreamaddon', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            if ua:
                li.setProperty('inputstream.adaptive.stream_headers', 'User-Agent=' + urllib.parse.quote(ua))

        xbmc.Player().play(play_url, li)
    except Exception as e:
        _log_error("Error TDT play: {0}".format(e))
        xbmcgui.Dialog().ok("Error", "No se pudo reproducir:\n{0}".format(e))

_WATCH_HISTORY_FILE = "watch_history.json"
_MAX_WATCH_HISTORY = 100

def _load_watch_history():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    fp = os.path.join(p, _WATCH_HISTORY_FILE)
    if not os.path.exists(fp): return []
    try:
        with open(fp, 'r', encoding='utf-8') as f: return json.load(f)
    except (json.JSONDecodeError, IOError): return []

def _save_watch_history(history):
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    fp = os.path.join(p, _WATCH_HISTORY_FILE)
    try:
        with open(fp, 'w', encoding='utf-8') as f: json.dump(history, f, ensure_ascii=False)
    except IOError: pass

def _add_watch_entry(vid, title, thumb="", duration=0):
    if not vid: return
    history = _load_watch_history()
    history = [entry for entry in history if entry.get("vid") != vid]
    history.insert(0, {"vid": vid, "title": title, "thumb": thumb, "duration": duration, "watched_at": int(time.time())})
    history = history[:_MAX_WATCH_HISTORY]
    _save_watch_history(history)

def _get_watched_ids():
    return set(entry.get("vid", "") for entry in _load_watch_history())

def _view_watch_history():
    import datetime
    h = int(sys.argv[1])
    history = _load_watch_history()
    if history:
        li = xbmcgui.ListItem(label="[COLOR red][B]Borrar todo el historial de visionado[/B][/COLOR]")
        li.setArt({'icon': ui_utils.media_icon('borrar_historial.png'), 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'plot': "Tienes {0} v\u00eddeos en el historial.".format(len(history))})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="clear_watch_history"), listitem=li, isFolder=False)
    if not history:
        li = xbmcgui.ListItem(label="[COLOR gray]No has reproducido ning\u00fan v\u00eddeo a\u00fan[/COLOR]")
        li.setArt({'icon': ui_utils.media_icon('visionado_vacio.png'), 'fanart': core_settings.addon_fanart()})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h); return
    xbmcplugin.setContent(h, 'videos')
    addon = xbmcaddon.Addon()
    ai = addon.getAddonInfo('icon')
    for entry in history:
        vid = entry.get('vid', '')
        vt = entry.get('title', 'Video')
        dth = entry.get('thumb', '') or ai
        du = entry.get('duration', 0)
        try: du = int(du)
        except (ValueError, TypeError): du = 0
        watched_at = entry.get('watched_at', 0)
        try:
            dt = datetime.datetime.fromtimestamp(watched_at)
            date_str = dt.strftime("%d/%m/%Y %H:%M")
        except Exception: date_str = ""
        label = "[COLOR lime][V][/COLOR] {0}".format(vt)
        li = xbmcgui.ListItem(label=label)
        li.setArt({'thumb': dth, 'icon': dth})
        plot = "Visto: {0}".format(date_str)
        if du: plot += "\nDuraci\u00f3n: {0}m {1}s".format(du // 60, du % 60)
        li.setInfo('video', {'title': vt, 'plot': plot, 'duration': du})
        li.setProperty("IsPlayable", "true")
        is_ace = bool(vid and vid.startswith("acestream://"))
        cm = []
        if vid:
            cm.append(("Eliminar del historial", "RunPlugin({0})".format(_u(action="del_watch_entry", url=vid))))
            if is_ace:
                _ih = vid.replace("acestream://", "")
                _fav_params = json.dumps({"infohash": _ih, "name": vt})
                cm.append(("Añadir a Mis Favoritos", "RunPlugin({0})".format(
                    _u(action="add_favorite", title=vt, fav_url="ace_" + _ih,
                       icon=dth, platform="acestream",
                       fav_action="play_ace_result", params=_fav_params))))
            else:
                cm.append(("Abrir en navegador", "RunPlugin({0})".format(_u(action="dm_open_browser", url=vid))))
                _fav_params = json.dumps({"vid": vid, "title": vt})
                cm.append(("Añadir a Mis Favoritos", "RunPlugin({0})".format(
                    _u(action="add_favorite", title=vt, fav_url="pv_" + vid,
                       icon=dth, platform="dailymotion",
                       fav_action="pv", params=_fav_params))))
        li.addContextMenuItems(cm)
        if is_ace:
            play_url = _u(action="play_ace_result", infohash=vid.replace("acestream://", ""), name=vt)
        else:
            play_url = _u(action="pv", vid=vid, title=urllib.parse.quote(vt))
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)

def _del_watch_entry(vid):
    if not vid: return
    history = _load_watch_history()
    history = [entry for entry in history if entry.get("vid") != vid]
    _save_watch_history(history)
    xbmc.executebuiltin("Container.Refresh")

def _clear_watch_history():
    if xbmcgui.Dialog().yesno("EspaDaily", "\u00bfBorrar todo el historial de visionado?"):
        _save_watch_history([])
        xbmc.executebuiltin("Container.Refresh")




def _show_trending():
    h = int(sys.argv[1])
    try:
        time_limit = int(time.time()) - 604800
        params = {
            "sort": "trending", "language": "es", "created_after": time_limit,
            "limit": ui_utils.dm_limite_lista(50),
            "fields": "id,title,thumbnail_720_url,thumbnail_url,duration,views_total,owner.screenname,owner.username"
        }
        datos = ui_utils.dm_api_videos("/videos", params, timeout=15)
        rs = ui_utils.filtrar_dm_borrados(datos.get("list", []), cuantos=50)
        if not rs:
            xbmcgui.Dialog().ok("Tendencias", "No se han encontrado v\u00eddeos en tendencia.")
            xbmcplugin.endOfDirectory(h); return
        xbmcplugin.setContent(h, 'videos')
        watched_ids = _get_watched_ids()
        addon = xbmcaddon.Addon()
        ai = addon.getAddonInfo('icon')
        for i, v in enumerate(rs):
            vt = v.get("title", "Video")
            vi = v.get("id")
            ow = v.get("owner.screenname") or v.get("owner.username", "")
            du = 0
            try: du = int(v.get("duration", 0))
            except (ValueError, TypeError): pass
            vw = 0
            try: vw = int(v.get("views_total", 0))
            except (ValueError, TypeError): pass
            dth = v.get("thumbnail_720_url") or v.get("thumbnail_url") or ai
            is_watched = vi in watched_ids if vi else False
            watched_mark = "[COLOR lime][V][/COLOR] " if is_watched else ""
            label = "[COLOR orange]{0}.[/COLOR] {1}{2}".format(i + 1, watched_mark, vt)
            li = xbmcgui.ListItem(label=label)
            li.setArt({'thumb': dth, 'icon': dth})
            li.setInfo('video', {'title': vt, 'plot': "Canal: {0}\nVistas: {1:,}\nDuraci\u00f3n: {2}m {3}s".format(ow, vw, du // 60, du % 60), 'duration': du})
            li.setProperty("IsPlayable", "true")
            cm = []
            if vi:
                cm.append(("Descargar Video", "RunPlugin({0})".format(_u(action="download_video", vid=vi, title=vt))))
                cm.append(("Abrir en navegador", "RunPlugin({0})".format(_u(action="dm_open_browser", url=vi))))
            li.addContextMenuItems(cm)
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="pv", vid=vi, title=urllib.parse.quote(vt)), listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
    except Exception as e:
        xbmcgui.Dialog().ok("Error", "Error al cargar tendencias:\n{0}".format(str(e)))
        try: xbmcplugin.endOfDirectory(h)
        except Exception: pass




def _dm_open_browser(vid):
    dm_web = ui_utils.del_conector("dm_web") if vid else None
    if dm_web:
        # open_browser_url tambi\u00e9n ense\u00f1a la direcci\u00f3n cuando no hay navegador (LibreELEC).
        open_browser_url(dm_web(vid))

def _sanitize_log_line(line):
    line = re.sub(r'(access_token=)[^&\s]+', lambda m: m.group(1) + '***', line)
    line = re.sub(r'(bearer=)[^&\s]+', lambda m: m.group(1) + '***', line)
    line = re.sub(r'(hdnts=)[^&\s]+', lambda m: m.group(1) + '***', line)
    line = re.sub(r'(token=)[^&\s]+', lambda m: m.group(1) + '***', line)
    line = re.sub(r'(Authorization:\s*Bearer\s+)\S+', lambda m: m.group(1) + '***', line, flags=re.IGNORECASE)
    return line

def _view_kodi_log():
    try:
        log_path = xbmcvfs.translatePath("special://logpath/kodi.log")
        if not os.path.exists(log_path):
            xbmcgui.Dialog().ok("EspaDaily", "No se encontr\u00f3 el archivo de log de Kodi.")
            return
        with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
            lines = f.readlines()
        last_lines = lines[-100:]
        espa_lines = [_sanitize_log_line(l.rstrip()) for l in last_lines if 'espadaily' in l.lower() or 'espakodi' in l.lower()]
        if not espa_lines:
            espa_lines = [_sanitize_log_line(l.rstrip()) for l in last_lines[-30:]]
        text = "\n".join(espa_lines[-50:])
        xbmcgui.Dialog().textviewer("Log de Kodi (EspaDaily)", text)
    except Exception as e:
        xbmcgui.Dialog().ok("Error", "No se pudo leer el log:\n{0}".format(e))

def _view_kodi_log_full():
    """Muestra las últimas N líneas del log de Kodi sin filtrar."""
    try:
        log_path = xbmcvfs.translatePath("special://logpath/kodi.log")
        if not os.path.exists(log_path):
            xbmcgui.Dialog().ok("EspaDaily", "No se encontr\u00f3 el archivo de log de Kodi.")
            return
        opts = ["\u00daltimas 50 l\u00edneas", "\u00daltimas 100 l\u00edneas", "\u00daltimas 200 l\u00edneas"]
        counts = [50, 100, 200]
        sel = xbmcgui.Dialog().select("\u00bfCu\u00e1ntas l\u00edneas?", opts)
        if sel < 0: return
        with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
            lines = f.readlines()
        text = "".join([_sanitize_log_line(l) for l in lines[-counts[sel]:]])
        xbmcgui.Dialog().textviewer("Log de Kodi (completo)", text)
    except Exception as e:
        xbmcgui.Dialog().ok("Error", "No se pudo leer el log:\n{0}".format(e))

def _view_kodi_log_errors():
    """Muestra solo las líneas de error y warning del log."""
    try:
        log_path = xbmcvfs.translatePath("special://logpath/kodi.log")
        if not os.path.exists(log_path):
            xbmcgui.Dialog().ok("EspaDaily", "No se encontr\u00f3 el archivo de log de Kodi.")
            return
        with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
            lines = f.readlines()
        error_lines = [_sanitize_log_line(l.rstrip()) for l in lines[-500:]
                       if ' error ' in l.lower() or 'warning' in l.lower() or 'exception' in l.lower() or 'traceback' in l.lower()]
        if not error_lines:
            xbmcgui.Dialog().ok("EspaDaily", "No se encontraron errores recientes en el log.")
            return
        text = "\n".join(error_lines[-80:])
        xbmcgui.Dialog().textviewer("Errores del Log de Kodi", text)
    except Exception as e:
        xbmcgui.Dialog().ok("Error", "No se pudo leer el log:\n{0}".format(e))

def _search_kodi_log():
    """Busca un texto en el log de Kodi."""
    kb = xbmc.Keyboard('', 'Buscar en el log de Kodi')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        return
    term = kb.getText().strip().lower()
    try:
        log_path = xbmcvfs.translatePath("special://logpath/kodi.log")
        if not os.path.exists(log_path):
            xbmcgui.Dialog().ok("EspaDaily", "No se encontr\u00f3 el archivo de log.")
            return
        with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
            lines = f.readlines()
        matches = [_sanitize_log_line(l.rstrip()) for l in lines if term in l.lower()]
        if not matches:
            xbmcgui.Dialog().ok("EspaDaily", "No se encontr\u00f3 '{0}' en el log.".format(kb.getText().strip()))
            return
        header = "{0} resultados para '{1}'".format(len(matches), kb.getText().strip())
        text = "\n".join(matches[-80:])
        xbmcgui.Dialog().textviewer(header, text)
    except Exception as e:
        xbmcgui.Dialog().ok("Error", str(e))

def _log_info():
    _l("EspaDaily log tools active")


# AUTOSTART y AUTOF AV
_AUTOSTART_DELAY_LABELS = ['Sin espera', '5 seg', '10 seg', '15 seg', '30 seg', '1 min']

# Tipos de addon que tiene sentido abrir al arrancar (lanzables con RunAddon). Filtrar
# por tipo deja fuera skins, repositorios, modulos, servicios, scrapers e interfaces
# web (Chorus) sin mantener listas negras de prefijos.
_AUTOSTART_LAUNCHABLE_TYPES = ('xbmc.python.pluginsource', 'xbmc.python.script')

def _get_launchable_addons():
    seen = {}
    for atype in _AUTOSTART_LAUNCHABLE_TYPES:
        try:
            resp = json.loads(xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'id': 1,
                'method': 'Addons.GetAddons',
                'params': {'type': atype, 'enabled': True, 'properties': ['name']},
            })))
        except Exception:
            continue
        for a in (resp.get('result') or {}).get('addons') or []:
            aid = a.get('addonid')
            if aid:
                seen[aid] = a.get('name') or aid
    return sorted(((name, aid) for aid, name in seen.items()), key=lambda x: x[0].lower())

def _autostart_delay_label(raw):
    try:
        idx = int(raw)
        return _AUTOSTART_DELAY_LABELS[idx] if 0 <= idx < len(_AUTOSTART_DELAY_LABELS) else 'Sin espera'
    except (ValueError, TypeError):
        return raw if raw in _AUTOSTART_DELAY_LABELS else 'Sin espera'

def _get_kodi_favourites():
    import xml.etree.ElementTree as ET
    ruta = xbmcvfs.translatePath('special://profile/favourites.xml')
    try:
        root = ET.parse(ruta).getroot()
    except (OSError, ET.ParseError):
        return []
    favs = []
    for elem in root.findall('favourite'):
        cmd = (elem.text or '').strip()
        name = elem.get('name') or cmd
        if cmd:
            favs.append((name, cmd, elem.get('thumb') or ''))
    return favs

def _autoejecutar_menu():
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)
    _fanart = core_settings.addon_fanart()

    li = xbmcgui.ListItem(label="Inicio automático de addons")
    li.setArt({'icon': _mi('adv_autostart.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Configura hasta 3 addons que se abriran automaticamente al arrancar Kodi."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="autostart_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Inicio automático de favoritos")
    li.setArt({'icon': _mi('adv_autostart.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Configura hasta 3 favoritos de Kodi que se abrirán automáticamente al arrancar."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="autofav_menu"), listitem=li, isFolder=True)

    webapp_on = xbmcaddon.Addon().getSetting('webapp_autostart') == 'true'
    webapp_estado = "[COLOR limegreen]ACTIVADO[/COLOR]" if webapp_on else "[COLOR grey]DESACTIVADO[/COLOR]"
    li = xbmcgui.ListItem(label=f"Arrancar WebApp al iniciar: {webapp_estado}")
    li.setArt({'icon': _mi('webapp_autostart.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Al arrancar Kodi, levanta el servidor de la WebApp de EspaDaily y abre el navegador, sin tener que entrar al menú Experimental.\n\nPulsa para activar o desactivar."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_webapp_autostart"), listitem=li, isFolder=False)
    _webapp_estado_items(_fanart)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _autostart_menu():
    addon = xbmcaddon.Addon()
    ico = ui_utils.media_icon("adv_autostart.png") or "DefaultAddonService.png"
    for i in range(1, 4):
        enabled = addon.getSetting(f'autostart_{i}_enabled') == 'true'
        addon_id = addon.getSetting(f'autostart_{i}_id').strip()
        delay_label = _autostart_delay_label(addon.getSetting(f'autostart_{i}_delay'))
        if enabled and addon_id:
            nombre = addon_id
            try: nombre = xbmcaddon.Addon(addon_id).getAddonInfo('name')
            except RuntimeError: pass
            label = f"Slot {i}: [COLOR green]{nombre}[/COLOR]  ({delay_label})"
            plot = f"Addon: {nombre}\nID: {addon_id}\nRetardo: {delay_label}\n\n[I]Pulsa para editar o desactivar.[/I]"
        else:
            label = f"Slot {i}: [COLOR grey]Sin configurar[/COLOR]"
            plot = "Slot vacío. Pulsa para configurar un addon que se abrirá automaticamente al arrancar Kodi."
        ui_utils.add_item(action="autostart_config_slot", title=label, thumbnail=ico, folder=False, plot=plot, slot=i)
    ui_utils.close_item_list()

def _autostart_config_slot(slot):
    addon = xbmcaddon.Addon()
    addon_id = addon.getSetting(f'autostart_{slot}_id').strip()
    enabled = addon.getSetting(f'autostart_{slot}_enabled') == 'true'
    delay_label = _autostart_delay_label(addon.getSetting(f'autostart_{slot}_delay'))
    delay_idx = next((i for i, l in enumerate(_AUTOSTART_DELAY_LABELS) if l == delay_label), 0)
    nombre = addon_id
    if addon_id:
        try: nombre = xbmcaddon.Addon(addon_id).getAddonInfo('name')
        except RuntimeError: pass
    if enabled and addon_id:
        delay_txt = f'despues de {delay_label}' if delay_label != 'Sin espera' else 'en cuanto Kodi arranque'
        sel = xbmcgui.Dialog().select(f'Slot {slot}: {nombre} se abre {delay_txt}',
            ['Cambiar addon', 'Cambiar retardo', 'Desactivar este slot'])
        if sel < 0: return
        if sel == 2:
            addon.setSetting(f'autostart_{slot}_enabled', 'false')
            xbmcgui.Dialog().notification("Inicio automático", f"Slot {slot} desactivado", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh"); return
        if sel == 1:
            idx = xbmcgui.Dialog().select("Retardo antes de lanzar", _AUTOSTART_DELAY_LABELS, preselect=delay_idx)
            if idx < 0: return
            addon.setSetting(f'autostart_{slot}_delay', _AUTOSTART_DELAY_LABELS[idx])
            xbmcgui.Dialog().notification("Inicio automático", f"Retardo: {_AUTOSTART_DELAY_LABELS[idx]}", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh"); return
    addons_lista = _get_launchable_addons()
    if not addons_lista:
        xbmcgui.Dialog().notification("Inicio automático", "No se encontraron addons instalados", xbmcgui.NOTIFICATION_WARNING)
        xbmc.executebuiltin("Container.Refresh"); return
    names = [name for name, _aid in addons_lista]
    presel = next((i for i, (_, aid) in enumerate(addons_lista) if aid == addon_id), -1)
    sel_addon = xbmcgui.Dialog().select("Seleccionar addon a lanzar al arrancar", names, preselect=presel)
    if sel_addon < 0: return
    nuevo_id = addons_lista[sel_addon][1]
    nuevo_nombre = addons_lista[sel_addon][0]
    idx = xbmcgui.Dialog().select("Retardo antes de lanzar", _AUTOSTART_DELAY_LABELS, preselect=delay_idx)
    nuevo_delay = _AUTOSTART_DELAY_LABELS[idx] if idx >= 0 else delay_label
    addon.setSetting(f'autostart_{slot}_enabled', 'true')
    addon.setSetting(f'autostart_{slot}_id', nuevo_id)
    addon.setSetting(f'autostart_{slot}_delay', nuevo_delay)
    xbmcgui.Dialog().notification("Inicio automático", f"Slot {slot}: {nuevo_nombre}", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _autofav_menu():
    addon = xbmcaddon.Addon()
    ico = ui_utils.media_icon("adv_autostart.png") or "DefaultAddonService.png"
    for i in range(1, 4):
        enabled = addon.getSetting(f'autofav_{i}_enabled') == 'true'
        titulo = addon.getSetting(f'autofav_{i}_title').strip()
        delay_label = _autostart_delay_label(addon.getSetting(f'autofav_{i}_delay'))
        if enabled and titulo:
            label = f"Favorito {i}: [COLOR green]{titulo}[/COLOR]  ({delay_label})"
            plot = f"Favorito: {titulo}\nRetardo: {delay_label}\n\n[I]Pulsa para editar o desactivar.[/I]"
        else:
            label = f"Favorito {i}: [COLOR grey]Sin configurar[/COLOR]"
            plot = "Slot vacío. Pulsa para elegir un favorito de Kodi que se abrirá automaticamente al arrancar."
        ui_utils.add_item(action="autofav_config_slot", title=label, thumbnail=ico, folder=False, plot=plot, slot=i)
    ui_utils.close_item_list()

def _autofav_config_slot(slot):
    addon = xbmcaddon.Addon()
    titulo = addon.getSetting(f'autofav_{slot}_title').strip()
    enabled = addon.getSetting(f'autofav_{slot}_enabled') == 'true'
    delay_label = _autostart_delay_label(addon.getSetting(f'autofav_{slot}_delay'))
    delay_idx = next((i for i, l in enumerate(_AUTOSTART_DELAY_LABELS) if l == delay_label), 0)
    if enabled and titulo:
        delay_txt = f'despues de {delay_label}' if delay_label != 'Sin espera' else 'en cuanto Kodi arranque'
        sel = xbmcgui.Dialog().select(f'Favorito {slot}: {titulo} se abre {delay_txt}',
            ['Cambiar favorito', 'Cambiar retardo', 'Desactivar este slot'])
        if sel < 0: return
        if sel == 2:
            addon.setSetting(f'autofav_{slot}_enabled', 'false')
            xbmcgui.Dialog().notification("Inicio automático", f"Favorito {slot} desactivado", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh"); return
        if sel == 1:
            idx = xbmcgui.Dialog().select("Retardo antes de lanzar", _AUTOSTART_DELAY_LABELS, preselect=delay_idx)
            if idx < 0: return
            addon.setSetting(f'autofav_{slot}_delay', _AUTOSTART_DELAY_LABELS[idx])
            xbmcgui.Dialog().notification("Inicio automático", f"Retardo: {_AUTOSTART_DELAY_LABELS[idx]}", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh"); return
    favs = _get_kodi_favourites()
    if not favs:
        xbmcgui.Dialog().notification("Inicio automático", "No tienes favoritos guardados en Kodi", xbmcgui.NOTIFICATION_WARNING)
        xbmc.executebuiltin("Container.Refresh"); return
    names = [name for name, _cmd, _thumb in favs]
    presel = next((i for i, (name, _c, _t) in enumerate(favs) if name == titulo), -1)
    sel_fav = xbmcgui.Dialog().select("Seleccionar favorito a lanzar al arrancar", names, preselect=presel)
    if sel_fav < 0: return
    nuevo_titulo, nuevo_cmd, _ = favs[sel_fav]
    idx = xbmcgui.Dialog().select("Retardo antes de lanzar", _AUTOSTART_DELAY_LABELS, preselect=delay_idx)
    nuevo_delay = _AUTOSTART_DELAY_LABELS[idx] if idx >= 0 else delay_label
    addon.setSetting(f'autofav_{slot}_enabled', 'true')
    addon.setSetting(f'autofav_{slot}_title', nuevo_titulo)
    addon.setSetting(f'autofav_{slot}_cmd', nuevo_cmd)
    addon.setSetting(f'autofav_{slot}_delay', nuevo_delay)
    xbmcgui.Dialog().notification("Inicio automático", f"Favorito {slot}: {nuevo_titulo}", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


# CRT VINTAGE
def crt_config_menu():
    addon = xbmcaddon.Addon()
    def _st(k): return addon.getSetting(k) == 'true'
    def _onoff(v): return "[COLOR lime]ON[/COLOR]" if v else "[COLOR red]OFF[/COLOR]"
    master = _st('crt_enabled')
    ui_utils.add_item(action="crt_toggle", title=f"Activar Modo CRT: {_onoff(master)}",
        thumbnail=ui_utils.media_icon("crt_tv.png"), folder=True, key="crt_enabled",
        plot="Activa o desactiva el filtro CRT sobre la reproducción de video. Al activarlo puede que necesites reiniciar Kodi para que empiece a aplicarse.")
    if master:
        ui_utils.add_item(action="crt_toggle", title=f"Líneas de barrido (scanlines): {_onoff(_st('crt_scanlines'))}",
            thumbnail=ui_utils.media_icon("crt_tv.png"), folder=True, key="crt_scanlines")
        ui_utils.add_item(action="crt_toggle", title=f"Viñeta (bordes oscuros): {_onoff(_st('crt_vignette'))}",
            thumbnail=ui_utils.media_icon("crt_tv.png"), folder=True, key="crt_vignette")
        ui_utils.add_item(action="crt_toggle", title=f"Marco curvo del tubo: {_onoff(_st('crt_bezel'))}",
            thumbnail=ui_utils.media_icon("crt_tv.png"), folder=True, key="crt_bezel")
        ui_utils.add_item(action="crt_toggle", title=f"Tinte cálido (sepia): {_onoff(_st('crt_sepia'))}",
            thumbnail=ui_utils.media_icon("crt_tv.png"), folder=True, key="crt_sepia")
        ui_utils.add_item(action="crt_toggle", title=f"Grano / estatica: {_onoff(_st('crt_grain'))}",
            thumbnail=ui_utils.media_icon("crt_tv.png"), folder=True, key="crt_grain")
        ui_utils.add_item(action="crt_toggle", title=f"Barra de desincronización: {_onoff(_st('crt_rollbar'))}",
            thumbnail=ui_utils.media_icon("crt_tv.png"), folder=True, key="crt_rollbar")
        ui_utils.add_item(action="crt_toggle", title=f"Parpadeo de brillo: {_onoff(_st('crt_flicker'))}",
            thumbnail=ui_utils.media_icon("crt_tv.png"), folder=True, key="crt_flicker")
    ui_utils.close_item_list()

def crt_toggle(key):
    addon = xbmcaddon.Addon()
    if key in ('crt_enabled', 'crt_scanlines', 'crt_vignette', 'crt_bezel', 'crt_sepia',
               'crt_grain', 'crt_rollbar', 'crt_flicker'):
        activado = addon.getSetting(key) != 'true'
        addon.setSetting(key, 'true' if activado else 'false')
        if key == 'crt_enabled' and activado:
            xbmcgui.Dialog().ok("Modo CRT activado",
                "El filtro se aplicara a [B]todos los videos[/B] que reproduzcas en "
                "Kodi mientras este activo, no solo a EspaDaily.\n\n"
                "Si no aparece al reproducir, [B]reinicia Kodi[/B] una vez para que "
                "el servicio del filtro arranque.")
    xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
    xbmc.executebuiltin('Container.Refresh')


# Constantes AceStream
_ACE_PROXY_FILE = 'acestream_proxy.json'
_ACE_RE_ID  = re.compile(r'^[0-9a-fA-F]{40}$')
_ACE_RE_URL = re.compile(r'^acestream://[0-9a-fA-F]{40}$', re.IGNORECASE)
_ACE_PROXY_RX = re.compile(
    r'^(?:[^:@/\s]+:[^@/\s]*@)?'           # usuario:clave@ (opcional)
    r'[a-zA-Z0-9._\-]+'                    # host
    r':\d{1,5}$'                           # :puerto
)
_ACE_TAG_RE    = re.compile(r'<[^>]+>')
_KODI_TAG_RE   = re.compile(r'\[/?(?:COLOR|B|I|LIGHT|UPPERCASE|LOWERCASE)[^\]]*\]', re.IGNORECASE)
_ACE_ANCHOR_RE = re.compile(
    r'<a\b[^>]*?(?:href|content_id|infohash)=["\']?'
    r'(?:acestream://)?([0-9a-fA-F]{40})["\']?[^>]*>(.*?)</a>',
    re.IGNORECASE | re.DOTALL,
)
_ACE_LOOSE_RE  = re.compile(r'(?:acestream://|content_id=|infohash=)([0-9a-fA-F]{40})', re.IGNORECASE)
_ACE_HISTORY_MAX = 100


def _ace_proxy_cfg():
    c = ui_utils.load_json(_ACE_PROXY_FILE, default={})
    if not isinstance(c, dict):
        c = {}
    return {'enabled': bool(c.get('enabled')), 'addr': str(c.get('addr') or '')}


def _ace_proxy_set(**kwargs):
    c = _ace_proxy_cfg()
    c.update(kwargs)
    ui_utils.save_json(_ACE_PROXY_FILE, c)


def _ace_proxy_refresh(h):
    xbmcplugin.endOfDirectory(h, succeeded=False)
    xbmc.executebuiltin('Container.Refresh')


def _proxy_display(addr):
    if not addr:
        return '(sin proxy)'
    return addr if len(addr) <= 40 else addr[:37] + '...'


def _ace_save_history(type_, value):
    hist = ui_utils.load_json('acestream_history.json', default=[])
    if not isinstance(hist, list):
        hist = []
    ts = int(time.time())
    date = time.strftime('%d/%m/%Y %H:%M', time.localtime(ts))
    hist = [e for e in hist if not (e.get('type') == type_ and e.get('value') == value)]
    hist.append({'type': type_, 'value': value, 'date': date, 'ts': ts})
    if len(hist) > _ACE_HISTORY_MAX:
        hist = hist[-_ACE_HISTORY_MAX:]
    ui_utils.save_json('acestream_history.json', hist)


def _acestream_enter_id():
    h = int(sys.argv[1])
    raw = ui_utils.get_text('ID AceStream (40 hex)').strip()
    if not raw:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    if not _ACE_RE_ID.match(raw):
        xbmcgui.Dialog().ok("AceStream", "ID no válido.\nDebe ser exactamente 40 caracteres hexadecimales (0-9, a-f).")
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    url = 'acestream://' + raw.lower()
    _ace_save_history('id', url)
    play_url = f"{sys.argv[0]}?action=play_ace&url={urllib.parse.quote(url)}&title=AceStream"
    xbmc.executebuiltin(f'RunPlugin({play_url})')
    xbmcplugin.endOfDirectory(h, succeeded=False)

def _acestream_enter_url():
    h = int(sys.argv[1])
    raw = ui_utils.get_text('URL acestream:// (40 hex)').strip()
    if not raw:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    if not _ACE_RE_URL.match(raw):
        xbmcgui.Dialog().ok("AceStream", "URL no válida.\nFormato esperado: acestream://[40 caracteres hex]")
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    url = raw.lower()
    _ace_save_history('url', url)
    play_url = f"{sys.argv[0]}?action=play_ace&url={urllib.parse.quote(url)}&title=AceStream"
    xbmc.executebuiltin(f'RunPlugin({play_url})')
    xbmcplugin.endOfDirectory(h, succeeded=False)


def _acestream_history_clear():
    h = int(sys.argv[1])
    if not xbmcgui.Dialog().yesno("Historial AceStream", "¿Borrar todo el historial?"):
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    ui_utils.save_json('acestream_history.json', [])
    xbmcgui.Dialog().notification("AceStream", "Historial borrado", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(h, succeeded=False)


def _acestream_history_delete(ts_str):
    try:
        ts = int(ts_str)
    except (TypeError, ValueError):
        return
    hist = ui_utils.load_json('acestream_history.json', default=[])
    hist = [e for e in hist if e.get('ts') != ts]
    ui_utils.save_json('acestream_history.json', hist)
    xbmc.executebuiltin("Container.Refresh")


def _acestream_history_scan(url):
    h = int(sys.argv[1])
    if not url:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    _do_acestream_scan(h, url)


def _acestream_history_search(query):
    if not query:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    _search_acestream_results(query)


def _acestream_proxy_clear():
    _ace_proxy_set(addr='')
    _ace_proxy_refresh(int(sys.argv[1]))


def _acestream_proxy_find():
    h = int(sys.argv[1])
    import busqueda_total
    bg = xbmcgui.DialogProgressBG()
    bg.create("AceStream", "Buscando proxy disponible...")
    try:
        addr = busqueda_total.obtener_proxy_valido()
    finally:
        bg.close()
    if addr:
        _ace_proxy_set(addr=addr)
        xbmcgui.Dialog().notification("AceStream", f"Proxy: {_proxy_display(addr)}", xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification("AceStream", "No se encontró proxy disponible",
                                      xbmcgui.NOTIFICATION_WARNING)
    _ace_proxy_refresh(h)


def _acestream_proxy_manual():
    h = int(sys.argv[1])
    kb = xbmc.Keyboard(_ace_proxy_cfg()['addr'], 'Proxy (host:puerto o usuario:clave@host:puerto)')
    kb.doModal()
    addr = kb.getText().strip() if kb.isConfirmed() else ''
    if not addr:   # cancelado o vacío: no tocar nada (para borrar está "Quitar proxy")
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    if not _ACE_PROXY_RX.match(addr):
        xbmcgui.Dialog().ok("AceStream", "Formato no válido.\nUsa host:puerto o usuario:clave@host:puerto")
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    _ace_proxy_set(addr=addr, enabled=True)
    _ace_proxy_refresh(h)


def _acestream_proxy_toggle():
    _ace_proxy_set(enabled=not _ace_proxy_cfg()['enabled'])
    _ace_proxy_refresh(int(sys.argv[1]))


def _acestream_scan_url():
    h = int(sys.argv[1])
    raw = ui_utils.get_text('URL de web o canal Telegram (t.me/canal)').strip()
    if not raw:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    # Normalizar entrada de Telegram o URL web
    input_text = raw
    clean_tg = re.sub(r'^https?://', '', input_text)
    if clean_tg.startswith('t.me/'):
        clean_tg = re.sub(r'^t\.me/(?:s/)?', '', clean_tg)
    elif clean_tg.startswith('@'):
        clean_tg = clean_tg.lstrip('@')
    # Quitar posibles barras o parámetros de consulta al final del canal
    clean_tg = clean_tg.split('/')[0].split('?')[0].strip()

    # Si es un formato válido de canal de Telegram (ej: letras, números o _ con longitud >= 4)
    if re.match(r'^[a-zA-Z][a-zA-Z0-9_]{3,}$', clean_tg):
        raw = f'https://t.me/s/{clean_tg}'
    else:
        # Si es una dirección web y no tiene protocolo, se lo añadimos
        if not input_text.startswith(('http://', 'https://')):
            raw = 'https://' + input_text

    _ace_save_history('scan', raw)
    _do_acestream_scan(h, raw)


def _acestream_search_by_name():
    query = ui_utils.get_text('Buscar en AceStream').strip()
    if not query:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    _ace_save_history('search', query)
    _search_acestream_results(query)


def _acestream_show_history():
    h = int(sys.argv[1])
    hist = ui_utils.load_json('acestream_history.json', default=[])
    if not hist:
        xbmcgui.Dialog().ok("Historial AceStream", "El historial está vacío.")
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    xbmcplugin.setPluginCategory(h, "Historial AceStream")
    xbmcplugin.setContent(h, "videos")

    type_label = {
        'search': 'Búsqueda',
        'url': 'URL acestream://',
        'id': 'Hash directo',
        'scan': 'Web / Telegram',
    }
    type_icon = {
        'search': ui_utils.media_icon('srch_estandar.png'),
        'url': ui_utils.media_icon('url.png'),
        'id': ui_utils.media_icon('bt_episodio.png'),
        'scan': ui_utils.media_icon('url_scan.png'),
    }

    _fanart = core_settings.addon_fanart()
    for entry in reversed(hist):
        t      = entry.get('type', '')
        val    = entry.get('value', '')
        date   = entry.get('date', '')
        ts     = entry.get('ts', 0)
        tlabel = type_label.get(t, t)
        icon   = type_icon.get(t, ui_utils.media_icon('p2p_desconocido.png'))
        display = val if len(val) <= 55 else val[:52] + '...'
        title  = f"[{tlabel}] {display}"
        plot   = f"Tipo: {tlabel}\nValor: {val}\nFecha: {date}"
        li = xbmcgui.ListItem(label=title)
        li.setInfo("video", {"title": title, "plot": plot})
        li.setArt({"icon": icon, "thumb": icon, "fanart": _fanart})
        del_url = f"{sys.argv[0]}?action=acestream_history_delete&ts={ts}"
        li.addContextMenuItems([("Eliminar del historial", f"RunPlugin({del_url})")])
        if t in ('url', 'id'):
            li.setProperty("IsPlayable", "true")
            item_url = _u(action="play_ace_result", infohash=val.replace("acestream://", ""), name=display)
            xbmcplugin.addDirectoryItem(handle=h, url=item_url, listitem=li, isFolder=False)
        elif t == 'search':
            item_url = f"{sys.argv[0]}?action=acestream_history_search&q={urllib.parse.quote(val)}"
            xbmcplugin.addDirectoryItem(handle=h, url=item_url, listitem=li, isFolder=True)
        elif t == 'scan':
            item_url = f"{sys.argv[0]}?action=acestream_history_scan&url={urllib.parse.quote(val)}"
            xbmcplugin.addDirectoryItem(handle=h, url=item_url, listitem=li, isFolder=True)

    li_clear = xbmcgui.ListItem(label="[COLOR red]Borrar todo el historial[/COLOR]")
    li_clear.setInfo("video", {"title": "Borrar todo el historial"})
    li_clear.setArt({"icon": ui_utils.media_icon('borrar_historial.png'), "fanart": core_settings.addon_fanart()})
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=f"{sys.argv[0]}?action=acestream_history_clear",
        listitem=li_clear,
        isFolder=False,
    )
    xbmcplugin.endOfDirectory(h)


def _check_integration_first_use(addon_name):
    if core_settings.is_integration_first_use_shown(addon_name):
        return True
    title, text = _INTEGRATION_FIRST_USE_TEXTS[addon_name]
    accepted = xbmcgui.Dialog().yesno(
        f"Buscar en {title}",
        text,
        yeslabel="Aceptar",
        nolabel="Cancelar",
    )
    if accepted:
        core_settings.mark_integration_first_use_shown(addon_name)
    return accepted

def _clean_ace_name(fragment):
    """Extrae el texto visible de un <a>. Quita etiquetas HTML, descodifica entidades, quita el BBCode
    que Kodi interpretaría en el label y colapsa espacios."""
    txt = _html.unescape(_ACE_TAG_RE.sub(' ', fragment or ''))
    txt = _KODI_TAG_RE.sub('', txt)
    return re.sub(r'\s+', ' ', txt).strip()


def _do_acestream_scan(h, raw):
    dp = xbmcgui.DialogProgress()
    dp.create("AceStream - Escaneando", f"Conectando con {raw[:60]}...")
    try:
        dp.update(30, "Descargando página...")
        ap = _ace_proxy_cfg()
        proxy = None
        if ap['enabled'] and ap['addr']:
            purl = _proxy_url(ap['addr'])
            proxy = {'http': purl, 'https': purl}
        try:
            page = _fetch_scan_text(raw, None)                  # directo primero
        except Exception as e_direct:
            if not proxy:
                raise
            xbmc.log(f"[EspaDaily AceStream] escaneo directo falló, reintento con proxy: {e_direct}", xbmc.LOGWARNING)
            dp.update(45, "Reintentando con proxy...")
            page = _fetch_scan_text(raw, proxy)                 # fallback por proxy
        dp.update(70, "Buscando enlaces acestream...")

        found = _extract_ace_links(page)
        dp.close()

        if not found:
            xbmcgui.Dialog().ok("AceStream", f"No se encontraron enlaces acestream en:\n{raw}")
            xbmcplugin.endOfDirectory(h, succeeded=False)
            return

        xbmcplugin.setPluginCategory(h, f"AceStream · {raw[:50]}")
        xbmcplugin.setContent(h, "videos")
        for hash_id, name in found:
            url = f"acestream://{hash_id}"
            label = name[:80] if name else f"Acestream {hash_id[:8]}..."
            li = xbmcgui.ListItem(label=label)
            li.setInfo("video", {"title": label, "plot": url})
            li.setArt({"icon": ui_utils.media_icon('p2p.png')})
            li.setProperty("IsPlayable", "true")
            play_url = _u(action="play_ace_result", infohash=hash_id, name=label)
            xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)

    except Exception as e:
        try: dp.close()
        except Exception: pass
        xbmc.log(f"[EspaDaily AceStream] escaneo falló ({raw[:80]}): {e}", xbmc.LOGWARNING)
        xbmcgui.Dialog().ok("Error", f"No se pudo escanear la URL:\n{str(e)[:200]}")
        xbmcplugin.endOfDirectory(h, succeeded=False)


def _extract_ace_links(text):
    """[(hash, nombre|None)] de los enlaces acestream del HTML, deduplicados por hash (gana
    el primer nombre). Prioriza el texto de los <a>; los hashes sueltos (acestream:// o
    content_id/infohash) entran sin nombre como red de seguridad. Preserva orden."""
    out = {}   # dict conserva el orden de inserción
    for m in _ACE_ANCHOR_RE.finditer(text):
        hid = m.group(1).lower()
        name = _clean_ace_name(m.group(2))
        if name and (name.lower().startswith('acestream://') or _ACE_RE_ID.match(name)):
            name = ''   # el texto del enlace es la propia URL/hash: no aporta nombre
        if hid not in out:
            out[hid] = name or None
        elif name and not out[hid]:
            out[hid] = name
    for m in _ACE_LOOSE_RE.finditer(text):
        out.setdefault(m.group(1).lower(), None)
    return list(out.items())


_SCAN_MAX_BYTES = 5 * 1024 * 1024   # las páginas de listas/Telegram son HTML pequeño


def _fetch_scan_text(url, proxy):
    headers = {'User-Agent': ui_utils.HEADERS["User-Agent"]}
    resp = requests.get(url, headers=headers, proxies=proxy, timeout=15, stream=True)
    resp.raise_for_status()
    chunks = []
    total = 0
    for chunk in resp.iter_content(chunk_size=65536):
        chunks.append(chunk)
        total += len(chunk)
        if total >= _SCAN_MAX_BYTES:
            break
    raw = b''.join(chunks)
    enc = resp.encoding or resp.apparent_encoding or 'utf-8'
    return raw.decode(enc, errors='replace')


def _proxy_url(addr):
    """Normaliza un proxy a URL con esquema. 'host:port' -> 'http://host:port'; respeta un
    http(s):// ya presente. requests/urllib lo tratan así de forma uniforme entre versiones."""
    return addr if '://' in addr else f'http://{addr}'


def _search_alfa_from_results(query):
    alfa_id = core_settings.get_alfa_addon_id()
    if not alfa_id:
        xbmcgui.Dialog().ok("EspaDaily",
            "El plugin Alfa no está instalado.\n\n"
            "Instala Alfa para usar esta función.")
        return
    if not core_settings.is_alfa_integration_enabled():
        xbmcgui.Dialog().ok("EspaDaily",
            "La búsqueda en Alfa está desactivada.\n\n"
            "Actívala en:\nOpciones → Búsqueda en otros addons → Buscar en Alfa")
        return
    if not _check_integration_first_use('alfa'):
        return
    texto = ui_utils.get_text('Buscar en Alfa', query or '').strip()
    if texto:
        item_data = {'module': 'search', 'action': 'new_search', 'search_text': texto, 'mode': 'all'}
        payload = urllib.parse.quote(
            base64.b64encode(json.dumps(item_data, separators=(',', ':')).encode('utf-8')).decode('utf-8')
        )
        xbmc.executebuiltin(f"Container.Update(plugin://{alfa_id}/?{payload})")

def _search_balandro_from_results(query):
    balandro_id = 'plugin.video.balandro'
    if not ui_utils.addon_listo(balandro_id, "Balandro",
            "El plugin de Balandro no está instalado.\n\n"
            "Instala Balandro para usar esta función."):
        return
    if not core_settings.is_balandro_integration_enabled():
        xbmcgui.Dialog().ok("EspaDaily",
            "La búsqueda en Balandro está desactivada.\n\n"
            "Actívala en:\nOpciones → Búsqueda en otros addons → Buscar en Balandro")
        return
    if not _check_integration_first_use('balandro'):
        return

    # Teclado/web con consulta pre-rellenada
    texto = ui_utils.get_text('Buscar en Balandro', query or '').strip()
    if texto:
        # Reutilizamos el sistema de codificación de BuscaBalandro (JSON + Base64)
        item_data = {
            'channel': 'search',
            'action': 'search',
            'search_type': 'all',
            'buscando': texto,
        }
        payload = base64.b64encode(json.dumps(item_data).encode('utf-8')).decode('utf-8')
        balandro_url = f"plugin://{balandro_id}/?{urllib.parse.quote_plus(payload)}"
        xbmc.executebuiltin(f"Container.Update({balandro_url})")

# AVISO LEGAL:
# Este buscador es un lanzador independiente integrado en EspaDaily que permite
# abrir la función de búsqueda del addon Jackt-.-.. ook desde este menú rápido.
# EspaDaily NO aloja, distribuye, enlaza ni reproduce contenido de ningún tipo.
# Toda la funcionalidad de búsqueda es proporcionada íntegramente por el addon Jacktoo-.-..-k,
# sobre el cual este proyecto no tiene control ni responsabilidad alguna.
def _search_jacktook_from_results(query):
    jacktook_id = 'plugin.video.jacktook'
    if not ui_utils.addon_listo(jacktook_id, "Jacktook",
            "El plugin Jacktook no está instalado.\n\n"
            "Instala Jacktook para usar esta función."):
        return
    if not core_settings.is_jacktook_integration_enabled():
        xbmcgui.Dialog().ok("EspaDaily",
            "La búsqueda en Jacktook está desactivada.\n\n"
            "Actívala en:\nOpciones → Búsqueda en otros addons → Buscar en Jacktook")
        return
    if not _check_integration_first_use('jacktook'):
        return
    texto = ui_utils.get_text('Buscar en Jacktook', query or '').strip()
    if texto:
        # Misma ruta interna que usa Jacktook en su propia UI de búsqueda multimodal
        params = {'action': 'handle_tmdb_search', 'mode': 'multi', 'page': '1', 'query': texto}
        url = f"plugin://{jacktook_id}/?{urllib.parse.urlencode(params)}"
        xbmc.executebuiltin(f"Container.Update({url})")

def _search_in_addon(addon_id, q, ot):
    params = {'action': 'search_alt_prompt', 'q': q, 'ot': ot or ''}
    url = f"plugin://{addon_id}/?" + urllib.parse.urlencode(params)
    xbmc.executebuiltin(f'RunPlugin({url})')

# AVISO LEGAL:
# Este buscador es un lanzador independiente integrado en EspaDaily que permite
# abrir la función de búsqueda del addon Alfa desde este menú rápido.
# EspaDaily NO aloja, distribuye, enlaza ni reproduce contenido de ningún tipo.
# Toda la funcionalidad de búsqueda es proporcionada íntegramente por el addon A-.-.lfa,
# sobre el cual este proyecto no tiene control ni responsabilidad alguna.
def _search_palantir_from_results(query):
    """Búsqueda en Palantir (dinámico) desde resultados, con detección de parche Estuary."""
    if core_settings.are_external_integrations_disabled():
        xbmcgui.Dialog().ok("EspaDaily",
            "La búsqueda en otros addons está desactivada globalmente.\n\n"
            "Actívala en:\nOpciones → Búsqueda en otros addons → Buscar en otros addons")
        return
    if not core_settings.is_palantir_integration_enabled():
        xbmcgui.Dialog().ok("EspaDaily",
            "La búsqueda en Palantir 3 está desactivada.\n\n"
            "Actívala en:\nOpciones → Búsqueda en otros addons → Buscar en Palantir 3")
        return
    palantir_id = core_settings.get_palantir_addon_id()
    if not palantir_id:
        xbmcgui.Dialog().ok("EspaDaily",
            "Palantir no está instalado.\n\n"
            "Instala Palantir para usar esta función.")
        return
    if not _check_integration_first_use('palantir'):
        return
    if not _ensure_palantir_fix_ready():
        return

    # Teclado/web con consulta pre-rellenada
    texto = ui_utils.get_text('Buscar en Palantir (Detectado)', query or '')
    if texto:
        _search_palantir(texto)

def _search_palantir_prompt(query):
    if core_settings.are_external_integrations_disabled():
        xbmcgui.Dialog().ok("EspaDaily",
            "La búsqueda en otros addons está desactivada globalmente.\n\n"
            "Actívala en:\nOpciones → Búsqueda en otros addons → Buscar en otros addons")
        return
    if not core_settings.is_palantir_integration_enabled():
        xbmcgui.Dialog().ok("EspaDaily",
            "La búsqueda en Palantir 3 está desactivada.\n\n"
            "Actívala en:\nOpciones → Búsqueda en otros addons → Buscar en Palantir 3")
        return
    if not _check_integration_first_use('palantir'):
        return
    if not _ensure_palantir_fix_ready():
        return
    nq = ui_utils.get_text('Buscar en Palantir (Detectado)', query or '')
    if nq:
        _search_palantir(nq)

def _url_player_config_menu():
    addon = xbmcaddon.Addon()
    _mp = os.path.join(addon.getAddonInfo('path'), 'resources', 'media')

    def _ico(name, fallback='DefaultAddonService.png'):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    h = int(sys.argv[1])
    _fanart = core_settings.addon_fanart()

    # webremote_mode es labelenum: puede venir como etiqueta o como índice
    mode_raw = (addon.getSetting('webremote_mode') or 'Red local').strip()
    mode_internet = mode_raw in ('1', 'Internet')

    # 1. Modo de conexión
    mode_label = "[COLOR cyan]Internet (relay ntfy)[/COLOR]" if mode_internet else "[COLOR green]Red local[/COLOR]"
    li = xbmcgui.ListItem(label=f"Modo de conexión: {mode_label}")
    li.setArt({'icon': _ico('adv_puerto.png', 'DefaultNetwork.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': (
        "Cómo escucha el receptor de URLs.\n\n"
        "[B]Red local:[/B] accesible solo en tu WiFi. Rápido y sin dependencias.\n\n"
        "[B]Internet (relay ntfy):[/B] usa el servidor ntfy para recibir URLs desde fuera de casa.\n\n"
        "[COLOR blue][I]Pulsa para cambiar.[/I][/COLOR]"
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="set_webremote_mode"), listitem=li, isFolder=False)

    # 2. Puerto (reutiliza handler config_remote_port)
    cur_port = addon.getSetting('remote_port') or '8089'
    li = xbmcgui.ListItem(label=f"Puerto servidor: [COLOR deepskyblue]{cur_port}[/COLOR]")
    li.setArt({'icon': _ico('adv_puerto.png', 'DefaultNetwork.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': (
        f"Puerto inicial del servidor HTTP local para enviar URLs desde el móvil o PC.\n"
        f"Si está ocupado, se prueban los 10 siguientes.\nPuerto actual: {cur_port}\n\n"
        "[COLOR blue][I]Pulsa para cambiar.[/I][/COLOR]"
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="config_remote_port"), listitem=li, isFolder=False)

    # 3. Seguridad (reutiliza handler toggle_remote_secure)
    secure = addon.getSetting('remote_secure') == 'true'
    secure_label = "[COLOR lime]ACTIVADA[/COLOR]" if secure else "[COLOR gray]DESACTIVADA[/COLOR]"
    li = xbmcgui.ListItem(label=f"Seguridad (código de acceso): {secure_label}")
    li.setArt({'icon': _ico('adv_anti_errores.png', 'DefaultAddonProgram.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': (
        "Protección del mando web.\n\n"
        "DESACTIVADA (por defecto): cualquier dispositivo de tu WiFi puede acceder. Ideal en casa.\n\n"
        "ACTIVADA: la URL incluye un código único; sin él nadie accede aunque esté en tu red. "
        "Recomendado en redes públicas.\n\n"
        "[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_remote_secure"), listitem=li, isFolder=False)

    # 4. Confirmar antes de reproducir
    confirm = addon.getSetting('webremote_confirm') == 'true'
    confirm_label = "[COLOR lime]SÍ[/COLOR]" if confirm else "[COLOR grey]NO[/COLOR]"
    li = xbmcgui.ListItem(label=f"Confirmar antes de reproducir: {confirm_label}")
    li.setArt({'icon': _ico('adv_anti_errores.png', 'DefaultAddonService.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': (
        "Si está activo, Kodi pregunta antes de reproducir cada URL recibida desde el móvil o PC. "
        "Evita reproducciones accidentales.\n\n"
        "[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_webremote_confirm"), listitem=li, isFolder=False)

    # 5 y 6. Solo en modo Internet
    if mode_internet:
        ntfy_server = (addon.getSetting('webremote_server') or 'https://ntfy.sh').rstrip('/')
        ntfy_topic = addon.getSetting('webremote_topic') or '(se genera al primer uso)'

        li = xbmcgui.ListItem(label=f"Servidor relay: [COLOR deepskyblue]{ntfy_server}[/COLOR]")
        li.setArt({'icon': _ico('adv_puerto.png', 'DefaultNetwork.png'), 'fanart': _fanart})
        li.setInfo('video', {'plot': (
            f"URL del servidor ntfy para el relay de Internet.\nActual: {ntfy_server}\n\n"
            f"Canal asignado: {ntfy_topic}\n\n"
            "Puedes usar el público ntfy.sh o alojar el tuyo.\n\n"
            "[COLOR blue][I]Pulsa para cambiar la URL.[/I][/COLOR]"
        )})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="set_webremote_server"), listitem=li, isFolder=False)

        li = xbmcgui.ListItem(label="[COLOR orange]Regenerar canal ntfy[/COLOR]")
        li.setArt({'icon': _ico('adv_refrescar.png', 'DefaultAddonService.png'), 'fanart': _fanart})
        li.setInfo('video', {'plot': (
            f"Canal actual: {ntfy_topic}\n\n"
            "Borra el canal para que se genere uno nuevo aleatorio al próximo arranque del mando.\n"
            "Tendrás que actualizar la suscripción en tu móvil.\n\n"
            "[COLOR blue][I]Pulsa para regenerar.[/I][/COLOR]"
        )})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="reset_webremote_topic"), listitem=li, isFolder=False)

    # Resolver Debrid (estado leído de settings, sin llamadas de red)
    deb_enabled = addon.getSetting('debrid_enabled') == 'true'
    deb_provider, deb_auth, deb_user = _debrid_status()
    if deb_enabled and deb_auth:
        deb_label = "Resolver Debrid: [COLOR lime]{0}[/COLOR]".format(
            "{0} · {1}".format(deb_provider, deb_user) if deb_user else deb_provider)
    elif deb_enabled:
        deb_label = "Resolver Debrid: [COLOR orange]activado, sin vincular[/COLOR]"
    else:
        deb_label = "Resolver Debrid: [COLOR gray]desactivado[/COLOR]"
    li = xbmcgui.ListItem(label=deb_label)
    li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': (
        "Reproduce enlaces de hosters premium (1fichier, Mega, Rapidgator...) y "
        "convierte magnets en streams directos usando tu cuenta Debrid.\n\n"
        "Vincula la cuenta, elige proveedor y opciones.\n\n"
        "[COLOR blue][I]Pulsa para gestionar.[/I][/COLOR]"
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_menu"), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h)

def backup_favs_dialog():
    opts = [
        "Exportar a JSON (para restaurar)",
        "Exportar a Texto (.txt)",
        "Importar Favoritos (JSON)",
    ]
    sel = xbmcgui.Dialog().select("Copia de Seguridad de Favoritos", opts)
    if sel == 0:
        export_favs()
    elif sel == 1:
        export_favs_txt()
    elif sel == 2:
        import_favs()

def clear_full_cache():
    # Limpiar caché JSON de catálogo y otros temporales
    if xbmcgui.Dialog().yesno("Limpiar Caché", "¿Borrar todos los datos de caché del catálogo?\nEsto forzará a recargar la información de A3Player."):
        try:
             _clear_cat_cache()
             xbmcgui.Dialog().notification("EspaDaily", "Caché borrada", xbmcgui.NOTIFICATION_INFO)
             xbmc.executebuiltin("Container.Refresh")
        except Exception as e:
             xbmcgui.Dialog().notification("EspaDaily", f"Error borrando caché: {str(e)}", xbmcgui.NOTIFICATION_ERROR)

def clear_ui_cache():
    xbmc.executebuiltin("Container.Refresh")
    xbmcgui.Dialog().notification("EspaDaily", "Interfaz actualizada", xbmcgui.NOTIFICATION_INFO)

def _vfs_join(folder, name):
    """Une carpeta y fichero también para las rutas de red (smb://, nfs://) que devuelve
    Dialog().browse(), que os.path.join estropea en Windows."""
    sep = '' if folder.endswith(('/', '\\')) else '/'
    return f"{folder}{sep}{name}"


def export_favs():
    if not core_settings.get_favorites():
        xbmcgui.Dialog().notification("EspaDaily", "No hay favoritos para exportar", xbmcgui.NOTIFICATION_WARNING)
        return
    d = xbmcgui.Dialog().browse(3, 'Seleccionar carpeta destino', 'files')
    if not d: return

    # Con xbmcvfs y no shutil, porque browse() puede devolver una carpeta de red.
    if xbmcvfs.copy(ui_utils.get_path('favorites.json'), _vfs_join(d, 'favorites_backup.json')):
        xbmcgui.Dialog().notification("EspaDaily", "Favoritos exportados con éxito")
    else:
        xbmcgui.Dialog().ok("Error", "No se pudo exportar los favoritos a esa carpeta.")

def export_favs_menu():
    """Submenú con opciones de exportación e importación de favoritos."""
    ui_utils.add_item(action="export_favs_txt", title="[COLOR gold]Exportar a Texto (.txt)[/COLOR]", thumbnail=ui_utils.media_icon("favs_export_txt.png"), folder=False, plot="Genera un archivo de texto plano legible con todos tus favoritos.")
    ui_utils.add_item(action="export_favs", title="[COLOR gold]Exportar a JSON (para restaurar)[/COLOR]", thumbnail=ui_utils.media_icon("backup_favs.png"), folder=False, plot="Exporta tus favoritos como archivo JSON que puedes restaurar después.")
    ui_utils.add_item(action="import_favs", title="[COLOR lightblue]Importar Favoritos (JSON)[/COLOR]", thumbnail=ui_utils.media_icon("backup_restore.png"), folder=False, plot="Restaura favoritos desde un archivo JSON exportado previamente.")
    ui_utils.close_item_list()

def export_favs_txt():
    """Exporta la lista de favoritos a un archivo de texto plano."""
    favs = core_settings.get_favorites()
    if not favs:
        xbmcgui.Dialog().notification("EspaDaily", "No hay favoritos para exportar", xbmcgui.NOTIFICATION_WARNING)
        return

    d = xbmcgui.Dialog().browse(3, 'Seleccionar carpeta destino', 'files')
    if not d: return

    lines = [f"Favoritos EspaDaily - {time.strftime('%d/%m/%Y %H:%M')}",
             f"Total: {len(favs)} favoritos", "=" * 50, ""]
    for fav in favs:
        lines.append(f"{fav.get('title', 'Sin título')}")
        if fav.get('url'):
            lines.append(f"  URL: {fav['url']}")
        if fav.get('action'):
            lines.append(f"  Tipo: {fav['action']}")
        lines.append("")

    # Con xbmcvfs, porque browse() puede devolver una carpeta de red.
    with xbmcvfs.File(_vfs_join(d, 'favoritos_espadaily.txt'), 'w') as fh:
        ok = fh.write("\n".join(lines).encode('utf-8'))
    if ok:
        xbmcgui.Dialog().notification("EspaDaily", f"Exportados {len(favs)} favoritos a TXT")
    else:
        xbmcgui.Dialog().ok("Error", "No se pudo escribir el archivo en esa carpeta.")

def import_favs():
    f = xbmcgui.Dialog().browse(1, 'Seleccionar archivo favorites.json', 'files', '.json')
    if not f: return

    with xbmcvfs.File(f) as fh:
        raw = bytes(fh.readBytes())
    try:
        data = json.loads(raw.decode('utf-8-sig'))
    except (ValueError, UnicodeDecodeError) as e:
        xbmcgui.Dialog().ok("Error", f"Archivo no válido o corrupto: {e}")
        return

    # Sin 'url' un favorito no se puede abrir, y además rompe add/remove_favorite.
    favs = [x for x in data if isinstance(x, dict) and isinstance(x.get('url'), str) and x['url']] \
        if isinstance(data, list) else []
    if not favs:
        xbmcgui.Dialog().ok("Error", "El archivo no contiene favoritos válidos.")
        return
    descartados = len(data) - len(favs)
    aviso = f"\n({descartados} entradas sin URL se descartarán)" if descartados else ""
    if xbmcgui.Dialog().yesno("EspaDaily", f"¿Importar {len(favs)} favoritos?{aviso}\n\nSe borrarán los favoritos actuales."):
        ui_utils.save_json('favorites.json', favs)
        xbmcgui.Dialog().notification("EspaDaily", "Favoritos importados")
        xbmc.executebuiltin("Container.Refresh")

def input_mode_menu():
    """Elige cómo se introduce el texto en las búsquedas, ya sea teclado, preguntar o web."""
    keys = ['keyboard', 'ask', 'web']
    opts = ['Teclado de Kodi (siempre)',
            'Preguntar cada vez (teclado o web)',
            'Escribir desde el móvil/PC (web)']
    cfg = ui_utils.load_json('settings.json')
    cur = cfg.get('web_input_mode', 'keyboard')
    preselect = keys.index(cur) if cur in keys else 0
    sel = xbmcgui.Dialog().select('Método de escritura para búsquedas', opts, preselect=preselect)
    if sel >= 0:
        cfg['web_input_mode'] = keys[sel]
        ui_utils.save_json('settings.json', cfg)
        xbmc.executebuiltin("Container.Refresh")

def multi_run(raw):
    """Ejecuta y muestra la búsqueda múltiple (idempotente, los términos vienen en la URL)."""
    if connector is None:
        xbmcgui.Dialog().ok("EspaDaily", "El conector no está disponible.")
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return

    terms = [t.strip() for t in raw.split(',') if t.strip()]
    if not terms:
        xbmcgui.Dialog().notification("EspaDaily", "No se encontraron términos válidos", xbmcgui.NOTIFICATION_WARNING)
        ui_utils.close_item_list()
        return

    if len(terms) > 10:
        terms = terms[:10]
        xbmcgui.Dialog().notification("EspaDaily", "Limitado a 10 términos", xbmcgui.NOTIFICATION_INFO)

    h = int(sys.argv[1])
    dp = xbmcgui.DialogProgress()
    dp.create("Búsqueda Múltiple", f"Buscando {len(terms)} términos...")

    all_results = []
    seen_ids = set()

    for idx, term in enumerate(terms):
        if dp.iscanceled(): break
        dp.update(int((idx / len(terms)) * 100), f"Buscando: {term}")

        try:
            params = {
                "search": term,
                "sort": "relevance",
                "language": "es",
                "limit": ui_utils.dm_limite_lista(10),
                "fields": "id,title,thumbnail_720_url,thumbnail_url,duration,views_total,owner.screenname,owner.username"
            }
            data = ui_utils.dm_api_videos("/videos", params, timeout=15)
            for item in ui_utils.filtrar_dm_borrados(data.get("list", []), cuantos=10):
                vid = item.get("id", "")
                if vid and vid not in seen_ids:
                    seen_ids.add(vid)
                    all_results.append((term, item))
        except Exception as e:
            # Un término que falla no debe dejar sin los resultados de los demás.
            xbmc.log(f"[EspaDaily] Búsqueda múltiple, '{term}': {e}", xbmc.LOGWARNING)

    dp.close()

    if not all_results:
        xbmcgui.Dialog().ok("Búsqueda Múltiple", "No se encontraron resultados para ningún término.")
        xbmcplugin.endOfDirectory(h)
        return

    # Agrupar por término de búsqueda
    for term, item in all_results:
        vid = item.get("id", "")
        title = item.get("title", "Sin título")
        thumb = item.get("thumbnail_720_url") or item.get("thumbnail_url", "")
        try:
            dur = int(item.get("duration", 0))
        except (ValueError, TypeError):
            dur = 0
        owner = item.get("owner.screenname") or item.get("owner.username", "")
        try:
            views = int(item.get("views_total", 0))
        except (ValueError, TypeError):
            views = 0

        dur_min = dur // 60 if dur else 0
        label = f"{title} [COLOR gray]({term})[/COLOR]"
        if dur_min:
            label += f" [COLOR cyan]{dur_min}min[/COLOR]"

        plot = f"Canal: {owner}\nBúsqueda: {term}\nDuración: {dur_min}min\nVisitas: {views:,}"

        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': thumb or 'DefaultVideo.png', 'thumb': thumb})
        li.setInfo('video', {'plot': plot, 'duration': dur})
        # play_dm reproduce con setResolvedUrl, que solo funciona en un ítem IsPlayable.
        # Sin esto Kodi lo lanzaba como script (handle -1) y el vídeo no salía.
        li.setProperty('IsPlayable', 'true')

        cm = []
        cm.append(("[COLOR lime]Abrir en navegador[/COLOR]", f"RunPlugin({sys.argv[0]}?action=dm_open_browser&url={urllib.parse.quote(vid)})"))
        # Guarda el vídeo. Antes guardaba el término con el título del vídeo, y el favorito
        # abría una búsqueda en vez de ese vídeo.
        cm.append(("Añadir a Favoritos", f"RunPlugin({sys.argv[0]}?action=add_fav&title={urllib.parse.quote(title)}&url={urllib.parse.quote(vid)}&f_thumb={urllib.parse.quote(thumb)}&extra=&f_action=play_dm)"))
        li.addContextMenuItems(cm)

        play_url = f"{sys.argv[0]}?action=play_dm&url={urllib.parse.quote(vid)}&title={urllib.parse.quote(title)}&thumb={urllib.parse.quote(thumb)}&duration={dur}"
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)
    xbmcgui.Dialog().notification("Búsqueda Múltiple", f"{len(all_results)} resultados de {len(terms)} términos")

def multi_search():
    """Búsqueda múltiple. Pide los términos y navega a la vista de resultados."""
    if connector is None:
        xbmcgui.Dialog().ok("EspaDaily", "El conector no está disponible.")
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return

    raw = ui_utils.get_text('Términos separados por comas').strip()
    if not raw:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return

    # Con folder=False el prompt no queda en el historial, "volver atrás" va al menú.
    xbmc.executebuiltin(f'Container.Update("{sys.argv[0]}?action=multi_run&q={urllib.parse.quote(raw)}")')


def search_order_menu():
    _addon = xbmcaddon.Addon()

    ui_utils.add_item(action="noop", title="[COLOR gold]- Al abrir un programa de un catálogo -[/COLOR]",
        thumbnail=ui_utils.media_icon("separador.png"), folder=False)
    if _addon.getSetting('catalog_long_first') != 'false':
        lf_label = "Catálogo · Vídeos largos primero: [COLOR green]ACTIVADO[/COLOR]"
        lf_plot = "Al abrir un programa de RTVE, Mediaset o Atresplayer, los vídeos de 30 min o más (capítulos completos) suben, sin pasar por delante de uno que coincide mejor.\n\n[I]Pulsa para desactivar.[/I]"
    else:
        lf_label = "Catálogo · Vídeos largos primero: [COLOR gray]DESACTIVADO[/COLOR]"
        lf_plot = "Los resultados de un programa del catálogo se ordenan solo por parecido con su nombre.\n\n[I]Pulsa para activar.[/I]"
    ui_utils.add_item(action="toggle_catalog_long_first", title=lf_label,
        thumbnail=ui_utils.media_icon("adv_antitrailers.png"), folder=False, plot=lf_plot)

    ui_utils.add_item(action="noop", title="[COLOR gold]- Todas las búsquedas -[/COLOR]",
        thumbnail=ui_utils.media_icon("separador.png"), folder=False)
    if core_settings.is_prioritize_match_active():
        p_label = "Prioriza: [COLOR green]COINCIDENCIA DEL TÍTULO[/COLOR]"
        p_plot = "Ordena por coincidencia de las palabras del título, por encima de la duración.\n\n[I]Pulsa para priorizar vídeos largos.[/I]"
    else:
        p_label = "Prioriza: [COLOR green]VÍDEOS LARGOS[/COLOR]"
        p_plot = "Sube los vídeos largos (capítulos completos) sobre tráileres o clips cortos.\n\n[I]Pulsa para priorizar la coincidencia del título.[/I]"
    ui_utils.add_item(action="toggle_prioritize_match", title=p_label,
        thumbnail=ui_utils.media_icon("adv_priorizar.png"), folder=False, plot=p_plot)

    min_m = core_settings.get_min_duration()
    a_label = (f"Ocultar clips cortos: [COLOR green]+{min_m} MIN[/COLOR]"
               if min_m > 0 else "Ocultar clips cortos: [COLOR gray]NO[/COLOR]")
    a_plot = ("Quita de las búsquedas los vídeos más cortos que el tiempo elegido. Se piden ya así a "
              "Dailymotion, de modo que la lista sale completa con vídeos largos.\n\n[I]Pulsa para configurar.[/I]")
    ui_utils.add_item(action="set_min_duration", title=a_label,
        thumbnail=ui_utils.media_icon("adv_antitrailers.png"), folder=False, plot=a_plot)

    if core_settings.is_recent_active():
        t_label = "Recientes primero: [COLOR green]ACTIVADO[/COLOR]"
        t_plot = "Prioriza los vídeos subidos más recientemente.\n\n[I]Pulsa para volver a orden por relevancia.[/I]"
    else:
        t_label = "Recientes primero: [COLOR gray]DESACTIVADO[/COLOR]"
        t_plot = "Ordena por relevancia (parecido del título), sin importar la fecha.\n\n[I]Pulsa para priorizar recientes.[/I]"
    ui_utils.add_item(action="toggle_recent", title=t_label,
        thumbnail=ui_utils.media_icon("adv_filtro_tiempo.png"), folder=False, plot=t_plot)

    for clave, rotulo, explicacion in _DM_BUSQUEDA:
        activo = _addon.getSetting(clave) == 'true'
        estado = "[COLOR green]ACTIVADO[/COLOR]" if activo else "[COLOR gray]DESACTIVADO[/COLOR]"
        ui_utils.add_item(action="toggle_dm_ajuste", url=clave, title=f"{rotulo}: {estado}",
            thumbnail=ui_utils.media_icon("adv_exacta.png"), folder=False,
            plot=f"{explicacion}\n\n[I]Pulsa para {'desactivar' if activo else 'activar'}.[/I]")

    ui_utils.close_item_list()


# Interruptores de las búsquedas de DM que cambia toggle_dm_ajuste: (ajuste nativo,
# rótulo, explicación). También están en la pestaña Dailymotion de los ajustes del addon.
_DM_BUSQUEDA = (
    ("dm_exigir_numero", "Solo resultados con el número de capítulo buscado",
     "Si lo buscado lleva un número (capítulo, programa, año), se ocultan los resultados que no lo "
     "tienen en el título; con temporada y capítulo, cuenta el del capítulo. Los capítulos con "
     "otro número ya van detrás aunque no la actives."),
    ("dm_exigir_palabras", "Solo resultados con todas las palabras buscadas",
     'Se ocultan los resultados a los que les falta alguna palabra de lo buscado (sin contar '
     'artículos ni palabras como "capítulo"). Da listas más cortas pero sin vídeos de otra serie.'),
)

def set_dl_mode():
    opts = [
        "Nivel 1: DIRECTO (Normal)", 
        "Nivel 2: SAFE MODE (Gujal Style)", 
        "Nivel 3: MODO ESPADAILY (Procesado HLS)",
        "Nivel 4: YT-DLP (Requiere yt-dlp instalado)",
        "Nivel 5: ULTRA (Multi-hilo HLS+)"
    ]
    idx = xbmcgui.Dialog().select("Modo de Descarga", opts)
    if idx >= 0:
        cfg = ui_utils.load_json('settings.json')
        cfg['dl_mode'] = idx # 0=Direct, 1=Safe, 2=EspaDaily, 3=yt-dlp, 4=Ultra
        
        # Mantener compatibilidad hacia atrás
        cfg['dl_safe_mode'] = (idx == 1)
        
        ui_utils.save_json('settings.json', cfg)
        xbmcgui.Dialog().notification("EspaDaily", f"Modo descarga: Nivel {idx+1} guardado")
        xbmc.executebuiltin("Container.Refresh")

def set_precision():
    opts = ["Nivel 1: BÁSICO (Solo Título)", "Nivel 2: ESTÁNDAR (Serie + Título - Recomendado)", "Nivel 3: AVANZADO (Serie + Temporada)"]
    idx = xbmcgui.Dialog().select("Contexto de Búsqueda", opts)
    if idx >= 0:
        d = ui_utils.load_json('settings.json')
        d['context_level'] = idx + 1
        ui_utils.save_json('settings.json', d)
        xbmcgui.Dialog().notification("EspaDaily", f"Nivel {idx+1} guardado")

def show_info():
    t = (
        "[B]Términos y Condiciones:[/B]\n• Este addon es completamente GRATUITO y siempre lo será, además es sin ánimo de lucro. Si alguien te lo ha vendido, te han estafado. Las etiquetas ATP+ o Premium hacen referencia a la suscripción de la plataforma de origen, no a este addon.\n"
        "• NO aloja ningún contenido\n\n"
        "[B]Exención de responsabilidad:[/B]\n"
        "Los desarrolladores de este addon NO se hacen responsables del uso "
        "que los usuarios hagan del mismo, ni del contenido que puedan "
        "encontrar a través de búsquedas externas.\n\n"
        "[B]¿Cómo funciona?[/B]\nAccede a contenido de internet replicando el comportamiento de un navegador web estándar. No elude restricciones técnicas ni sistemas de autenticación. El usuario es responsable de verificar que el uso cumple con los términos de cada plataforma que accede.\n\n"
        "Además del catálogo directo, permite buscar vídeos relacionados en plataformas de terceros. No está configurado para buscar contenido ilegal ni protegido. "
        "Los resultados pueden variar: es posible que encuentres un trailer, un resumen, o contenido similar subido por otros usuarios.\n\n"
        "El addon no garantiza ni controla qué resultados aparecen, "
        "ya que depende de lo que esté disponible de forma libre en internet.\n\n"
        "[COLOR red][B]AVISO LEGAL:[/B][/COLOR] El uso de este addon implica la lectura y aceptación estricta del documento [B]AVISO_LEGAL.txt[/B] incluido en esta instalación."
    )
    xbmcgui.Dialog().textviewer("EspaDaily - Términos y Condiciones", t)

def show_last_message():
    """Muestra el último aviso (messages.json)"""
    try:
        if not _MESSAGES_URL:
            xbmcgui.Dialog().ok("Último aviso", "Servicio de mensajes no configurado.")
            return

        try:
            import time
            url = f"{_MESSAGES_URL}?_cb={int(time.time())}"
            r = requests.get(url, timeout=7)
            r.raise_for_status()
        except requests.RequestException as e:
            _log_error(f"Error red mensajes: {e}")
            xbmcgui.Dialog().ok("Último aviso", "Servicio no disponible en este momento.")
            return
        
        try:
            # El JSON del servidor tiene trailing commas manuales (ej: "}, ]"), por lo que json normal falla.
            # Esta expresión regular elimina las comas sobrantes antes de parsear.
            clean_json = re.sub(r',\s*([\]}])', r'\1', r.text)
            data = json.loads(clean_json)
        except Exception as e:
            _log_error(f"Error JSON mensajes: {e}")
            xbmcgui.Dialog().ok("Último aviso", "Error al procesar la respuesta del servidor.")
            return

        if isinstance(data, dict) and "messages" in data:
            msgs = data["messages"]
        elif isinstance(data, list):
            msgs = data
        else:
            msgs = [data]
        
        valid_msgs = [m for m in msgs if m and isinstance(m, dict) and m.get("id")]
        if not valid_msgs:
            xbmcgui.Dialog().ok("Último aviso", "No hay avisos recientes disponibles.")
            return
        
        msg = valid_msgs[-1]
        body = msg.get("text") or msg.get("message", "")
        title = msg.get("title", "Último aviso")
        color = msg.get("color", "white")
        formatted_text = f"[COLOR {color}][B]{title}[/B][/COLOR]\n\n{body}"
        
        xbmcgui.Dialog().textviewer("Aviso", formatted_text)
    except Exception as e:
        _log_error(f"show_last_message gen error: {e}")
        xbmcgui.Dialog().ok("Error", "Ocurrió un error inesperado al cargar el aviso.")


def show_web_info():
    import universo; universo.show()

# MOTOR DE INSTANTÁNEAS DEL CATÁLOGO ACTUAL


# FUNCIONES FALTANTES (parches de compatibilidad heredados)
def _load_dm_settings():
    raw = ui_utils.load_json('settings.json')
    cfg = dict(raw) if isinstance(raw, dict) else {}
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    f = os.path.join(p, 'dm_settings.json')
    if os.path.exists(f):
        try:
            with open(f, 'r', encoding='utf-8') as _fh:
                dm_legacy = json.load(_fh)
            if isinstance(dm_legacy, dict):
                for k, v in dm_legacy.items():
                    if k not in cfg:
                        cfg[k] = v
        except (OSError, ValueError) as e:
            xbmc.log(f"[EspaDaily] No se pudo leer dm_settings.json: {e}", xbmc.LOGWARNING)
    cfg['dm_max_quality'] = core_settings.get_dm_max_quality()
    return cfg

def _debrid_status():
    provider = xbmcaddon.Addon().getSetting('debrid_provider') or 'AllDebrid'
    try:
        import debrid_resolver
        r = debrid_resolver.get_resolver()
        return provider, r.is_authorized(), r.stored_user()
    except Exception:
        return provider, False, ""

def _debrid_menu():
    addon = xbmcaddon.Addon()
    _mp = os.path.join(addon.getAddonInfo('path'), 'resources', 'media')

    def _ico(name, fallback='DefaultAddonService.png'):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    h = int(sys.argv[1])
    _fanart = core_settings.addon_fanart()
    enabled = addon.getSetting('debrid_enabled') == 'true'
    provider, authorized, user = _debrid_status()

    if authorized:
        estado = "[COLOR lime]{0} · {1}[/COLOR]".format(provider, user) if user else "[COLOR lime]{0}[/COLOR]".format(provider)
    else:
        estado = "[COLOR gray]Sin vincular[/COLOR]"
    li = xbmcgui.ListItem(label="Estado: {0}".format(estado))
    li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Proveedor activo y cuenta vinculada."})
    xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)

    en_label = "[COLOR lime]ACTIVADA[/COLOR]" if enabled else "[COLOR grey]DESACTIVADA[/COLOR]"
    li = xbmcgui.ListItem(label="Resolución Debrid: {0}".format(en_label))
    li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Si está activa, magnets y enlaces de hosters premium se resuelven con tu cuenta antes del método normal.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_toggle_enabled"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Proveedor: [COLOR deepskyblue]{0}[/COLOR]".format(provider))
    li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Servicio Debrid a usar: AllDebrid, Real-Debrid, TorBox o Premiumize."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_set_provider"), listitem=li, isFolder=False)

    if not authorized:
        supports_pin = True
        try:
            import debrid_resolver
            supports_pin = debrid_resolver.get_resolver().SUPPORTS_PIN
        except Exception:
            pass
        if supports_pin:
            li = xbmcgui.ListItem(label="[COLOR limegreen]Vincular cuenta (código PIN)[/COLOR]")
            li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png'), 'fanart': _fanart})
            li.setInfo('video', {'plot': "Muestra un código para introducir en la web del proveedor y vincula tu cuenta automáticamente."})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_authorize_pin"), listitem=li, isFolder=False)
        li = xbmcgui.ListItem(label="[COLOR limegreen]Introducir API Key manualmente[/COLOR]")
        li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png'), 'fanart': _fanart})
        li.setInfo('video', {'plot': "Pega la API key de tu cuenta (la encuentras en la web del proveedor)."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_authorize_key"), listitem=li, isFolder=False)
    else:
        li = xbmcgui.ListItem(label="Comprobar cuenta / tráfico")
        li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png'), 'fanart': _fanart})
        li.setInfo('video', {'plot': "Consulta el estado de tu cuenta (premium, caducidad)."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_account"), listitem=li, isFolder=False)
        li = xbmcgui.ListItem(label="[COLOR lightsalmon]Desconectar cuenta[/COLOR]")
        li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png'), 'fanart': _fanart})
        li.setInfo('video', {'plot': "Elimina la cuenta vinculada de este addon."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_deauthorize"), listitem=li, isFolder=False)

    cached = addon.getSetting('debrid_cached_only') == 'true'
    li = xbmcgui.ListItem(label="Solo caché (no esperar descargas): {0}".format(
        "[COLOR lime]SÍ[/COLOR]" if cached else "[COLOR grey]NO[/COLOR]"))
    li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Si está activo, un magnet que no esté ya en la nube se omite en lugar de esperar a que se descargue."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_toggle_cached"), listitem=li, isFolder=False)

    cleanup = addon.getSetting('debrid_auto_cleanup') == 'true'
    li = xbmcgui.ListItem(label="Borrar torrent tras reproducir: {0}".format(
        "[COLOR lime]SÍ[/COLOR]" if cleanup else "[COLOR grey]NO[/COLOR]"))
    li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Elimina el torrent de tu cuenta tras obtener el enlace, para no llenar la nube."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_toggle_cleanup"), listitem=li, isFolder=False)

    quality = addon.getSetting('debrid_auto_quality') == 'true'
    li = xbmcgui.ListItem(label="Auto-seleccionar mayor calidad/archivo: {0}".format(
        "[COLOR lime]SÍ[/COLOR]" if quality else "[COLOR grey]NO[/COLOR]"))
    li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "Si está activo, elige automáticamente el archivo de vídeo más grande y la mayor calidad sin preguntar."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_toggle_quality"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)

def _debrid_reset_instance():
    try:
        import debrid_resolver
        debrid_resolver.reset_resolver()
    except Exception:
        pass

def _debrid_toggle_enabled():
    addon = xbmcaddon.Addon()
    cur = addon.getSetting('debrid_enabled') == 'true'
    if not cur:
        if addon.getSetting('debrid_disclaimer_seen') != 'true':
            if not xbmcgui.Dialog().yesno(
                "Resolver Debrid - Uso responsable",
                "El resolver usa TU cuenta Debrid para reproducir los enlaces y magnets que TÚ proporcionas.\n\n"
                "Eres responsable del contenido al que accedes y de respetar la ley de tu país y los términos de tu servicio Debrid.\n\n"
                "¿Activar el Resolver Debrid?"):
                return
            addon.setSetting('debrid_disclaimer_seen', 'true')
        addon.setSetting('debrid_enabled', 'true')
        xbmcgui.Dialog().notification("Debrid", "Resolución ACTIVADA", xbmcgui.NOTIFICATION_INFO, 2000)
    else:
        addon.setSetting('debrid_enabled', 'false')
        xbmcgui.Dialog().notification("Debrid", "Resolución DESACTIVADA", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")

def _debrid_set_provider():
    opciones = ["AllDebrid", "Real-Debrid", "TorBox", "Premiumize"]
    cur = xbmcaddon.Addon().getSetting('debrid_provider') or 'AllDebrid'
    pre = opciones.index(cur) if cur in opciones else 0
    sel = xbmcgui.Dialog().select("Proveedor Debrid", opciones, preselect=pre)
    if sel < 0:
        return
    xbmcaddon.Addon().setSetting('debrid_provider', opciones[sel])
    _debrid_reset_instance()
    xbmcaddon.Addon().setSetting('debrid_hosts_cache', '')
    xbmc.executebuiltin("Container.Refresh")

def _debrid_authorize_pin():
    try:
        import debrid_resolver
        ok = debrid_resolver.get_resolver().authorize_pin()
    except Exception as e:
        xbmcgui.Dialog().ok("Debrid", "Error al vincular:\n{0}".format(e))
        return
    if ok:
        xbmcgui.Dialog().notification("Debrid", "Cuenta vinculada", xbmcgui.NOTIFICATION_INFO, 2500)
    _debrid_reset_instance()
    xbmc.executebuiltin("Container.Refresh")

def _debrid_authorize_key():
    key = xbmcgui.Dialog().input("API Key del proveedor")
    if not key:
        return
    try:
        import debrid_resolver
        ok = debrid_resolver.get_resolver().authorize_apikey(key)
    except Exception as e:
        xbmcgui.Dialog().ok("Debrid", "Error:\n{0}".format(e))
        return
    if ok:
        xbmcgui.Dialog().notification("Debrid", "Cuenta vinculada", xbmcgui.NOTIFICATION_INFO, 2500)
    _debrid_reset_instance()
    xbmc.executebuiltin("Container.Refresh")

def _debrid_deauthorize():
    if not xbmcgui.Dialog().yesno("Debrid", "¿Desconectar la cuenta de este addon?"):
        return
    try:
        import debrid_resolver
        debrid_resolver.get_resolver().deauthorize()
    except Exception:
        pass
    _debrid_reset_instance()
    xbmcgui.Dialog().notification("Debrid", "Cuenta desconectada", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")

def _debrid_account():
    try:
        import debrid_resolver
        info = debrid_resolver.get_resolver().account_info()
    except Exception as e:
        xbmcgui.Dialog().ok("Debrid", "No se pudo consultar la cuenta:\n{0}".format(e))
        return
    estado = "Premium" if info.get("premium") else "No premium"
    expiry = info.get("expiry_text") or ""
    days = info.get("days")
    extra = info.get("extra") or ""
    lineas = ["Usuario: {0}".format(info.get("username", "?")), "Estado: {0}".format(estado)]
    if expiry:
        dtxt = " ({0} días)".format(days) if isinstance(days, int) else ""
        lineas.append("Válida hasta: {0}{1}".format(expiry, dtxt))
    if extra:
        lineas.append(extra)
    xbmcgui.Dialog().ok("Cuenta Debrid", "\n".join(lineas))

def _debrid_toggle_cached():
    cur = xbmcaddon.Addon().getSetting('debrid_cached_only') == 'true'
    xbmcaddon.Addon().setSetting('debrid_cached_only', "false" if cur else "true")
    _debrid_reset_instance()
    xbmc.executebuiltin("Container.Refresh")

def _debrid_toggle_cleanup():
    cur = xbmcaddon.Addon().getSetting('debrid_auto_cleanup') == 'true'
    xbmcaddon.Addon().setSetting('debrid_auto_cleanup', "false" if cur else "true")
    _debrid_reset_instance()
    xbmc.executebuiltin("Container.Refresh")

def _debrid_toggle_quality():
    cur = xbmcaddon.Addon().getSetting('debrid_auto_quality') == 'true'
    xbmcaddon.Addon().setSetting('debrid_auto_quality', "false" if cur else "true")
    _debrid_reset_instance()
    xbmc.executebuiltin("Container.Refresh")

def _ek_addon_is_installed(addon_id):
    try: xbmcaddon.Addon(addon_id); return True
    except Exception: return False

def espakodi_addons_menu():
    import espakodi_installer
    espakodi_installer.render_menu(int(sys.argv[1]))

def espakodi_app_menu():
    ui_utils.visto('espakodi_app')
    import espakodi_app
    import list_screen
    list_screen.ventana_o_lista("espakodi_app_menu", espakodi_app.mostrar_ventana,
                                espakodi_app.render_menu)

def _ek_espatv_launch():
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.espatv)"):
        xbmc.executebuiltin("RunAddon(plugin.video.espatv)")
    else:
        xbmcgui.Dialog().ok("EspaDaily", "EspaTV no está instalado.")

def _ek_espadaily_launch():
    xbmc.executebuiltin("RunAddon(plugin.video.espadaily)")

def _ek_atresdaily_launch():
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.atresdaily)"):
        xbmc.executebuiltin("RunAddon(plugin.video.atresdaily)")
    else:
        xbmcgui.Dialog().ok("EspaDaily", "AtresDaily no está instalado.")

def _ek_loiolog_launch():
    if xbmc.getCondVisibility("System.HasAddon(plugin.program.loiolog)"):
        xbmc.executebuiltin("RunAddon(plugin.program.loiolog)")
    else:
        xbmcgui.Dialog().ok("EspaDaily", "Loiolog no está instalado.")

def _ek_flowfav_launch():
    if xbmc.getCondVisibility("System.HasAddon(plugin.program.flowfav)"):
        xbmc.executebuiltin("RunAddon(plugin.program.flowfav)")
    else:
        xbmcgui.Dialog().ok("EspaDaily", "FlowFav no está instalado.")

def _ek_streamninja_launch():
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.streamninja)"):
        xbmc.executebuiltin("RunAddon(plugin.video.streamninja)")
    else:
        xbmcgui.Dialog().ok("EspaDaily", "StreamNinja no está instalado.")

def _open_loiolog():
    _ek_loiolog_launch()

def _loiolog_install():
    xbmcgui.Dialog().ok("EspaDaily", "Instala Loiolog desde el repositorio EspaKodi.")


# Wrappers de historial / favoritos / descargas
def view_history():
    _show_history()


def del_history():
    _clear_history()


def view_favorites():
    _show_favorites()


def view_downloads():
    _show_downloads()


# Favoritos (add / play local / gestión descargas)
def add_fav(title='Favorito', action='search', url='', thumbnail='', extra=''):
    fav_url = f"{action}_{url}" if url else action
    added = core_settings.add_favorite(title, fav_url, thumbnail, '', action, {'url': url, 'extra': extra})
    if added:
        xbmcgui.Dialog().notification("EspaDaily", "Añadido a Favoritos", xbmcgui.NOTIFICATION_INFO, 2000)
    else:
        xbmcgui.Dialog().notification("EspaDaily", "Ya está en Favoritos", xbmcgui.NOTIFICATION_WARNING, 2000)


def play_local(path):
    if not path or not os.path.exists(path):
        xbmcgui.Dialog().ok("EspaDaily", "El archivo no existe o la ruta está vacía.")
        return
    li = xbmcgui.ListItem(path=path)
    li.setProperty("IsPlayable", "true")
    xbmc.Player().play(path, li)


def del_file(path):
    if not path:
        return
    title = os.path.basename(path)
    if not xbmcgui.Dialog().yesno("Eliminar archivo", f"¿Borrar del disco?\n{title}"):
        return
    try:
        if os.path.exists(path):
            os.remove(path)
        core_settings.remove_download(path)
        xbmcgui.Dialog().notification("EspaDaily", "Archivo eliminado", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")
    except OSError as exc:
        xbmcgui.Dialog().ok("Error", f"No se pudo eliminar:\n{exc}")


def del_dl_history(path):
    if not path:
        return
    core_settings.remove_download(path)
    xbmc.executebuiltin("Container.Refresh")


def export_cache():
    dest_dir = xbmcgui.Dialog().browse(3, 'Seleccionar carpeta destino', 'files')
    if not dest_dir:
        return
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    cache_dir = os.path.join(profile, 'api_cache')
    if not os.path.isdir(cache_dir):
        xbmcgui.Dialog().ok("EspaDaily", "No hay caché para exportar.")
        return
    dest_zip = os.path.join(dest_dir, 'espadaily_cache.zip')
    try:
        with zipfile.ZipFile(dest_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
            for fn in os.listdir(cache_dir):
                zf.write(os.path.join(cache_dir, fn), fn)
        xbmcgui.Dialog().notification("EspaDaily", "Caché exportada", xbmcgui.NOTIFICATION_INFO)
    except Exception as exc:
        xbmcgui.Dialog().ok("Error", f"No se pudo exportar la caché:\n{exc}")


# Cache / settings internos
def _toggle_estuary_palantir_fix():
    state = estuary_palantir_compatibility.patch_state()
    if state == 'patched':
        if estuary_palantir_compatibility.unpatch_palantir_skin():
            # Reset del consentimiento: si lo quita a mano, no debe reaplicarse solo después.
            core_settings.set_estuary_fix_accepted(False)
            xbmcgui.Dialog().notification("EspaDaily", "Ajuste Estuary Palantir retirado", xbmcgui.NOTIFICATION_INFO)
        else:
            xbmcgui.Dialog().ok("EspaDaily", "No se pudo modificar el archivo del skin.")
    elif state == 'unpatched':
        if estuary_palantir_compatibility.patch_palantir_skin():
            # patch_palantir_skin ya muestra su propia notificación y recarga el skin.
            core_settings.set_estuary_fix_accepted(True)
        else:
            xbmcgui.Dialog().ok("EspaDaily", "No se pudo modificar el archivo del skin.")


def _clear_cat_cache():
    import glob as _glob
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    cache_dir = os.path.join(profile, 'api_cache')
    if not os.path.isdir(cache_dir):
        return
    for f in _glob.glob(os.path.join(cache_dir, '*.json')):
        try:
            os.remove(f)
        except OSError:
            pass


def _toggle_catalog_long_first():
    addon = xbmcaddon.Addon()
    cur = addon.getSetting('catalog_long_first') == 'true'
    addon.setSetting('catalog_long_first', 'false' if cur else 'true')
    msg = "Series largas: primero" if not cur else "Series largas: orden normal"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")


def _fanart_menu():
    h = int(sys.argv[1])
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)
    core_settings.migrate_fanart_legacy()
    _fanart = core_settings.addon_fanart()
    disabled = core_settings.is_fanart_disabled()

    if disabled:
        onoff_label = 'Fanart de fondo:  [COLOR red]DESACTIVADO[/COLOR]'
        onoff_plot = 'No se muestra ninguna imagen de fondo en los menús.\n\nEste interruptor es el mismo que el de Ajustes de Kodi.\n\nPulsa para activarlo.'
    else:
        onoff_label = 'Fanart de fondo:  [COLOR green]ACTIVADO[/COLOR]'
        onoff_plot = 'Se muestra una imagen de fondo en los menús.\n\nEste interruptor es el mismo que el de Ajustes de Kodi.\n\nPulsa para desactivarlo.'
    li = xbmcgui.ListItem(label=onoff_label)
    li.setArt({'icon': _mi('adv_fanart.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': onoff_plot})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='fanart_toggle'), listitem=li, isFolder=False)

    if not disabled:
        mode = core_settings.get_fanart_mode()
        mode_tag = _FANART_MODE_TAGS.get(mode, mode)
        mode_plot = _FANART_MODE_PLOTS.get(mode, '')
        li = xbmcgui.ListItem(label=f'[B]Fuente[/B]  {mode_tag}')
        li.setArt({'icon': _mi('adv_refrescar.png'), 'fanart': _fanart})
        li.setInfo('video', {'plot': f'{mode_plot}\n\nPulsa para alternar entre imagen del addon e imagen personalizada.'})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action='fanart_cycle_mode'), listitem=li, isFolder=False)

        custom_path = core_settings.get_custom_fanart_path()
        if custom_path:
            custom_tag = f'[COLOR cyan]{custom_path}[/COLOR]'
            custom_plot = f'Imagen actual: {custom_path}\n\nPulsa para elegir otra imagen.'
        else:
            custom_tag = '[COLOR grey]Sin configurar[/COLOR]'
            custom_plot = 'Aún no has seleccionado ninguna imagen personalizada.\n\nPulsa para explorar tus archivos y elegir una.'
        li = xbmcgui.ListItem(label=f'[B]Imagen personalizada[/B]  {custom_tag}')
        li.setArt({'icon': ui_utils.media_icon('adv_fanart.png'), 'fanart': _fanart})
        li.setInfo('video', {'plot': custom_plot + '\n\nFormatos soportados: JPG, PNG.'})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action='fanart_browse_custom'), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _fanart_toggle():
    core_settings.set_fanart_disabled(not core_settings.is_fanart_disabled())
    xbmc.executebuiltin('Container.Refresh')


def _fanart_cycle_mode():
    mode = core_settings.get_fanart_mode()
    next_mode = _FANART_MODES[(_FANART_MODES.index(mode) + 1) % len(_FANART_MODES)] if mode in _FANART_MODES else 'addon'
    core_settings.set_fanart_mode(next_mode)
    xbmc.executebuiltin('Container.Refresh')


def _fanart_browse_custom():
    path = str(xbmcgui.Dialog().browse(2, 'Seleccionar imagen de fondo', 'files', '.jpg|.jpeg|.png', True, False, ''))
    if path and path != '0' and xbmcvfs.exists(path):
        core_settings.set_custom_fanart_path(path)
        core_settings.set_fanart_mode('custom')
    xbmc.executebuiltin('Container.Refresh')


def _toggle_ext_search_enabled():
    addon = xbmcaddon.Addon()
    cur = addon.getSetting('ext_search_enabled') == 'true'
    addon.setSetting('ext_search_enabled', 'false' if cur else 'true')
    msg = "Búsqueda externa activada" if not cur else "Búsqueda externa desactivada"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")


def _toggle_ext_search_dialog():
    addon = xbmcaddon.Addon()
    cur = addon.getSetting('ext_search_dialog') == 'true'
    addon.setSetting('ext_search_dialog', 'false' if cur else 'true')
    msg = "Diálogo búsqueda externa activado" if not cur else "Diálogo búsqueda externa desactivado"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")


def _set_dm_safe_level():
    cur = _load_dm_settings().get('dm_safe_level', 0)
    try:
        cur_level = int(cur) if 0 <= int(cur) <= 4 else 0
    except (ValueError, TypeError):
        cur_level = 0
    opts = ["Desactivado", "Básico", "Extremo", "YT-DLP", "ISA"]
    sel = xbmcgui.Dialog().select("Modo Anti-Errores DM", opts, preselect=cur_level)
    if sel < 0:
        return
    cfg = ui_utils.load_json('settings.json')
    if not isinstance(cfg, dict):
        cfg = {}
    cfg['dm_safe_level'] = sel
    ui_utils.save_json('settings.json', cfg)
    xbmcgui.Dialog().notification("EspaDaily", f"Nivel DM: {sel}", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")


# Interruptores de las listas de Dailymotion: (ajuste nativo, rótulo, explicación).
# Al ser ajustes de Kodi, este submenú y la pestaña Dailymotion de los ajustes del
# addon leen y cambian lo mismo.
_DM_LISTAS = (
    ("dm_filtrar_retirados", "Ocultar vídeos retirados",
     "El buscador de Dailymotion sigue devolviendo vídeos que ya han sido retirados: "
     "aparecen en la lista y al pulsarlos no reproducen. Con esta opción no se muestran."),
    ("dm_ocultar_privados", "Ocultar vídeos privados",
     "Algunos vídeos salen en las búsquedas aunque su autor los ha hecho privados, y no se "
     "pueden ver de ninguna forma. Distinguirlos de los que sí se pueden ver cuesta una "
     "consulta por cada uno, y suelen ser menos de 1 de cada 100 resultados."),
    ("dm_ocultar_directos_apagados", "Ocultar directos que no están emitiendo",
     "Un canal en directo que ahora mismo no emite no se puede reproducir. Desactívala si "
     "prefieres encontrar esos canales en las búsquedas aunque estén apagados."),
    ("dm_rellenar_listas", "Rellenar las listas con más resultados",
     "Al ocultar vídeos, algunas búsquedas se quedan en 4 o 5 resultados. Con esta opción se "
     "piden más a Dailymotion para que la lista salga completa, en la misma consulta."),
)


def dm_listas_menu():
    addon = xbmcaddon.Addon()
    for clave, rotulo, explicacion in _DM_LISTAS:
        estado = ("[COLOR gray]NO[/COLOR]" if addon.getSetting(clave) == 'false'
                  else "[COLOR green]SÍ[/COLOR]")
        ui_utils.add_item(action="toggle_dm_ajuste", url=clave, title=f"{rotulo}: {estado}",
                          thumbnail=ui_utils.media_icon("adv_anti_errores.png"), folder=False,
                          plot=f"{explicacion}\n\n[I]Pulsa para cambiar.[/I]")
    ui_utils.close_item_list()


def toggle_dm_ajuste(clave):
    rotulos = {c: r for c, r, _ in _DM_LISTAS + _DM_BUSQUEDA}
    if clave not in rotulos:
        return
    addon = xbmcaddon.Addon()
    activo = addon.getSetting(clave) == 'false'
    addon.setSetting(clave, 'true' if activo else 'false')
    xbmcgui.Dialog().notification("EspaDaily", f"{rotulos[clave]}: {'SÍ' if activo else 'NO'}")
    xbmc.executebuiltin("Container.Refresh")



def _set_download_path():
    cur = _load_dm_settings().get('download_path', '')
    path = xbmcgui.Dialog().browse(3, 'Seleccionar carpeta de descargas', 'files', '', False, False, cur)
    if path:
        cfg = ui_utils.load_json('settings.json')
        if not isinstance(cfg, dict):
            cfg = {}
        cfg['download_path'] = path
        ui_utils.save_json('settings.json', cfg)
        xbmcgui.Dialog().notification("EspaDaily", "Ruta de descargas actualizada", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")


# YouTube
def _yt_native_search_results(query):
    import youtube_search
    youtube_search.render_results(int(sys.argv[1]), query)


def _yt_results_keyboard():
    kb = xbmc.Keyboard('', 'Buscar en YouTube')
    kb.doModal()
    if kb.isConfirmed() and kb.getText().strip():
        _yt_native_search_results(kb.getText().strip())
    else:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)


# Búsqueda externa (gujal / externos)
def _search_dailymotion_gujal(q):
    dm_id = 'plugin.video.dailymotion_com'
    # xbmcaddon.Addon(id) no falla con un addon desactivado, así que no servía para saberlo.
    if not ui_utils.addon_listo(dm_id, "Dailymotion (Gujal)",
            "El plugin de Dailymotion (Gujal) no está instalado.\n\n"
            "Instálalo para usar esta función."):
        return

    if xbmcaddon.Addon().getSetting('gujal_search_enabled') != 'true':
        xbmcgui.Dialog().ok("EspaDaily",
            "La búsqueda en Dailymotion (Gujal) está desactivada.\n\n"
            "Actívala en:\nOpciones → Búsqueda en otros addons → Buscar en Dailymotion (Gujal)")
        return
        
    nq = ui_utils.get_text('Buscar en DailyMotion (Gujal)', q or '').strip()
    if not nq:
        try: xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        except Exception: pass  # lanzada como script: no hay carpeta que cerrar
        return
        
    lista = ui_utils.del_conector("dm_lista_gujal")
    if not lista:
        return
    dm_api_url = lista(nq)
    plugin_url = f"plugin://{dm_id}/?mode=listVideos&url={urllib.parse.quote_plus(dm_api_url)}"
    xbmc.executebuiltin(f"Container.Update({plugin_url})")


def _search_external_prompt(q=""):
    nq = ui_utils.get_text('Búsqueda externa', q or '').strip()
    if not nq:
        try: xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        except Exception: pass  # lanzada como script: no hay carpeta que cerrar
        return
    opts = ["YouTube", "DailyMotion (Gujal)", "Cancelar"]
    sel = xbmcgui.Dialog().select("Buscar en", opts)
    if sel == 0:
        xbmc.executebuiltin("Container.Update({0})".format(_u(action='yt_html_search', q=nq)))
    elif sel == 1:
        _search_dailymotion_gujal(nq)
    else:
        try: xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        except Exception: pass  # lanzada como script: no hay carpeta que cerrar


# DailyMotion playlists y canales guardados
_DM_SAVED_CHANNELS_FILE = 'dm_saved_channels.json'


def _dm_load_saved_channels():
    d = ui_utils.load_json(_DM_SAVED_CHANNELS_FILE, default={})
    return d if isinstance(d, dict) else {}


def _dm_espatv_canales():
    from concurrent.futures import ThreadPoolExecutor
    import threading
    h = int(sys.argv[1])
    try:
        espatv_path = xbmcaddon.Addon('plugin.video.espatv').getAddonInfo('path')
        if not espatv_path:
            raise RuntimeError("plugin.video.espatv path vacío")
        json_path = os.path.join(espatv_path, 'canales_espana.json')
        with open(json_path, encoding='utf-8') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            raise ValueError("canales_espana.json: formato inesperado")
    except Exception as e:
        xbmc.log(f"[EspaDaily] dm_espatv_canales: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("EspaDaily",
            "No se pudo cargar el catálogo de canales.\n"
            "Asegúrate de que el addon EspaTV está instalado y habilitado.")
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    seen = set()
    candidates = []
    for cat in data.values():
        if not isinstance(cat, dict):
            continue
        for ch in cat.get('channels', []):
            if not isinstance(ch, dict):
                continue
            u = ch.get('username', '')
            if u and u not in seen:
                seen.add(u)
                candidates.append((ch.get('name', u), u))
    candidates.sort(key=lambda x: x[0].lower())

    had_net_error = threading.Event()
    api = ui_utils.del_conector("dm_api")
    if not api:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    def _fetch_avatar(args):
        name, username = args
        usuario = f"/user/{urllib.parse.quote(username, safe='')}"
        listas = api(f"{usuario}/playlists", {"fields": "id", "limit": 1}, timeout=5)
        if listas is None:
            had_net_error.set()
        if not (listas or {}).get("list"):
            return None
        perfil = api(usuario, {"fields": "avatar_720_url"}, timeout=5)
        return name, username, (perfil or {}).get('avatar_720_url', '')

    channels = []
    with ThreadPoolExecutor(max_workers=10) as pool:
        for result in pool.map(_fetch_avatar, candidates):
            if result is not None:
                channels.append(result)

    if not channels:
        if had_net_error.is_set():
            xbmcgui.Dialog().ok("EspaDaily",
                "No se pudo conectar con Dailymotion.\n"
                "Comprueba tu conexión a internet.")
            xbmcplugin.endOfDirectory(h, succeeded=False)
        else:
            li = xbmcgui.ListItem(label="[COLOR gray]No hay canales disponibles[/COLOR]")
            xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
            xbmcplugin.endOfDirectory(h)
        return
    for name, user, avatar in channels:
        li = xbmcgui.ListItem(label=name)
        li.setInfo('video', {'plot': f"Canal DM: {user}"})
        if avatar:
            li.setArt({'icon': avatar, 'thumb': avatar})
        item_url = f"{sys.argv[0]}?action=dm_user_playlists&user={urllib.parse.quote(user, safe='')}"
        save_url = (f"{sys.argv[0]}?action=dm_save_channel"
                    f"&user={urllib.parse.quote(user, safe='')}"
                    f"&name={urllib.parse.quote(name, safe='')}")
        li.addContextMenuItems([("Guardar canal", f"RunPlugin({save_url})")])
        xbmcplugin.addDirectoryItem(handle=h, url=item_url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def _dm_playlists_menu():
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _lmi(n): return os.path.join(_med, n)
    ui_utils.add_item(action="dm_espatv_canales", title="Canales", thumbnail=_lmi('srch_canal.png'), folder=True,
                      plot="Canales de EspaTV.")
    ui_utils.add_item(action="dm_playlists_search", title="Buscar playlists por usuario", thumbnail=_lmi('srch_exacta.png'), folder=True,
                      plot="Introduce un nombre de usuario de DailyMotion para ver sus playlists.")
    ui_utils.add_item(action="dm_saved_channels", title="Canales DM guardados", thumbnail=_lmi('historial.png'), folder=True,
                      plot="Gestiona tus canales de DailyMotion guardados.")
    ui_utils.close_item_list()


def _dm_playlists_search():
    user = ui_utils.get_text('Usuario de DailyMotion').strip()
    if not user:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    _dm_user_playlists(user)


def _dm_saved_channels_menu():
    h = int(sys.argv[1])
    channels = _dm_load_saved_channels()
    if not channels:
        li = xbmcgui.ListItem(label="[COLOR gray]No hay canales guardados[/COLOR]")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
    else:
        for user, name in channels.items():
            label = name or user
            li = xbmcgui.ListItem(label=label)
            li.setInfo('video', {'plot': f"Canal DM: {user}"})
            item_url = f"{sys.argv[0]}?action=dm_user_playlists&user={urllib.parse.quote(user)}"
            del_url = f"{sys.argv[0]}?action=dm_delete_saved_channel&user={urllib.parse.quote(user)}"
            li.addContextMenuItems([("Eliminar canal", f"RunPlugin({del_url})")])
            xbmcplugin.addDirectoryItem(handle=h, url=item_url, listitem=li, isFolder=True)
    li_add = xbmcgui.ListItem(label="[COLOR lime]+ Añadir canal[/COLOR]")
    add_url = f"{sys.argv[0]}?action=dm_save_channel&user=&name="
    xbmcplugin.addDirectoryItem(handle=h, url=add_url, listitem=li_add, isFolder=False)
    xbmcplugin.endOfDirectory(h)


def _dm_save_channel(user='', name=''):
    if not user:
        user = ui_utils.get_text('Usuario de DailyMotion').strip()
    if not user:
        return
    if not name:
        name = user
    channels = _dm_load_saved_channels()
    channels[user] = name
    ui_utils.save_json(_DM_SAVED_CHANNELS_FILE, channels)
    xbmcgui.Dialog().notification("EspaDaily", f"Canal '{name}' guardado", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")


def _dm_delete_saved_channel(user):
    if not user:
        return
    channels = _dm_load_saved_channels()
    channels.pop(user, None)
    ui_utils.save_json(_DM_SAVED_CHANNELS_FILE, channels)
    xbmc.executebuiltin("Container.Refresh")


def _dm_user_playlists(user):
    if not user:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    h = int(sys.argv[1])
    api = ui_utils.del_conector("dm_api")
    if not api:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    datos = api(f"/user/{urllib.parse.quote(user)}/playlists",
                {"fields": "id,name,videos_total,thumbnail_url", "limit": 50}, timeout=15)
    items = (datos or {}).get("list", [])
    if not items:
        xbmcgui.Dialog().ok("EspaDaily", f"No se encontraron playlists para: {user}")
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    xbmcplugin.setContent(h, "videos")
    for pl in items:
        pid = pl.get("id", "")
        pname = pl.get("name", pid)
        thumb = pl.get("thumbnail_url", "")
        total = pl.get("videos_total", 0)
        li = xbmcgui.ListItem(label=f"{pname} ({total} vídeos)")
        li.setArt({'icon': thumb or 'DefaultAddonVideo.png', 'thumb': thumb})
        li.setInfo('video', {'plot': f"Playlist de {user}: {total} vídeos"})
        item_url = f"{sys.argv[0]}?action=dm_view_playlist&pid={urllib.parse.quote(pid)}"
        xbmcplugin.addDirectoryItem(handle=h, url=item_url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def _dm_view_playlist(pid):
    if not pid:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    h = int(sys.argv[1])
    datos = ui_utils.dm_api_videos(
        f"/playlist/{urllib.parse.quote(pid)}/videos",
        {"fields": "id,title,thumbnail_360_url,duration,owner.username", "limit": 100},
        timeout=15,
    )
    items = ui_utils.filtrar_dm_borrados(datos.get("list", []))
    if not items:
        xbmcgui.Dialog().ok("EspaDaily", "La playlist está vacía o no se pudo cargar.")
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    xbmcplugin.setContent(h, "videos")
    for item in items:
        vid = item.get("id", "")
        title = item.get("title", "Sin título")
        thumb = item.get("thumbnail_360_url", "")
        try:
            dur = int(item.get("duration", 0))
        except (ValueError, TypeError):
            dur = 0
        li = xbmcgui.ListItem(label=title)
        li.setArt({'icon': thumb, 'thumb': thumb})
        li.setInfo('video', {'title': title, 'duration': dur})
        li.setProperty("IsPlayable", "true")
        play_url = f"{sys.argv[0]}?action=pv&vid={urllib.parse.quote(vid)}&title={urllib.parse.quote(title)}"
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)


# FlowFav
def _open_flowfav():
    _ek_flowfav_launch()


def _flowfav_install():
    xbmcgui.Dialog().ok("EspaDaily", "Instala FlowFav desde el repositorio EspaKodi.")


# Log / diagnóstico
def _log_menu():
    h = int(sys.argv[1])
    items = [
        ("Ver log de Kodi (últimas líneas)", "view_kodi_log",      "adv_log.png"),
        ("Ver log completo",                 "view_kodi_log_full",  "adv_log.png"),
        ("Ver solo errores",                 "view_kodi_log_errors","log_errores.png"),
        ("Buscar en el log",                 "search_kodi_log",     "adv_log.png"),
        ("Info del log",                     "log_info",            "backup_info.png"),
        ("Exportar log",                     "export_log",          "log_export.png"),
        ("Borrar log de errores",            "clear_error_log",     "backup_delete.png"),
    ]
    _fanart = core_settings.addon_fanart()
    for label, action, ico in items:
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': ui_utils.media_icon(ico), 'fanart': _fanart})
        url = f"{sys.argv[0]}?action={action}"
        xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)


def _export_log():
    log_path = xbmc.translatePath('special://logpath/kodi.log')
    dest_dir = xbmcgui.Dialog().browse(3, 'Seleccionar carpeta destino', 'files')
    if not dest_dir:
        return
    dest = os.path.join(dest_dir, 'kodi.log')
    try:
        shutil.copy2(log_path, dest)
        xbmcgui.Dialog().notification("EspaDaily", "Log exportado", xbmcgui.NOTIFICATION_INFO, 2000)
    except Exception as exc:
        xbmcgui.Dialog().ok("Error", f"No se pudo exportar el log:\n{exc}")


def _view_log_visual():
    log_path = xbmc.translatePath('special://logpath/kodi.log')
    try:
        with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
            lines = f.readlines()
        xbmcgui.Dialog().textviewer("Log de Kodi", ''.join(lines[-100:]))
    except Exception as exc:
        xbmcgui.Dialog().ok("Error", f"No se pudo leer el log:\n{exc}")


def _show_log_line(data):
    if not data:
        return
    try:
        line = urllib.parse.unquote(data)
    except Exception:
        line = data
    xbmcgui.Dialog().ok("Línea de log", line)


def _clear_error_log():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    err_log = os.path.join(profile, 'error_log.json')
    try:
        if os.path.exists(err_log):
            os.remove(err_log)
        xbmcgui.Dialog().notification("EspaDaily", "Log de errores borrado", xbmcgui.NOTIFICATION_INFO, 2000)
    except OSError as exc:
        xbmcgui.Dialog().ok("Error", f"No se pudo borrar:\n{exc}")


# Backups
def _get_backup_dir():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    d = os.path.join(profile, 'backups')
    if not os.path.exists(d):
        os.makedirs(d)
    return d


def _backups_menu():
    ui_utils.add_item(action="create_backup_full", title="Crear copia de seguridad completa",
                      thumbnail=ui_utils.media_icon("backup_full.png"), folder=False,
                      plot="Genera un ZIP con todos tus favoritos, historial, categorías y ajustes.")
    ui_utils.add_item(action="list_backups", title="Ver y restaurar copias",
                      thumbnail=ui_utils.media_icon("backup_restore.png"), folder=True,
                      plot="Lista las copias guardadas y permite restaurarlas.")
    ui_utils.add_item(action="export_favs_txt", title="Exportar favoritos a texto",
                      thumbnail=ui_utils.media_icon("favs_export_txt.png"), folder=False,
                      plot="Genera un archivo .txt legible con tus favoritos.")
    ui_utils.close_item_list()


def _create_backup_full():
    backup_dir = _get_backup_dir()
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    ts = time.strftime('%Y%m%d_%H%M%S')
    dest_zip = os.path.join(backup_dir, f'backup_{ts}.zip')
    files_to_backup = [
        'favorites.json', 'downloads_history.json', 'acestream_history.json',
        'acestream_proxy.json', 'settings.json', 'integration_first_use.json',
    ]
    try:
        with zipfile.ZipFile(dest_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
            for fn in files_to_backup:
                fp = os.path.join(profile, fn)
                if os.path.exists(fp):
                    zf.write(fp, fn)
            import iptv_lists
            for fp, arcname in iptv_lists.backup_files():
                zf.write(fp, arcname)
        xbmcgui.Dialog().ok("EspaDaily", f"Copia creada:\n{os.path.basename(dest_zip)}")
    except Exception as exc:
        xbmcgui.Dialog().ok("Error", f"No se pudo crear la copia:\n{exc}")


def _list_backups():
    h = int(sys.argv[1])
    _fanart = core_settings.addon_fanart()
    backup_dir = _get_backup_dir()
    zips = sorted([f for f in os.listdir(backup_dir) if f.endswith('.zip')], reverse=True)
    if not zips:
        li = xbmcgui.ListItem(label="[COLOR gray]No hay copias de seguridad[/COLOR]")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
    else:
        for fn in zips:
            fp = os.path.join(backup_dir, fn)
            size_kb = os.path.getsize(fp) // 1024
            li = xbmcgui.ListItem(label=f"{fn} ({size_kb} KB)")
            li.setArt({'icon': ui_utils.media_icon('backup_zip.png'), 'fanart': _fanart})
            restore_url = f"{sys.argv[0]}?action=restore_backup_selective&path={urllib.parse.quote(fp)}"
            del_url = f"{sys.argv[0]}?action=delete_single_backup&path={urllib.parse.quote(fp)}"
            li.addContextMenuItems([
                ("Restaurar esta copia", f"RunPlugin({restore_url})"),
                ("[COLOR red]Eliminar copia[/COLOR]", f"RunPlugin({del_url})"),
            ])
            xbmcplugin.addDirectoryItem(handle=h, url=restore_url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)


def _restore_backup_selective(path):
    if not path or not os.path.exists(path):
        xbmcgui.Dialog().ok("EspaDaily", "No se encontró el archivo de copia.")
        return
    if not xbmcgui.Dialog().yesno("Restaurar copia", f"¿Restaurar desde:\n{os.path.basename(path)}?\n\nSe sobrescribirán los datos actuales."):
        return
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    try:
        with zipfile.ZipFile(path, 'r') as zf:
            for member in zf.namelist():
                if member == 'custom_iptv_lists.json' or member.startswith('iptv_lists/'):
                    continue
                if '..' in member or member.startswith('/') or member.startswith('\\'):
                    continue
                zf.extract(member, profile)
            if 'custom_iptv_lists.json' in zf.namelist():
                import iptv_lists
                iptv_lists.restore_from_backup(zf)
        xbmcgui.Dialog().ok("EspaDaily", "Copia restaurada. Reinicia Kodi para aplicar los cambios.")
    except Exception as exc:
        xbmcgui.Dialog().ok("Error", f"No se pudo restaurar:\n{exc}")


def _delete_single_backup(path):
    if not path:
        return
    if not xbmcgui.Dialog().yesno("Eliminar copia", f"¿Borrar permanentemente?\n{os.path.basename(path)}"):
        return
    try:
        os.remove(path)
        xbmcgui.Dialog().notification("EspaDaily", "Copia eliminada", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")
    except OSError as exc:
        xbmcgui.Dialog().ok("Error", f"No se pudo eliminar:\n{exc}")


def _export_favorites_txt():
    favs = core_settings.get_favorites()
    if not favs:
        xbmcgui.Dialog().ok("EspaDaily", "No hay favoritos para exportar.")
        return
    dest_dir = xbmcgui.Dialog().browse(3, 'Seleccionar carpeta destino', 'files')
    if not dest_dir:
        return
    # 'url' y no 'fav_url', que es como se guarda en favorites.json; el TXT salía sin direcciones.
    texto = "".join(f"{fav.get('title', '')}\t{fav.get('url', '')}\n" for fav in favs)
    # Con xbmcvfs, porque browse() puede devolver una carpeta de red.
    with xbmcvfs.File(_vfs_join(dest_dir, 'favoritos_espadaily.txt'), 'w') as fh:
        ok = fh.write(texto.encode('utf-8'))
    if ok:
        xbmcgui.Dialog().notification("EspaDaily", "Favoritos exportados a .txt", xbmcgui.NOTIFICATION_INFO, 2000)
    else:
        xbmcgui.Dialog().ok("Error", "No se pudo escribir el archivo en esa carpeta.")


def router(ps):
    motivo = _motivo_de_bloqueo()
    if motivo:
        xbmcgui.Dialog().ok("EspaDaily", motivo)
        return

    p = dict(urllib.parse.parse_qsl(ps)); a = p.get("action")
    u = p.get("url", ""); e = p.get("extra", "")

    # Modo Fantasía: solo se instala el puente si la ventana está abierta
    if xbmcgui.Window(10000).getProperty("espadaily.fantasia"):
        try:
            import fantasia
            fantasia.instalar_puente()
        except Exception as e:
            xbmc.log(f"[EspaDaily] Error al instalar puente de Fantasía: {e}", xbmc.LOGWARNING)

    # Guard: acciones que requieren connector activo
    _CONNECTOR_ACTIONS = {
        "ls", "fs", "lfr", "pv", "play_dm", "ls_rtve", "fs_rtve", "atresplayer_menu",
        "ls_mediaset", "download_video", "top_movies", "trending",
        "cache_top_movies_covers", "dm_playlists_search", "dm_user_playlists",
        "dm_view_playlist", "create_snapshot", "fav_news",
        "rtve_ext_router", "chopo_router", "mediaset_ext_router",
    }
    if a in _CONNECTOR_ACTIONS and connector is None:
        xbmcgui.Dialog().ok("EspaDaily", "El módulo de conexión no está disponible.\nComprueba tu conexión a internet y reinicia el addon.")
        return
    if a == "ls": _ls(p.get("cid"), page=int(p.get("page", 0)))
    elif a == "fs": _fs(p.get("au"), p.get("st"), p.get("sth", ""), p.get("pu", ""))
    elif a == "lfr_atres": _lfr(p.get("ru", ""), p.get("st", ""), p.get("sth", ""), p.get("prem") == "1", pagina=int(p.get("pagina") or 0))
    elif a == "fs_mediaset": _fs_mediaset(p.get("purl", ""), p.get("st", ""), p.get("sth", ""), p.get("cid", ""))
    elif a == "fs_mediaset_season": _fs_mediaset_season(p.get("spath", ""), p.get("st", ""), p.get("sth", ""))
    elif a == "lfr":
        # Sin nh ni mode llega de abrir un programa de un catálogo (RTVE, Mediaset,
        # Atresplayer); el historial, las categorías y la búsqueda manual traen nh.
        _catalogo = not p.get("nh") and not p.get("mode")
        _lfd(p.get("q"), p.get("ot"), p.get("mode", ""), nh=p.get("nh"),
             largos_primero=_catalogo and xbmcaddon.Addon().getSetting('catalog_long_first') != 'false')
    elif a == "pv": _pv(p.get("vid"), p.get("title", ""))
    elif a == "ep_dialog": _ep_dialog(p.get("q", ""), p.get("ot", ""), p.get("t", ""), p.get("eid", ""), p.get("sn", ""))
    elif a == "catalog_menu": _catalog_menu()
    elif a == "topzilla_menu": _topzilla_menu()
    elif a == "info_menu": info_menu()
    elif a == "show_last_message": show_last_message()
    elif a == "info": _info()
    elif a == "vpn_info": xbmcgui.Dialog().ok("La VPN puede causar fallos o ser necesaria", "Algunos servidores bloquean VPNs (desactívala si algo no carga).\n\nEn Dailymotion puede ocurrir lo contrario, si no carga prueba activando la VPN.")
    elif a == "web_info": _web_info()
    elif a == "atresplayer_menu": atresplayer_menu()
    elif a == "rtve_menu": rtve_menu()
    elif a == "ls_rtve": _ls_rtve(p.get("cid"), page=int(p.get("page", 1)))
    elif a == "fs_rtve": _fs_rtve(p.get("pid"), p.get("st"), p.get("sth", ""))
    elif a == "manual_search": _manual_search()
    elif a == "top_movies": _top_movies(p.get("page"))
    elif a == "mediaset_menu": mediaset_menu()
    elif a == "advanced_menu": advanced_menu()
    elif a == "add_sections_to_kodi_favs": _add_sections_to_kodi_favs()
    elif a == "ls_mediaset":
        _ls_mediaset(p.get("cid"), page=int(p.get("page", 1)))
    elif a == "search_mediaset_by_letter":
        _search_mediaset_by_letter(p.get("cid"))
    elif a == "show_history": _show_history()
    elif a == "history_menu": _history_menu()
    elif a == "search_alt_prompt":
        import trakt_manager; trakt_manager.search_dialog(p.get("q") or u, p.get("ot", ""), p.get("mode", ""))
    elif a == "tmdbhelper_search": _search_tmdbhelper(p.get("q", ""))
    elif a == "search_in_addon": _search_in_addon(p.get("addon_id", ""), p.get("q", ""), p.get("ot", ""))
    elif a == "clear_history": _clear_history()
    elif a == "remove_history_item": _remove_history_item(p.get("q"))
    elif a == "snapshots_menu": snapshots_menu()
    elif a == "create_snapshot": _create_snapshot()
    elif a == "view_snapshot": _view_snapshot(p.get("file"), p.get("path"))
    elif a == "delete_snapshot_menu": _delete_snapshot_menu()
    elif a == "delete_snapshot": _delete_snapshot(p.get("file"))
    elif a == "import_backup": _import_backup()
    elif a == "toggle_debug": _toggle_debug()
    elif a == "toggle_frozen": _toggle_frozen()
    elif a == "toggle_recent": _toggle_recent()
    elif a == "set_min_duration": _set_min_duration_filter()
    elif a == "toggle_prioritize_match": _toggle_prioritize_match()
    elif a == "show_favorites": _show_favorites()
    elif a == "add_favorite":
         try:
             params = json.loads(p.get("params", "{}"))
         except (ValueError, TypeError):
             # Si el JSON viene mal formado, extraemos solo la 'q' del título
             params = {'q': p.get("title", "")}
         added = core_settings.add_favorite(p.get("title"), p.get("fav_url"), p.get("icon"), p.get("platform"), p.get("fav_action"), params)
         if added:
             xbmcgui.Dialog().notification("EspaDaily", "Añadido a Favoritos", xbmcgui.NOTIFICATION_INFO)
         else:
             xbmcgui.Dialog().notification("EspaDaily", "Ya existe en Favoritos", xbmcgui.NOTIFICATION_WARNING)
    elif a == "remove_favorite":
         core_settings.remove_favorite(p.get("fav_url"))
         xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_rename":
         kb = xbmc.Keyboard(p.get("old_title"), 'Renombrar Favorito')
         kb.doModal()
         if kb.isConfirmed():
             new_t = kb.getText()
             if new_t:
                 core_settings.rename_favorite(p.get("fav_url"), new_t)
                 xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_move_up":
         if core_settings.move_favorite(p.get("fav_url"), "up"):
             xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_move_down":
         if core_settings.move_favorite(p.get("fav_url"), "down"):
             xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_news": _show_fav_news()
    elif a == "fav_backup_menu": _fav_backup_menu()
    elif a == "fav_export": _export_favorites()
    elif a == "fav_import": _import_favorites()
    elif a == "show_downloads": _show_downloads()
    elif a == "remove_download":
         core_settings.remove_download(p.get("dl_path"))
         xbmc.executebuiltin("Container.Refresh")
    elif a == "delete_download_file":
         _delete_download_file(p.get("dl_path"), p.get("title"))
    elif a == "check_repo_status": _check_repo_status()
    elif a == "clear_cache": _clear_cache()
    elif a == "cleanup_menu": _cleanup_menu()
    elif a == "limpieza_menu": _limpieza_menu()
    elif a == "cleanup_caches": _cleanup_caches()
    elif a == "vacuum_metadata_db": _vacuum_metadata_db_action()
    elif a == "refresh_main":
        if not _check_legal_compliance(): return
        _force_check_update()
    elif a == "toggle_full_context": _toggle_full_context()
    elif a == "toggle_snapshot_context": _toggle_snapshot_context()
    elif a == "snapshot_context_help": _snapshot_context_help()
    elif a == "download_video": _download_video(p.get("vid"), p.get("title"))
    elif a == "toggle_advanced_search": _toggle_advanced_search()
    elif a == "toggle_live_tv_grid": _toggle_live_tv_grid()
    elif a == "advanced_search_menu": _advanced_search_menu()
    elif a == "busqueda_otros_addons_menu": _busqueda_otros_addons_menu()


    elif a == "execute_adv_search": _execute_adv_search(p.get("mode", ""), p)
    elif a == "toggle_iptv_anti_errors": _toggle_iptv_anti_errors()
    elif a == "toggle_tdt_inputstream": _toggle_tdt_inputstream()
    elif a == "toggle_palantir_integration": _toggle_palantir_integration()
    elif a == "toggle_estuary_palantir_fix": _toggle_estuary_palantir_fix()
    elif a == "toggle_balandro_integration": _toggle_balandro_integration()
    elif a == "toggle_alfa_integration": _toggle_alfa_integration()
    elif a == "toggle_jacktook_integration": _toggle_jacktook_integration()
    elif a == "toggle_atresdaily_integration": _toggle_atresdaily_integration()
    elif a == "toggle_espatv_integration": _toggle_espatv_integration()
    elif a == "toggle_topzilla_integration": _toggle_topzilla_integration()
    elif a == "toggle_tmdbhelper_integration": _toggle_tmdbhelper_integration()
    elif a == "toggle_gujal_integration": _toggle_gujal_integration()
    elif a == "toggle_external_integrations": _toggle_external_integrations()
    elif a == "accessibility_menu": accessibility_menu()
    elif a == "acc_set_color": _acc_set_color_mode()
    elif a == "acc_toggle_bold": _acc_toggle_bold()
    elif a == "acc_toggle_symbols": _acc_toggle_symbols()
    elif a == "acc_toggle_icon_tint": _acc_toggle_icon_tint()
    elif a == "snapshot_info": _snapshot_info()
    elif a == "export_snapshot_menu": _export_snapshot_menu() # NUEVO
    elif a == "import_snapshot_menu": _import_snapshot_menu()
    
    # CATEGORY MANAGER RUTAS
    elif a == "cat_menu": category_manager.main_menu()
    elif a == "cat_create": category_manager.create_category()
    elif a == "cat_delete": category_manager.delete_category(p.get("name"))
    elif a == "cat_rename": category_manager.rename_category(p.get("name"))
    elif a == "cat_view": category_manager.view_category(p.get("name"))
    elif a == "cat_add_item_dialog": category_manager.add_item_dialog(p.get("q"))
    elif a == "cat_remove_item": category_manager.remove_item(p.get("cat"), p.get("q"))
    elif a == "cat_move_item": category_manager.move_item(p.get("from_cat"), p.get("q"))
    elif a == "cat_export": category_manager.export_categories()
    elif a == "cat_import": category_manager.import_categories()
    elif a == "cat_move_from_favs": 
         # Acción compuesta: Añadir a categoría -> Si éxito -> Borrar de favoritos
         if category_manager.add_item_dialog(p.get("q")):
             removed = core_settings.remove_favorite(p.get("fav_url"))
             if not removed:
                 # Debug: Avisar si falla el borrado
                 xbmcgui.Dialog().notification("EspaDaily", "Error: No se pudo quitar de favoritos", xbmcgui.NOTIFICATION_ERROR)
             else:
                 time.sleep(0.2) # Pequeña pausa para asegurar escritura
                 xbmc.executebuiltin("Container.Refresh")
    
    elif a == "palantir_search": _search_palantir(p.get("q"))
    elif a == "palantir_search_prompt": _search_palantir_prompt(p.get("q"))
    elif a == "elementum_search": _search_elementum(p.get("q"))
    elif a == "yt_results": _yt_native_search_results(p.get("query", ""))
    elif a == "yt_results_kb": _yt_results_keyboard()
    
    elif a == "exp_menu": exploration_history.show_menu()
    elif a == "exp_edit": exploration_history.edit_query(p.get("q"))
    elif a == "exp_to_search": exploration_history.add_to_search_history(p.get("q"))
    elif a == "exp_delete": exploration_history.delete_entry(p.get("q"))
    elif a == "exp_clear_all": exploration_history.clear_all()
    elif a == "exp_set_depth": exploration_history.set_depth()
    elif a == "exp_search_direct": exploration_history.search_direct(p.get("q"))
    elif a == "sanitized_info": _sanitized_info()
    elif a == "version_notes": _version_notes()
    elif a == "version_notes_v1": _version_notes_v1()
    elif a == "view_error_log": _view_error_log()
    elif a == "cache_top_movies_covers": _cache_top_movies_covers()
    elif a == "clear_top_movies_cache": _clear_top_movies_cache()
    elif a == "edit_and_search":

        q = p.get("q", "")
        ot = p.get("ot", "")
        kb = xbmc.Keyboard(q, 'Editar y Buscar')
        kb.doModal()
        if kb.isConfirmed():
             nq = kb.getText()
             if nq:


                 xbmc.executebuiltin(f"Container.Update({_u(action='lfr', q=nq, ot=ot)})")


    # TRAKT ACIONES
    elif a == "menu_collections":
        import trakt_manager
        trakt_manager.menu_collections()
    elif a == "trakt_root":
        import trakt_manager
        trakt_manager.menu_trakt_root()
    elif a == "trakt_options":
        import trakt_manager
        trakt_manager.menu_options()
    elif a == "trakt_help_guide":
        import trakt_manager
        trakt_manager.help_guide()
    elif a == "trakt_set_key":
        import trakt_manager
        trakt_manager.set_api_key()
    elif a == "trakt_import":
        import trakt_manager
        trakt_manager.import_list()
    elif a == "trakt_view_list":
        import trakt_manager
        trakt_manager.view_list(p.get("list_id"), p.get("show_covers") == "1")
    elif a == "trakt_delete_list":
        import trakt_manager
        trakt_manager.delete_list(p.get("list_id"))
    elif a == "trakt_covers_menu":
        import trakt_manager
        trakt_manager.covers_menu(p.get("list_id"), p.get("show_covers", "0"))
    elif a == "trakt_cache_covers":
        import trakt_manager
        trakt_manager.cache_covers(p.get("list_id"))
    elif a == "trakt_clear_cache":
        import trakt_manager
        trakt_manager.clear_cache(p.get("list_id"))
    elif a == "trakt_refresh_defaults":
        import trakt_manager
        trakt_manager.refresh_all_lists()
    elif a == "trakt_cache_all_meta":
        import trakt_manager
        trakt_manager.cache_all_meta()
    elif a == "trakt_clear_all_meta":
        import trakt_manager
        trakt_manager.clear_all_meta()
    elif a == "trakt_import_espatv":
        import trakt_manager
        trakt_manager.import_from_espatv()
    elif a == "filmaffinity_menu":
        import filmaffinity
        filmaffinity.menu()
    elif a == "filmaffinity_list":
        import filmaffinity
        filmaffinity.show_list(p.get("genre", ""))
    elif a == "filmaffinity_submenu":
        _fa = core_settings.addon_fanart()
        _icons_fa = {"En Cines España": ui_utils.media_icon('fa_cartelera.png'), "Top Valoradas": ui_utils.media_icon('fa_top.png')}
        for label, action, plot in [
            ("En Cines España", "filmaffinity_cartelera", "Películas en cines en España según FilmAffinity."),
            ("Top Valoradas",   "filmaffinity_top",       "Las películas mejor valoradas de la historia."),
        ]:
            li = xbmcgui.ListItem(label=label)
            li.setArt({'icon': _icons_fa.get(label, ui_utils.media_icon('cat_filmaffinity.png')), 'fanart': _fa})
            li.setInfo('video', {'plot': plot})
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action=action), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "filmaffinity_cartelera":
        import filmaffinity
        filmaffinity.show_cartelera()
    elif a == "filmaffinity_top":
        import filmaffinity
        filmaffinity.show_top()
    elif a == "sensacine_submenu":
        _fa = core_settings.addon_fanart()
        _icons_sc = {"En Cartelera": ui_utils.media_icon('sc_cartelera.png'), "Estrenos": ui_utils.media_icon('sc_estrenos.png')}
        for label, action, plot in [
            ("En Cartelera", "sensacine_menu",     "Películas en cines según SensaCine."),
            ("Estrenos",     "sensacine_estrenos",  "Últimos estrenos según SensaCine."),
        ]:
            li = xbmcgui.ListItem(label=label)
            li.setArt({'icon': _icons_sc.get(label, ui_utils.media_icon('cat_sensacine.png')), 'fanart': _fa})
            li.setInfo('video', {'plot': plot})
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action=action), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "sensacine_menu":
        import sensacine
        sensacine.show_cartelera()
    elif a == "sensacine_estrenos":
        import sensacine
        sensacine.show_estrenos()
    elif a == "cinemeta_top":
        import cinemeta
        cinemeta.show_top()
    elif a == "cinemeta_cache_meta":
        import cinemeta
        cinemeta.cache_meta()
    elif a == "cinemeta_clear_meta":
        import cinemeta
        cinemeta.clear_meta()
    elif a == "filmaffinity_cache_cartelera_meta":
        import filmaffinity
        filmaffinity.cache_cartelera_meta()
    elif a == "filmaffinity_clear_cartelera_meta":
        import filmaffinity
        filmaffinity.clear_cartelera_meta()
    elif a == "sensacine_cache_cartelera_meta":
        import sensacine
        sensacine.cache_cartelera_meta()
    elif a == "sensacine_clear_cartelera_meta":
        import sensacine
        sensacine.clear_cartelera_meta()
    elif a == "sensacine_cache_estrenos_meta":
        import sensacine
        sensacine.cache_estrenos_meta()
    elif a == "sensacine_clear_estrenos_meta":
        import sensacine
        sensacine.clear_estrenos_meta()


    elif a == "tmdb_lists_menu":
        import tmdb_lists
        tmdb_lists.show_menu()
    elif a == "tmdb_lists_show":
        import tmdb_lists
        tmdb_lists.show_list(p.get("endpoint", ""), p.get("media_type", "movie"), p.get("page", 1))

    elif a == "show_legal_txt": _show_legal_text()
    elif a == "revoke_legal": _revoke_legal()

    # URL PLAYER
    elif a == "open_url":
        import url_player; url_player.open_url_dialog()
    elif a == "url_input":
        import url_player; url_player.url_input()
    elif a == "url_history":
        import url_player; url_player.url_history_menu()
    elif a == "url_history_clear":
        import url_player; url_player.history_clear()
    elif a == "url_history_remove":
        import url_player; url_player.history_remove(p.get("url"))
    elif a == "url_bookmarks":
        import url_player; url_player.url_bookmarks_menu()
    elif a == "url_bookmark_save_from_history":
        import url_player; url_player.bookmark_save_from_history(p.get("url"))
    elif a == "url_bookmark_rename":
        import url_player; url_player.bookmark_rename(p.get("url"))
    elif a == "url_bookmark_delete":
        import url_player; url_player.bookmark_delete(p.get("url"))
    elif a == "url_play":
        import url_player; url_player.play_url_action(p.get("url"))
    elif a == "url_resolve":
        import url_player; url_player.resolve_for_kodi(p.get("url"))
    elif a == "play_ace":
        import acestream_player; acestream_player.play_from_url(p.get("url", ""), p.get("title", "AceStream"))
    elif a == "play_ace_result":
        _play_ace_result(p.get("infohash", ""), p.get("name", ""))
    elif a == "toggle_acestream_server_mode": _toggle_acestream_server_mode()
    elif a == "toggle_acestream_enabled": _toggle_acestream_enabled()
    elif a == "url_player_ensure_sn":
        import url_player; url_player.url_player_ensure_streamninja()

    # DM PLAYLISTS
    elif a == "dm_playlists_menu": _dm_playlists_menu()
    elif a == "dm_playlists_search": _dm_playlists_search()
    elif a == "dm_saved_channels": _dm_saved_channels_menu()
    elif a == "dm_save_channel": _dm_save_channel(p.get("user", ""), p.get("name", ""))
    elif a == "dm_delete_saved_channel": _dm_delete_saved_channel(p.get("user", ""))
    elif a == "dm_user_playlists": _dm_user_playlists(p.get("user"))
    elif a == "dm_view_playlist": _dm_view_playlist(p.get("pid"))
    elif a == "dm_espatv_canales": _dm_espatv_canales()

    # DM AJUSTES
    elif a == "set_dm_safe_level": _set_dm_safe_level()
    elif a == "dm_listas_menu": dm_listas_menu()
    elif a == "toggle_dm_ajuste": toggle_dm_ajuste(p.get("url", ""))
    elif a == "set_dl_mode": set_dl_mode()

    # BUSQUEDAS EXTERNAS
    elif a == "search_external_prompt": _search_external_prompt(p.get("q"))
    elif a == "dm_gujal_search": _search_dailymotion_gujal(p.get("q"))
    elif a == "search_atres_catalog": _search_atresplayer_catalog(p)
    elif a == "search_mediaset_catalog": _search_mediaset_catalog(p)
    elif a == "search_rtve_catalog": _search_rtve_catalog(p)
    elif a == "search_elementum_prompt": _search_elementum_prompt()
    elif a == "search_acestream_prompt": _search_acestream_prompt()
    elif a == "search_acestream_results": _search_acestream_results(p.get("q", ""))

    # EPG EN TEXTO
    elif a == "epg_texto_espadaily":
        import epg_texto; epg_texto.epg_texto_espadaily()
    elif a == "epg_texto_canal":
        import epg_texto; epg_texto.epg_texto_canal(p.get("ch_id", ""), p.get("ch_name", ""))
    elif a == "epg_texto_programa":
        import epg_texto; epg_texto.epg_texto_programa(p.get("title", ""), p.get("plot", ""))
    elif a == "epg_texto_refresh":
        import epg_texto; epg_texto.epg_texto_refresh()
    elif a == "noop": pass

    # TDT / TV EN DIRECTO
    elif a == "live_tv_entry":
        # Decision en tiempo de clic (no en el menu, que queda cacheado): asi el toggle
        # de Ajustes/Opciones aplica sin reiniciar el addon.
        # El Modo TV no pasa por live_tv_menu, que es donde se apaga el punto verde.
        ui_utils.visto(_NUEVO_EN_MENU["live_tv_entry"])
        if _live_tv_grid_on():
            if not _require_connector(): return
            import experimental_tv_espa; experimental_tv_espa.show()
        else:
            xbmc.executebuiltin("Container.Update({0}?action=live_tv_menu)".format(sys.argv[0]))
    elif a == "live_tv_menu": live_tv_menu()
    elif a == "live_mediaset_menu": live_mediaset_menu()
    elif a == "play_live_mediaset": play_live_mediaset(p.get("url", ""))
    elif a == "live_atres_menu": live_atres_menu()
    elif a == "play_live_atres": play_live_atres(p.get("ch_id", ""))
    elif a == "live_atres_now": live_atres_now()
    elif a == "play_media": play_atres_episode(p.get("url", ""))
    elif a == "live_rtve_menu": live_rtve_menu()
    elif a == "play_live_rtve": play_live_rtve(p.get("video_id", ""))
    elif a == "tdt_channels_json": tdt_channels_json()
    elif a == "tdt_json_ambit": tdt_json_ambit(p.get("url", ""))
    elif a == "tdt_channels": tdt_channels()
    elif a == "play_tdt": play_tdt(p.get("url", ""), p.get("title", ""))
    elif a == "add_custom_iptv":
        import iptv_lists; iptv_lists.add_list()
    elif a == "view_custom_iptv":
        import iptv_lists; iptv_lists.open_legacy(u)
    elif a == "delete_custom_iptv":
        import iptv_lists; iptv_lists.delete_legacy(u)
    elif a and a.startswith("iptv_"):
        import iptv_lists; iptv_lists.route(a, p)

    # WATCH HISTORY
    elif a == "watch_history": _view_watch_history()
    elif a == "del_watch_entry": _del_watch_entry(p.get("url", ""))
    elif a == "clear_watch_history": _clear_watch_history()

    # TRENDING / MULTI-SEARCH
    elif a == "trending": _show_trending()
    elif a == "multi_search": multi_search()

    # UTILIDADES
    elif a == "open_browser_url": open_browser_url(p.get("url", ""))
    elif a == "dm_open_browser": _dm_open_browser(p.get("url", ""))
    elif a == "log_menu": _log_menu()
    elif a == "view_kodi_log": _view_kodi_log()
    elif a == "view_kodi_log_full": _view_kodi_log_full()
    elif a == "view_kodi_log_errors": _view_kodi_log_errors()
    elif a == "search_kodi_log": _search_kodi_log()
    elif a == "log_info": _log_info()
    elif a == "export_log": _export_log()
    elif a == "view_log_visual": _view_log_visual()
    elif a == "show_log_line": _show_log_line(p.get("data", ""))
    elif a == "clear_error_log": _clear_error_log()
    elif a == "open_flowfav": _open_flowfav()
    elif a == "flowfav_install": _flowfav_install()
    elif a == "set_download_path": _set_download_path()
    elif a == "toggle_dev_mode": _toggle_dev_mode()

    # BACKUPS
    elif a == "backups_menu": _backups_menu()
    elif a == "create_backup_full": _create_backup_full()
    elif a == "list_backups": _list_backups()
    elif a == "restore_backup_selective": _restore_backup_selective(p.get("file", ""))
    elif a == "delete_single_backup": _delete_single_backup(p.get("file", ""))
    elif a == "slyguy_install": _slyguy_install(p.get("addon_id", ""), p.get("title", "Addon"))
    elif a == "export_favs_txt": _export_favorites_txt()
    elif a == "open_atresdaily": _open_atresdaily()
    elif a == "atresdaily_install": _atresdaily_install()
    elif a == "open_espatv": _open_espatv()
    elif a == "open_loiolog": _open_loiolog()
    elif a == "loiolog_install": _loiolog_install()

    # ESPAKODI ADDONS MENU








    # UNIVERSO
    elif a == "show_universo":
        import universo; universo.show()

    # Esta sección se ha hecho mirando el addon Chop0 TV, la idea no es hacer lo mismo, muchas gracias Chop0.
    elif a == "rtve_ext_router" or a == "chopo_router":
        if not _require_connector(): return
        ra = p.get("rtve_action") or p.get("chopo_action") or "main_list"
        fn = connector._RTVE_EXT_ACTIONS.get(ra)
        if fn:
            fn(p)
        else:
            xbmcgui.Dialog().notification("EspaDaily", "Acción RTVE no encontrada: " + ra, xbmcgui.NOTIFICATION_WARNING)

    # Esta sección se ha hecho mirando el addon Chop0 TV, la idea no es hacer lo mismo, muchas gracias Chop0.
    elif a == "mediaset_ext_router":
        if not _require_connector(): return
        ma = p.get("ms_action", "main_list")
        fn = connector._MEDIASET_EXT_ACTIONS.get(ma)
        if fn:
            fn(p)
        else:
            xbmcgui.Dialog().notification("EspaDaily", "Acción Mediaset no encontrada: " + ma, xbmcgui.NOTIFICATION_WARNING)

    # SEARCH SHORTCUTS MANAGER
    elif a == "ssm_menu":
        import search_shortcuts_manager; search_shortcuts_manager.main_menu()
    elif a == "ssm_reorder":
        import search_shortcuts_manager; search_shortcuts_manager.reorder_menu()
    elif a == "ssm_actions":
        import search_shortcuts_manager; search_shortcuts_manager.shortcut_actions(int(p.get("idx", 0)))
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "ssm_add_addon":
        import search_shortcuts_manager; search_shortcuts_manager.add_from_installed_addon()
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "ssm_add_command":
        import search_shortcuts_manager; search_shortcuts_manager.add_command()
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "ssm_add_fav":
        import search_shortcuts_manager; search_shortcuts_manager.add_from_kodi_favorites()
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "ssm_delete":
        import search_shortcuts_manager; search_shortcuts_manager.delete_shortcut(int(p.get("idx", 0)))
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "ssm_rename":
        import search_shortcuts_manager; search_shortcuts_manager.rename_shortcut(int(p.get("idx", 0)))
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "ssm_move_up":
        import search_shortcuts_manager; search_shortcuts_manager.move_shortcut(int(p.get("idx", 0)), "up")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "ssm_move_down":
        import search_shortcuts_manager; search_shortcuts_manager.move_shortcut(int(p.get("idx", 0)), "down")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    # AUTOSTART Y AUTOF AV
    elif a == "autoejecutar_menu": _autoejecutar_menu()
    elif a == "autostart_menu": _autostart_menu()
    elif a == "autostart_config_slot": _autostart_config_slot(int(p.get("slot", 0)))
    elif a == "autofav_menu": _autofav_menu()
    elif a == "autofav_config_slot": _autofav_config_slot(int(p.get("slot", 0)))

# CRT VINTAGE
    elif a == "crt_config_menu": crt_config_menu()
    elif a == "crt_toggle": crt_toggle(p.get("key", ""))

    # ALMACENAMIENTO Y MANTENIMIENTO
    elif a == "storage_menu":
        import storage_manager; storage_manager.storage_menu()
    elif a == "kodi_maintenance_menu":
        import kodi_maintenance; kodi_maintenance.maintenance_menu()
    elif a == "view_kodi_log_simple":
        try:
            log_path = xbmcvfs.translatePath('special://logpath/kodi.log')
            if os.path.exists(log_path):
                from collections import deque
                with open(log_path, 'r', encoding='utf-8', errors='ignore') as f:
                    last_50 = ''.join(deque(f, maxlen=50))
                xbmcgui.Dialog().textviewer("Log de Kodi (ultimas 50 líneas)", last_50)
            else:
                xbmcgui.Dialog().ok("Log", "No se encontro el archivo de log.")
        except Exception as e:
            xbmcgui.Dialog().ok("Error", str(e))

    # DEBRID
    elif a == "debrid_menu": _debrid_menu()
    elif a == "debrid_toggle_enabled": _debrid_toggle_enabled()
    elif a == "debrid_set_provider": _debrid_set_provider()
    elif a == "debrid_authorize_pin": _debrid_authorize_pin()
    elif a == "debrid_authorize_key": _debrid_authorize_key()
    elif a == "debrid_deauthorize": _debrid_deauthorize()
    elif a == "debrid_account": _debrid_account()
    elif a == "debrid_toggle_cached": _debrid_toggle_cached()
    elif a == "debrid_toggle_cleanup": _debrid_toggle_cleanup()
    elif a == "debrid_toggle_quality": _debrid_toggle_quality()
    elif a == "debrid_library":
        import url_player; url_player.debrid_library_menu()
    elif a == "debrid_library_files":
        import url_player; url_player.debrid_library_files(p.get("id"))
    elif a == "debrid_library_play":
        import url_player; url_player.debrid_library_play(p.get("id"), p.get("file"))
    elif a == "debrid_library_delete":
        import url_player; url_player.debrid_library_delete(p.get("id"))
    elif a == "debrid_download":
        import url_player; url_player.debrid_download(p.get("id"), p.get("title", ""))

    # BUSQUEDA TOTAL (Megabuscador)
    elif a == "bt_search":
        import busqueda_total; busqueda_total.prompt_and_run(int(sys.argv[1]))
    elif a == "bt_run":
        import busqueda_total; busqueda_total.run(int(sys.argv[1]), p.get("q", ""))
    elif a == "bt_toggle":
        import busqueda_total; busqueda_total.toggle(int(sys.argv[1]), p.get("key", ""))
    elif a == "bt_sources_menu":
        import busqueda_total; busqueda_total.show_sources_menu(int(sys.argv[1]))
    elif a == "bt_cine_menu":
        import busqueda_total; busqueda_total.show_cine_menu(int(sys.argv[1]))
    elif a == "bt_rank_menu":
        import busqueda_total; busqueda_total.show_rank_menu(int(sys.argv[1]))
    elif a == "bt_set_mindur":
        import busqueda_total; busqueda_total.set_min_duration(int(sys.argv[1]))
    elif a == "bt_proxy_find":
        import busqueda_total; busqueda_total.proxy_find(int(sys.argv[1]))
    elif a == "bt_proxy_clear":
        import busqueda_total; busqueda_total.proxy_clear(int(sys.argv[1]))
    elif a == "play_dm": _pv(u or p.get("vid"), p.get("title", ""))
    # BUSCADORES INDIVIDUALES
    elif a == "yt_html_search":
        import youtube_search; youtube_search.render_results(int(sys.argv[1]), p.get("q", ""))
    elif a == "odysee_search":
        import odysee_search; odysee_search.render_results(int(sys.argv[1]), p.get("q", ""))
    elif a == "odysee_play":
        import odysee_search; odysee_search.play_item(int(sys.argv[1]), p.get("name", ""), p.get("claim_id", ""))
    elif a == "search_odysee_prompt":
        _search_odysee_from_results()
    elif a == "peertube_search":
        import peertube_search; peertube_search.render_results(int(sys.argv[1]), p.get("q", ""))
    elif a == "peertube_play":
        import peertube_search; peertube_search.play_item(int(sys.argv[1]), p.get("uuid", ""))
    elif a == "search_peertube_prompt":
        _search_peertube_from_results()
    elif a == "bitchute_search":
        import bitchute_search; bitchute_search.render_results(int(sys.argv[1]), p.get("q", ""))
    elif a == "bitchute_play":
        import bitchute_search; bitchute_search.play_item(int(sys.argv[1]), p.get("video_id", ""))
    elif a == "search_bitchute_prompt":
        _search_bitchute_from_results()
    elif a == "search_youtube_prompt":
        _search_youtube_from_results()
    # MEGABUSCADOR MENU
    elif a == "busqueda_total":
        import busqueda_total; busqueda_total.show_menu(int(sys.argv[1]))
    elif a == "experimental_menu":
        _experimental_menu()
    elif a == "modo_cine":
        import experimental_home_espa; experimental_home_espa.show()
    elif a == "modo_tv":
        if not _require_connector(): return
        import experimental_tv_espa; experimental_tv_espa.show()
    elif a == "webapp_espa_open":
        _webapp_espa_open()
    elif a == "webapp_espa_autostart":
        if connector is not None:
            _webapp_espa_open(silent=True)
        else:
            xbmc.log("[EspaDaily] Autostart de la webapp omitido: connector no cargado.", xbmc.LOGINFO)
    elif a == "webapp_espa_stop":
        # El servidor puede vivir en otra invocación (el autoarranque, o la que abrió la
        # WebApp). Antes esto no paraba nada y aun así avisaba de que estaba detenido.
        from webapp import bootstrap as _wb
        if _wb.get_url() is None:
            xbmcgui.Dialog().notification("EspaDaily WebApp", "La WebApp no estaba en marcha", xbmcgui.NOTIFICATION_INFO, 2000)
        elif _wb.stop():
            xbmcgui.Dialog().notification("EspaDaily WebApp", "Servidor detenido", xbmcgui.NOTIFICATION_INFO, 2000)
        else:
            xbmcgui.Dialog().notification("EspaDaily WebApp", "El servidor no respondió a la parada", xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmc.executebuiltin("Container.Refresh")
    elif a == "webapp_espa_toggle_lan":
        cfg = ui_utils.load_json('settings.json')
        if not isinstance(cfg, dict):
            cfg = {}
        cfg['webapp_lan_mode'] = not cfg.get('webapp_lan_mode', False)
        ui_utils.save_json('settings.json', cfg)
        from webapp import bootstrap as _wb
        if cfg['webapp_lan_mode']:
            # Se arranca ya para poder dar la dirección a los demás dispositivos.
            url = _wb.ensure_running()
            if url:
                # Cuatro líneas como mucho, porque el cuadro centra el texto y corta lo que sobra por arriba.
                xbmcgui.Dialog().ok("EspaDaily WebApp",
                                    f"Red local activada. En el móvil o en otro equipo de tu red, abre:\n\n[B]{url}[/B]")
            else:
                xbmcgui.Dialog().ok("EspaDaily WebApp",
                                    "La red local queda activada, pero el servidor no arrancó. Revisa el registro de Kodi.")
        else:
            # Solo se reinicia si estaba en marcha.
            url = _wb.restart_if_running()
            xbmcgui.Dialog().notification("EspaDaily WebApp", url or "Se aplicará al abrir la WebApp",
                                          xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin("Container.Refresh")
    elif a == "toggle_webapp_autostart":
        _toggle_webapp_autostart()

    # ESPAKODI INSTALLER
    elif a == "espakodi_addons_menu":
        espakodi_addons_menu()
    elif a == "espakodi_app_menu":
        espakodi_app_menu()
    elif a == "ek_apk":
        import espakodi_app
        espakodi_app.descargar(p.get("nombre", ""))
    elif a == "ek_apk_bits":
        import espakodi_app
        espakodi_app.info_bits()
    elif a == "ek_apk_web":
        import espakodi_app
        espakodi_app.abrir_web()
    elif a == "ek_telegram":
        import espakodi_app
        espakodi_app.abrir_telegram()
    elif a == "ek_apk_borrar":
        import espakodi_app
        if espakodi_app.borrar_descargas() == "refrescar":
            xbmc.executebuiltin("Container.Refresh")
    elif a == "ek_espatv_launch":
        import espakodi_installer; espakodi_installer.launch_by_id("plugin.video.espatv")
    elif a == "ek_espadaily_launch":
        import espakodi_installer; espakodi_installer.launch_by_id("plugin.video.espadaily")
    elif a == "ek_atresdaily_launch":
        import espakodi_installer; espakodi_installer.launch_by_id("plugin.video.atresdaily")
    elif a == "ek_loiolog_launch":
        import espakodi_installer; espakodi_installer.launch_by_id("plugin.program.loiolog")
    elif a == "ek_flowfav_launch":
        import espakodi_installer; espakodi_installer.launch_by_id("plugin.program.flowfavmanager")
    elif a == "ek_streamninja_launch":
        import espakodi_installer; espakodi_installer.launch_by_id("plugin.video.streamninja")
    elif a == "topzilla_launch":
        import espakodi_installer; espakodi_installer.launch_by_id("plugin.video.topzilla")
    elif a == "loiolink_launch":
        import espakodi_installer; espakodi_installer.launch_by_id("plugin.program.loiolink")
    elif a == "ek_launch":
        import espakodi_installer; espakodi_installer.launch_by_id(p.get("addon_id", ""))
    elif a == "ek_open_repo":
        import espakodi_installer; espakodi_installer.open_repo_unificado()
    elif a == "ek_open_web":
        import espakodi_installer; espakodi_installer.open_web()

    # URL REMOTE
    elif a == "url_remote":
        import url_remote; url_remote.start_remote()
    elif a == "url_scan":
        import url_player; url_player.scan_videos_dialog()
    elif a == "url_player_config":
        _url_player_config_menu()
    elif a == "config_remote_port":
        _addon = xbmcaddon.Addon()
        _old = _addon.getSetting('remote_port') or '8089'
        _new = xbmcgui.Dialog().input("Puerto del servidor remoto", defaultt=_old, type=xbmcgui.INPUT_NUMERIC)
        if _new:
            try:
                _port_num = int(_new)
            except ValueError:
                _port_num = -1
            if 1024 <= _port_num <= 65535:
                _addon.setSetting('remote_port', str(_port_num))
                xbmcgui.Dialog().notification("EspaDaily", f"Puerto cambiado a {_port_num}", xbmcgui.NOTIFICATION_INFO, 2000)
                xbmc.executebuiltin("Container.Refresh")
            else:
                xbmcgui.Dialog().ok("EspaDaily", "Puerto no valido. Debe estar entre 1024 y 65535.")
    elif a == "toggle_remote_secure":
        cur = xbmcaddon.Addon().getSetting('remote_secure') == 'true'
        xbmcaddon.Addon().setSetting('remote_secure', 'false' if cur else 'true')
        xbmcgui.Dialog().notification("EspaDaily", f"Seguridad: {'ACTIVADA' if not cur else 'DESACTIVADA'}", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")
    elif a == "set_webremote_mode":
        labels = ["Red local", "Internet"]
        addon = xbmcaddon.Addon()
        cur_raw = (addon.getSetting('webremote_mode') or 'Red local').strip()
        cur = 1 if cur_raw in ('1', 'Internet') else 0
        sel = xbmcgui.Dialog().select("Modo de conexión", ["Red local (solo WiFi)", "Internet (relay ntfy)"], preselect=cur)
        if sel >= 0:
            addon.setSetting('webremote_mode', labels[sel])
            xbmcgui.Dialog().notification("EspaDaily", f"Modo: {labels[sel]}", xbmcgui.NOTIFICATION_INFO, 2000)
            xbmc.executebuiltin("Container.Refresh")
    elif a == "toggle_webremote_confirm":
        cur = xbmcaddon.Addon().getSetting('webremote_confirm') == 'true'
        xbmcaddon.Addon().setSetting('webremote_confirm', 'false' if cur else 'true')
        msg = "Confirmacion ACTIVADA" if not cur else "Confirmacion DESACTIVADA"
        xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")
    elif a == "set_webremote_server":
        addon = xbmcaddon.Addon()
        cur = (addon.getSetting('webremote_server') or 'https://ntfy.sh').strip()
        nuevo = xbmcgui.Dialog().input("Servidor relay ntfy (URL completa)", defaultt=cur)
        if nuevo:
            nuevo = nuevo.strip().rstrip('/')
            if nuevo.startswith(("http://", "https://")):
                addon.setSetting('webremote_server', nuevo)
                xbmcgui.Dialog().notification("EspaDaily", "Servidor actualizado", xbmcgui.NOTIFICATION_INFO, 2000)
                xbmc.executebuiltin("Container.Refresh")
            else:
                xbmcgui.Dialog().ok("EspaDaily", "URL no valida. Debe empezar por http:// o https://")
    elif a == "reset_webremote_topic":
        addon = xbmcaddon.Addon()
        cur = addon.getSetting('webremote_topic') or '(no asignado)'
        if xbmcgui.Dialog().yesno("Regenerar canal ntfy", f"Canal actual: {cur}\n\nSe generará uno nuevo al próximo arranque del mando.\nTendras que actualizar la suscripción en tu móvil.\n\nContinuar?"):
            addon.setSetting('webremote_topic', '')
            xbmcgui.Dialog().notification("EspaDaily", "Canal regenerado al próximo uso", xbmcgui.NOTIFICATION_INFO, 2500)
            xbmc.executebuiltin("Container.Refresh")

    elif a == "search_alfa_from_results": _search_alfa_from_results(p.get("q"))
    elif a == "search_balandro_from_results": _search_balandro_from_results(p.get("q"))
    elif a == "search_jacktook_from_results": _search_jacktook_from_results(p.get("q"))
    # Acción antigua que ya no enlaza nada; la conservan favoritos y atajos guardados.
    elif a == "input_search": _manual_search()
    elif a == "multi_run": multi_run(p.get("q", ""))
    elif a == "show_info": show_info()
    elif a == "show_web_info": show_web_info()
    elif a == "show_last_message": show_last_message()
    elif a == "inicio_elegir":
        ui_utils.visto('inicio')
        import inicio
        inicio.elegir()
    elif a == "novedades":
        import novedades
        novedades.mostrar()
    elif a == "fantasia":
        ui_utils.visto('fantasia')
        import fantasia
        fantasia.mostrar()
    elif a == "fantasia_orden":
        import fantasia
        fantasia.reenviar(p.get("orden", ""))
    elif a == "separador":
        from minijuegos import sorpresa
        sorpresa.ofrecer()
    elif a == "minijuegos_borrar_record":
        from minijuegos import lista
        lista.borrar_record()
    elif a == "minijuegos_menu":
        from minijuegos import ajustes
        ajustes.menu()
    elif a == "minijuegos_ajuste":
        from minijuegos import ajustes
        ajustes.cambiar(p.get("url", ""))
    elif a == "export_favs": export_favs()
    elif a == "import_favs": import_favs()
    elif a == "export_favs_menu": export_favs_menu()
    elif a == "backup_favs_dialog": backup_favs_dialog()
    elif a == "acestream_tools_menu":       _acestream_tools_menu()
    elif a == "acestream_search_name":      _acestream_search_by_name()
    elif a == "acestream_enter_url":        _acestream_enter_url()
    elif a == "acestream_enter_id":         _acestream_enter_id()
    elif a == "acestream_scan_url":         _acestream_scan_url()
    elif a == "acestream_show_history":     _acestream_show_history()
    elif a == "acestream_history_search":   _acestream_history_search(p.get("q"))
    elif a == "acestream_history_scan":     _acestream_history_scan(u)
    elif a == "acestream_history_delete":   _acestream_history_delete(p.get("ts"))
    elif a == "acestream_history_clear":    _acestream_history_clear()
    elif a == "acestream_proxy_toggle":     _acestream_proxy_toggle()
    elif a == "acestream_proxy_find":       _acestream_proxy_find()
    elif a == "acestream_proxy_manual":     _acestream_proxy_manual()
    elif a == "acestream_proxy_clear":      _acestream_proxy_clear()
    elif a == "input_mode_menu": input_mode_menu()
    elif a == "search_order_menu": search_order_menu()
    elif a == "set_precision": set_precision()
    elif a == "clear_full_cache": clear_full_cache()
    elif a == "clear_ui_cache": clear_ui_cache()
    elif a == "export_cache": export_cache()
    elif a == "toggle_catalog_long_first": _toggle_catalog_long_first()
    elif a == 'fanart_menu':           _fanart_menu()
    elif a == 'fanart_toggle':         _fanart_toggle()
    elif a == 'fanart_cycle_mode':     _fanart_cycle_mode()
    elif a == 'fanart_browse_custom':  _fanart_browse_custom()
    elif a == "toggle_ext_search_enabled": _toggle_ext_search_enabled()
    elif a == "toggle_ext_search_dialog": _toggle_ext_search_dialog()
    elif a == "view_history": view_history()
    elif a == "del_history": del_history()
    # Acepta también fav_action/thumbnail, los nombres que usaba la Búsqueda Múltiple; con
    # ellos el favorito se guardaba como búsqueda y sin icono.
    elif a == "add_fav": add_fav(title=p.get("title", "Favorito"), action=p.get("f_action") or p.get("fav_action") or "search", url=u, thumbnail=p.get("f_thumb") or p.get("thumbnail") or ICON_MAIN, extra=e)
    elif a == "del_fav": 
            if core_settings.remove_favorite(u): xbmc.executebuiltin("Container.Refresh")
    elif a == "view_favorites": view_favorites()
    elif a == "view_downloads": view_downloads()
    elif a == "play_local": play_local(u)
    elif a == "del_file": del_file(u)
    elif a == "del_dl_history": del_dl_history(u)
    else:
        # Verificaciones previas al menu principal
        if not _check_legal_compliance(): return
        # Honeypot: detectar manipulacion del connector
        if getattr(connector, '_DEBUG_MODE_BACKDOOR', False):
            xbmcgui.Dialog().ok("SEGURIDAD", "Se ha detectado una modificaci\u00f3n no autorizada en el m\u00f3dulo de conexi\u00f3n.")
            return
        import stats
        stats.ping()
        _check_messages()
        main_menu()
        try:
            import welcome_splash
            welcome_splash.show_if_needed()
        except Exception as e:
            xbmc.log(f"[EspaDaily] welcome_splash error: {e}", xbmc.LOGWARNING)

if __name__ == "__main__":
    try:
        router(sys.argv[2][1:])
    except Exception as e:
        import traceback
        _log_error(f"Unhandled exception: {str(e)}\n{traceback.format_exc()}")
        xbmcgui.Dialog().ok("EspaDaily - Error", "Ocurrió un error inesperado al procesar la ruta.\n\nConsulta el log de errores en Opciones.")
