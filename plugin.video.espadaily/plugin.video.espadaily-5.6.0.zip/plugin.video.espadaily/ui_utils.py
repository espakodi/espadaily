# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
# Helpers de interfaz, serializacion y entrada de texto.
import os
import sys
import json
import threading
import urllib.parse
from concurrent.futures import ThreadPoolExecutor

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import core_settings

ADDON = xbmcaddon.Addon()
ICON_MAIN = os.path.join(ADDON.getAddonInfo('path'), 'icon.jpg')
_MEDIA_DIR = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'media')

PUNTO_NUEVO = "[COLOR lime]●[/COLOR] "
# Lo nuevo que ya se ha abierto: un archivo vacío por clave. No va en los ajustes porque
# cada xbmcaddon.Addon() tiene su propia copia y setSetting reescribe el settings.xml
# entero, así que una instancia creada antes borraría la marca (y cargar esa copia cuesta
# leer dos XML por cada punto).
_VISTOS = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')), 'vistos')


def punto(clave):
    """El punto verde de lo nuevo mientras no se haya abierto (ver visto). Para volver a
    encender el de un menú porque tiene algo nuevo dentro, se le cambia la clave."""
    return "" if os.path.exists(os.path.join(_VISTOS, clave)) else PUNTO_NUEVO


def visto(clave):
    """Apaga el punto verde. Devuelve True si lo ha apagado ahora; con dos llamadas a la
    vez, solo una, porque el archivo se crea en exclusiva."""
    if not clave:
        return False
    try:
        os.makedirs(_VISTOS, exist_ok=True)
        with open(os.path.join(_VISTOS, clave), 'x'):
            pass
    except FileExistsError:
        return False
    except OSError as e:
        xbmc.log(f"[EspaDaily] No se puede guardar como visto '{clave}': {e}", xbmc.LOGWARNING)
        return False
    return True


def del_conector(nombre):
    """La función `nombre` del conector, o None tras avisar si el cargado no la tiene todavía.

    default.py baja el conector nuevo en cuanto ve que el de la caché es viejo; esto solo pasa
    si no se ha podido (sin conexión, o con el publicado aún sin actualizar)."""
    funcion = getattr(sys.modules.get('connector'), nombre, None)
    if funcion is None:
        xbmc.log(f"[EspaDaily] El conector cargado no tiene {nombre}", xbmc.LOGWARNING)
        xbmcgui.Dialog().notification(
            "EspaDaily", "Falta actualizar el módulo de conexión. Revisa la conexión y vuelve a probar.",
            xbmcgui.NOTIFICATION_WARNING, 5000)
    return funcion


HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
}

_DM_OCULTAR = ('dm_filtrar_retirados', 'dm_ocultar_privados', 'dm_ocultar_directos_apagados')


def ajuste_dm(clave):
    """Interruptor de las listas de Dailymotion. Son ajustes nativos, así que la
    pestaña Dailymotion de los ajustes del addon y el submenú de Ajustes
    avanzados cambian lo mismo. Todos valen True por defecto."""
    return xbmcaddon.Addon().getSetting(clave) != 'false'


def dm_firma_filtro():
    """Estado de los interruptores de las listas DM, para la clave de las cachés
    de búsquedas. Sin ella, un cambio de ajuste no se notaría hasta que caducan."""
    return "".join("1" if ajuste_dm(c) else "0" for c in _DM_OCULTAR + ('dm_rellenar_listas',))


def dm_limite_lista(n):
    """Cuántos resultados pedir a la API para poder enseñar n después del filtro.

    En algunas búsquedas 16 de cada 20 resultados están retirados. Con "Rellenar
    las listas" se piden hasta cinco veces más (la API da 100 como mucho) y
    filtrar_dm_borrados recorta a n, así que la lista sale llena sin consultas de más.
    """
    if any(ajuste_dm(c) for c in _DM_OCULTAR) and ajuste_dm('dm_rellenar_listas'):
        return max(n, min(100, n * 5))
    return n


# access_error de un vídeo que ya no existe: DM005 si Dailymotion lo retiró y DM002 si lo
# borró su autor. Los dos siguen saliendo en búsquedas y tendencias; los vivos nunca los llevan.
_DM_RETIRADOS = {"DM002", "DM005"}
# Tope de privados que se comprueban por lista. Un canal que restringe sus vídeos
# los tiene todos así, y sin tope su playlist tardaría decenas de segundos.
_DM_MAX_PRIVADOS = 20


def dm_api_videos(ruta, params, timeout=10):
    """JSON de la API de Dailymotion en `ruta` ("/videos", "/playlist/<id>/videos"...), por el
    conector y pidiendo también access_error, para que filtrar_dm_borrados sepa qué no se
    puede ver sin hacer otra consulta (unos 0,3 s menos por lista). {} si falla."""
    api = del_conector("dm_api")
    return (api(ruta, params, timeout=timeout, con_error=True) if api else None) or {}


def _dm_codigo(v):
    ae = v.get("access_error")
    return ae.get("code") if isinstance(ae, dict) else None


def _dm_privados(vids):
    """Los de `vids` (todos DM016) que son privados, comprobados a la vez por el conector."""
    privado = getattr(sys.modules.get('connector'), 'dm_privado', None)
    if not vids or privado is None:
        return set()
    with ThreadPoolExecutor(max_workers=min(8, len(vids))) as ex:
        return {vid for vid, es in zip(vids, ex.map(privado, vids)) if es}


def _dm_codigos_por_lote(ids):
    """{id: código de access_error} de los vídeos que siguen existiendo, o None si
    la API falla. Es el camino de las listas pedidas sin dm_api_videos."""
    api = getattr(sys.modules.get('connector'), 'dm_api', None)
    if api is None:
        return None
    codigos = {}
    for inicio in range(0, len(ids), 100):
        datos = api("/videos", {"ids": ",".join(ids[inicio:inicio + 100]), "fields": "id",
                                "limit": 100}, timeout=8, con_error=True)
        # {} es un error de la API y None, sin conexión: sin filtrar.
        if not datos:
            return None
        for v in datos.get("list", []):
            codigos[str(v.get("id"))] = _dm_codigo(v)
    return codigos


def filtrar_dm_borrados(videos, id_key="id", cuantos=None):
    """Quita de una lista de resultados de Dailymotion lo que no se puede ver.

    Según los ajustes: retirados, privados y directos que no están emitiendo. Con
    `cuantos` devuelve como mucho esos, para las listas pedidas de más con
    dm_limite_lista.

    El índice de búsqueda de DM sigue devolviendo vídeos borrados. Su campo
    access_error dice qué error daría cada uno: DM005 y DM002 retirado, DM003 directo sin
    emisión y DM016 posible privado. Si la lista se pidió con dm_api_videos ya lo
    trae y no hace falta consultar nada; si no, se piden los ids por lote, que
    omite los retirados. Los DM016 se comprueban a la vez, hasta _DM_MAX_PRIVADOS.

    Ante cualquier fallo devuelve la lista intacta: mostrar algún vídeo muerto es
    mucho menos grave que vaciar los resultados del usuario.
    """
    intacta = videos if cuantos is None else videos[:cuantos]
    retirados = ajuste_dm('dm_filtrar_retirados')
    privados = ajuste_dm('dm_ocultar_privados')
    apagados = ajuste_dm('dm_ocultar_directos_apagados')
    if not (retirados or privados or apagados) or not videos:
        return intacta

    if all(isinstance(v, dict) and "access_error" in v for v in videos):
        codigos = {str(v.get(id_key)): _dm_codigo(v) for v in videos}
    else:
        ids = [str(v.get(id_key)) for v in videos if v.get(id_key)]
        # Por lote, una respuesta vacía no distingue "todos retirados" de un fallo
        # de la API; ante la duda, sin filtrar.
        codigos = _dm_codigos_por_lote(ids) if len(ids) >= 2 else None
        if not codigos:
            return intacta

    dudosos = [str(v.get(id_key)) for v in videos
               if codigos.get(str(v.get(id_key))) == "DM016"] if privados else []
    son_privados = _dm_privados(dudosos[:_DM_MAX_PRIVADOS])

    visibles = []
    n_retirados = n_privados = n_apagados = 0
    for v in videos:
        if cuantos is not None and len(visibles) >= cuantos:
            break
        vid = str(v.get(id_key))
        codigo = codigos.get(vid, "DM005")  # por lote, el que falta es retirado
        if codigo in _DM_RETIRADOS:
            if retirados:
                n_retirados += 1
                continue
        elif codigo == "DM003" and apagados:
            n_apagados += 1
            continue
        elif vid in son_privados:
            n_privados += 1
            continue
        visibles.append(v)

    if n_retirados or n_privados or n_apagados:
        xbmc.log(f"[EspaDaily] filtro DM: ocultos {n_retirados} retirados, {n_privados} "
                 f"privados y {n_apagados} directos sin emisión", xbmc.LOGINFO)
    return visibles

def media_icon(filename):
    p = os.path.join(_MEDIA_DIR, filename)
    return p if os.path.exists(p) else ''

def get_params():
    p = {}
    if len(sys.argv) >= 3 and sys.argv[2]:
        p = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    return p

def add_item(action, title, url='', thumbnail='', extra='', folder=True, isPlayable=False, plot='', fanart='', context=None, nuevo='', **kwargs):
    li = xbmcgui.ListItem(punto(nuevo) + title if nuevo else title)
    art = {}
    if thumbnail:
        art['icon'] = thumbnail
        art['thumb'] = thumbnail
    if not fanart:
        fanart = core_settings.addon_fanart()
    if fanart:
        art['fanart'] = fanart
    li.setArt(art)
    info = {'title': title}
    if plot:
        info['plot'] = plot
    li.setInfo('video', info)
    if isPlayable:
        li.setProperty('IsPlayable', 'true')
        folder = False
    if context:
        li.addContextMenuItems(menu_contextual(context))
    u = f'{sys.argv[0]}?action={action}&title={urllib.parse.quote(title)}&url={urllib.parse.quote(url)}&extra={urllib.parse.quote(extra)}'
    for key, value in kwargs.items():
        u += f'&{key}={urllib.parse.quote(str(value))}'
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=li, isFolder=folder)

def close_item_list():
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def menu_contextual(entradas):
    """Las entradas de un menú contextual. Con el Modo Fantasía abierto pasan por su puente."""
    fantasia = sys.modules.get('fantasia')
    return list(entradas) if fantasia is None else fantasia.menu_contextual(entradas)

def play_resolved(url):
    li = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)

def get_path(filename):
    p = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    return os.path.join(p, filename)

def load_json(name, default=None):
    try:
        with open(get_path(name), 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        if default is not None:
            return default
        if 'settings' in name or 'config' in name or 'last_adv' in name:
            return {}
        return []

def save_json(name, data):
    path = get_path(name)
    tmp = f'{path}.{os.getpid()}.{threading.get_ident()}.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f)
        os.replace(tmp, path)
    except Exception as e:
        try:
            os.remove(tmp)
        except OSError:
            pass
        xbmc.log(f'[EspaDaily] Error guardando {name}: {e}', xbmc.LOGERROR)

_ask_choice = None

def get_text(title, default=''):
    global _ask_choice
    mode = load_json('settings.json').get('web_input_mode', 'keyboard')
    use_web = mode == 'web'
    if mode == 'ask':
        if _ask_choice is None:
            sel = xbmcgui.Dialog().select('Como quieres escribir?',
                ['Teclado de Kodi', 'Escribir desde el movil/PC'])
            if sel < 0:
                return ''
            _ask_choice = sel
        use_web = _ask_choice == 1
    if use_web:
        try:
            import web_input
            r = web_input.receive_text(title, default)
            if r is not None:
                return r
        except Exception as e:
            xbmc.log(f'[EspaDaily] web_input no disponible, uso teclado: {e}', xbmc.LOGWARNING)
    kb = xbmc.Keyboard(default, title)
    kb.doModal()
    return kb.getText() if kb.isConfirmed() else ''


def _activar(addon_id):
    """Enciende un addon instalado. True si queda encendido.

    Con JSON-RPC y no con el builtin EnableAddon, que pregunta sí/no cada vez. SetAddonEnabled
    contesta OK tanto si lo enciende como si no, así que se pide una vez y se mira el estado."""
    xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Addons.SetAddonEnabled",
                                    "params": {"addonid": addon_id, "enabled": True}}))
    monitor = xbmc.Monitor()
    for _ in range(30):
        if xbmc.getCondVisibility(f"System.AddonIsEnabled({addon_id})"):
            return True
        if monitor.waitForAbort(0.1):
            break
    return bool(xbmc.getCondVisibility(f"System.AddonIsEnabled({addon_id})"))


def addon_listo(addon_id, nombre, aviso_si_falta=None):
    """True si el addon está instalado y activado. Si está desactivado, ofrece activarlo; si no
    está instalado, enseña aviso_si_falta (si lo hay) y devuelve False.

    Desde Kodi 19 System.HasAddon es cierto también con el addon desactivado, y uno desactivado
    no abre ni reproduce nada. InstallAddon tampoco hace nada con él."""
    if xbmc.getCondVisibility(f"System.AddonIsEnabled({addon_id})"):
        return True
    if not xbmc.getCondVisibility(f"System.HasAddon({addon_id})"):
        if aviso_si_falta:
            xbmcgui.Dialog().ok("EspaDaily", aviso_si_falta)
        return False
    if not xbmcgui.Dialog().yesno("EspaDaily", f"{nombre} está instalado pero desactivado.\n\n¿Activarlo ahora?",
                                  nolabel="Cerrar", yeslabel="Activar"):
        return False
    if _activar(addon_id):
        xbmcgui.Dialog().notification("EspaDaily", f"{nombre} activado", xbmcgui.NOTIFICATION_INFO, 3000)
        return True
    xbmcgui.Dialog().ok("EspaDaily", f"Kodi no ha podido activar {nombre}. Actívalo en Addons > Mis addons.")
    return False
