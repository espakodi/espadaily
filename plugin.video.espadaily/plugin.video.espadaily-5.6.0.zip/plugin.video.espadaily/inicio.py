# -*- coding: utf-8 -*-
# EspaDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
"""Lo que se abre nada más entrar en EspaDaily (Opciones > Al abrir EspaDaily)."""
import os

import xbmc
import xbmcaddon
import xbmcgui

RAIZ = 'plugin://plugin.video.espadaily/'
_VIDEOS = 10025
# La entrada más reciente se queda con el turno, y una espera anterior que siga viva ya no
# abre nada.
_TURNO = 'espadaily.inicio'
_ESPERA_S = 10
_PASO_S = 0.05

# En el orden de los values de inicio_destino en settings.xml, que guarda la posición.
# (texto, acción, se abre como carpeta). Lo que no es carpeta se lanza como al pulsarlo.
DESTINOS = (
    ('Menú principal', '', True),
    ('TV en Directo', 'live_tv_entry', False),
    ('Modo Fantasía', 'fantasia', False),
    ('Explorar', 'catalog_menu', True),
    ('Buscar en internet', 'manual_search', True),
    ('Megabuscador', 'busqueda_total', True),
    ('Abrir URL', 'open_url', True),
    ('loiolink', 'loiolink_launch', False),
    ('Historial', 'history_menu', True),
    ('Mis Favoritos', 'show_favorites', True),
    ('Mis Descargas', 'show_downloads', True),
    ('TDT Channels España', 'tdt_channels_json', True),
    ('Universo EspaKodi', 'show_universo', False),
)


def _posicion(addon):
    try:
        n = int(addon.getSetting('inicio_destino') or 0)
    except ValueError:
        return 0
    return n if 0 <= n < len(DESTINOS) else 0


def destino(addon):
    """(url, carpeta) de lo que se abre al entrar, o None si es el menú principal."""
    _, accion, carpeta = DESTINOS[_posicion(addon)]
    if not accion:
        return None
    return f'{RAIZ}?action={accion}', carpeta


def texto(addon):
    """Lo elegido, como sale en Opciones / Configuración."""
    nombre, _, _ = DESTINOS[_posicion(addon)]
    return nombre


def _es_raiz(ruta):
    """La raíz del addon, con o sin la barra final y con la consulta vacía."""
    base, _, consulta = ruta.partition('?')
    return base.rstrip('/') == RAIZ.rstrip('/') and not consulta


def _elementos():
    try:
        return int(xbmc.getInfoLabel('Container.NumItems') or 0)
    except ValueError:
        return 0


def recien_abierto():
    """Si esta llamada a la raíz es la de entrar en EspaDaily, y no la de volver al menú
    principal desde dentro o la de refrescarlo, que dejan en Vídeos algo de EspaDaily."""
    if xbmcgui.getCurrentWindowId() != _VIDEOS or xbmcgui.Window(10000).getProperty('espadaily.fantasia'):
        return False
    ruta = xbmc.getInfoLabel('Container.FolderPath')
    if _es_raiz(ruta):
        # Desde Inicio o Favoritos, Kodi pone la raíz como carpeta de Vídeos antes de llamar
        # al addon, todavía vacía. Al refrescar el menú, ya tiene sus botones.
        return not _elementos()
    return not ruta.startswith(RAIZ)


def al_entrar(addon):
    """(url, carpeta, turno) de lo que se abre si esta llamada a la raíz es la de entrar, o
    None. Va antes de pintar el menú, porque después la ventana de Vídeos ya lo tiene y no se
    distingue de volver a él. El turno se toma aquí y no al esperar, porque una espera
    anterior que siga viva vería este mismo menú y abriría también."""
    elegido = destino(addon)
    if elegido is None or not recien_abierto():
        return None
    turno = os.urandom(8).hex()
    xbmcgui.Window(10000).setProperty(_TURNO, turno)
    return (*elegido, turno)


def abrir(url, carpeta, turno):
    """Lo abre en cuanto se ve el menú principal, para que Atrás vuelva a él. Un
    Container.Update mandado mientras Kodi aún lo está poniendo se pierde."""
    casa = xbmcgui.Window(10000)
    monitor = xbmc.Monitor()
    try:
        for _ in range(int(_ESPERA_S / _PASO_S)):
            if casa.getProperty(_TURNO) != turno:
                return
            if (xbmcgui.getCurrentWindowId() == _VIDEOS and _es_raiz(xbmc.getInfoLabel('Container.FolderPath'))
                    and _elementos()):
                xbmc.executebuiltin(f'Container.Update({url})' if carpeta else f'RunPlugin({url})')
                return
            if monitor.waitForAbort(_PASO_S):
                return
    finally:
        if casa.getProperty(_TURNO) == turno:
            casa.clearProperty(_TURNO)


def elegir():
    """Botón de Opciones con lo mismo que el ajuste, en una lista."""
    addon = xbmcaddon.Addon()
    n = xbmcgui.Dialog().select('Al abrir EspaDaily', [t for t, _, _ in DESTINOS], preselect=_posicion(addon))
    if n < 0:
        return
    addon.setSetting('inicio_destino', str(n))
    xbmc.executebuiltin('Container.Refresh')
