# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
#
# Búsqueda en BitChute vía su API REST pública (la web es una SPA; no hay HTML
# scrapeable). Dos llamadas:
#   1) /search/videos devuelve metadatos (sin URL de stream).
#   2) Al reproducir, /video/media entrega el MP4 directo.
# La API ignora la query cuando no hay coincidencias y devuelve el catálogo entero,
# así que se aplica un filtro de relevancia sobre los resultados. Las peticiones, la lectura
# y ese filtro los hace el conector (buscar_bitchute, bitchute_stream).
import hashlib
import json
import os
import sys
import time
import urllib.parse
import urllib.error

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

import ui_utils

_CACHE_DIR = xbmcvfs.translatePath(
    "special://userdata/addon_data/plugin.video.espadaily/search_cache/")
_CACHE_TTL = 3600  # segundos


def _cache_get(key):
    path = os.path.join(_CACHE_DIR, key + ".json")
    try:
        if time.time() - os.path.getmtime(path) > _CACHE_TTL:
            return None
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except OSError:
        return None


def _cache_set(key, data):
    # tmp único por proceso + os.replace atómico (igual que peertube_search).
    try:
        os.makedirs(_CACHE_DIR, exist_ok=True)
        tmp = os.path.join(_CACHE_DIR, f"{key}.{os.getpid()}.tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(tmp, os.path.join(_CACHE_DIR, key + ".json"))
    except OSError:
        pass


def _fmt_duration(secs):
    if not isinstance(secs, int) or secs <= 0:
        return ""
    h, rem = divmod(secs, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def search(query):
    query = (query or "").strip()
    if not query:
        return []
    key = "bitchute_" + hashlib.md5(query.lower().encode()).hexdigest()[:16]
    cached = _cache_get(key)
    if cached is not None:
        return cached
    buscar = ui_utils.del_conector("buscar_bitchute")
    if not buscar:
        return []
    results = buscar(query)
    _cache_set(key, results)
    return results


def play_item(handle, video_id):
    """Resuelve y reproduce un vídeo de BitChute. Llamado por default.py action=bitchute_play."""
    resolver = ui_utils.del_conector("bitchute_stream")
    if not resolver:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    dp = xbmcgui.DialogProgress()
    dp.create("EspaDaily", "Resolviendo stream de BitChute...")
    try:
        stream_url = resolver(video_id)
        dp.close()
    except (urllib.error.URLError, OSError, ValueError) as e:
        dp.close()
        xbmc.log(f"[EspaDaily] Error resolviendo BitChute: {e}", xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok("EspaDaily", f"Error al resolver el stream:\n{e}")
        return

    if not stream_url:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok("EspaDaily", "No se pudo obtener la URL de reproducción de BitChute.")
        return

    xbmc.log(f"[EspaDaily] BitChute stream: {stream_url}", xbmc.LOGINFO)
    li = xbmcgui.ListItem(path=stream_url)
    if stream_url.lower().split("?")[0].endswith(".m3u8"):   # defensivo: casi todo es MP4
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstreamaddon', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(handle, True, li)


def render_results(handle, query):
    query = (query or "").strip()
    if not query:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    dp = xbmcgui.DialogProgress()
    dp.create("EspaDaily", f"Buscando en BitChute: {query}...")
    try:
        results = search(query)
        dp.close()
    except (urllib.error.URLError, OSError, ValueError) as e:
        dp.close()
        xbmc.log(f"[EspaDaily] Error buscando en BitChute: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("EspaDaily", f"Error al buscar en BitChute:\n{e}")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if not results:
        xbmcgui.Dialog().ok("EspaDaily", f"No se encontraron resultados para:\n{query}")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    addon_url = sys.argv[0]
    xbmcplugin.setContent(handle, 'videos')
    for r in results:
        play_url = addon_url + '?' + urllib.parse.urlencode(
            {'action': 'bitchute_play', 'video_id': r['video_id']})
        thumb = r["thumb"] or "DefaultMusicVideos.png"

        li = xbmcgui.ListItem(label=r["title"])
        li.setArt({'icon': 'DefaultMusicVideos.png', 'thumb': thumb,
                   'poster': thumb, 'fanart': thumb})
        plot_lines = []
        if r.get("channel"):     plot_lines.append(f"Canal: {r['channel']}")
        dur = _fmt_duration(r.get("duration", 0))
        if dur:                  plot_lines.append(f"Duración: {dur}")
        if r.get("description"): plot_lines.append(r["description"][:300])
        li.setInfo('video', {'plot': "\n".join(plot_lines) or r["title"],
                             'title': r["title"], 'duration': r.get("duration", 0),
                             'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')

        xbmcplugin.addDirectoryItem(handle=handle, url=play_url,
                                    listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(handle)
