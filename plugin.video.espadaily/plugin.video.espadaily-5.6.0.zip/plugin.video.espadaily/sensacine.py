# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
import sys
import json
import os
import time
import urllib.parse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import core_settings
import ui_utils

_SC_TTL = 6 * 3600       # 6 horas


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)

def _handle():
    return int(sys.argv[1])


# Caché

def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'espadaily_sc_cache.json')


def _load_cache():
    empty = {"cartelera": {}}
    try:
        path = _cache_path()
        if not os.path.exists(path):
            return empty
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        if not isinstance(data.get("cartelera"), dict):
            return empty
        return data
    except Exception as e:
        xbmc.log(f"[EspaDaily-SC] cache load error: {e}", xbmc.LOGWARNING)
        return empty


def _save_cache(data):
    try:
        path = _cache_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, path)
    except Exception as e:
        xbmc.log(f"[EspaDaily-SC] cache save error: {e}", xbmc.LOGWARNING)


def _cache_fresh(cache):
    c = cache.get("cartelera", {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < _SC_TTL


# Scraping

def _scrape(tipo):
    """[{id, title, poster}] de "cartelera" o "estrenos", o None si falla. La lectura de la web
    la hace el conector (sensacine_lista), que se arregla en caliente si SensaCine cambia."""
    lista = getattr(sys.modules.get('connector'), 'sensacine_lista', None)
    return lista(tipo) if lista else None


def _scrape_cartelera():
    return _scrape("cartelera")


# Entrada pública

def _fetch_cartelera():
    cache = _load_cache()

    if _cache_fresh(cache):
        films = cache["cartelera"]["films"]
        xbmc.log(f"[EspaDaily-SC] cartelera desde caché ({len(films)} títulos)", xbmc.LOGINFO)
        return films

    scraped = _scrape_cartelera()
    if scraped is not None:
        films = scraped
        cache["cartelera"] = {"fetched_at": time.time(), "films": films}
    elif cache.get("cartelera", {}).get("films"):
        films = cache["cartelera"]["films"]
        xbmc.log("[EspaDaily-SC] SC inaccesible, usando caché caducada", xbmc.LOGWARNING)
    else:
        return []

    _save_cache(cache)
    return films


def show_cartelera():
    import metadata_enricher as me

    films = _fetch_cartelera()
    if not films:
        xbmcgui.Dialog().notification("EspaDaily", "No se pudo cargar SensaCine", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = core_settings.addon_fanart()
    first_title = films[0]['title'] if films else None
    has_meta = bool(me.enrich(title=first_title, media_type='movie', use_cache_only=True)) if first_title else False

    if not has_meta:
        li = xbmcgui.ListItem(label="[COLOR yellow][B]Descargar metadatos completos (actores, director...)[/B][/COLOR]")
        icon_path = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'descargas.png')
        li.setArt({'icon': icon_path})
        li.setInfo('video', {'plot': "Descarga sinopsis en español, actores y director de las películas en cartelera."})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="sensacine_cache_cartelera_meta"), listitem=li, isFolder=False)
    else:
        li = xbmcgui.ListItem(label="[COLOR red]Borrar metadatos de cartelera[/COLOR]")
        li.setArt({'icon': ui_utils.media_icon('backup_delete.png')})
        li.setInfo('video', {'plot': "Elimina los metadatos guardados de la cartelera actual."})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="sensacine_clear_cartelera_meta"), listitem=li, isFolder=False)

    for f in films:
        li = xbmcgui.ListItem(label=f['title'])
        meta = me.enrich(title=f['title'], media_type='movie', use_cache_only=True)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster']})
            li.setInfo('video', {'title': f['title'], 'mediatype': 'movie'})
            poster = f['poster']
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=f['title'], ot=poster, mode='movie')
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())

 
# Estrenos

def _estrenos_fresh(cache):
    c = cache.get("estrenos", {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < _SC_TTL


def _scrape_estrenos():
    return _scrape("estrenos")


def _fetch_estrenos():
    cache = _load_cache()

    if _estrenos_fresh(cache):
        films = cache["estrenos"]["films"]
        xbmc.log(f"[EspaDaily-SC] estrenos desde caché ({len(films)} títulos)", xbmc.LOGINFO)
        return films

    scraped = _scrape_estrenos()
    if scraped is not None:
        films = scraped
        cache["estrenos"] = {"fetched_at": time.time(), "films": films}
    elif cache.get("estrenos", {}).get("films"):
        films = cache["estrenos"]["films"]
        xbmc.log("[EspaDaily-SC] estrenos inaccesible, usando caché caducada", xbmc.LOGWARNING)
    else:
        return []

    _save_cache(cache)
    return films


def show_estrenos():
    import metadata_enricher as me

    films = _fetch_estrenos()
    if not films:
        xbmcgui.Dialog().notification("EspaDaily", "No se pudo cargar SensaCine Estrenos", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = core_settings.addon_fanart()
    first_title = films[0]['title'] if films else None
    has_meta = bool(me.enrich(title=first_title, media_type='movie', use_cache_only=True)) if first_title else False

    if not has_meta:
        li = xbmcgui.ListItem(label="[COLOR yellow][B]Descargar metadatos completos (actores, director...)[/B][/COLOR]")
        icon_path = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'descargas.png')
        li.setArt({'icon': icon_path})
        li.setInfo('video', {'plot': "Descarga sinopsis en español, actores y director de los próximos estrenos."})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="sensacine_cache_estrenos_meta"), listitem=li, isFolder=False)
    else:
        li = xbmcgui.ListItem(label="[COLOR red]Borrar metadatos de estrenos[/COLOR]")
        li.setArt({'icon': ui_utils.media_icon('backup_delete.png')})
        li.setInfo('video', {'plot': "Elimina los metadatos guardados de los próximos estrenos."})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="sensacine_clear_estrenos_meta"), listitem=li, isFolder=False)
    for f in films:
        li = xbmcgui.ListItem(label=f['title'])
        meta = me.enrich(title=f['title'], media_type='movie', use_cache_only=True)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster']})
            li.setInfo('video', {'title': f['title'], 'mediatype': 'movie'})
            poster = f['poster']
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=f['title'], ot=poster, mode='movie')
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())


def cache_cartelera_meta():
    import metadata_enricher as me

    films = _fetch_cartelera()
    if not films:
        xbmcgui.Dialog().notification("EspaDaily", "No hay películas en cartelera", xbmcgui.NOTIFICATION_ERROR)
        return

    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("EspaDaily", "Descargando metadatos cartelera...")
    try:
        count = me.batch_fetch_with_progress(items, pDialog)
    finally:
        pDialog.close()

    xbmcgui.Dialog().notification(
        "EspaDaily",
        "Metadatos guardados: {0}/{1}".format(count, len(items)),
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")


def clear_cartelera_meta():
    import metadata_enricher as me

    films = _fetch_cartelera()
    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    me.delete_items(items)
    xbmcgui.Dialog().notification("EspaDaily", "Metadatos de cartelera eliminados", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def cache_estrenos_meta():
    import metadata_enricher as me

    films = _fetch_estrenos()
    if not films:
        xbmcgui.Dialog().notification("EspaDaily", "No hay estrenos disponibles", xbmcgui.NOTIFICATION_ERROR)
        return

    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("EspaDaily", "Descargando metadatos estrenos...")
    try:
        count = me.batch_fetch_with_progress(items, pDialog)
    finally:
        pDialog.close()

    xbmcgui.Dialog().notification(
        "EspaDaily",
        "Metadatos guardados: {0}/{1}".format(count, len(items)),
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")


def clear_estrenos_meta():
    import metadata_enricher as me

    films = _fetch_estrenos()
    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    me.delete_items(items)
    xbmcgui.Dialog().notification("EspaDaily", "Metadatos de estrenos eliminados", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")
