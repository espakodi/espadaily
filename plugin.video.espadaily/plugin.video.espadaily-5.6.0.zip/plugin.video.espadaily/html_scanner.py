# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
"""Escáner HTML de vídeos embebidos y enlaces P2P.

El escáner vive en el conector (escanear_pagina, descargar_html), que se arregla en caliente
cuando una web cambia sus patrones. Aquí quedan la misma interfaz de siempre y el formato de
tamaños y duraciones. No importa nada de Kodi, porque iptv_parse lo usa fuera de él.
"""
import sys

_DOWNLOAD_TIMEOUT = 10


def _del_conector(nombre):
    # Sin conector (o con uno anterior a la 5.6.0) el escaneo sale vacío, como una web sin vídeos.
    return getattr(sys.modules.get('connector'), nombre, None)


def scan_page(url, timeout=None, html_content=None, with_sizes=True):
    """Analiza una URL o HTML en crudo y devuelve los vídeos detectados: una lista de dicts
    con ``title``, ``url``, ``filesize`` y ``ext``. Con with_sizes pide el tamaño de cada
    vídeo con un HEAD de hasta 4 s por enlace; las listas de canales lo apagan, porque un
    directo no tiene tamaño y una web con 50 enlaces tardaría minutos."""
    escanear = _del_conector("escanear_pagina")
    if not escanear:
        return []
    return escanear(url, timeout=timeout, html_content=html_content, with_sizes=with_sizes)


def download_html(url, timeout=_DOWNLOAD_TIMEOUT):
    """HTML de la página (hasta 512 KB), o '' si no es HTML o no se puede descargar."""
    descargar = _del_conector("descargar_html")
    return descargar(url, timeout) if descargar else ''


def format_size(byte_count):
    if byte_count is None or byte_count < 0:
        return ''
    if byte_count == 0:
        return '0 B'

    units = ('B', 'KB', 'MB', 'GB', 'TB')
    size = float(byte_count)
    for unit in units:
        if size < 1024.0:
            if unit == 'B':
                return f'{size:.0f} {unit}'
            return f'{size:.1f} {unit}'
        size /= 1024.0
    return f'{size:.1f} PB'


def format_duration(seconds):
    if seconds is None or seconds < 0:
        return ''
    seconds = int(seconds)
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    if h > 0:
        return f'{h:02d}:{m:02d}:{s:02d}'
    return f'{m:02d}:{s:02d}'
